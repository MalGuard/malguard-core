param(
  [Parameter(Mandatory=$true)][ValidatePattern('^[a-f0-9]{64}$')][string]$PayloadHash,
  [switch]$Quiet,
  [switch]$NoLaunch
)
$ErrorActionPreference='Stop'
Set-StrictMode -Version 2
$quietMode=$Quiet -or $env:MALGUARD_SETUP_QUIET -eq '1'
$noLaunchMode=$NoLaunch -or $env:MALGUARD_SETUP_QUIET -eq '1'
$powershell=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
if ([Environment]::Is64BitOperatingSystem -and -not [Environment]::Is64BitProcess) {$powershell=Join-Path $env:SystemRoot 'Sysnative\WindowsPowerShell\v1.0\powershell.exe'}
$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
$principal=New-Object Security.Principal.WindowsPrincipal($identity)
if (-not [Environment]::Is64BitProcess -or -not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  try {
    $arguments='-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "'+$PSCommandPath+'" -PayloadHash '+$PayloadHash
    if ($quietMode) {$arguments+=' -Quiet'}
    if ($noLaunchMode) {$arguments+=' -NoLaunch'}
    $elevated=Start-Process -FilePath $powershell -ArgumentList $arguments -Verb RunAs -WindowStyle Hidden -PassThru
    if (-not $elevated.WaitForExit(600000)) {throw 'Elevated setup exceeded its deadline'}
    exit $elevated.ExitCode
  } catch {
    if (-not $quietMode) {
      Add-Type -AssemblyName System.Windows.Forms
      [Windows.Forms.MessageBox]::Show('Administrator approval is required. '+$_.Exception.Message,'MalGuard setup') | Out-Null
    }
    exit 40
  }
}
$registry=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine,[Microsoft.Win32.RegistryView]::Registry64)
try {
  $key=$registry.OpenSubKey('SOFTWARE\Microsoft\Windows\CurrentVersion')
  try {$programFiles=[string]$key.GetValue('ProgramFilesDir')} finally {$key.Dispose()}
} finally {$registry.Dispose()}
$target=Join-Path $programFiles 'MalGuard'
$stage=Join-Path $programFiles ('MalGuard.install.'+[guid]::NewGuid().ToString('N'))
$backup=Join-Path $programFiles ('MalGuard.previous.'+[guid]::NewGuid().ToString('N'))
$taskName='MalGuard Signed Security Update'
$replaced=$false
$installed=$false
$taskChanged=$false
$previousTask=$null
$message=''
$setupWatch=[Diagnostics.Stopwatch]::StartNew()
$stageWatch=[Diagnostics.Stopwatch]::StartNew()
$stageTimings=New-Object 'Collections.Generic.List[object]'
$currentStage=''
$setupForm=$null
$setupLabel=$null

function Set-InstallStage([string]$Name, [string]$Title) {
  if ($script:currentStage) {$script:stageTimings.Add(@{stage=$script:currentStage;elapsedMs=$script:stageWatch.ElapsedMilliseconds})}
  $script:currentStage=$Name
  $script:stageWatch.Restart()
  if ($script:setupForm) {
    $script:setupLabel.Text=$Title
    [Windows.Forms.Application]::DoEvents()
  }
}

function Invoke-SetupEngine {
  param(
    [Parameter(Mandatory=$true)][string]$Engine,
    [Parameter(Mandatory=$true)][ValidateSet('--self-test','--refresh-security')][string]$Mode,
    [ValidateRange(100,60000)][int]$DeadlineMs=60000
  )
  $process=$null
  try {
    # Start-Process in Windows PowerShell can lose ExitCode for a fast child.
    # Retain the native process handle from creation through completion.
    $process=New-Object Diagnostics.Process
    $process.StartInfo.FileName=$Engine
    $process.StartInfo.Arguments=$Mode
    $process.StartInfo.UseShellExecute=$false
    $process.StartInfo.CreateNoWindow=$true
    $process.StartInfo.RedirectStandardOutput=$true
    $process.StartInfo.RedirectStandardError=$true
    if (-not $process.Start()) {throw 'Setup engine could not be started'}
    # Both pipes must be drained concurrently, including during a timeout.
    $stdout=$process.StandardOutput.ReadToEndAsync()
    $stderr=$process.StandardError.ReadToEndAsync()
    $clock=[Diagnostics.Stopwatch]::StartNew()
    $timedOut=$false
    while (-not $process.WaitForExit(200)) {
      if ($script:setupForm) {[Windows.Forms.Application]::DoEvents()}
      if ($clock.ElapsedMilliseconds -ge $DeadlineMs) {
        Stop-Process -Id $process.Id -Force
        $process.WaitForExit(5000) | Out-Null
        $timedOut=$true
        break
      }
    }
    if (-not $stdout.Wait(1000) -or -not $stderr.Wait(1000)) {throw 'Setup engine diagnostic pipes did not close'}
    $text=$stdout.Result
    if ([Text.Encoding]::UTF8.GetByteCount($text) -gt 65536 -or [Text.Encoding]::UTF8.GetByteCount($stderr.Result) -gt 8192) {throw 'Setup engine output exceeds its diagnostic limit'}
    return @{timedOut=$timedOut;exitCode=$(if ($timedOut) {-1} else {$process.ExitCode});stdout=$text}
  } finally {
    if ($process -and -not $process.HasExited) {Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue}
    if ($process) {$process.Dispose()}
  }
}

function Assert-OrdinaryTree([string]$Root) {
  $pending=New-Object 'Collections.Generic.Stack[IO.DirectoryInfo]'
  $rootItem=Get-Item -LiteralPath $Root -Force
  if ($rootItem -isnot [IO.DirectoryInfo] -or ($rootItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {throw 'Installation root is not an ordinary directory'}
  $pending.Push($rootItem)
  $count=0
  while ($pending.Count -gt 0) {
    $current=$pending.Pop()
    foreach ($entry in $current.GetFileSystemInfos()) {
      $count++
      if ($count -gt 10000 -or $entry.FullName.Substring($Root.Length).Split('\').Length -gt 32) {throw 'Installation inspection budget exceeded'}
      if (($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {throw 'Installation reparse points are forbidden'}
      if ($entry -is [IO.DirectoryInfo]) {$pending.Push($entry)}
    }
  }
}

try {
  if (-not [Environment]::Is64BitOperatingSystem) {throw 'This build requires Windows x64'}
  # An IExpress or PowerShell 7 parent can supply an incompatible module path.
  # Load only the native Windows PowerShell modules, never user profile modules.
  $env:PSModulePath=Join-Path $PSHOME 'Modules'
  foreach ($module in @('Microsoft.PowerShell.Management','Microsoft.PowerShell.Utility','Microsoft.PowerShell.Security','ScheduledTasks')) {
    Import-Module -Name (Join-Path $PSHOME ('Modules\'+$module+'\'+$module+'.psd1')) -ErrorAction Stop
  }
  if (-not $quietMode) {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    $setupForm=New-Object Windows.Forms.Form
    $setupForm.Text='MalGuard setup'
    $setupForm.ClientSize=New-Object Drawing.Size(460,150)
    $setupForm.StartPosition='CenterScreen'
    $setupForm.FormBorderStyle='FixedDialog'
    $setupForm.ControlBox=$false
    $setupForm.Font=New-Object Drawing.Font('Segoe UI',11)
    $setupLabel=New-Object Windows.Forms.Label
    $setupLabel.SetBounds(24,25,410,50)
    $setupForm.Controls.Add($setupLabel)
    $bar=New-Object Windows.Forms.ProgressBar
    $bar.SetBounds(24,93,410,18)
    $bar.Style='Marquee'
    $bar.MarqueeAnimationSpeed=30
    $setupForm.Controls.Add($bar)
    $setupForm.Show()
  }
  Set-InstallStage 'verify-package' 'Verifying the installer package'
  $payload=Join-Path $PSScriptRoot 'payload.zip'
  if ((Get-FileHash -LiteralPath $payload -Algorithm SHA256).Hash.ToLowerInvariant() -ne $PayloadHash) {throw 'Installer payload integrity mismatch'}
  if (Test-Path -LiteralPath $target) {Assert-OrdinaryTree $target}
  New-Item -ItemType Directory -Path $stage | Out-Null
  $stageAcl=New-Object Security.AccessControl.DirectorySecurity
  $stageAcl.SetSecurityDescriptorSddlForm('O:BAG:BAD:P(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)(A;OICI;GRGX;;;BU)')
  (Get-Item -LiteralPath $stage).SetAccessControl($stageAcl)
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  $archive=[IO.Compression.ZipFile]::OpenRead($payload)
  Set-InstallStage 'extract-files' 'Extracting verified application files'
  try {
    if ($archive.Entries.Count -gt 10000) {throw 'Installer entry limit exceeded'}
    $expanded=[long]0
    $names=New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach ($entry in $archive.Entries) {
      if ($setupForm) {[Windows.Forms.Application]::DoEvents()}
      $name=$entry.FullName
      if ($name -match '\\|:|(^|/)\.\.?(/|$)' -or $name.StartsWith('/') -or -not $names.Add($name) -or $name.Split('/').Length -gt 32) {throw 'Unsafe or duplicate installer path'}
      if ($entry.Length -gt 256MB -or $expanded -gt 512MB-$entry.Length) {throw 'Installer expansion limit exceeded'}
      $expanded+=$entry.Length
      $destination=Join-Path $stage ($name -replace '/','\')
      if ($name.EndsWith('/')) {New-Item -ItemType Directory -Path $destination -Force | Out-Null;continue}
      New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($destination)) -Force | Out-Null
      $input=$entry.Open()
      $output=[IO.File]::Open($destination,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
      try {$input.CopyTo($output)} finally {$output.Dispose();$input.Dispose()}
    }
  } finally {$archive.Dispose()}
  Set-InstallStage 'verify-components' 'Checking extracted files and components'
  $manifest=Get-Content -LiteralPath (Join-Path $stage 'install-manifest.json') -Raw | ConvertFrom-Json
  if ($manifest.schema -ne 1 -or $manifest.product -ne 'MalGuard clean-room desktop' -or $manifest.files.Count -gt 10000) {throw 'Installer manifest identity invalid'}
  $files=@(Get-ChildItem -LiteralPath $stage -File -Recurse -Force)
  if ($files.Count -ne $manifest.files.Count+1) {throw 'Installer checksum coverage mismatch'}
  foreach ($record in $manifest.files) {
    if ($setupForm) {[Windows.Forms.Application]::DoEvents()}
    if ($record.path -match '\\|:|(^|/)\.\.?(/|$)' -or $record.path.StartsWith('/') -or $record.sha256 -notmatch '^[a-f0-9]{64}$') {throw 'Installer manifest entry invalid'}
    if ((Get-FileHash -LiteralPath (Join-Path $stage $record.path) -Algorithm SHA256).Hash.ToLowerInvariant() -ne $record.sha256) {throw 'Installed file integrity mismatch'}
  }
  foreach ($required in @('malguard-desktop.exe','engine/MalGuard.exe','engine/protect-install.ps1','uninstall.ps1','webview2-bootstrapper.exe')) {
    if (-not (Test-Path -LiteralPath (Join-Path $stage $required) -PathType Leaf)) {throw ('Installer component missing: '+$required)}
  }
  Set-InstallStage 'webview-runtime' 'Checking the Microsoft WebView2 prerequisite'
  $runtimeFound=$false
  foreach ($runtimeKey in @('HKLM:\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}','HKLM:\SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}','HKCU:\SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}')) {
    $runtime=Get-ItemProperty -LiteralPath $runtimeKey -ErrorAction SilentlyContinue
    if ($runtime -and $runtime.pv -and [version]$runtime.pv -gt [version]'0.0.0.0') {$runtimeFound=$true}
  }
  if (-not $runtimeFound) {
    if ($setupLabel) {$setupLabel.Text='Installing the Microsoft-signed WebView2 prerequisite';[Windows.Forms.Application]::DoEvents()}
    $bootstrap=Join-Path $stage 'webview2-bootstrapper.exe'
    $signature=Get-AuthenticodeSignature -LiteralPath $bootstrap
    if ($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch '(^|,\s*)O=Microsoft Corporation(,|$)') {throw 'WebView2 prerequisite signature is invalid'}
    $runtimeProcess=Start-Process -FilePath $bootstrap -ArgumentList '/silent /install' -WorkingDirectory $stage -PassThru
    $runtimeClock=[Diagnostics.Stopwatch]::StartNew()
    while (-not $runtimeProcess.WaitForExit(200)) {
      if ($setupForm) {[Windows.Forms.Application]::DoEvents()}
      if ($runtimeClock.ElapsedMilliseconds -ge 180000) {Stop-Process -Id $runtimeProcess.Id -Force;throw 'WebView2 prerequisite installation timed out'}
    }
    if ($runtimeProcess.ExitCode -ne 0) {throw ('WebView2 prerequisite installation failed: '+$runtimeProcess.ExitCode)}
  }
  Set-InstallStage 'install-engine' 'Installing the scanner and protecting update files'
  $previous=Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
  if ($previous) {
    if ($previous.Actions.Count -ne 1 -or $previous.Actions[0].Execute.Trim('"') -ne (Join-Path $target 'engine\MalGuard.exe')) {throw 'Updater task name belongs to an unexpected action'}
    $previousTask=Export-ScheduledTask -TaskName $taskName
    Disable-ScheduledTask -TaskName $taskName | Out-Null
    $taskChanged=$true
    Stop-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
  }
  if (Test-Path -LiteralPath $target) {Move-Item -LiteralPath $target -Destination $backup;$replaced=$true}
  Move-Item -LiteralPath $stage -Destination $target
  $installed=$true
  & $powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File (Join-Path $target 'engine\protect-install.ps1') -Directory $target
  if ($LASTEXITCODE -ne 0) {throw 'Privileged updater code protection failed'}
  $engine=Join-Path $target 'engine\MalGuard.exe'
  Set-InstallStage 'self-test' 'Running the installed scanner self-test'
  $selfResult=Invoke-SetupEngine -Engine $engine -Mode '--self-test'
  if ($selfResult.timedOut) {throw 'Installed engine self-test exceeded the 60-second deadline'}
  $self=$selfResult.stdout | ConvertFrom-Json
  if ($selfResult.exitCode -ne 0 -or -not $self.self_test_passed) {throw 'Installed engine self-test failed'}
  Set-InstallStage 'signed-update' 'Receiving and verifying signed threat data (up to 60 seconds)'
  $refresh=Invoke-SetupEngine -Engine $engine -Mode '--refresh-security'
  if ($refresh.timedOut -or $refresh.exitCode -ne 0) {$message='Security data update unavailable; retry the update button. SAFE remains blocked until required coverage completes.'}
  Set-InstallStage 'configure-shortcuts' 'Configuring scheduled updates and shortcuts'
  $action=New-ScheduledTaskAction -Execute $engine -Argument '--refresh-security' -WorkingDirectory (Join-Path $target 'engine')
  $trigger=New-ScheduledTaskTrigger -Daily -At '03:00'
  $taskPrincipal=New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
  $settings=New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Minutes 5) -StartWhenAvailable
  Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $taskPrincipal -Settings $settings -Force | Out-Null
  $taskChanged=$true
  $wsh=New-Object -ComObject WScript.Shell
  foreach ($shortcutPath in @((Join-Path ([Environment]::GetFolderPath('CommonDesktopDirectory')) 'MalGuard.lnk'),(Join-Path ([Environment]::GetFolderPath('CommonPrograms')) 'MalGuard.lnk'),(Join-Path ([Environment]::GetFolderPath('Desktop')) 'MalGuard.lnk'))) {
    $shortcut=$wsh.CreateShortcut($shortcutPath)
    $shortcut.TargetPath=Join-Path $target 'malguard-desktop.exe'
    $shortcut.WorkingDirectory=$target
    $shortcut.Description='MalGuard / GTA Guard'
    $shortcut.Save()
  }
  $uninstallKey='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\MalGuard'
  New-Item -Path $uninstallKey -Force | Out-Null
  $uninstallCommand='"'+$powershell+'" -NoProfile -ExecutionPolicy Bypass -File "'+(Join-Path $target 'uninstall.ps1')+'"'
  foreach ($entry in @{DisplayName='MalGuard / GTA Guard';DisplayVersion='1.3.1';Publisher='MalGuard';InstallLocation=$target;DisplayIcon=(Join-Path $target 'malguard-desktop.exe');UninstallString=$uninstallCommand;QuietUninstallString=($uninstallCommand+' -Quiet')}.GetEnumerator()) {
    Set-ItemProperty -LiteralPath $uninstallKey -Name $entry.Key -Value $entry.Value
  }
  # Preserve the previous installation as a rollback copy instead of deleting
  # files or reports that may have been added by the user.
  Set-InstallStage 'complete' 'Installation complete'
  $result=@{schema=1;installed=$true;format='IExpress-PowerShell';version='1.3.1';target=$target;setupProcess64Bit=[Environment]::Is64BitProcess;previousInstallation=$(if ($replaced) {$backup} else {''});warning=$message;elapsedMs=$setupWatch.ElapsedMilliseconds;stages=@($stageTimings);requiresDeviceLicense=$false;installerPasswordRequired=$false}
  $result | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $target 'installation-result.json') -Encoding UTF8
  if (-not $noLaunchMode) {Start-Process -FilePath (Join-Path $target 'malguard-desktop.exe') -WorkingDirectory $target}
  if (-not $quietMode) {
    if ($setupForm) {$setupForm.Hide()}
    Add-Type -AssemblyName System.Windows.Forms
    [Windows.Forms.MessageBox]::Show(('MalGuard installed successfully. '+$message),'MalGuard setup') | Out-Null
  }
  exit 0
} catch {
  if ($setupForm) {$setupForm.Hide()}
  $failure=$_.Exception.Message
  if ($installed) {
    # Move failed output aside; do not recursively delete user content.
    Move-Item -LiteralPath $target -Destination ($target+'.failed.'+[guid]::NewGuid().ToString('N')) -ErrorAction SilentlyContinue
  }
  if ($replaced -and -not (Test-Path -LiteralPath $target)) {Move-Item -LiteralPath $backup -Destination $target}
  if ($taskChanged) {
    if ($previousTask) {Register-ScheduledTask -TaskName $taskName -Xml $previousTask -Force | Out-Null}
    else {Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue}
  }
  $diagnostic=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'MalGuard-install-error.txt'
  ('MalGuard IExpress setup failed: '+$failure) | Set-Content -LiteralPath $diagnostic -Encoding UTF8
  Write-Error $failure -ErrorAction Continue
  if (-not $quietMode) {
    Add-Type -AssemblyName System.Windows.Forms
    [Windows.Forms.MessageBox]::Show(($failure+"`r`nDiagnostic: "+$diagnostic),'MalGuard setup error') | Out-Null
  }
  exit 41
} finally {
  if ($setupForm) {$setupForm.Dispose()}
}
