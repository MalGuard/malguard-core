"""CI-only MalwareBazaar metadata ingestion and Ed25519 bundle publication."""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
import re
import sys
from datetime import UTC, datetime
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import HTTPRedirectHandler, Request, build_opener

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from malguard_core.integrity import BundleVerifier, bundle_snapshot  # noqa: E402
from malguard_core.integrity.bundle import strict_json  # noqa: E402
from malguard_core.reputation import ReputationStore  # noqa: E402
from malguard_core.reputation.trust import PUBLIC_KEYS  # noqa: E402
from malguard_core.rules import compile_bundle  # noqa: E402

MAX_RECORDS = 10_000
MAX_RESPONSE = 16 * 1024 * 1024


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ValueError("Authenticated API redirects forbidden")


def metadata_records(data: bytes) -> dict[str, dict]:
    if len(data) > MAX_RESPONSE:
        raise ValueError("Metadata byte budget exceeded")
    response = strict_json(data)
    if not isinstance(response, dict) or response.get("query_status") != "ok":
        raise ValueError("MalwareBazaar did not return authenticated successful metadata")
    rows = response.get("data")
    if not isinstance(rows, list) or not rows or len(rows) > MAX_RECORDS:
        raise ValueError("MalwareBazaar row budget or response shape invalid")
    records = {}
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError("Metadata row is not an object")
        digest = row.get("sha256_hash")
        if not isinstance(digest, str) or not re.fullmatch(r"[a-f0-9]{64}", digest):
            raise ValueError("Invalid real metadata SHA256")
        records[digest] = {
            "sha256": digest,
            "reviewed_by": "MalGuard automated authenticated-metadata validation",
            "reference": "https://bazaar.abuse.ch/sample/" + digest + "/",
            "description_en": "Exact SHA256 listed by the authenticated MalwareBazaar metadata API.",
            "description_fa": "هش دقیق فایل در دادهٔ تأییدشدهٔ MalwareBazaar ثبت شده است.",
        }
    return records


def fetch_metadata(auth_key: str) -> bytes:
    if not auth_key or len(auth_key) > 512 or any(c.isspace() for c in auth_key):
        raise ValueError("MalwareBazaar Auth-Key missing or invalid")
    # Metadata only. Never use get_file, uploads or malware batch endpoints.
    request = Request("https://mb-api.abuse.ch/api/v1/",
                      data=urlencode({"query": "recent_detections", "hours": "48"}).encode(),
                      headers={"Auth-Key": auth_key,
                               "Content-Type": "application/x-www-form-urlencoded",
                               "Accept-Encoding": "identity"}, method="POST")
    with build_opener(NoRedirect()).open(request, timeout=40) as response:
        if response.status != 200 or response.headers.get("Content-Encoding") not in (None, "identity"):
            raise ValueError("Invalid metadata transport")
        data = response.read(MAX_RESPONSE + 1)
    if len(data) > MAX_RESPONSE:
        raise ValueError("Metadata byte budget exceeded")
    return data


def build_snapshot(metadata: bytes, signing_key: bytes, epoch: int, now: datetime,
                   rules: bytes, previous: bytes | None = None) -> dict:
    private = Ed25519PrivateKey.from_private_bytes(signing_key)
    public = private.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)
    key_id = "malguard-online-2026-10"
    if PUBLIC_KEYS[key_id] != public:
        raise ValueError("Signing secret does not match the provisioned application key")
    records = {}
    verifier = BundleVerifier(PUBLIC_KEYS)
    if previous:
        prior = verifier.verify_snapshot(strict_json(previous))
        if prior.key_id != key_id or epoch <= prior.epoch:
            raise ValueError("Publisher rollback or signer mismatch")
        records = {record["sha256"]: record
                   for record in strict_json(prior.payloads["blocklist.json"])["records"]}
    records.update(metadata_records(metadata))
    if len(records) > MAX_RECORDS:
        raise ValueError("Accumulated blocklist budget reached; previous publication retained")
    payloads = {"blocklist.json": json.dumps({"records": [records[k] for k in sorted(records)]},
                                          ensure_ascii=False, separators=(",", ":")).encode(),
                "allowlist.json": b'{"records":[]}', "iocs.json": b'{"records":[]}',
                "revoked_signers.json": b'{"records":[]}', "rules/gta_guard.yar": rules}
    manifest = {"bundle_version": "mb-" + str(epoch), "epoch": epoch,
                "minimum_engine_version": "1.0.0", "ruleset_version": "1.0.0",
                "created_at": now.isoformat(), "key_id": key_id,
                "files": {name: hashlib.sha256(value).hexdigest()
                          for name, value in sorted(payloads.items())}}
    manifest_bytes = json.dumps(manifest, sort_keys=True, separators=(",", ":")).encode()
    snapshot = {"schema_version": 1,
                "manifest_b64": base64.b64encode(manifest_bytes).decode(),
                "signature_b64": base64.b64encode(private.sign(manifest_bytes)).decode(),
                "payloads": {name: base64.b64encode(value).decode()
                             for name, value in payloads.items()}}
    verified = verifier.verify_snapshot(snapshot)
    ReputationStore(verified)
    try:
        compile_bundle(verified)
    except Exception as error:
        raise ValueError("Ruleset compilation failed") from error
    return bundle_snapshot(verified)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--epoch", type=int, required=True)
    args = parser.parse_args()
    key = base64.b64decode(os.environ.get("MALGUARD_UPDATE_SIGNING_KEY", "").strip(), validate=True)
    if len(key) != 32:
        raise ValueError("MALGUARD_UPDATE_SIGNING_KEY must contain the provisioned 32-byte base64 key")
    metadata = fetch_metadata(os.environ.get("MALGUARD_ABUSECH_AUTH_KEY", ""))
    rules = Path(__file__).resolve().parents[2] / "rules/gta_guard.yar"
    previous = args.output.read_bytes() if args.output.exists() else None
    snapshot = build_snapshot(metadata, key, args.epoch, datetime.now(UTC), rules.read_bytes(), previous)
    data = json.dumps(snapshot, separators=(",", ":")).encode()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_bytes(data)
    print("Authenticated metadata published; no samples downloaded; bundle epoch", args.epoch)


if __name__ == "__main__":
    main()
