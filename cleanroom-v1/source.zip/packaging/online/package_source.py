"""Build an auditable clean-room CI input without private keys or build caches."""

import argparse
import hashlib
import json
import zipfile
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    files = []
    for folder in ("malguard_core", "malguard_cli", "tests", "rules", "data", "packaging",
                   "desktop", "docs"):
        for path in (root / folder).rglob("*"):
            if path.is_file() and not any(part in {"__pycache__", "node_modules", "target", "engine"}
                                          for part in path.relative_to(root).parts):
                if path.is_symlink():
                    raise ValueError("Source symlinks are forbidden")
                files.append(path)
    files.extend(root / name for name in ("pyproject.toml", "requirements-lock.txt",
                                          "README.md", "ARCHITECTURE.md"))
    with zipfile.ZipFile(args.output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(files):
            archive.write(path, path.relative_to(root).as_posix())
    data = args.output.read_bytes()
    manifest = {"sha256": hashlib.sha256(data).hexdigest(), "files": len(files), "bytes": len(data),
                "app_version": "1.1.0", "engine_version": "1.0.0", "cleanroom": True,
                "synthetic_tests_only": True}
    args.output.with_suffix(".json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(manifest))


if __name__ == "__main__":
    main()
