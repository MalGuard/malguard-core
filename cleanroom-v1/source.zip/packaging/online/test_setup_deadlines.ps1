param([Parameter(Mandatory=$true)][string]$Output)
$ErrorActionPreference='Stop'
$script:setupForm=$null
$scriptPath=Join-Path $PSScriptRoot 'install_iexpress.ps1'
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile($scriptPath,[ref]$tokens,[ref]$errors)
if ($errors.Count) {throw 'Installer does not parse in Windows PowerShell'}
$function=$ast.Find({param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Invoke-SetupEngine'},$true)
if (-not $function) {throw 'Bounded setup engine helper is absent'}
. ([scriptblock]::Create($function.Extent.Text))
$root=Join-Path $env:RUNNER_TEMP ('mg-deadline-'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $root | Out-Null
try {
  $engine=Join-Path $root 'inert-setup-test.exe'
  Add-Type -TypeDefinition @'
using System;
using System.Diagnostics;
using System.Threading;
public static class InertSetupTest {
  public static int Main(string[] args) {
    Console.WriteLine("{\"self_test_passed\":true,\"pid\":" + Process.GetCurrentProcess().Id + "}");
    Console.Out.Flush();
    if (args.Length == 1 && args[0] == "--refresh-security") Thread.Sleep(15000);
    return 0;
  }
}
'@ -OutputAssembly $engine -OutputType ConsoleApplication
  $good=Invoke-SetupEngine -Engine $engine -Mode '--self-test' -DeadlineMs 3000
  if ($good.timedOut -or $good.exitCode -ne 0 -or -not ($good.stdout | ConvertFrom-Json).self_test_passed) {throw ('Completed setup engine result was lost: timedOut='+$good.timedOut+'; exitCode='+$good.exitCode+'; stdoutLength='+$good.stdout.Length)}
  $clock=[Diagnostics.Stopwatch]::StartNew()
  $slow=Invoke-SetupEngine -Engine $engine -Mode '--refresh-security' -DeadlineMs 1200
  if (-not $slow.timedOut -or $slow.exitCode -ne -1 -or $clock.ElapsedMilliseconds -gt 6000) {throw 'Setup engine deadline did not terminate the waiting stage'}
  $pidValue=($slow.stdout | ConvertFrom-Json).pid
  if (Get-Process -Id $pidValue -ErrorAction SilentlyContinue) {throw 'Timed-out setup child survived'}
  if (@(Get-ChildItem -LiteralPath $root -Filter '.setup-*').Count -ne 0) {throw 'Temporary setup output was not removed'}
  @{passed=4;failed=0;checks=@('completed-engine-result','bounded-update-timeout','timed-out-child-terminated','temporary-output-cleaned')} | ConvertTo-Json | Set-Content -LiteralPath $Output -Encoding UTF8
} finally {
  Remove-Item -LiteralPath $root -Recurse -Force
}
