param([Parameter(Mandatory=$true)][string]$Engine, [Parameter(Mandatory=$true)][string]$Output)
$ErrorActionPreference='Stop'
$license=Join-Path ([Environment]::GetFolderPath('CommonApplicationData')) 'MalGuard/Licenses/desktop-1.3.0.json'
$original=[IO.File]::ReadAllBytes($license)
$checks=@()
try {
  $status=& $Engine --license-status | ConvertFrom-Json
  if ($LASTEXITCODE -ne 0 -or -not $status.authorized -or -not $status.private_build) {throw 'Authorized private frozen engine failed'}
  $checks+=@{name='signed-same-device-accepted';passed=$true}
  foreach ($case in @(@{file='wrong-device.json';reason='DEVICE_MISMATCH'},@{file='tampered.json';reason='LICENSE_SIGNATURE_INVALID'})) {
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot ('../../desktop/license-test-fixtures/'+$case.file)) -Destination $license -Force
    $status=& $Engine --license-status | ConvertFrom-Json
    if ($LASTEXITCODE -ne 78 -or $status.authorized -or $status.reason -ne $case.reason) {throw ('Invalid license accepted: '+$case.file)}
    $checks+=@{name=$case.reason;passed=$true}
  }
  Remove-Item -LiteralPath $license
  foreach ($mode in @('--license-status','--self-test','--refresh-security','--malguard-worker')) {
    $text=& $Engine $mode
    if ($LASTEXITCODE -ne 78) {throw ('Missing license did not block: '+$mode)}
    $checks+=@{name=('missing-license-blocks-'+$mode);passed=$true}
  }
} finally {[IO.File]::WriteAllBytes($license,$original)}
@{checks=$checks;passed=$checks.Count;failed=0} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $Output -Encoding UTF8
exit 0
