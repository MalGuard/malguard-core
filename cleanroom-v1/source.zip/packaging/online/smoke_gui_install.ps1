param([Parameter(Mandatory=$true)][string]$Setup, [Parameter(Mandatory=$true)][string]$Output)
$ErrorActionPreference='Stop'
$install=Join-Path $env:ProgramFiles 'MalGuard'
$checks=@()
$process=Start-Process -FilePath (Resolve-Path $Setup).Path -ArgumentList '/S' -PassThru
if (-not $process.WaitForExit(180000)) {
  Stop-Process -Id $process.Id -Force
  throw 'Installer exceeded the 180-second safety deadline'
}
if ($process.ExitCode -ne 0) {
  $diagnostic=Join-Path $install 'installer-protection.log'
  if (Test-Path -LiteralPath $diagnostic) {
    $reader=[IO.File]::OpenText($diagnostic)
    try {
      $buffer=New-Object char[] 4096
      $length=$reader.Read($buffer,0,$buffer.Length)
      Write-Output ('Installer protection diagnostic: '+[string]::new($buffer,0,$length))
    } finally {$reader.Dispose()}
  }
  $helper=Join-Path $install 'engine/protect-install.ps1'
  Write-Output "Installed protection helper exists: $(Test-Path -LiteralPath $helper)"
  $verifiedSource=Join-Path $PSScriptRoot '../../desktop/protect-install.ps1'
  if ((Test-Path -LiteralPath $helper) -and (Get-FileHash -LiteralPath $helper).Hash -eq (Get-FileHash -LiteralPath $verifiedSource).Hash) {
    & "$env:SystemRoot\SysWOW64\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $helper -Directory $install
    Write-Output "Independent installed helper exit: $LASTEXITCODE"
  }
  throw "Installer exit $($process.ExitCode)"
}
$helper=Join-Path $install 'engine/protect-install.ps1'
$sourceHelper=Join-Path $PSScriptRoot '../../desktop/protect-install.ps1'
if (-not (Test-Path -LiteralPath $helper) -or (Get-FileHash -LiteralPath $helper).Hash -ne (Get-FileHash -LiteralPath $sourceHelper).Hash) {throw 'Installed protection helper differs from verified source'}
$engine=Join-Path $install 'engine\MalGuard.exe'
$gui=Join-Path $install 'malguard-desktop.exe'
if (-not (Test-Path $engine) -or -not (Test-Path $gui)) {throw 'Installed GUI or engine missing'}
$checks+=@{name='native-install-paths';passed=$true}
$acl=Get-Acl -LiteralPath $engine
if ($acl.Owner -notmatch 'Administrators$|SYSTEM$') {throw 'Installed updater owner is unprotected'}
foreach ($ace in $acl.Access) {
  if ($ace.IdentityReference -match 'Users$' -and ($ace.FileSystemRights -band [Security.AccessControl.FileSystemRights]::Write) -ne 0) {throw 'Users may modify the SYSTEM updater'}
}
$checks+=@{name='system-updater-code-acl';passed=$true}
$self=& $engine --self-test | ConvertFrom-Json
if ($LASTEXITCODE -ne 0 -or -not $self.self_test_passed -or $self.python_version -ne '3.12.15') {throw 'Installed frozen self-test failed'}
$checks+=@{name='installed-python315-self-test';passed=$true}
$online=& $engine --security-status | ConvertFrom-Json
if ($LASTEXITCODE -ne 0 -or -not $online.available -or -not $online.fresh -or $online.record_count -le 0) {throw 'Installed signed online feed is unavailable or stale'}
$checks+=@{name='installed-signed-online-feed';passed=$true;epoch=$online.epoch;record_count=$online.record_count}
$task=Get-ScheduledTask -TaskName 'MalGuard Signed Security Update'
if ($task.Actions.Count -ne 1 -or $task.Actions[0].Execute.Trim('"') -ne $engine -or $task.Actions[0].Arguments -ne '--refresh-security') {throw 'Scheduled action does not match trusted updater'}
if ($task.Principal.UserId -notin @('SYSTEM','S-1-5-18')) {throw 'Updater task principal is incorrect'}
$checks+=@{name='daily-system-update-task';passed=$true}
$wsh=New-Object -ComObject WScript.Shell
$shortcut=$wsh.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'MalGuard.lnk'))
if ($shortcut.TargetPath -ne $gui) {throw 'Desktop shortcut still targets the console app'}
$checks+=@{name='gui-desktop-shortcut';passed=$true}
$app=Start-Process -FilePath $gui -PassThru
try {
  $deadline=(Get-Date).AddSeconds(30)
  do {
    Start-Sleep -Milliseconds 300
    $app.Refresh()
    if ($app.HasExited) {throw 'Native GUI exited before opening a window'}
  } while ($app.MainWindowHandle -eq 0 -and (Get-Date) -lt $deadline)
  if ($app.MainWindowHandle -eq 0 -or $app.MainWindowTitle -ne 'MalGuard / GTA Guard') {throw 'Native GUI window did not open'}
  $checks+=@{name='native-tauri-window-startup';passed=$true}
} finally {if (-not $app.HasExited) {Stop-Process -Id $app.Id -Force}}
$uninstall=Join-Path $install 'uninstall.exe'
if (-not (Test-Path $uninstall)) {throw 'Native uninstaller missing'}
$uninstaller=Start-Process -FilePath $uninstall -ArgumentList '/S' -PassThru -Wait
if ($uninstaller.ExitCode -ne 0) {throw 'Native uninstaller failed'}
Start-Sleep -Seconds 2
if (Get-ScheduledTask -TaskName 'MalGuard Signed Security Update' -ErrorAction SilentlyContinue) {throw 'Scheduled task survived uninstall'}
$checks+=@{name='native-uninstall-task-removal';passed=$true}
@{checks=$checks;passed=$checks.Count;failed=0;sample_execution=$false;platform=(Get-CimInstance Win32_OperatingSystem).Caption;gui_visual_interaction_tested=$false} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $Output -Encoding utf8
