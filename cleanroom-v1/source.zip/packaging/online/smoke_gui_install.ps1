param([Parameter(Mandatory=$true)][string]$Setup, [Parameter(Mandatory=$true)][string]$Output)
$ErrorActionPreference='Stop'
$install=Join-Path $env:ProgramFiles 'MalGuard'
$checks=@()
$windowsPowerShell=Join-Path $env:SystemRoot 'System32/WindowsPowerShell/v1.0/powershell.exe'
$diagnostics=Join-Path (Split-Path -Parent (Split-Path -Parent (Resolve-Path $Setup).Path)) 'iexpress-diagnostics'
$badHash='0'*64
$invalid=Start-Process -FilePath $windowsPowerShell -ArgumentList ('-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "'+(Join-Path $diagnostics 'install.ps1')+'" -PayloadHash '+$badHash+' -Quiet -NoLaunch') -PassThru
if (-not $invalid.WaitForExit(30000) -or $invalid.ExitCode -ne 41 -or (Test-Path -LiteralPath $install)) {throw 'Corrupt installer was not rejected before installation'}
$checks+=@{name='iexpress-payload-tampering-rejected';passed=$true}
$env:MALGUARD_SETUP_QUIET='1'
$process=Start-Process -FilePath (Resolve-Path $Setup).Path -ArgumentList '/Q:A /R:N' -PassThru
if (-not $process.WaitForExit(360000)) {
  Stop-Process -Id $process.Id -Force
  throw 'Installer exceeded the 360-second safety deadline'
}
if ($process.ExitCode -ne 0) {
  $diagnostic=Join-Path $install 'installer-protection.log'
  if (Test-Path -LiteralPath $diagnostic) {
    $reader=[IO.File]::OpenText($diagnostic)
    try {
      $buffer=New-Object char[] 4096
      $length=$reader.Read($buffer,0,$buffer.Length)
      Write-Output ('Installer protection diagnostic: '+[string]::new($buffer,0,$length))
    } finally {$reader.Dispose()}
  }
  $helper=Join-Path $install 'engine/protect-install.ps1'
  Write-Output "Installed protection helper exists: $(Test-Path -LiteralPath $helper)"
  $verifiedSource=Join-Path $PSScriptRoot '../../desktop/protect-install.ps1'
  if ((Test-Path -LiteralPath $helper) -and (Get-FileHash -LiteralPath $helper).Hash -eq (Get-FileHash -LiteralPath $verifiedSource).Hash) {
    & "$env:SystemRoot\SysWOW64\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $helper -Directory $install
    Write-Output "Independent installed helper exit: $LASTEXITCODE"
  }
  throw "Installer exit $($process.ExitCode)"
}
$helper=Join-Path $install 'engine/protect-install.ps1'
$sourceHelper=Join-Path $PSScriptRoot '../../desktop/protect-install.ps1'
if (-not (Test-Path -LiteralPath $helper) -or (Get-FileHash -LiteralPath $helper).Hash -ne (Get-FileHash -LiteralPath $sourceHelper).Hash) {throw 'Installed protection helper differs from verified source'}
$engine=Join-Path $install 'engine\MalGuard.exe'
$gui=Join-Path $install 'malguard-desktop.exe'
if (-not (Test-Path $engine) -or -not (Test-Path $gui)) {throw 'Installed GUI or engine missing'}
$checks+=@{name='native-install-paths';passed=$true}
$installation=Get-Content -LiteralPath (Join-Path $install 'installation-result.json') -Raw | ConvertFrom-Json
if (-not $installation.installed -or $installation.format -ne 'IExpress-PowerShell' -or -not $installation.setupProcess64Bit) {throw '64-bit IExpress installation result missing'}
$checks+=@{name='iexpress-powershell-exe-install';passed=$true}
$prerequisite=Get-AuthenticodeSignature -LiteralPath (Join-Path $install 'webview2-bootstrapper.exe')
if ($prerequisite.Status -ne 'Valid' -or $prerequisite.SignerCertificate.Subject -notmatch '(^|,\s*)O=Microsoft Corporation(,|$)') {throw 'Bundled WebView2 prerequisite is not Microsoft-signed'}
$checks+=@{name='microsoft-signed-webview2-prerequisite';passed=$true}
$acl=Get-Acl -LiteralPath $engine
if ($acl.Owner -notmatch 'Administrators$|SYSTEM$') {throw 'Installed updater owner is unprotected'}
foreach ($ace in $acl.Access) {
  if ($ace.IdentityReference -match 'Users$' -and ($ace.FileSystemRights -band [Security.AccessControl.FileSystemRights]::Write) -ne 0) {throw 'Users may modify the SYSTEM updater'}
}
$checks+=@{name='system-updater-code-acl';passed=$true}
$self=& $engine --self-test | ConvertFrom-Json
if ($LASTEXITCODE -ne 0 -or -not $self.self_test_passed -or $self.python_version -ne '3.12.15') {throw 'Installed frozen self-test failed'}
$checks+=@{name='installed-python315-self-test';passed=$true}
$online=& $engine --security-status | ConvertFrom-Json
if ($LASTEXITCODE -ne 0 -or -not $online.available -or -not $online.fresh -or $online.record_count -le 0) {throw 'Installed signed online feed is unavailable or stale'}
$checks+=@{name='installed-signed-online-feed';passed=$true;epoch=$online.epoch;record_count=$online.record_count}
$task=Get-ScheduledTask -TaskName 'MalGuard Signed Security Update'
if ($task.Actions.Count -ne 1 -or $task.Actions[0].Execute.Trim('"') -ne $engine -or $task.Actions[0].Arguments -ne '--refresh-security') {throw 'Scheduled action does not match trusted updater'}
if ($task.Principal.UserId -notin @('SYSTEM','S-1-5-18')) {throw 'Updater task principal is incorrect'}
$checks+=@{name='daily-system-update-task';passed=$true}
$wsh=New-Object -ComObject WScript.Shell
$shortcut=$wsh.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'MalGuard.lnk'))
if ($shortcut.TargetPath -ne $gui) {throw 'Desktop shortcut still targets the console app'}
$checks+=@{name='gui-desktop-shortcut';passed=$true}
$app=Start-Process -FilePath $gui -PassThru
try {
  $deadline=(Get-Date).AddSeconds(30)
  do {
    Start-Sleep -Milliseconds 300
    $app.Refresh()
    if ($app.HasExited) {throw 'Native GUI exited before opening a window'}
  } while ($app.MainWindowHandle -eq 0 -and (Get-Date) -lt $deadline)
  if ($app.MainWindowHandle -eq 0 -or $app.MainWindowTitle -ne 'MalGuard / GTA Guard') {throw 'Native GUI window did not open'}
  $checks+=@{name='native-tauri-window-startup';passed=$true}
} finally {if (-not $app.HasExited) {Stop-Process -Id $app.Id -Force}}
$repeat=Start-Process -FilePath (Resolve-Path $Setup).Path -ArgumentList '/Q:A /R:N' -PassThru
if (-not $repeat.WaitForExit(360000) -or $repeat.ExitCode -ne 0) {throw 'Reinstallation failed'}
$repeatResult=Get-Content -LiteralPath (Join-Path $install 'installation-result.json') -Raw | ConvertFrom-Json
if (-not $repeatResult.previousInstallation -or -not (Test-Path -LiteralPath (Join-Path $repeatResult.previousInstallation 'engine/MalGuard.exe'))) {throw 'Previous engine was not preserved during replacement'}
$checks+=@{name='iexpress-repeat-install-preserves-rollback';passed=$true}
$before=(Get-FileHash -LiteralPath $engine -Algorithm SHA256).Hash
$invalidAgain=Start-Process -FilePath $windowsPowerShell -ArgumentList ('-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "'+(Join-Path $diagnostics 'install.ps1')+'" -PayloadHash '+$badHash+' -Quiet -NoLaunch') -PassThru
if (-not $invalidAgain.WaitForExit(30000) -or $invalidAgain.ExitCode -ne 41 -or (Get-FileHash -LiteralPath $engine -Algorithm SHA256).Hash -ne $before) {throw 'Failed replacement changed the working engine'}
$checks+=@{name='iexpress-failed-replacement-preserves-engine';passed=$true}
$userReport=Join-Path $install 'harmless-user-report.txt'
Set-Content -LiteralPath $userReport -Value 'Harmless user report preservation fixture'
$uninstall=Join-Path $install 'uninstall.ps1'
if (-not (Test-Path $uninstall)) {throw 'Native uninstaller missing'}
$uninstaller=Start-Process -FilePath $windowsPowerShell -ArgumentList ('-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "'+$uninstall+'" -Quiet') -PassThru -Wait
if ($uninstaller.ExitCode -ne 0) {throw 'Native uninstaller failed'}
Start-Sleep -Seconds 2
if (Get-ScheduledTask -TaskName 'MalGuard Signed Security Update' -ErrorAction SilentlyContinue) {throw 'Scheduled task survived uninstall'}
$checks+=@{name='native-uninstall-task-removal';passed=$true}
if (-not (Test-Path -LiteralPath $userReport)) {throw 'Uninstall erased user-added content'}
$checks+=@{name='uninstall-preserves-user-files';passed=$true}
@{checks=$checks;passed=$checks.Count;failed=0;sample_execution=$false;platform=(Get-CimInstance Win32_OperatingSystem).Caption;gui_visual_interaction_tested=$false} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $Output -Encoding utf8
