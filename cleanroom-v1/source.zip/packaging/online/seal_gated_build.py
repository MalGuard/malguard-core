"""Publish only ciphertext of the tested unrestricted installer for delivery."""

import hashlib
import json
import os
import struct
from pathlib import Path

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.serialization import load_pem_public_key


def main() -> None:
    source = os.environ["GITHUB_SHA"]
    assert len(source) == 40 and len(bytes.fromhex(source)) == 20
    root = Path("verified-desktop")
    exe = root / "MalGuard-Setup-x64.exe"
    data = exe.read_bytes()
    assert 1024 < len(data) <= 40 * 1024 * 1024 and data[:2] == b"MZ"
    offset = struct.unpack_from("<I", data, 0x3C)[0]
    assert 64 <= offset < len(data) - 4 and data[offset:offset + 4] == b"PE\x00\x00"
    policy = Path("cleanroom-source/malguard_cli/license_policy.py").read_text()
    assert "PRIVATE_LICENSE_PUBLIC_KEY_HEX: str | None = None" in policy
    public = load_pem_public_key(Path(".private-build/delivery-recipient.pem").read_bytes())
    assert isinstance(public, rsa.RSAPublicKey) and public.key_size >= 3072
    key, nonce = os.urandom(32), os.urandom(12)
    wrapped = public.encrypt(key, padding.OAEP(
        mgf=padding.MGF1(hashes.SHA256()), algorithm=hashes.SHA256(), label=None
    ))
    aad = b"MalGuard site-gated desktop 1.3.1:" + source.encode("ascii")
    sealed = b"MGBUILD2" + struct.pack(">I", len(wrapped)) + wrapped + nonce + AESGCM(key).encrypt(
        nonce, data, aad
    )
    (root / (exe.name + ".sealed")).write_bytes(sealed)
    manifest = {
        "schema": 1, "status": "site-gated-windows-build-verified",
        "app_version": "1.3.1", "engine_version": "1.2.1", "source_commit": source,
        "build": "MG-1.3.1-WIN64-" + source[:12], "filename": exe.name,
        "size": len(data), "sha256": hashlib.sha256(data).hexdigest(),
        "sealed_sha256": hashlib.sha256(sealed).hexdigest(),
        "requires_device_license": False, "installer_password_required": False,
        "authenticode_signed": False, "run_id": os.environ["GITHUB_RUN_ID"],
        "source_archive_sha256": hashlib.sha256(Path("cleanroom-v1/source.zip").read_bytes()).hexdigest(),
    }
    (root / "site-gated-release.json").write_text(json.dumps(manifest, indent=2) + "\n")
    exe.unlink()
    for name in ("setup-stdout.txt", "setup-stderr.txt"):
        (root / name).unlink(missing_ok=True)
    print("Unrestricted installer verified and encrypted for site-gated delivery")


if __name__ == "__main__":
    main()
