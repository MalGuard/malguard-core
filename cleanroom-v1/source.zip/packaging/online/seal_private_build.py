"""Encrypt the genuine Windows installer to the private delivery recipient."""

import hashlib
import json
import os
import struct
from pathlib import Path

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.serialization import load_pem_public_key


def main() -> None:
    source = os.environ["GITHUB_SHA"]
    assert len(source) == 40 and len(bytes.fromhex(source)) == 20
    root = Path("verified-desktop")
    exe = root / "MalGuard-Online-Setup-x64.exe"
    data = exe.read_bytes()
    assert 1024 < len(data) <= 64 * 1024 * 1024 and data[:2] == b"MZ"
    offset = struct.unpack_from("<I", data, 0x3C)[0]
    assert 64 <= offset < len(data) - 4 and data[offset:offset + 4] == b"PE\x00\x00"
    public = load_pem_public_key(Path(".private-build/delivery-recipient.pem").read_bytes())
    assert isinstance(public, rsa.RSAPublicKey) and public.key_size >= 3072
    key, nonce = os.urandom(32), os.urandom(12)
    wrapped = public.encrypt(key, padding.OAEP(mgf=padding.MGF1(hashes.SHA256()),
                                             algorithm=hashes.SHA256(), label=None))
    aad = b"MalGuard private desktop 1.3.0:" + source.encode("ascii")
    sealed = b"MGBUILD2" + struct.pack(">I", len(wrapped)) + wrapped + nonce + AESGCM(key).encrypt(
        nonce, data, aad
    )
    (root / (exe.name + ".sealed")).write_bytes(sealed)
    policy = Path("cleanroom-source/malguard_cli/license_policy.py").read_text(encoding="utf-8")
    license_public = Path(".private-build/license-public.hex").read_text().strip()
    assert f'"{license_public}"' in policy
    manifest = {
        "schema": 1, "status": "private-windows-build-verified", "app_version": "1.3.0",
        "engine_version": "1.2.0", "source_commit": source,
        "build": "MG-1.3.0-WIN64-" + source[:12], "filename": exe.name,
        "size": len(data), "sha256": hashlib.sha256(data).hexdigest(),
        "sealed_sha256": hashlib.sha256(sealed).hexdigest(),
        "license_public_key": license_public, "requires_device_license": True,
        "authenticode_signed": False, "run_id": os.environ["GITHUB_RUN_ID"],
        "source_archive_sha256": hashlib.sha256(Path("cleanroom-v1/source.zip").read_bytes()).hexdigest(),
    }
    (root / "private-release.json").write_text(json.dumps(manifest, indent=2) + "\n")
    exe.unlink()
    for name in ("setup-stdout.txt", "setup-stderr.txt"):
        (root / name).unlink(missing_ok=True)
    print("Verified installer encrypted; only ciphertext and test evidence may be published")


if __name__ == "__main__":
    main()
