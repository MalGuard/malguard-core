param(
  [Parameter(Mandatory=$true)][string]$PackageRoot,
  [Parameter(Mandatory=$true)][string]$Output,
  [Parameter(Mandatory=$true)][string]$DiagnosticDirectory
)
$ErrorActionPreference='Stop'
$package=(Resolve-Path -LiteralPath $PackageRoot).Path
$outputPath=[IO.Path]::GetFullPath($Output)
$work=Join-Path ([IO.Path]::GetTempPath()) ('MalGuard-build-'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $work | Out-Null
try {
  foreach ($required in @('malguard-desktop.exe','engine/MalGuard.exe','engine/protect-install.ps1')) {
    if (-not (Test-Path -LiteralPath (Join-Path $package $required) -PathType Leaf)) {throw ('Missing trusted component: '+$required)}
  }
  $bootstrap=Join-Path $package 'webview2-bootstrapper.exe'
  Invoke-WebRequest -Uri 'https://go.microsoft.com/fwlink/p/?LinkId=2124703' -OutFile $bootstrap -UseBasicParsing
  $signature=Get-AuthenticodeSignature -LiteralPath $bootstrap
  if ($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch '(^|,\s*)O=Microsoft Corporation(,|$)') {throw 'WebView2 bootstrapper is not signed by Microsoft'}
  Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'uninstall_iexpress.ps1') -Destination (Join-Path $package 'uninstall.ps1')
  $records=@(Get-ChildItem -LiteralPath $package -File -Recurse -Force | Sort-Object FullName | ForEach-Object {
    if (($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {throw 'Build payload reparse point forbidden'}
    @{path=($_.FullName.Substring($package.Length).TrimStart('\') -replace '\\','/');sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()}
  })
  @{schema=1;product='MalGuard clean-room desktop';version='1.1.0';files=$records} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $package 'install-manifest.json') -Encoding UTF8
  $payload=Join-Path $work 'payload.zip'
  Compress-Archive -Path (Join-Path $package '*') -DestinationPath $payload -CompressionLevel Optimal
  $digest=(Get-FileHash -LiteralPath $payload -Algorithm SHA256).Hash.ToLowerInvariant()
  # Windows PowerShell 5.1 requires a BOM for non-ASCII source files.
  $script=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'install_iexpress.ps1') -Raw
  [IO.File]::WriteAllText((Join-Path $work 'install.ps1'),$script,(New-Object Text.UTF8Encoding($true)))
  $appCommand='powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File install.ps1 -PayloadHash '+$digest
  $sed=@"
[Version]
Class=IEXPRESS
SEDVersion=3
[Options]
PackagePurpose=InstallApp
ShowInstallProgramWindow=0
HideExtractAnimation=0
UseLongFileName=1
InsideCompressed=0
CAB_FixedSize=0
CAB_ResvCodeSigning=0
RebootMode=N
InstallPrompt=%InstallPrompt%
DisplayLicense=%DisplayLicense%
FinishMessage=%FinishMessage%
TargetName=%TargetName%
FriendlyName=%FriendlyName%
AppLaunched=%AppLaunched%
PostInstallCmd=%PostInstallCmd%
AdminQuietInstCmd=%AdminQuietInstCmd%
UserQuietInstCmd=%UserQuietInstCmd%
SourceFiles=SourceFiles
[Strings]
InstallPrompt=
DisplayLicense=
FinishMessage=
TargetName=$($outputPath.Replace('%','%%'))
FriendlyName=MalGuard / GTA Guard graphical scanner
AppLaunched=$appCommand
PostInstallCmd=<None>
AdminQuietInstCmd=$appCommand
UserQuietInstCmd=$appCommand
FILE0="payload.zip"
FILE1="install.ps1"
[SourceFiles]
SourceFiles0=$($work.TrimEnd('\').Replace('%','%%'))\
[SourceFiles0]
%FILE0%=
%FILE1%=
"@
  $sedPath=Join-Path $work 'setup.sed'
  Set-Content -LiteralPath $sedPath -Value $sed -Encoding ASCII
  New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($outputPath)) -Force | Out-Null
  $iexpress=Join-Path $env:SystemRoot 'System32\iexpress.exe'
  $process=Start-Process -FilePath $iexpress -ArgumentList ('/N /Q "'+$sedPath+'"') -WorkingDirectory $work -PassThru
  if (-not $process.WaitForExit(180000)) {Stop-Process -Id $process.Id -Force;throw 'IExpress build deadline exceeded'}
  if ($process.ExitCode -ne 0 -or -not (Test-Path -LiteralPath $outputPath)) {throw ('IExpress build failed: '+$process.ExitCode)}
  New-Item -ItemType Directory -Path $DiagnosticDirectory -Force | Out-Null
  Copy-Item -LiteralPath $payload -Destination (Join-Path $DiagnosticDirectory 'payload.zip')
  Copy-Item -LiteralPath (Join-Path $work 'install.ps1') -Destination (Join-Path $DiagnosticDirectory 'install.ps1')
  @{payloadHash=$digest;format='IExpress-PowerShell';engineVersion='1.0.0';appVersion='1.1.0'} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $DiagnosticDirectory 'build.json') -Encoding UTF8
  Write-Output ('IExpress installer built: '+$outputPath)
} finally {Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue}
