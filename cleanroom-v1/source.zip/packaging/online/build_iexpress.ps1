param(
  [Parameter(Mandatory=$true)][string]$PackageRoot,
  [Parameter(Mandatory=$true)][string]$Output,
  [Parameter(Mandatory=$true)][string]$DiagnosticDirectory
)
$ErrorActionPreference='Stop'
$package=(Resolve-Path -LiteralPath $PackageRoot).Path
$outputPath=[IO.Path]::GetFullPath($Output)
$temporaryRoot=$(if ($env:RUNNER_TEMP) {$env:RUNNER_TEMP} else {[IO.Path]::GetTempPath()})
$work=Join-Path $temporaryRoot ('mg-'+[guid]::NewGuid().ToString('N').Substring(0,8))
New-Item -ItemType Directory -Path $work | Out-Null
try {
  foreach ($required in @('malguard-desktop.exe','engine/MalGuard.exe','engine/protect-install.ps1')) {
    if (-not (Test-Path -LiteralPath (Join-Path $package $required) -PathType Leaf)) {throw ('Missing trusted component: '+$required)}
  }
  $bootstrap=Join-Path $package 'webview2-bootstrapper.exe'
  Invoke-WebRequest -Uri 'https://go.microsoft.com/fwlink/p/?LinkId=2124703' -OutFile $bootstrap -UseBasicParsing
  $signature=Get-AuthenticodeSignature -LiteralPath $bootstrap
  if ($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch '(^|,\s*)O=Microsoft Corporation(,|$)') {throw 'WebView2 bootstrapper is not signed by Microsoft'}
  Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'uninstall_iexpress.ps1') -Destination (Join-Path $package 'uninstall.ps1')
  $records=@(Get-ChildItem -LiteralPath $package -File -Recurse -Force | Sort-Object FullName | ForEach-Object {
    if (($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {throw 'Build payload reparse point forbidden'}
    @{path=($_.FullName.Substring($package.Length).TrimStart('\') -replace '\\','/');sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()}
  })
  @{schema=1;product='MalGuard clean-room desktop';version='1.1.0';files=$records} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $package 'install-manifest.json') -Encoding UTF8
  $payload=Join-Path $work 'payload.zip'
  Compress-Archive -Path (Join-Path $package '*') -DestinationPath $payload -CompressionLevel Optimal
  $digest=(Get-FileHash -LiteralPath $payload -Algorithm SHA256).Hash.ToLowerInvariant()
  # Windows PowerShell 5.1 requires a BOM for non-ASCII source files.
  $script=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'install_iexpress.ps1') -Raw
  [IO.File]::WriteAllText((Join-Path $work 'install.ps1'),$script,(New-Object Text.UTF8Encoding($true)))
  $launcher="@echo off`r`n"+'"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" -PayloadHash '+$digest+"`r`nexit /b %errorlevel%`r`n"
  Set-Content -LiteralPath (Join-Path $work 'launch.cmd') -Value $launcher -Encoding ASCII
  # Keep the legacy self-extractor command short; payload identity is passed
  # by the complete embedded launcher without relying on SED command limits.
  $appCommand='cmd.exe /c launch.cmd'
  $sed=@"
[Version]
Class=IEXPRESS
SEDVersion=3
[Options]
PackagePurpose=InstallApp
ShowInstallProgramWindow=0
HideExtractAnimation=0
UseLongFileName=1
InsideCompressed=0
CAB_FixedSize=0
CAB_ResvCodeSigning=0
RebootMode=N
InstallPrompt=%InstallPrompt%
DisplayLicense=%DisplayLicense%
FinishMessage=%FinishMessage%
TargetName=%TargetName%
FriendlyName=%FriendlyName%
AppLaunched=%AppLaunched%
PostInstallCmd=%PostInstallCmd%
AdminQuietInstCmd=%AdminQuietInstCmd%
UserQuietInstCmd=%UserQuietInstCmd%
SourceFiles=SourceFiles
[Strings]
InstallPrompt=
DisplayLicense=
FinishMessage=
TargetName=$($outputPath.Replace('%','%%'))
FriendlyName=MalGuard graphical scanner
AppLaunched=$appCommand
PostInstallCmd=<None>
AdminQuietInstCmd=$appCommand
UserQuietInstCmd=$appCommand
FILE0="payload.zip"
FILE1="install.ps1"
FILE2="launch.cmd"
[SourceFiles]
SourceFiles0=$($work.TrimEnd('\').Replace('%','%%'))\
[SourceFiles0]
%FILE0%=
%FILE1%=
%FILE2%=
"@
  # Source ZIP files retain Unix newlines; emit a Windows INI specification.
  $sed=$sed -replace "`r?`n","`r`n"
  $sedPath=Join-Path $work 'setup.sed'
  Set-Content -LiteralPath $sedPath -Value $sed -Encoding ASCII
  New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($outputPath)) -Force | Out-Null
  $iexpress=Join-Path $env:SystemRoot 'System32\iexpress.exe'
  $process=Start-Process -FilePath $iexpress -ArgumentList @('/N','/Q',$sedPath) -WorkingDirectory $work -PassThru
  if (-not $process.WaitForExit(180000)) {Stop-Process -Id $process.Id -Force;throw 'IExpress build deadline exceeded'}
  if ($process.ExitCode -ne 0 -or -not (Test-Path -LiteralPath $outputPath)) {
    Add-Type -TypeDefinition @'
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
namespace MalGuardPackaging {
  public static class WindowText {
    private delegate bool Callback(IntPtr window, IntPtr parameter);
    [DllImport("user32.dll")] private static extern bool EnumWindows(Callback callback, IntPtr parameter);
    [DllImport("user32.dll")] private static extern bool EnumChildWindows(IntPtr window, Callback callback, IntPtr parameter);
    [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr window, out uint processId);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] private static extern int GetWindowText(IntPtr window, StringBuilder text, int length);
    public static string Read(int processId) {
      var output = new StringBuilder();
      Callback child = (window, unused) => {
        var text = new StringBuilder(1024);
        GetWindowText(window, text, 1024);
        if (text.Length > 0 && output.Length < 8192) output.AppendLine(text.ToString());
        return output.Length < 8192;
      };
      Callback root = (window, unused) => {
        uint owner;
        GetWindowThreadProcessId(window, out owner);
        if (owner == processId) { child(window, IntPtr.Zero); EnumChildWindows(window, child, IntPtr.Zero); }
        return output.Length < 8192;
      };
      EnumWindows(root, IntPtr.Zero);
      return output.ToString();
    }
  }
}
'@
    $diagnosticProcess=Start-Process -FilePath $iexpress -ArgumentList @('/N',$sedPath) -WorkingDirectory $work -PassThru
    try {
      for ($attempt=0;$attempt -lt 20 -and -not $diagnosticProcess.HasExited;$attempt++) {
        Start-Sleep -Milliseconds 250
        $windowText=[MalGuardPackaging.WindowText]::Read($diagnosticProcess.Id)
        if ($windowText) {Write-Output ('IExpress diagnostic window: '+$windowText);break}
        $diagnosticProcess.Refresh()
      }
    } finally {if (-not $diagnosticProcess.HasExited) {Stop-Process -Id $diagnosticProcess.Id -Force}}
    Write-Output ('IExpress build directory: '+$work)
    Write-Output $sed
    foreach ($file in @(Get-ChildItem -LiteralPath $work -File -Force)) {
      Write-Output ($file.Name+' bytes='+$file.Length)
      if ($file.Extension -in @('.log','.rpt','.ddf','.inf') -and $file.Length -lt 16384) {Write-Output (Get-Content -LiteralPath $file.FullName -Raw)}
    }
    throw ('IExpress build failed: '+$process.ExitCode)
  }
  New-Item -ItemType Directory -Path $DiagnosticDirectory -Force | Out-Null
  Copy-Item -LiteralPath $payload -Destination (Join-Path $DiagnosticDirectory 'payload.zip')
  Copy-Item -LiteralPath (Join-Path $work 'install.ps1') -Destination (Join-Path $DiagnosticDirectory 'install.ps1')
  @{payloadHash=$digest;format='IExpress-PowerShell';engineVersion='1.0.0';appVersion='1.1.0'} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $DiagnosticDirectory 'build.json') -Encoding UTF8
  Write-Output ('IExpress installer built: '+$outputPath)
} finally {Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue}
exit 0
