param([switch]$Quiet)
$ErrorActionPreference='Stop'
$target=[IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')
$registry=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine,[Microsoft.Win32.RegistryView]::Registry64)
try {
  $key=$registry.OpenSubKey('SOFTWARE\Microsoft\Windows\CurrentVersion')
  try {$expected=Join-Path ([string]$key.GetValue('ProgramFilesDir')) 'MalGuard'} finally {$key.Dispose()}
} finally {$registry.Dispose()}
if ($target -ne $expected) {throw 'Uninstall path is not the protected MalGuard installation'}
$principal=New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  $powershell=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
  $arguments='-NoProfile -ExecutionPolicy Bypass -File "'+$PSCommandPath+'"'
  if ($Quiet) {$arguments+=' -Quiet'}
  $process=Start-Process -FilePath $powershell -ArgumentList $arguments -Verb RunAs -PassThru -Wait
  exit $process.ExitCode
}
$pending=New-Object 'Collections.Generic.Stack[IO.DirectoryInfo]'
$root=Get-Item -LiteralPath $target -Force
if (($root.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {throw 'Uninstall root is a reparse point'}
$pending.Push($root)
$directories=New-Object 'Collections.Generic.List[string]'
$count=0
while ($pending.Count -gt 0) {
  $current=$pending.Pop()
  $directories.Add($current.FullName)
  foreach ($entry in $current.GetFileSystemInfos()) {
    $count++
    if ($count -gt 10000 -or $entry.FullName.Substring($target.Length).Split('\').Length -gt 32) {throw 'Uninstall inspection limit exceeded'}
    if (($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {throw 'Uninstall reparse point rejected'}
    if ($entry -is [IO.DirectoryInfo]) {$pending.Push($entry)}
  }
}
$manifest=Get-Content -LiteralPath (Join-Path $target 'install-manifest.json') -Raw | ConvertFrom-Json
if ($manifest.schema -ne 1 -or $manifest.product -ne 'MalGuard clean-room desktop') {throw 'Uninstall manifest invalid'}
foreach ($record in $manifest.files) {
  if ($record.path -match '\\|:|(^|/)\.\.?(/|$)' -or $record.path.StartsWith('/') -or $record.sha256 -notmatch '^[a-f0-9]{64}$') {throw 'Uninstall manifest path invalid'}
}
$task=Get-ScheduledTask -TaskName 'MalGuard Signed Security Update' -ErrorAction SilentlyContinue
if ($task) {
  if ($task.Actions.Count -ne 1 -or $task.Actions[0].Execute.Trim('"') -ne (Join-Path $target 'engine\MalGuard.exe')) {throw 'Unexpected scheduled task action'}
  Stop-ScheduledTask -TaskName $task.TaskName -ErrorAction SilentlyContinue
  Unregister-ScheduledTask -TaskName $task.TaskName -Confirm:$false
}
$wsh=New-Object -ComObject WScript.Shell
foreach ($shortcut in @((Join-Path ([Environment]::GetFolderPath('CommonDesktopDirectory')) 'MalGuard.lnk'),(Join-Path ([Environment]::GetFolderPath('CommonPrograms')) 'MalGuard.lnk'),(Join-Path ([Environment]::GetFolderPath('Desktop')) 'MalGuard.lnk'))) {
  if ((Test-Path -LiteralPath $shortcut) -and $wsh.CreateShortcut($shortcut).TargetPath -eq (Join-Path $target 'malguard-desktop.exe')) {Remove-Item -LiteralPath $shortcut}
}
# Remove only unchanged owned files. User reports and modified files survive.
foreach ($record in $manifest.files) {
  $file=Join-Path $target $record.path
  if ((Test-Path -LiteralPath $file -PathType Leaf) -and (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant() -eq $record.sha256) {Remove-Item -LiteralPath $file}
}
foreach ($name in @('installation-result.json','install-manifest.json')) {Remove-Item -LiteralPath (Join-Path $target $name) -ErrorAction SilentlyContinue}
foreach ($directory in @($directories | Sort-Object Length -Descending)) {
  if ((Test-Path -LiteralPath $directory) -and @(Get-ChildItem -LiteralPath $directory -Force).Count -eq 0) {Remove-Item -LiteralPath $directory}
}
Remove-Item -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\MalGuard' -ErrorAction SilentlyContinue
if (-not $Quiet) {
  Add-Type -AssemblyName System.Windows.Forms
  [Windows.Forms.MessageBox]::Show('MalGuard removed. Reports, signed security history and rollback copies were retained.','MalGuard') | Out-Null
}
exit 0
