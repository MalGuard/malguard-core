"""Build-time policy selection; no runtime environment bypass is available."""

import argparse
import base64
import json
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from malguard_cli.device_license import DOMAIN, license_path, windows_fingerprint


def main() -> None:
    parser = argparse.ArgumentParser()
    choice = parser.add_mutually_exclusive_group(required=True)
    choice.add_argument("--test-device", action="store_true")
    choice.add_argument("--public-key-file", type=Path)
    args = parser.parse_args()
    if args.test_device:
        # Ephemeral CI signer is never the production release authority.
        key = Ed25519PrivateKey.generate()
        public = key.public_key().public_bytes_raw().hex()
        payload = {"schema": 1, "product": "MalGuard", "app_version": "1.3.0",
                   "fingerprint": windows_fingerprint()}
        signature = key.sign(DOMAIN + json.dumps(payload, sort_keys=True,
                                                separators=(",", ":")).encode())
        path = license_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps({**payload, "signature": base64.b64encode(signature).decode()}),
                        encoding="utf-8")
        fixtures = Path(__file__).resolve().parents[2] / "desktop/license-test-fixtures"
        fixtures.mkdir(parents=True, exist_ok=True)
        wrong = {**payload, "fingerprint": "0" * 64}
        wrong_signature = key.sign(DOMAIN + json.dumps(wrong, sort_keys=True,
                                                      separators=(",", ":")).encode())
        (fixtures / "wrong-device.json").write_text(json.dumps({
            **wrong, "signature": base64.b64encode(wrong_signature).decode()
        }), encoding="utf-8")
        (fixtures / "tampered.json").write_text(json.dumps({
            **wrong, "signature": base64.b64encode(signature).decode()
        }), encoding="utf-8")
    else:
        public = args.public_key_file.read_text(encoding="ascii").strip()
        assert len(public) == 64 and len(bytes.fromhex(public)) == 32
    root = Path(__file__).resolve().parents[2]
    (root / "malguard_cli/license_policy.py").write_text(
        '"""Immutable private Windows release policy."""\n'
        f'PRIVATE_LICENSE_PUBLIC_KEY_HEX: str | None = "{public}"\n'
        'PRIVATE_APP_VERSION = "1.3.0"\n', encoding="utf-8"
    )
    print("Private policy configured; no private signing key stored in the build")


if __name__ == "__main__":
    main()
