"""Windows x64 onedir build with signed resources and isolated worker entry."""

import sys
from pathlib import Path

from PyInstaller.utils.hooks import collect_data_files, collect_submodules, copy_metadata

root = Path(SPECPATH).resolve().parents[1]
sys.path.insert(0, str(root))
packages = (
    "malguard_core", "malguard_cli", "dnfile", "yara_x", "py7zr", "signify",
    "asn1crypto", "certvalidator", "oscrypto", "mscerts", "Cryptodome",
)
hidden = sorted({module for package in packages for module in collect_submodules(package)})
data = collect_data_files("malguard_core", includes=["reputation/data/**", "py.typed"])
data += collect_data_files("mscerts")
data += copy_metadata("malguard")

analysis = Analysis(
    [str(root / "packaging/windows/entry.py")],
    pathex=[str(root)], binaries=[], datas=data,
    hiddenimports=hidden, hookspath=[], hooksconfig={}, runtime_hooks=[],
    excludes=["pytest", "mypy", "ruff", "pip_audit", "tkinter", "unittest"],
    noarchive=False, optimize=0,
)
archive = PYZ(analysis.pure)
executable = EXE(
    archive, analysis.scripts, [], exclude_binaries=True, name="MalGuard",
    debug=False, bootloader_ignore_signals=False, strip=False, upx=False,
    console=True, disable_windowed_traceback=False,
    uac_admin=False, uac_uiaccess=False,
)
bundle = COLLECT(
    executable, analysis.binaries, analysis.datas,
    strip=False, upx=False, name="MalGuard",
)
