; Compile only a trusted release directory prepared by package_release.py.
Unicode true
Target amd64-unicode
RequestExecutionLevel user
SetCompressor /SOLID lzma
CRCCheck on
Name "MalGuard / GTA Guard"
OutFile "${SETUP_PATH}"
InstallDir "$LOCALAPPDATA\Programs\MalGuard"
InstallDirRegKey HKCU "Software\MalGuard" "InstallDir"
VIProductVersion "1.0.0.0"
VIAddVersionKey /LANG=1033 "ProductName" "MalGuard / GTA Guard"
VIAddVersionKey /LANG=1033 "FileDescription" "Offline defensive static scanner installer"
VIAddVersionKey /LANG=1033 "FileVersion" "1.0.0"

!include "MUI2.nsh"
!include "WinVer.nsh"
!define MUI_ABORTWARNING
!define MUI_FINISHPAGE_RUN "$INSTDIR\MalGuard.exe"
!define MUI_FINISHPAGE_RUN_NOTCHECKED
!define MUI_FINISHPAGE_RUN_TEXT "Open MalGuard"
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"
!insertmacro MUI_LANGUAGE "Farsi"

Function .onInit
  SetShellVarContext current
  SetRegView 64
  ${IfNot} ${AtLeastWin10}
    MessageBox MB_OK|MB_ICONSTOP "MalGuard requires 64-bit Windows 10 or Windows 11."
    SetErrorLevel 10
    Quit
  ${EndIf}
FunctionEnd

Section "MalGuard" Main
  SetShellVarContext current
  SetRegView 64
  ClearErrors
  SetOutPath "$INSTDIR"
  File /r "${PAYLOAD_DIR}\*"
  IfErrors install_failed
  ClearErrors
  WriteUninstaller "$INSTDIR\Uninstall.exe"
  IfErrors install_failed
  ClearErrors
  CreateDirectory "$SMPROGRAMS\MalGuard"
  CreateShortCut "$SMPROGRAMS\MalGuard\MalGuard.lnk" "$INSTDIR\MalGuard.exe"
  CreateShortCut "$SMPROGRAMS\MalGuard\Uninstall.lnk" "$INSTDIR\Uninstall.exe"
  CreateDirectory "$DESKTOP"
  CreateShortCut "$DESKTOP\MalGuard.lnk" "$INSTDIR\MalGuard.exe"
  IfErrors shortcut_warning shortcuts_complete
shortcut_warning:
  DetailPrint "A shortcut could not be created. Open MalGuard.exe from the installation directory."
shortcuts_complete:
  ClearErrors
  WriteRegStr HKCU "Software\MalGuard" "InstallDir" "$INSTDIR"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\MalGuard" "DisplayName" "MalGuard / GTA Guard"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\MalGuard" "DisplayVersion" "1.0.0"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\MalGuard" "DisplayIcon" "$INSTDIR\MalGuard.exe"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\MalGuard" "InstallLocation" "$INSTDIR"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\MalGuard" "UninstallString" '$\"$INSTDIR\Uninstall.exe$\"'
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\MalGuard" "QuietUninstallString" '$\"$INSTDIR\Uninstall.exe$\" /S'
  WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\MalGuard" "NoModify" 1
  WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\MalGuard" "NoRepair" 1
  IfErrors install_failed
  Goto install_complete
install_failed:
  MessageBox MB_OK|MB_ICONSTOP "Installation could not be completed. Check folder permissions and available disk space."
  SetErrorLevel 11
  Quit
install_complete:
SectionEnd

Section "Uninstall"
  SetShellVarContext current
  SetRegView 64
  ; No recursive directory deletion: only this release's owned files.
  !include "${OWNED_FILES}"
  Delete "$INSTDIR\Uninstall.exe"
  RMDir "$INSTDIR"
  Delete "$SMPROGRAMS\MalGuard\MalGuard.lnk"
  Delete "$SMPROGRAMS\MalGuard\Uninstall.lnk"
  RMDir "$SMPROGRAMS\MalGuard"
  Delete "$DESKTOP\MalGuard.lnk"
  DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\MalGuard"
  DeleteRegKey HKCU "Software\MalGuard"
  ; Reports in LOCALAPPDATA\MalGuard\Reports are intentionally retained.
SectionEnd
