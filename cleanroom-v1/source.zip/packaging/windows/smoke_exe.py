"""Trusted standalone EXE QA; all fixture bytes are inert and only scanned."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import struct
import subprocess
import tempfile
import time
from pathlib import Path


def verify(executable: Path, fixtures: Path, output: Path) -> dict[str, object]:
    executable = executable.resolve()
    manifest = json.loads((fixtures / "manifest.json").read_text(encoding="utf-8"))
    if manifest["synthetic_only"] is not True or manifest["sample_execution"] is not False:
        raise ValueError("Only the trusted generated synthetic fixture manifest is accepted")
    checks: list[dict[str, object]] = []
    with tempfile.TemporaryDirectory(prefix="malguard-exe-qa-") as temporary:
        directory = Path(temporary)
        environment = os.environ.copy()
        for key in ("PYTHONPATH", "PYTHONHOME", "PYTHONIOENCODING", "PYTHONUTF8"):
            environment.pop(key, None)
        environment["LOCALAPPDATA"] = str(directory / "user-data")
        (directory / "malguard_core.py").write_text(
            "raise RuntimeError('untrusted working directory imported')\n", encoding="utf-8")

        def run(name: str, arguments: list[str], expected: int,
                data: bytes | None = None) -> subprocess.CompletedProcess[bytes]:
            started = time.monotonic()
            process = subprocess.run(  # noqa: S603 -- fixed trusted scanner, never fixture executable
                [str(executable), *arguments], cwd=directory, env=environment,
                input=data, capture_output=True, timeout=120, check=False)
            checks.append({"name": name, "arguments": arguments,
                           "returncode": process.returncode, "expected_returncode": expected,
                           "seconds": round(time.monotonic() - started, 3),
                           "stdout_sha256": hashlib.sha256(process.stdout).hexdigest(),
                           "stderr": process.stderr.decode("utf-8", errors="replace")[:4096]})
            assert process.returncode == expected, (name, process.returncode, process.stderr)
            return process

        help_result = run("utf8-help", ["--help"], 0)
        assert any("\u0600" <= letter <= "\u06ff" for letter in help_result.stdout.decode("utf-8"))
        assert not help_result.stderr
        self_test = json.loads(run("frozen-self-test", ["--self-test"], 0).stdout)
        assert self_test["self_test_passed"] and self_test["frozen"]
        assert self_test["sample_execution"] is False
        assert self_test["platform"] == "win32"
        code = {"SAFE": 0, "SUSPICIOUS": 1, "MALICIOUS": 2, "INVALID": 3, "INCONCLUSIVE": 3}
        reports = {}
        for case in manifest["cases"]:
            sample = fixtures / case["name"]
            assert hashlib.sha256(sample.read_bytes()).hexdigest() == case["sha256"]
            result = run("scan:" + case["name"], [str(sample), "--format", "json"], code[case["verdict"]])
            report = json.loads(result.stdout)
            assert not result.stderr
            assert report["verdict"] == case["verdict"], case["name"]
            assert report["risk_score"] == case["risk"], case["name"]
            assert report["coverage_score"] == case["coverage"], case["name"]
            assert len(report["artifacts"]) == case["artifacts"], case["name"]
            assert report["hashes"]["sha256"] == case["sha256"]
            assert hashlib.sha256(sample.read_bytes()).hexdigest() == case["sha256"]
            reports[case["name"]] = report
            checks[-1].update(verdict=report["verdict"], coverage=report["coverage_score"],
                              risk=report["risk_score"], artifact_count=len(report["artifacts"]))
        safe_sample = fixtures / manifest["cases"][0]["name"]
        repeated = json.loads(run("deterministic-json", [str(safe_sample), "--format", "json"], 0).stdout)
        assert repeated == reports[safe_sample.name]
        text = run("persian-text", [str(safe_sample)], 0)
        assert any("\u0600" <= letter <= "\u06ff" for letter in text.stdout.decode("utf-8"))
        report_path = directory / "گزارش با فاصله.json"
        saved = run("exclusive-new-json", [str(safe_sample), "--format", "json", "--output", str(report_path)], 0)
        assert not saved.stdout and not saved.stderr
        original_report = report_path.read_bytes()
        rejected = run("existing-report-refused", [str(safe_sample), "--format", "json", "--output", str(report_path)], 4)
        assert "FileExistsError" in rejected.stderr.decode("utf-8")
        assert report_path.read_bytes() == original_report
        run("input-overwrite-refused", [str(safe_sample), "--format", "json", "--output", str(safe_sample)], 4)
        assert hashlib.sha256(safe_sample.read_bytes()).hexdigest() == manifest["cases"][0]["sha256"]
        run("unknown-switch-rejected", ["--unknown-option"], 2)
        run("private-switch-extra-arguments-rejected", ["--malguard-worker", "--self-test"], 2)
        invalid_frame = run("worker-hostile-frame-rejected", ["--malguard-worker"], 70,
                            struct.pack(">I", 2) + b"[]")
        assert not invalid_frame.stdout and not invalid_frame.stderr
        evaluation = json.loads(run("synthetic-evaluation", ["--evaluate", str(fixtures / "dataset")], 0).stdout)
        assert evaluation["sample_count"] == 2 and evaluation["scan_failures"] == 0
        assert evaluation["metrics"]["true_positives"] == evaluation["metrics"]["true_negatives"] == 1
        assert evaluation["acceptance_targets_evaluated"] is False
        interactive = run("interactive-persian-path", [], 0, (str(safe_sample) + "\n\n").encode("utf-8"))
        assert "JSON report saved to:" in interactive.stdout.decode("utf-8")
        generated = list((directory / "user-data/MalGuard/Reports").glob("scan-*.json"))
        assert len(generated) == 1 and json.loads(generated[0].read_text(encoding="utf-8"))["verdict"] == "SAFE"
    result: dict[str, object] = {
        "schema_version": 1, "passed": True, "platform": os.name,
        "verification_environment": "Wine compatibility runtime" if os.environ.get("WINEPREFIX") else "native Windows",
        "native_windows_10_11_qualification": False,
        "sample_execution": False, "synthetic_only": True, "self_test": self_test,
        "executable_sha256": hashlib.sha256(executable.read_bytes()).hexdigest(),
        "check_count": len(checks), "checks": checks,
    }
    with output.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--exe", required=True, type=Path)
    parser.add_argument("--fixtures", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    result = verify(args.exe, args.fixtures, args.output)
    print(json.dumps({"passed": result["passed"], "check_count": result["check_count"]}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
