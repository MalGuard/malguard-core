"""Install/uninstall our trusted build in a disposable Windows lab profile."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import tempfile
import time
from pathlib import Path


def verify(release: Path, output: Path) -> dict[str, object]:
    if os.name != "nt":
        raise ValueError("Installer runtime verification requires Windows or Wine")
    import winreg
    import ctypes
    from ctypes import wintypes

    shell = ctypes.WinDLL("shell32", use_last_error=True)
    shell.SHGetFolderPathW.argtypes = [wintypes.HWND, ctypes.c_int, wintypes.HANDLE,
                                      wintypes.DWORD, wintypes.LPWSTR]
    shell.SHGetFolderPathW.restype = ctypes.c_long

    def shell_folder(identifier: int) -> Path:
        buffer = ctypes.create_unicode_buffer(260)
        assert shell.SHGetFolderPathW(None, identifier, None, 0, buffer) == 0
        return Path(buffer.value)

    registry = "Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\MalGuard"
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, registry, 0,
                            winreg.KEY_READ | winreg.KEY_WOW64_64KEY):
            raise ValueError("Use a disposable profile without an existing MalGuard installation")
    except FileNotFoundError:
        pass
    setup = (release / "MalGuard-Setup-x64.exe").resolve()
    checks: list[dict[str, object]] = []
    with tempfile.TemporaryDirectory(prefix="malguard-install-qa-") as temporary:
        root = Path(temporary)
        destination = root / "برنامه با فاصله" / "MalGuard"
        environment = os.environ.copy()
        environment["LOCALAPPDATA"] = str(root / "user-data")
        # NSIS requires /D to be last and unquoted, including paths with spaces.
        # This is a CreateProcess command for our fixed trusted installer, not a shell.
        installed = subprocess.run(  # noqa: S603 -- fixed trusted installer in disposable profile
            f'"{setup}" /S /D={destination}', executable=str(setup),
            env=environment, capture_output=True, timeout=120, check=False)
        assert installed.returncode == 0, (installed.returncode, installed.stderr)
        executable = destination / "MalGuard.exe"
        assert executable.is_file() and (destination / "Uninstall.exe").is_file()
        records = json.loads((release / "MalGuard/release-files.json").read_text(encoding="utf-8"))["files"]
        for record in records:
            path = destination / record["path"]
            assert path.stat().st_size == record["size"]
            assert hashlib.sha256(path.read_bytes()).hexdigest() == record["sha256"], record["path"]
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, registry, 0,
                            winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as key:
            assert winreg.QueryValueEx(key, "InstallLocation")[0] == str(destination)
        checks.append({"name": "silent-install-persian-space-path", "passed": True,
                       "verified_file_count": len(records), "returncode": installed.returncode})
        shortcuts = [shell_folder(0x10) / "MalGuard.lnk",
                     shell_folder(0x02) / "MalGuard/MalGuard.lnk",
                     shell_folder(0x02) / "MalGuard/Uninstall.lnk"]
        assert all(path.is_file() for path in shortcuts), [
            {"path": str(path), "exists": path.exists(),
             "parent": str(path.parent), "parent_exists": path.parent.exists(),
             "entries": [entry.name for entry in path.parent.iterdir()] if path.parent.exists() else []}
            for path in shortcuts]
        checks.append({"name": "desktop-and-start-menu-shortcuts", "passed": True})
        result = subprocess.run(  # noqa: S603 -- installed trusted scanner
            [str(executable), "--self-test"], cwd=root, env=environment,
            capture_output=True, timeout=120, check=False)
        assert result.returncode == 0 and not result.stderr
        self_test = json.loads(result.stdout)
        assert self_test["self_test_passed"] and self_test["frozen"]
        checks.append({"name": "installed-frozen-self-test", "passed": True,
                       "details": self_test})
        sample = root / "نمونه بی خطر.lua"
        sample.write_bytes(b"return 0")
        interactive = subprocess.run(  # noqa: S603 -- only scanner executed; sample is inert input
            [str(executable)], cwd=root, env=environment,
            input=(str(sample) + "\n\n").encode("utf-8"), capture_output=True,
            timeout=120, check=False)
        assert interactive.returncode == 0 and not interactive.stderr
        report_folder = root / "user-data/MalGuard/Reports"
        reports = list(report_folder.glob("scan-*.json"))
        assert len(reports) == 1
        report_bytes = reports[0].read_bytes()
        assert json.loads(report_bytes)["verdict"] == "SAFE"
        checks.append({"name": "installed-interactive-json-report", "passed": True})
        unrelated = destination / "my-personal-notes.txt"
        unrelated.write_bytes(b"User file must survive uninstall\n")
        nested_unrelated = destination / "_internal/user-added.txt"
        nested_unrelated.write_bytes(b"Nested user file must survive uninstall\n")
        uninstaller = destination / "Uninstall.exe"
        removed = subprocess.run(  # noqa: S603 -- generated trusted uninstaller
            [str(uninstaller), "/S"], env=environment, capture_output=True,
            timeout=120, check=False)
        assert removed.returncode == 0, (removed.returncode, removed.stderr)
        # NSIS relocates the uninstaller into a temporary process. Its parent
        # can finish first, so observe the actual completion rather than exit alone.
        deadline = time.monotonic() + 30
        while (executable.exists() or uninstaller.exists()) and time.monotonic() < deadline:
            time.sleep(0.1)
        assert not executable.exists() and not uninstaller.exists()
        for record in records:
            assert not (destination / record["path"]).exists(), record["path"]
        assert not (destination / "release-files.json").exists()
        assert unrelated.read_bytes() == b"User file must survive uninstall\n"
        assert nested_unrelated.read_bytes() == b"Nested user file must survive uninstall\n"
        assert reports[0].read_bytes() == report_bytes
        assert sample.read_bytes() == b"return 0"
        assert all(not path.exists() for path in shortcuts)
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, registry, 0,
                                winreg.KEY_READ | winreg.KEY_WOW64_64KEY):
                raise AssertionError("Uninstall registry record remains")
        except FileNotFoundError:
            pass
        checks.append({"name": "uninstall-owned-files-only", "passed": True,
                       "preserved_reports": True, "preserved_user_files": True,
                       "preserved_sample": True, "returncode": removed.returncode})
    result_json: dict[str, object] = {
        "schema_version": 1, "passed": True, "sample_execution": False,
        "verification_environment": "Wine compatibility runtime" if os.environ.get("WINEPREFIX") else "native Windows",
        "native_windows_10_11_qualification": False,
        "setup_sha256": hashlib.sha256(setup.read_bytes()).hexdigest(),
        "checks": checks,
    }
    with output.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(result_json, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"passed": True, "check_count": len(checks)}))
    return result_json


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--release", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    verify(args.release, args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
