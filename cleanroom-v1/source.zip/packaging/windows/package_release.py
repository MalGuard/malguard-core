"""Package a trusted x64 frozen build; never inspect or execute scan samples."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import struct
import subprocess
import zipfile
from pathlib import Path


def require_amd64_pe(path: Path) -> None:
    with path.open("rb") as stream:
        header = stream.read(64)
        if len(header) != 64 or header[:2] != b"MZ":
            raise ValueError("Release executable is not a PE")
        offset = struct.unpack_from("<I", header, 60)[0]
        if not 64 <= offset <= 1024 * 1024:
            raise ValueError("Invalid trusted release PE offset")
        stream.seek(offset)
        signature = stream.read(6)
    if signature != b"PE\x00\x00\x64\x86":
        raise ValueError("Release executable must target Windows AMD64")


def nsis_literal(text: str) -> str:
    if any(character in text for character in '\r\n\x00"'):
        raise ValueError("Unsupported character in trusted packaging path")
    return text.replace("$", "$$")


def owned_files(payload: Path) -> str:
    """Delete named owned files and empty directories, preserving user files."""
    lines = []
    for path in sorted(payload.rglob("*")):
        if path.is_symlink():
            raise ValueError("Release payload cannot contain symlinks")
        if path.is_file():
            relative = nsis_literal(str(path.relative_to(payload)).replace("/", "\\"))
            lines.append(f'Delete "$INSTDIR\\{relative}"')
    directories = sorted((p for p in payload.rglob("*") if p.is_dir()),
                         key=lambda p: (-len(p.relative_to(payload).parts), p.as_posix()))
    for path in directories:
        relative = nsis_literal(str(path.relative_to(payload)).replace("/", "\\"))
        lines.append(f'RMDir "$INSTDIR\\{relative}"')
    return "\n".join(lines) + "\n"


def copy_notices(python_root: Path, destination: Path, nsis_license: Path | None) -> None:
    destination.mkdir()
    python_license = python_root / "LICENSE.txt"
    if not python_license.is_file():
        raise ValueError("Python redistribution license is required")
    shutil.copy2(python_license, destination / "Python-LICENSE.txt")
    packages = python_root / "Lib/site-packages"
    count = 0
    for distribution in sorted(packages.glob("*.dist-info")):
        for path in sorted(distribution.rglob("*")):
            if path.is_file() and any(word in path.name.upper()
                                      for word in ("LICENSE", "COPYING", "NOTICE")):
                target = destination / distribution.name / path.relative_to(distribution)
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(path, target)
                count += 1
    if count == 0:
        raise ValueError("Installed distribution license notices are missing")
    if nsis_license:
        shutil.copy2(nsis_license, destination / "NSIS-copyright.txt")
    (destination / "README.txt").write_text(
        "Original license and notice files from the verified Python build environment.\n"
        "Some notices belong to build tools rather than bundled runtime modules.\n"
        "PyInstaller's bootloader redistribution exception is in its COPYING.txt.\n",
        encoding="utf-8",
    )


def prepare(payload: Path, output: Path, python_root: Path,
            makensis: str, nsis_license: Path | None = None) -> dict[str, object]:
    payload = payload.resolve()
    output = output.resolve()
    require_amd64_pe(payload / "MalGuard.exe")
    if not (payload / "_internal").is_dir():
        raise ValueError("Complete onedir payload is required")
    if any(path.is_symlink() for path in payload.rglob("*")):
        raise ValueError("Release payload cannot contain symlinks")
    output.mkdir(parents=True, exist_ok=False)
    packaged = output / "MalGuard"
    shutil.copytree(payload, packaged)
    root = Path(__file__).resolve().parent
    shutil.copy2(root / "README-FA.txt", packaged / "README-FA.txt")
    copy_notices(python_root, packaged / "THIRD-PARTY-NOTICES", nsis_license)
    for path in sorted((root / "notices").iterdir()):
        shutil.copy2(path, packaged / "THIRD-PARTY-NOTICES" / path.name)
    records = [{"path": path.relative_to(packaged).as_posix(),
                "size": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
               for path in sorted(packaged.rglob("*")) if path.is_file()]
    (packaged / "release-files.json").write_text(
        json.dumps({"schema_version": 1, "engine_version": "1.0.0", "files": records},
                   ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    include = output / "owned-files.nsh"
    include.write_text(owned_files(packaged), encoding="utf-8")
    setup = output / "MalGuard-Setup-x64.exe"
    prefix = "/" if os.name == "nt" else "-"
    version = subprocess.run(  # noqa: S603 -- explicitly selected trusted build tool
        [makensis, prefix + "VERSION"], capture_output=True, text=True, check=True).stdout.strip()
    if not version.startswith("v3.11"):
        raise ValueError("The verified NSIS 3.11 build is required")
    definitions = {"PAYLOAD_DIR": packaged, "SETUP_PATH": setup, "OWNED_FILES": include}
    subprocess.run(  # noqa: S603 -- fixed installer script and validated trusted payload
        [makensis, prefix + "V2", *(prefix + "D" + key + "=" + nsis_literal(str(value))
                              for key, value in definitions.items()), str(root / "installer.nsi")],
        check=True,
    )
    require_amd64_pe(setup)
    portable = output / "MalGuard-Windows-x64.zip"
    with zipfile.ZipFile(portable, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(packaged.rglob("*")):
            if path.is_file():
                info = zipfile.ZipInfo("MalGuard/" + path.relative_to(packaged).as_posix(),
                                       date_time=(2026, 10, 5, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o100644 << 16
                archive.writestr(info, path.read_bytes())
    result: dict[str, object] = {
        "schema_version": 1, "engine_version": "1.0.0", "nsis_version": version,
        "architecture": "AMD64", "signed_executable": False,
        "files": [{"name": path.name, "size": path.stat().st_size,
                   "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
                  for path in (setup, portable, packaged / "MalGuard.exe")],
    }
    (output / "release-manifest.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8")
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--payload", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--python-root", required=True, type=Path)
    parser.add_argument("--makensis", required=True)
    parser.add_argument("--nsis-license", type=Path)
    arguments = parser.parse_args()
    print(json.dumps(prepare(arguments.payload, arguments.output, arguments.python_root,
                             arguments.makensis, arguments.nsis_license), indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
