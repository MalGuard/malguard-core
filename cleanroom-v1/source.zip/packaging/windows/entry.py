"""Fixed PyInstaller entry point; never interprets a scanned artifact."""

from malguard_cli.frozen import main

if __name__ == "__main__":
    raise SystemExit(main())
