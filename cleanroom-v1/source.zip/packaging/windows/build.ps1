[CmdletBinding()]
param(
    [string]$Python = "python",
    [Parameter(Mandatory = $true)][string]$MakeNsis,
    [Parameter(Mandatory = $true)][string]$NsisLicense,
    [Parameter(Mandatory = $true)][string]$Output,
    [string]$Wheelhouse = ""
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
$BuildRoot = Join-Path $ProjectRoot (".windows-build-" + [guid]::NewGuid().ToString("N"))

function Invoke-Checked {
    param([string]$Program, [string[]]$Arguments)
    & $Program @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "Trusted build command failed with exit code $LASTEXITCODE`: $Program"
    }
}

Invoke-Checked $Python @("-I", "-c", "import os, struct, sys; assert os.name == 'nt' and sys.version_info[:2] == (3, 12) and struct.calcsize('P') == 8, 'Windows x64 CPython 3.12 is required'")
if (Test-Path -LiteralPath $Output) { throw "Output must be a new release directory." }
$MakeNsis = (Resolve-Path -LiteralPath $MakeNsis).Path
$NsisLicense = (Resolve-Path -LiteralPath $NsisLicense).Path
New-Item -ItemType Directory -Path $BuildRoot | Out-Null
Invoke-Checked $Python @("-I", "-m", "venv", (Join-Path $BuildRoot "venv"))
$BuildPython = Join-Path $BuildRoot "venv\Scripts\python.exe"
$InstallOptions = @("-I", "-m", "pip", "install", "--require-hashes")
if ($Wheelhouse) {
    $Wheelhouse = (Resolve-Path -LiteralPath $Wheelhouse).Path
    $InstallOptions += @("--no-index", "--find-links", $Wheelhouse)
}
Invoke-Checked $BuildPython ($InstallOptions + @("-r", (Join-Path $ProjectRoot "requirements-lock.txt")))
Invoke-Checked $BuildPython ($InstallOptions + @("-r", (Join-Path $PSScriptRoot "build-requirements-lock.txt")))
Invoke-Checked $BuildPython @("-I", "-m", "pip", "install", "--no-deps", "--no-build-isolation", $ProjectRoot)
Invoke-Checked $BuildPython @("-I", "-m", "pip", "check")
Invoke-Checked $BuildPython @("-I", "-m", "PyInstaller", "--noconfirm", "--clean", "--distpath", (Join-Path $BuildRoot "dist"), "--workpath", (Join-Path $BuildRoot "work"), (Join-Path $PSScriptRoot "MalGuard.spec"))
Invoke-Checked (Join-Path $BuildRoot "dist\MalGuard\MalGuard.exe") @("--self-test")
$BasePython = & $BuildPython -I -c "import sys; print(sys.base_prefix)"
if ($LASTEXITCODE -ne 0) { throw "Could not determine trusted Python license location." }
Copy-Item -LiteralPath (Join-Path $BasePython "LICENSE.txt") -Destination (Join-Path $BuildRoot "venv\LICENSE.txt")
Invoke-Checked $BuildPython @("-I", (Join-Path $PSScriptRoot "package_release.py"), "--payload", (Join-Path $BuildRoot "dist\MalGuard"), "--output", $Output, "--python-root", (Join-Path $BuildRoot "venv"), "--makensis", $MakeNsis, "--nsis-license", $NsisLicense)
Write-Host "Windows artifacts are in $Output"
