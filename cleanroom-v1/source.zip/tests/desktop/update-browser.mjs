// Actual Python update jobs and signed inert fixtures through the desktop UI.
// Only the native UAC prompt, IPC and network transport are substituted.
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import http from 'node:http';
import {spawn} from 'node:child_process';
import {fileURLToPath,pathToFileURL} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');
const output=process.env.MALGUARD_UPDATE_QA_OUTPUT;
if(!output||!process.env.PLAYWRIGHT_MODULE)throw new Error('Set QA output and Playwright module');
const python=process.env.MALGUARD_PYTHON||'python';
const {chromium}=await import(pathToFileURL(process.env.PLAYWRIGHT_MODULE).href);
let page,scenario='new',pendingApproval=null,tests=0;
const stages=[],errors=[];
const check=(ok,message)=>{assert.ok(ok,message);tests++;};
async function driver(...args){return new Promise((resolve,reject)=>{
 const child=spawn(python,[path.join(root,'tests/desktop/update_driver.py'),args[0],output,...args.slice(1)],{cwd:root,stdio:['ignore','pipe','pipe']});
 let stdout='',pending='';
 child.stdout.on('data',data=>stdout+=data);
 child.stderr.on('data',data=>{
  pending+=data;const lines=pending.split('\n');pending=lines.pop();
  for(const line of lines){try{const event=JSON.parse(line);stages.push(event);page?.evaluate(p=>window.__emit('update-progress',p),event).catch(()=>{});}catch{}}
 });
 child.on('error',reject);child.on('exit',code=>{if(code)reject(new Error('Inert update driver failed'));else{try{resolve(stdout.trim()?JSON.parse(stdout):null);}catch(e){reject(e);}}});
});}
await driver('prepare');
const server=http.createServer(async(req,res)=>{
 const file={'/':'index.html','/app.js':'app.js','/app.css':'app.css'}[new URL(req.url,'http://localhost').pathname];
 if(!file){res.writeHead(404);res.end();return;}
 res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':file.endsWith('.css')?'text/css':'text/html');
 res.end(await fs.readFile(path.join(root,'desktop/ui',file)));
});
await new Promise(done=>server.listen(0,'127.0.0.1',done));
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true});
try{
 page=await browser.newPage({viewport:{width:900,height:850}});
 page.on('pageerror',e=>errors.push(e.message));
 await page.exposeBinding('__native',async(_source,name,args)=>{
  if(name==='release_info')return{build:'MG-1.3.2-WIN64-update-fixture'};
  if(name==='security_status')return driver('status');
  if(name==='refresh_security'){
   if(pendingApproval)await pendingApproval.promise;
   if(scenario==='cancel')throw new Error('UPDATE_APPROVAL_DECLINED');
   if(scenario==='timeout')throw new Error('UPDATE_TIMED_OUT');
   return driver('job',args.requestId,scenario);
  }
  throw new Error('Unexpected IPC command');
 });
 await page.addInitScript(()=>{
  const listeners=new Map();
  window.__emit=(name,payload)=>listeners.get(name)?.forEach(fn=>fn({payload}));
  window.__TAURI__={core:{invoke:(name,args)=>window.__native(name,args)},event:{listen:async(name,fn)=>{
   if(!listeners.has(name))listeners.set(name,[]);listeners.get(name).push(fn);return()=>{};
  }}};
 });
 await page.goto('http://127.0.0.1:'+server.address().port);
 await page.waitForFunction(()=>document.getElementById('updateStatus').textContent.includes('SHA-256'));
 check(await page.locator('#statusButton').count()===0,'There is one update action');
 pendingApproval={};pendingApproval.promise=new Promise(done=>pendingApproval.resolve=done);
 await page.click('#updateButton');
 check(await page.isVisible('#updateActivity'),'Animation starts during real approval wait');
 check(await page.locator('#updateButton').isDisabled(),'Second request is prevented');
 check((await page.textContent('#updateStatus')).includes('administrator'),'Approval is not reported as a download');
 await page.evaluate(()=>window.__emit('update-progress',{requestId:'12345678-abcd-abcd-abcd-123456789abc',stage:'installing'}));
 check((await page.textContent('#updateStatus')).includes('administrator'),'Other job telemetry ignored');
 pendingApproval.resolve();pendingApproval=null;
 await page.waitForFunction(()=>document.getElementById('updateTransfer').hasAttribute('value'));
 check((await page.textContent('#updateBytes')).includes('%'),'Real received byte percentage shown');
 await page.screenshot({path:path.join(output,'update-receiving-en.png')});
 await page.waitForFunction(()=>!document.getElementById('updateButton').disabled);
 check((await page.textContent('#updateStatus')).includes('1 new unique'),'One actual new hash reported');
 check(await page.textContent('#newHashCount')==='1','New count is one');
 check(await page.textContent('#knownHashCount')==='1','Previously present count is one');
 check(await page.textContent('#totalHashCount')==='2','Authenticated total is two');
 check(!await page.isVisible('#updateActivity'),'Working animation ends only after result');
 check(['downloading','verifying','comparing','installing'].every(s=>stages.some(p=>p.stage===s)),'Actual engine phases emitted');
 scenario='repeat';await page.click('#updateButton');
 await page.waitForFunction(()=>!document.getElementById('updateButton').disabled);
 check((await page.textContent('#updateStatus')).includes('No new information'),'Repeat reports already current');
 check(await page.textContent('#newHashCount')==='0'&&await page.textContent('#knownHashCount')==='2','Duplicates do not inflate new count');
 scenario='rules';await page.click('#updateButton');await page.waitForFunction(()=>!document.getElementById('updateButton').disabled);
 check((await page.textContent('#updateStatus')).includes('rules updated'),'Rules-only update is distinguished');
 const before=await fs.readFile(path.join(output,'cache/latest.json'));
 for(const mode of ['offline','tamper','cancel','timeout']){
  scenario=mode;await page.click('#updateButton');await page.waitForFunction(()=>!document.getElementById('updateButton').disabled);
  check(!await page.isVisible('#updateCounts'),mode+' does not publish success counts');
  check((await page.textContent('#updateStatus')).match(/did not complete|cancelled|time limit/),mode+' clearly explained');
  check((await fs.readFile(path.join(output,'cache/latest.json'))).equals(before),mode+' preserves verified cache');
 }
 scenario='unknown';await page.selectOption('#languageSelect','fa');await page.click('#updateButton');
 await page.waitForFunction(()=>document.getElementById('updateBytes').textContent.includes('اعلام نشده'));
 check(!await page.locator('#updateTransfer').getAttribute('value'),'Unknown size uses indeterminate progress');
 check((await page.textContent('#updateStage')).includes('دریافت'),'Persian shows actual download stage');
 await page.emulateMedia({reducedMotion:'reduce'});
 check(await page.locator('.update-orbit').evaluate(node=>getComputedStyle(node,'::before').animationName)==='none','Reduced motion respected');
 await page.screenshot({path:path.join(output,'update-receiving-fa.png')});
 await page.waitForFunction(()=>!document.getElementById('updateButton').disabled);
 check((await page.textContent('#updateStatus')).includes('اطلاعات جدید دریافت شد'),'Persian success result shown');
 check(await page.textContent('#newHashCount')==='۱'&&await page.textContent('#totalHashCount')==='۳','Persian uses actual new and total counts');
 scenario='unknown';await page.click('#updateButton');await page.waitForFunction(()=>!document.getElementById('updateButton').disabled);
 check((await page.textContent('#updateStatus')).includes('اطلاعات جدیدی وجود ندارد'),'Persian duplicate result matches request');
 await page.setViewportSize({width:700,height:850});
 check(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'RTL update layout fits desktop minimum width');
 await page.screenshot({path:path.join(output,'update-current-fa.png')});
 check(errors.length===0,'No page errors');
 await fs.writeFile(path.join(output,'update-qa.json'),JSON.stringify({passed:tests,errors,actual_signed_inert_jobs:true,stages:[...new Set(stages.map(s=>s.stage))]},null,2));
 console.log(JSON.stringify({passed:tests,actual_signed_inert_jobs:true,errors}));
}finally{await browser.close();await new Promise(done=>server.close(done));}
