/** Real Chromium UI + real installed Python engine. Only native picker, IPC,
 *  cache location and save dialog are substituted; no sample is executed.
 *  PLAYWRIGHT_MODULE must point to an installed pinned Playwright module.
 */
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import path from "node:path";
import os from "node:os";
import http from "node:http";
import { spawn } from "node:child_process";
import { fileURLToPath, pathToFileURL } from "node:url";
const root = path.resolve(
  path.dirname(fileURLToPath(import.meta.url)),
  "../..",
);
const output = path.resolve(
  process.env.MALGUARD_QA_OUTPUT ||
    path.join(os.tmpdir(), "malguard-desktop-qa"),
);
const python = process.env.MALGUARD_PYTHON || "python";
const feed = process.env.MALGUARD_QA_FEED;
if (!feed || !process.env.PLAYWRIGHT_MODULE)
  throw new Error("Set MALGUARD_QA_FEED and PLAYWRIGHT_MODULE");
const { chromium } = await import(
  pathToFileURL(process.env.PLAYWRIGHT_MODULE).href
);
await fs.mkdir(output, { recursive: true });
const cache = path.join(output, "cache");
await fs.mkdir(cache, { recursive: true, mode: 0o700 });
await fs.chmod(cache, 0o700);
await fs.copyFile(feed, path.join(cache, "latest.json"));
const fixtures = path.join(output, "fixtures");
await fs.mkdir(fixtures, { recursive: true });
for (const [name, data] of [
  [
    "notes.txt",
    'Plain text fixture.\npassword="private-value-12345678"\nHello.',
  ],
  ["fake.asi", "Harmless plain text, not a plugin."],
  ["mod.lua", "print('harmless fixture')"],
  [
    "attack-text.txt",
    "<img src=x onerror=globalThis.compromised=true>\n<script>alert(1)</script>",
  ],
  [
    "harmful.bin",
    "Login Data\0Local State\0password_value\0CryptUnprotectData\0HttpSendRequest\0POST\0",
  ],
])
  await fs.writeFile(path.join(fixtures, name), data);
await fs.writeFile(
  path.join(fixtures, "sound.wav"),
  Buffer.concat([
    Buffer.from("RIFF"),
    Buffer.from([196, 0, 0, 0]),
    Buffer.from("WAVEfmt "),
    Buffer.alloc(188),
  ]),
);
const cli =
  "from pathlib import Path; import sys; from malguard_cli import desktop; from malguard_core.updates import load_cached; desktop.load_cached=lambda:load_cached(Path(sys.argv[1])); raise SystemExit(desktop.main(sys.argv[2:]))";
let page,
  chosen = "notes.txt",
  gate = null,
  lastScan = null;
const stages = [],
  results = [],
  errors = [];
let savedCard = null,
  savedReport = null,
  tests = 0;
const check = (value, message) => {
  assert.ok(value, message);
  tests++;
};
async function engine(mode, file, scanId) {
  return await new Promise((resolve, reject) => {
    const child = spawn(
      python,
      ["-I", "-c", cli, cache, mode, ...(file ? [file] : [])],
      { cwd: root, stdio: ["ignore", "pipe", "pipe"] },
    );
    let stdout = "",
      stderr = "",
      pending = "";
    child.stdout.on("data", (data) => (stdout += data));
    child.stderr.on("data", (data) => {
      stderr += data;
      pending += data;
      const lines = pending.split("\n");
      pending = lines.pop();
      for (const line of lines) {
        try {
          const event = JSON.parse(line);
          if (event.event === "scan_stage") {
            stages.push({ scanId, stage: event.stage });
            page
              ?.evaluate((payload) => window.__emitScan(payload), {
                scanId,
                stage: event.stage,
              })
              .catch(() => {});
          }
        } catch {}
      }
    });
    child.on("error", reject);
    child.on("exit", (code) => {
      if (code) reject(new Error(stderr || "Engine failed"));
      else
        try {
          resolve(JSON.parse(stdout));
        } catch (error) {
          reject(error);
        }
    });
  });
}
const server = http.createServer(async (req, res) => {
  const name = new URL(req.url, "http://localhost").pathname;
  const files = {
    "/": "index.html",
    "/app.css": "app.css",
    "/app.js": "app.js",
  };
  if (!files[name]) {
    res.writeHead(404);
    res.end();
    return;
  }
  res.setHeader(
    "Content-Type",
    name.endsWith(".js")
      ? "text/javascript"
      : name.endsWith(".css")
        ? "text/css"
        : "text/html",
  );
  res.setHeader(
    "Content-Security-Policy",
    "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'none'; object-src 'none'; frame-src 'none'; base-uri 'none'; form-action 'none'",
  );
  res.end(await fs.readFile(path.join(root, "desktop/ui", files[name])));
});
await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
const url = "http://127.0.0.1:" + server.address().port;
const browser = await chromium.launch({
  executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium",
  headless: true,
});
try {
  const context = await browser.newContext({
    viewport: { width: 1120, height: 900 },
  });
  page = await context.newPage();
  page.on("pageerror", (e) => errors.push(String(e)));
  page.on("dialog", async (dialog) => {
    errors.push("Unexpected dialog: " + dialog.message());
    await dialog.dismiss();
  });
  await page.route("**/*", (route) =>
    route.request().url().startsWith(url) ? route.continue() : route.abort(),
  );
  await page.exposeBinding("__nativeInvoke", async (_source, name, args) => {
    if (name === "release_info") return { build: "MG-1.3.1-WIN64-development" };
    if (name === "security_status") return engine("--security-status");
    if (name === "choose_file") return path.join(fixtures, chosen);
    if (name === "refresh_security") return null;
    if (name === "scan_selected") {
      if (gate) await gate.promise;
      lastScan = await engine(
        "--desktop-scan",
        path.join(fixtures, chosen),
        args.scanId,
      );
      results.push({
        file: chosen,
        verdict: lastScan.report.verdict,
        type: lastScan.file_inspection.detected_type,
        scope: lastScan.file_inspection.scope_state,
      });
      return lastScan;
    }
    if (name === "save_report") {
      savedReport = lastScan;
      await fs.writeFile(
        path.join(output, "report.json"),
        JSON.stringify(savedReport, null, 2),
      );
      return true;
    }
    if (name === "save_card") {
      savedCard = Buffer.from(args.bytes);
      await fs.writeFile(path.join(output, "report-card.png"), savedCard);
      return true;
    }
    throw new Error("Unknown command " + name);
  });
  await page.addInitScript(() => {
    const listeners = [];
    window.__emitScan = (payload) => listeners.forEach((fn) => fn({ payload }));
    window.__TAURI__ = {
      core: { invoke: (name, args) => window.__nativeInvoke(name, args) },
      event: {
        listen: async (name, fn) => {
          if (name !== "scan-progress") throw new Error("Unknown event");
          listeners.push(fn);
          return () => {};
        },
      },
    };
  });
  await page.goto(url);
  await page.waitForFunction(() =>
    document.getElementById("updateStatus").textContent.includes("SHA-256"),
  );
  check((await page.getAttribute("html", "lang")) === "en", "English default");
  const verifiedStatus = await engine("--security-status");
  check(
    verifiedStatus.available && verifiedStatus.fresh && verifiedStatus.record_count > 0 &&
      (await page.textContent("#updateStatus")).includes(
        new Intl.NumberFormat("en-US").format(verifiedStatus.record_count),
      ),
    "Fresh signed feed and its actual authenticated count are displayed",
  );
  await page.locator(".update-details summary").click();
  check(
    (await page.textContent("#updateFacts")).includes(
      "malguard-online-2026-10",
    ),
    "Pinned signer exposed",
  );
  check(
    (await page.textContent(".update-details")).includes("Windows local time"),
    "Schedule explains local time",
  );
  await page.locator(".update-details summary").click();
  await page.screenshot({
    path: path.join(output, "ready-en.png"),
    fullPage: true,
    animations: "disabled",
  });
  await page.click("#chooseButton");
  gate = {};
  gate.promise = new Promise((resolve) => (gate.resolve = resolve));
  await page.click("#scanButton");
  await page.waitForFunction(
    () => document.getElementById("scanShell").dataset.phase === "scanning",
  );
  check(await page.isDisabled("#chooseButton"), "No selection races");
  check(
    (await page.textContent("#progressStage")) === "Starting local engine",
    "No fabricated stage before engine telemetry",
  );
  await page.evaluate(() =>
    window.__emitScan({ scanId: "old-scan", stage: "pe" }),
  );
  check(
    (await page.textContent("#progressStage")) === "Starting local engine",
    "Stale progress ignored",
  );
  await page.screenshot({
    path: path.join(output, "scanning-en.png"),
    fullPage: true,
    animations: "disabled",
  });
  gate.resolve();
  gate = null;
  await page.waitForFunction(
    () => document.getElementById("scanShell").dataset.phase === "complete",
  );
  check(lastScan.report.verdict === "INCONCLUSIVE", "Plain text never SAFE");
  check(await page.isVisible("#fileWarning"), "Specific red warning");
  check(
    (await page.textContent("#warningFacts")).includes("Plain text"),
    "Byte type in warning",
  );
  check(
    (await page.textContent("#riskGauge")).includes("Unknown"),
    "Unmeasured risk is unknown",
  );
  check(
    (await page.locator("#riskGauge .gauge-needle").count()) === 0,
    "Unknown is not a false zero needle",
  );
  check(
    stages.some((x) => x.stage === "strings") &&
      !stages.some((x) => x.stage === "pe"),
    "Only actual applicable stages emitted",
  );
  await page.screenshot({
    path: path.join(output, "text-result-en.png"),
    fullPage: true,
    animations: "disabled",
  });
  await page.click("#detailsButton");
  check(
    (await page.getAttribute("#detailsButton", "aria-expanded")) === "true",
    "Card flips open",
  );
  check(
    await page.evaluate(() => document.getElementById("resultFront").inert),
    "Hidden face cannot receive focus",
  );
  check(
    !(await page.textContent("#contentPreview")).includes("private-value"),
    "Secrets redacted",
  );
  check(
    (await page.textContent("#contentPreview")).includes("[REDACTED]"),
    "Redaction visible",
  );
  await page.screenshot({
    path: path.join(output, "card-en.png"),
    fullPage: true,
    animations: "disabled",
  });
  await page.click("#downloadCard");
  await page.waitForFunction(() =>
    document.getElementById("scanStatus").textContent.includes("PNG"),
  );
  check(
    savedCard
      .subarray(0, 8)
      .equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])),
    "Real PNG saved",
  );
  check(
    savedCard.readUInt32BE(16) === 1200 && savedCard.readUInt32BE(20) <= 2600,
    "Bounded card dimensions",
  );
  await page.click("#saveButton");
  check(
    savedReport.file_inspection.scope_state === "unsupported",
    "Full JSON includes byte description",
  );
  await page.selectOption("#languageSelect", "fa");
  check((await page.getAttribute("html", "dir")) === "rtl", "Persian RTL");
  check(
    (await page.textContent("#cardVerdict")).includes("خارج از پوشش"),
    "Localized accurate verdict",
  );
  await page.screenshot({
    path: path.join(output, "card-fa.png"),
    fullPage: true,
    animations: "disabled",
  });
  await page.click("#downloadCard");
  await page.waitForFunction(
    () => !document.getElementById("downloadCard").disabled,
  );
  await fs.copyFile(
    path.join(output, "report-card.png"),
    path.join(output, "report-card-fa.png"),
  );
  await page.click("#backButton");
  check(
    (await page.getAttribute("#detailsButton", "aria-expanded")) === "false",
    "Card returns to compact result",
  );
  for (const [file, type, verdict] of [
    ["fake.asi", "TEXT", "INVALID"],
    ["sound.wav", "WAVE_AUDIO", "INCONCLUSIVE"],
    ["mod.lua", "LUA_SOURCE", "SAFE"],
    ["harmful.bin", "UNKNOWN", "MALICIOUS"],
    ["attack-text.txt", "TEXT", "INCONCLUSIVE"],
  ]) {
    chosen = file;
    await page.click("#chooseButton");
    check(
      (await page.getAttribute("#scanShell", "data-phase")) === "ready",
      "New selection clears previous result",
    );
    await page.click("#scanButton");
    await page.waitForFunction(
      () => document.getElementById("scanShell").dataset.phase === "complete",
      {},
      { timeout: 30000 },
    );
    check(lastScan.report.verdict === verdict, file + " actual verdict");
    check(
      lastScan.file_inspection.detected_type === type,
      file + " actual type",
    );
    if (verdict === "SAFE") {
      check(
        await page.isHidden("#fileWarning"),
        "Valid supported script has no unsupported warning",
      );
      check(
        (await page.locator("#riskGauge .gauge-needle").count()) === 1,
        "Measured evidence score uses needle",
      );
    }
    if (file === "sound.wav")
      check(
        (await page.textContent("#warningReason")).includes("سرآیند"),
        "Audio header limitation explained",
      );
    if (file === "harmful.bin") {
      check(lastScan.report.risk_score > 0, "Real malicious score retained");
      await page.click("#detailsButton");
      check(
        (await page.textContent("#evidenceList")).includes(
          lastScan.report.evidence[0].rule_id,
        ),
        "Evidence identifiers retained",
      );
      await page.screenshot({
        path: path.join(output, "malicious-card-fa.png"),
        fullPage: true,
        animations: "disabled",
      });
      await page.click("#backButton");
    }
    if (file === "attack-text.txt") {
      await page.click("#detailsButton");
      check(
        (await page.locator("#contentPreview img").count()) === 0,
        "Sample markup displayed only as text",
      );
      check(
        !(await page.evaluate(() => window.compromised)),
        "No sample script execution",
      );
      await page.click("#backButton");
    }
  }
  await page.setViewportSize({ width: 700, height: 800 });
  await page.screenshot({
    path: path.join(output, "compact-fa.png"),
    fullPage: true,
    animations: "disabled",
  });
  check(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
    "No minimum-window horizontal overflow",
  );
  await page.emulateMedia({ reducedMotion: "reduce" });
  chosen = "mod.lua";
  await page.click("#chooseButton");
  await page.click("#scanButton");
  await page.waitForFunction(
    () => document.getElementById("scanShell").dataset.phase === "complete",
  );
  await page.click("#detailsButton");
  check(
    await page.isVisible("#reportCard"),
    "Card accessible with reduced motion",
  );
  check(
    (await page.evaluate(
      () =>
        getComputedStyle(document.getElementById("reportFlip"))
          .transitionDuration,
    )) === "0s",
    "Reduced motion respected",
  );
  const corrupted = JSON.parse(
    await fs.readFile(path.join(cache, "latest.json"), "utf8"),
  );
  corrupted.signature_b64 = Buffer.alloc(64).toString("base64");
  await fs.writeFile(
    path.join(cache, "latest.json"),
    JSON.stringify(corrupted),
  );
  await page.click("#statusButton");
  await page.waitForFunction(
    () => !document.getElementById("statusButton").disabled,
  );
  check(
    !(await page.textContent("#updateStatus")).includes("1,342"),
    "Invalid signature cannot retain a verified count",
  );
  check(
    (await page.textContent("#updateStatus")).includes("تأییدشده"),
    "Missing authenticated cache is explained",
  );
  await page.click("#chooseButton");
  await page.click("#scanButton");
  await page.waitForFunction(
    () => document.getElementById("scanShell").dataset.phase === "complete",
  );
  check(
    lastScan.report.verdict === "INCONCLUSIVE",
    "Tampered online cache blocks SAFE for a benign supported script",
  );
  check(
    !lastScan.updates.signature_verified,
    "Bad signature is never reported as verified",
  );
  check(
    (await page.locator("#riskGauge .gauge-needle").count()) === 0,
    "Missing trust uses an unknown gauge",
  );
  await fs.copyFile(feed, path.join(cache, "latest.json"));
  chosen = "removed-before-scan.txt";
  await page.click("#chooseButton");
  await page.click("#scanButton");
  await page.waitForFunction(
    () => document.getElementById("scanShell").dataset.phase === "complete",
  );
  check(
    lastScan.report.verdict === "INCONCLUSIVE",
    "Unavailable file receives no approval",
  );
  check(
    lastScan.file_inspection.size_known === false,
    "Unread file size is unknown, not invented zero",
  );
  check(
    (await page.textContent("#warningFacts")).includes("نامشخص"),
    "Unknown size is explained in the warning",
  );
  check(
    errors.length === 0,
    "No JavaScript errors or unexpected dialogs: " + errors.join("; "),
  );
  await fs.writeFile(
    path.join(output, "browser-results.json"),
    JSON.stringify(
      {
        checks: tests,
        engine: "actual installed Python scanner",
        native: "picker, IPC, cache path and save dialog substituted",
        results,
        stages,
        errors,
      },
      null,
      2,
    ),
  );
  console.log(
    JSON.stringify({ checks: tests, results, errors, output }, null, 2),
  );
} finally {
  await browser.close();
  await new Promise((resolve) => server.close(resolve));
}
