"""Inert signed fixtures for browser update QA; never used by production code."""
import base64
import importlib.util
import io
import json
import sys
import time
from datetime import UTC, datetime
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, NoEncryption, PrivateFormat, PublicFormat

from malguard_core.integrity import ProtectedEpochState
from malguard_core.reputation.trust import PUBLIC_KEYS
import malguard_core.updates as updates
import malguard_core.updates.desktop as jobs


def main():
    mode, output, *args = sys.argv[1:]
    root = Path(output)
    cache = root / "cache"
    root.mkdir(parents=True, exist_ok=True)
    if mode == "prepare":
        key = Ed25519PrivateKey.generate()
        (root / "public-key").write_bytes(key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw))
        PUBLIC_KEYS["malguard-online-2026-10"] = (root / "public-key").read_bytes()
        source = Path(__file__).resolve().parents[2] / "packaging/online/publish_feed.py"
        spec = importlib.util.spec_from_file_location("fixture_publisher", source)
        assert spec and spec.loader
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        rules = (source.parents[2] / "rules/gta_guard.yar").read_bytes()
        private = key.private_bytes(Encoding.Raw, PrivateFormat.Raw, NoEncryption())
        previous = None
        for index, hashes in enumerate([["a"*64], ["a"*64, "b"*64], ["a"*64, "b"*64],
                                        ["a"*64, "b"*64, "c"*64]]):
            metadata = json.dumps({"query_status": "ok", "data": [{"sha256_hash": h} for h in hashes]}).encode()
            snapshot = module.build_snapshot(metadata, private, index+100, datetime.now(UTC),
                rules + (b"\n// inert rules change\n" if index >= 2 else b""), previous)
            previous = json.dumps(snapshot).encode()
            (root / f"feed-{index}.json").write_bytes(previous)
        PUBLIC_KEYS["malguard-online-2026-10"] = (root / "public-key").read_bytes()
        updates.install((root / "feed-0.json").read_bytes(), cache, ProtectedEpochState(root / "epochs"))
        return
    PUBLIC_KEYS["malguard-online-2026-10"] = (root / "public-key").read_bytes()
    updates.default_cache_directory = lambda: cache
    jobs.default_cache_directory = lambda: cache
    updates.ProtectedEpochState = lambda: ProtectedEpochState(root / "epochs")
    if mode == "status":
        print(json.dumps(updates.status_json(updates.load_cached(cache)[1])))
        return
    request_id, scenario = args
    payload = (root / ("feed-3.json" if scenario == "unknown" else
                       "feed-2.json" if scenario == "rules" else "feed-1.json")).read_bytes()
    if scenario == "tamper":
        parsed = json.loads(payload)
        parsed["signature_b64"] = base64.b64encode(bytes(64)).decode()
        payload = json.dumps(parsed).encode()
    class Response(io.BytesIO):
        status = 200
        headers = {} if scenario == "unknown" else {"Content-Length": str(len(payload))}
        def read(self, limit=-1):
            time.sleep(0.05)
            return super().read(min(limit, 4096))
    class Opener:
        def open(self, request, timeout):
            if scenario == "offline":
                raise OSError("Inert offline fixture")
            return Response(payload)
    updates.build_opener = lambda *unused: Opener()
    notify = updates._notify
    def telemetry(progress, stage, **values):
        notify(progress, stage, **values)
        print(json.dumps({"requestId": request_id, "stage": stage, **values}), file=sys.stderr, flush=True)
        time.sleep(0.06)
    updates._notify = telemetry
    jobs.run_job(request_id)
    print(json.dumps(jobs.read_job(request_id)))


if __name__ == "__main__":
    main()
