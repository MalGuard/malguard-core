"""Synthetic raw facts, failure handling, and opacity-only YARA coverage."""

from malguard_core.budget import BudgetLedger
from malguard_core.model import CoverageState, ErrorCode, EvidenceDomain
from malguard_core.rules import analyze


def ledger(size=100000):
    return BudgetLedger({"yara_bytes": size, "parser_iterations": 1000, "evidence": 1000})


def test_yara_harm_independent_families():
    data = b"Login Data Local State CryptUnprotectData password_value UploadData"
    result = analyze(data, "fixture", "fixture.asi", ledger())
    assert result.state == CoverageState.COMPLETE
    assert {e.family for e in result.evidence} >= {"CREDENTIAL_ACCESS", "EXFILTRATION"}
    assert all(e.domain == EvidenceDomain.HARM for e in result.evidence)


def test_yara_http_browser_path_and_api_alone_are_weak():
    for data in (b"https://github.com/example", b"Login Data", b"VirtualAlloc", b"Process.Start"):
        assert not analyze(data, "fixture", "fixture.dll", ledger()).evidence


def test_yara_protector_only_is_opacity():
    result = analyze(b"UPX! VMProtect ConfuserEx", "fixture", "fixture.dll", ledger())
    assert result.evidence
    assert all(e.domain == EvidenceDomain.OPACITY for e in result.evidence)


def test_yara_work_limit_is_distinct_from_wallclock():
    result = analyze(b"harmless", "fixture", "fixture.txt", ledger(1))
    assert result.state == CoverageState.SKIPPED_LIMIT
    assert result.errors == (ErrorCode.ITERATION_BUDGET_EXHAUSTED,)


def test_yara_unsigned_source_fails_closed():
    result = analyze(b"harmless", "fixture", "fixture.txt", ledger(), rules_source="rule hidden { condition: false }")
    assert result.state == CoverageState.FAILED
    assert result.errors == (ErrorCode.INTEGRITY_FAILURE,)


def test_yara_signed_snapshot_has_same_detections():
    from malguard_core.reputation import load_default_store
    from malguard_core.integrity import bundle_snapshot
    data = b"Login Data CryptUnprotectData password_value UploadData"
    default = analyze(data, "fixture", "fixture.dll", ledger())
    update = analyze(data, "fixture", "fixture.dll", ledger(), bundle_snapshot(load_default_store().bundle))
    assert default == update


def test_yara_source_comment_and_literal_do_not_become_harm():
    for data in (
        b"/* Login Data CryptUnprotectData password_value UploadData */ class Example {}",
        b'const string example = "Login Data CryptUnprotectData password_value UploadData";',
    ):
        result = analyze(data, "fixture", "fixture.cs", ledger())
        assert result.evidence
        assert all(e.domain == EvidenceDomain.CONTEXT and e.base_weight == 0 for e in result.evidence)


def test_yara_source_calls_preserve_harm_and_broken_lexing_never_erases_it():
    for data in (
        b'var store = File.ReadAllBytes("Login Data"); var password_value = CryptUnprotectData(store); UploadData(password_value);',
        b'/* Login Data CryptUnprotectData password_value UploadData',
        b'MZ /* Login Data CryptUnprotectData password_value UploadData */',
        b'const string target = "Login Data CryptUnprotectData password_value UploadData"; GetMethod(target).Invoke();',
    ):
        result = analyze(data, "fixture", "fixture.cs", ledger())
        assert {e.family for e in result.evidence if e.domain == EvidenceDomain.HARM} >= {"CREDENTIAL_ACCESS", "EXFILTRATION"}


def test_yara_source_lexer_budget_failure_retains_collected_harm():
    budget = BudgetLedger({"yara_bytes": 10000, "parser_iterations": 3, "evidence": 100})
    data = b'const string example = "Login Data CryptUnprotectData password_value UploadData";'
    result = analyze(data, "fixture", "fixture.cs", budget)
    assert result.state == CoverageState.SKIPPED_LIMIT
    assert {e.family for e in result.evidence} >= {"CREDENTIAL_ACCESS", "EXFILTRATION"}
