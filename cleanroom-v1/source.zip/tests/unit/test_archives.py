"""Bounded hostile archive checks using only generated inert payloads."""

import base64
import struct
import zipfile

import pytest

from malguard_core.archives import analyze, normalize_member_name
from malguard_core.budget import BudgetLedger
from malguard_core.model import CoverageState, ErrorCode
from tests.builders.archive_fixtures import (
    central_local_mismatch, central_offsets, descriptor_zip, encrypted_zip, overlapping_zip,
    rar4_stored, seven_zip_bytes, zip_bytes, zip64_overflow, zip64_stored,
)


def scan(data: bytes, **kwargs):
    return analyze(data, "synthetic-archive", "mod.zip", BudgetLedger(), **kwargs)


@pytest.mark.parametrize("compression", [zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED])
def test_zip_harmless_member(compression):
    result = scan(zip_bytes([("scripts/main.lua", b"print('harmless')")], compression=compression))
    assert result.state is CoverageState.COMPLETE
    child = result.facts["children"][0]
    assert child["readable"]
    assert base64.b64decode(child["data_b64"]) == b"print('harmless')"


def test_empty_zip_is_complete():
    assert scan(zip_bytes([])).state is CoverageState.COMPLETE


@pytest.mark.parametrize("zip64", [False, True])
def test_zip_descriptor_stream(zip64):
    result = scan(descriptor_zip(zip64=zip64))
    assert result.state is CoverageState.COMPLETE
    assert result.facts["children"][0]["readable"]


def test_valid_zip64_bounds():
    result = scan(zip64_stored())
    assert result.state is CoverageState.COMPLETE
    assert base64.b64decode(result.facts["children"][0]["data_b64"]) == b"return 0"


@pytest.mark.parametrize("name", ["../escape.lua", "/absolute.lua", "C:\\escape.lua", "safe.lua:secret",
                                  "\\\\?\\C:\\device.lua", "AUX.lua", "folder/../../escape.lua"])
def test_zip_unsafe_paths_are_labels_only(name, tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    result = scan(zip_bytes([(name, b"print('harmless')")]))
    assert result.state is not CoverageState.COMPLETE
    assert result.facts["malformed"]
    assert any(e.rule_id == "MG.ARCHIVE.UNSAFE_PATH" for e in result.evidence)
    assert list(tmp_path.iterdir()) == []


@pytest.mark.parametrize("names", [("same.lua", "same.lua"), ("MOD.LUA", "mod.lua"),
                                   ("caf\u00e9.lua", "cafe\u0301.lua"), ("dir/a.lua", "dir\\a.lua"),
                                   ("name.lua", "name.lua. ")])
def test_duplicate_or_normalized_collision_blocks_clean(names):
    result = scan(zip_bytes([(name, b"return 0") for name in names]))
    assert result.facts["parser_disagreement"]
    assert result.facts["incomplete_children"]


def test_overlap_is_rejected_and_not_decompressed():
    result = scan(overlapping_zip())
    assert ErrorCode.PARSER_DISAGREEMENT in result.errors
    assert not any(child["readable"] for child in result.facts["children"])


def test_central_local_mismatch_blocks_clean():
    result = scan(central_local_mismatch())
    assert result.facts["parser_disagreement"]
    assert not result.facts["children"][0]["readable"]


def test_zip64_abuse_is_bounded():
    result = scan(zip64_overflow())
    assert result.facts["malformed"]
    assert ErrorCode.MALFORMED_INPUT in result.errors


def test_encrypted_member_blocks_clean():
    result = scan(encrypted_zip())
    assert result.state is CoverageState.BLOCKED
    assert ErrorCode.ENCRYPTED_MEMBER in result.errors
    assert result.facts["children"][0]["encrypted"]


def test_bomb_ratio_is_prechecked():
    result = scan(zip_bytes([("large.cfg", b"0" * (2 * 1024 * 1024))], compression=zipfile.ZIP_DEFLATED))
    assert result.state is CoverageState.SKIPPED_LIMIT
    assert result.facts["children"][0]["reason"] == "compression_ratio_limit"


def test_shared_expansion_budget_retains_completed_children():
    ledger = BudgetLedger({"decompressed_bytes": 12})
    result = analyze(zip_bytes([("one.lua", b"return 0"), ("two.lua", b"return 1")]),
                     "a", "mod.zip", ledger)
    assert result.state is CoverageState.SKIPPED_LIMIT
    assert result.facts["children"][0]["readable"]
    assert not result.facts["children"][1]["readable"]
    assert ledger.consumed("decompressed_bytes") == 8


def test_global_entries_not_reset_per_child():
    ledger = BudgetLedger({"archive_entries": 1})
    outer = analyze(zip_bytes([("inner.zip", zip_bytes([("safe.lua", b"return 0")]))]), "a", "mod.zip", ledger)
    inner_data = base64.b64decode(outer.facts["children"][0]["data_b64"])
    inner = analyze(inner_data, "b", "mod.zip!/inner.zip", ledger, depth=1)
    assert inner.state is CoverageState.SKIPPED_LIMIT
    assert ledger.consumed("archive_entries") == 1


def test_recursion_limit_is_deterministic():
    result = scan(zip_bytes([("safe.lua", b"return 0")]), depth=4, max_depth=4)
    assert result.state is CoverageState.SKIPPED_LIMIT
    assert ErrorCode.ITERATION_BUDGET_EXHAUSTED in result.errors


def test_nested_zip_and_7z_are_returned_for_normal_pipeline():
    inner = seven_zip_bytes([("main.lua", b"return 0")])
    outer = scan(zip_bytes([("assets.7z", inner)]))
    inner_result = analyze(base64.b64decode(outer.facts["children"][0]["data_b64"]),
                           "inner", "mod.zip!/assets.7z", BudgetLedger(), depth=1)
    assert inner_result.state is CoverageState.COMPLETE
    assert inner_result.facts["archive_type"] == "7Z"
    assert base64.b64decode(inner_result.facts["children"][0]["data_b64"]) == b"return 0"


def test_7z_uses_memory_factory_and_leaves_workspace_empty(tmp_path, monkeypatch):
    data = seven_zip_bytes([("scripts/main.lua", b"return 0"), ("docs/readme.txt", b"harmless")])
    monkeypatch.chdir(tmp_path)
    result = scan(data)
    assert result.state is CoverageState.COMPLETE
    assert all(item["readable"] for item in result.facts["children"])
    assert list(tmp_path.iterdir()) == []


def test_encrypted_7z_is_blocked():
    result = scan(seven_zip_bytes([("main.lua", b"return 0")], encrypted=True))
    assert result.state is CoverageState.BLOCKED
    assert ErrorCode.ENCRYPTED_MEMBER in result.errors


def test_corrupt_7z_crc_is_rejected():
    data = bytearray(seven_zip_bytes([("main.lua", b"return 0")]))
    data[8] ^= 1
    assert scan(bytes(data)).facts["malformed"]


def test_stored_rar4_without_external_tool(tmp_path, monkeypatch):
    import subprocess
    monkeypatch.setattr(subprocess, "Popen", lambda *a, **k: pytest.fail("external extractor invoked"))
    monkeypatch.chdir(tmp_path)
    result = scan(rar4_stored([("main.lua", b"return 0")]))
    assert result.state is CoverageState.COMPLETE
    assert base64.b64decode(result.facts["children"][0]["data_b64"]) == b"return 0"
    assert list(tmp_path.iterdir()) == []


@pytest.mark.parametrize("options", [{"encrypted": True}, {"compressed": True}])
def test_rar_unsupported_or_encrypted_never_invokes_tool(options, monkeypatch):
    import subprocess
    monkeypatch.setattr(subprocess, "Popen", lambda *a, **k: pytest.fail("external extractor invoked"))
    result = scan(rar4_stored([("main.lua", b"return 0")], **options))
    assert result.state is CoverageState.BLOCKED
    assert not result.facts["children"][0]["readable"]


def test_rar5_is_explicitly_unsupported():
    result = scan(b"Rar!\x1a\x07\x01\x00")
    assert result.state is CoverageState.BLOCKED
    assert ErrorCode.UNSUPPORTED_FORMAT in result.errors


@pytest.mark.parametrize("data", [b"PK\x03\x04", b"PK\x05\x06", b"7z\xbc\xaf\x27\x1c", b"Rar!\x1a\x07\x00"])
def test_truncated_archives_do_not_crash(data):
    assert scan(data).state is not CoverageState.COMPLETE


def test_member_crc_failure_preserves_other_member():
    data = bytearray(zip_bytes([("good.lua", b"return 0"), ("bad.lua", b"return 1")]))
    second = data.find(b"PK\x03\x04", 1)
    name_len, extra_len = struct.unpack_from("<HH", data, second + 26)
    data[second + 30 + name_len + extra_len] ^= 1
    result = scan(bytes(data))
    assert result.facts["children"][0]["readable"]
    assert not result.facts["children"][1]["readable"]
    assert result.facts["incomplete_children"]


def test_unsupported_zip_method_is_unreadable():
    result = scan(zip_bytes([("main.lua", b"return 0")], compression=zipfile.ZIP_BZIP2))
    assert result.state is CoverageState.BLOCKED
    assert ErrorCode.UNSUPPORTED_FORMAT in result.errors


def test_windows_name_normalization():
    assert normalize_member_name("Folder\\NAME.LUA. ")[0] == "folder/name.lua"


def test_later_corrupt_central_record_retains_first_valid_member():
    data = bytearray(zip_bytes([("first.lua", b"return 0"), ("second.lua", b"return 1")]))
    data[central_offsets(data)[1]] ^= 1
    result = scan(bytes(data))
    assert result.facts["parser_disagreement"]
    assert result.facts["children"][0]["readable"]
    assert base64.b64decode(result.facts["children"][0]["data_b64"]) == b"return 0"


def test_nonempty_directory_payload_is_analyzed_but_blocks_clean():
    result = scan(zip_bytes([("directory/", b"return 0")]))
    assert result.facts["malformed"]
    assert result.facts["children"][0]["readable"]


def test_unindexed_local_payload_blocks_clean():
    data = bytearray(zip_bytes([("visible.lua", b"return 0")]))
    central = central_offsets(data)[0]
    gap = b"unindexed harmless synthetic data"
    data[central:central] = gap
    end = data.rfind(b"PK\x05\x06")
    struct.pack_into("<I", data, end + 16, central + len(gap))
    result = scan(bytes(data))
    assert result.facts["parser_disagreement"]
    assert result.facts["children"][0]["readable"]


def test_result_payload_limit_preserves_first_completed_member(monkeypatch):
    import malguard_core.archives as archive_module
    monkeypatch.setattr(archive_module, "_MAX_RESULT", 8000)
    result = scan(zip_bytes([("one.lua", b"a" * 1500), ("two.lua", b"b" * 1500)]))
    assert result.state is CoverageState.SKIPPED_LIMIT
    assert result.facts["children"][0]["readable"]
    assert not result.facts["children"][1]["readable"]


def test_overlong_filename_report_fields_are_bounded():
    result = scan(zip_bytes([("a" * 20000 + ".lua", b"return 0")]))
    assert result.facts["malformed"]
    assert len(result.facts["children"][0]["member_name"]) <= 4096
    assert all(len(e.location.member or "") <= 4096 for e in result.evidence)


@pytest.mark.parametrize("fixture", [zip_bytes([("safe.lua", b"return 0")]), encrypted_zip(),
                                     central_local_mismatch(), rar4_stored([("safe.lua", b"return 0")])])
def test_isolated_worker_archive_protocol_and_budget_roundtrip(fixture):
    from malguard_core.settings import ScanSettings
    from malguard_core.workers import WorkerPool
    ledger = BudgetLedger()
    with WorkerPool(ScanSettings()) as pool:
        result = pool.run("archives", fixture, "worker-archive", "mod.zip", ledger,
                          {"depth": 0, "max_depth": 4})
    assert ErrorCode.PROTOCOL_VIOLATION not in result.errors
    assert ErrorCode.WORKER_FAILURE not in result.errors
    assert ledger.consumed("archive_entries") >= 1
    assert ledger.consumed("children") == len(result.facts["children"])
    assert ledger.consumed("evidence") == len(result.evidence)


def test_seeded_harmless_archive_metadata_mutations_do_not_crash():
    import random
    generator = random.Random(58194)
    original = zip_bytes([("one.lua", b"print('inert fixture')"), ("two.cfg", b"key=value")])
    for _ in range(256):
        mutated = bytearray(original)
        offset = generator.randrange(4, len(mutated))
        mutated[offset] ^= generator.randrange(1, 256)
        result = analyze(bytes(mutated), "mutated", "fixture.zip",
                         BudgetLedger({"archive_entries": 16, "children": 16,
                                       "parser_iterations": 256, "decompressed_bytes": 4096}))
        assert result.state in set(CoverageState)
        assert len(result.facts["children"]) <= 16


def test_report_is_deterministic_for_same_archive_bytes():
    data = central_local_mismatch()
    assert scan(data) == scan(data)
