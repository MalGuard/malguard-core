"""Private release authorization uses only signed, bounded device licenses."""

import base64
import json

import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from malguard_cli import device_license, frozen

FINGERPRINT = "a" * 64


def signed_license(key, **updates):
    payload = {"schema": 1, "product": "MalGuard", "app_version": "1.3.0",
               "fingerprint": FINGERPRINT}
    payload.update(updates)
    message = device_license.DOMAIN + json.dumps(
        payload, sort_keys=True, separators=(",", ":")
    ).encode()
    return json.dumps({**payload, "signature": base64.b64encode(key.sign(message)).decode()}).encode()


def test_signed_license_accepts_only_the_named_device():
    key = Ed25519PrivateKey.generate()
    data = signed_license(key)
    public = key.public_key().public_bytes_raw().hex()
    device_license.verify_license(data, public, FINGERPRINT)
    with pytest.raises(device_license.LicenseError, match="DEVICE_MISMATCH"):
        device_license.verify_license(data, public, "b" * 64)


def test_fingerprint_replacement_and_another_signer_are_rejected():
    key = Ed25519PrivateKey.generate()
    public = key.public_key().public_bytes_raw().hex()
    data = signed_license(key).replace(FINGERPRINT.encode(), b"b" * 64)
    with pytest.raises(device_license.LicenseError, match="SIGNATURE_INVALID"):
        device_license.verify_license(data, public, "b" * 64)
    with pytest.raises(device_license.LicenseError, match="SIGNATURE_INVALID"):
        device_license.verify_license(signed_license(Ed25519PrivateKey.generate()), public,
                                     FINGERPRINT)


@pytest.mark.parametrize("updates", [
    {"schema": True}, {"app_version": "1.2.0"}, {"product": "other"},
    {"fingerprint": "A" * 64}, {"fingerprint": "short"}, {"extra": "field"},
])
def test_signed_but_wrong_schema_or_version_is_rejected(updates):
    key = Ed25519PrivateKey.generate()
    with pytest.raises(device_license.LicenseError, match="LICENSE_INVALID"):
        device_license.verify_license(signed_license(key, **updates),
                                     key.public_key().public_bytes_raw().hex(), FINGERPRINT)


@pytest.mark.parametrize("data", [b"{}", b"null", b"\xff", b"x" * 4097,
                                  b'{"schema":1,"schema":1}', b'{"signature":"!"}'])
def test_malformed_oversized_or_ambiguous_license_is_rejected(data):
    key = Ed25519PrivateKey.generate()
    with pytest.raises(device_license.LicenseError):
        device_license.verify_license(data, key.public_key().public_bytes_raw().hex(), FINGERPRINT)


def test_missing_private_license_cannot_scan_refresh_evaluate_or_launch_worker(monkeypatch, tmp_path,
                                                                             capsys):
    key = Ed25519PrivateKey.generate()
    monkeypatch.setattr(device_license, "PRIVATE_LICENSE_PUBLIC_KEY_HEX",
                        key.public_key().public_bytes_raw().hex())
    monkeypatch.setattr(device_license, "windows_fingerprint", lambda: FINGERPRINT)
    monkeypatch.setattr(device_license, "license_path", lambda: tmp_path / "missing.json")
    for args in ([], ["--desktop-scan", "sample.lua"], ["--self-test"],
                 ["--refresh-security"], ["--evaluate"], ["--license-status"]):
        assert frozen.main(args) == 78
        assert json.loads(capsys.readouterr().out) == {
            "private_build": True, "authorized": False, "reason": "LICENSE_MISSING"
        }
    assert frozen.main(["--malguard-worker"]) == 78
    assert not capsys.readouterr().out


def test_private_status_returns_no_machine_identifier(monkeypatch, tmp_path):
    key = Ed25519PrivateKey.generate()
    path = tmp_path / "license.json"
    path.write_bytes(signed_license(key))
    monkeypatch.setattr(device_license, "PRIVATE_LICENSE_PUBLIC_KEY_HEX",
                        key.public_key().public_bytes_raw().hex())
    monkeypatch.setattr(device_license, "windows_fingerprint", lambda: FINGERPRINT)
    monkeypatch.setattr(device_license, "license_path", lambda: path)
    assert device_license.authorization() == {
        "private_build": True, "authorized": True, "reason": "DEVICE_AUTHORIZED"
    }
    path.write_bytes(b"x" * 4097)
    assert device_license.authorization()["authorized"] is False


def test_environment_has_no_license_or_machine_override(monkeypatch, tmp_path):
    monkeypatch.setattr(device_license, "PRIVATE_LICENSE_PUBLIC_KEY_HEX", "0" * 64)
    monkeypatch.setattr(device_license, "windows_fingerprint", lambda: "b" * 64)
    monkeypatch.setattr(device_license, "license_path", lambda: tmp_path / "missing.json")
    monkeypatch.setenv("MALGUARD_LICENSE_BYPASS", "1")
    monkeypatch.setenv("MALGUARD_DEVICE_FINGERPRINT", FINGERPRINT)
    assert device_license.authorization()["authorized"] is False
