"""Actual byte identification, honest scope, snapshot identity and telemetry."""

import hashlib
import io
import zipfile

import pytest

from malguard_core.api.scanner import Scanner
from malguard_core.intake import identify, type_mismatch_evidence
from malguard_core.intake.description import describe
from malguard_core.model import ArtifactStatus, Verdict
from tests.unit.test_foundation import synthetic_pe


@pytest.mark.parametrize(('content', 'kind'), [
    (b'RIFF'+bytes(4)+b'WAVEfmt ', 'WAVE_AUDIO'),
    (b'ID3'+bytes(20), 'ID3_AUDIO_METADATA'),
    (b'\xff\xfb\x90\x00'+bytes(12), 'MPEG_AUDIO'),
    (b'fLaC'+bytes(10), 'FLAC_AUDIO'),
    (b'OggS'+bytes(10), 'OGG_MEDIA'),
    (bytes(4)+b'ftypisom'+bytes(10), 'ISO_BASE_MEDIA'),
    (b'\x89PNG\r\n\x1a\n'+bytes(10), 'PNG_IMAGE'),
    (b'\xff\xd8\xff'+bytes(10), 'JPEG_IMAGE'),
    (b'GIF89a'+bytes(10), 'GIF_IMAGE'),
    (b'RIFF'+bytes(4)+b'WEBP'+bytes(10), 'WEBP_IMAGE'),
    (b'%PDF-1.7\n', 'PDF_DOCUMENT'),
])
def test_content_headers_override_misleading_mod_extension(content, kind):
    identity = identify(content, '.asi')
    assert identity['true_type'] == kind
    assert identity['structure_status'] == ArtifactStatus.MALFORMED
    info = describe(identity, 'sample.asi', len(content), True)
    assert info['scope_state'] == 'mismatch'
    assert info['header_only']
    assert not info['preview']


@pytest.mark.parametrize('extension', ['.txt', '.wav', '.mp3', '.bin'])
def test_plain_text_is_described_from_bytes_and_never_approved_as_mod(tmp_path, extension):
    content = 'سلام، این یک متن آزمایشی است.\n'.encode()
    path = tmp_path / ('sample'+extension)
    path.write_bytes(content)
    with Scanner() as scanner:
        report = scanner.scan_file(path)
        info = scanner.file_inspection
    assert report.verdict == Verdict.INCONCLUSIVE
    assert report.coverage_score < 100
    assert info['detected_type'] == 'TEXT'
    assert info['scope_state'] == 'unsupported'
    assert info['file_size'] == len(content)
    assert 'سلام' in info['preview']
    assert report.hashes.sha256 == hashlib.sha256(content).hexdigest()


@pytest.mark.parametrize('extension', ['.asi', '.dll', '.zip', '.7z', '.rar'])
def test_text_claiming_plugin_or_archive_gets_specific_mismatch(tmp_path, extension):
    path = tmp_path / ('fake'+extension)
    path.write_text('A harmless plain text description.')
    with Scanner() as scanner:
        report = scanner.scan_file(path)
        assert scanner.file_inspection['scope_state'] == 'mismatch'
    assert report.verdict == Verdict.INVALID


def test_multibyte_character_split_at_prefix_boundary_is_still_text():
    content = b'a'*8191+'سلام'.encode()
    identity = identify(content, '.txt')
    assert identity['true_type'] == 'TEXT'
    assert identity['preview_bytes'] == 8192
    assert len(describe(identity, 'notes.txt', len(content), True)['preview']) == 320


@pytest.mark.parametrize('encoding', ['utf-16', 'utf-16le', 'utf-16be'])
def test_unicode_preview_and_secrets_are_bounded_and_redacted(encoding):
    content = ('password="private-value-12345678"\nhello\u202efile.txt\n'+'x'*9000).encode(encoding)
    info = describe(identify(content, '.txt'), 'x\u202etest.txt', len(content), True)
    assert 'private-value' not in info['preview']
    assert '[REDACTED]' in info['preview']
    assert '\u202e' not in info['preview']
    assert '\\u202e' in info['filename']
    assert info['preview_bytes'] <= 8192


def test_description_and_hash_use_same_snapshot_despite_original_change(tmp_path):
    path = tmp_path / 'sample.txt'
    original = b'original captured content'
    path.write_bytes(original)
    def mutate(stage):
        if stage == 'reputation':
            path.write_bytes(b'changed original file')
    with Scanner(progress=mutate) as scanner:
        report = scanner.scan_file(path)
        assert scanner.file_inspection['preview'] == original.decode()
    assert report.hashes.sha256 == hashlib.sha256(original).hexdigest()


def test_observer_failure_cannot_change_verdict_and_no_fake_pe_stage(tmp_path):
    path = tmp_path / 'mod.lua'
    path.write_text("print('harmless')")
    seen = []
    def observer(stage):
        seen.append(stage)
        raise RuntimeError('UI observer unavailable')
    with Scanner(progress=observer) as scanner:
        report = scanner.scan_file(path)
    assert report.verdict == Verdict.SAFE
    assert seen[0] == 'capture' and seen[-1] == 'finalizing'
    assert 'script' in seen and 'rules' in seen
    assert not {'pe', 'dotnet', 'archive'} & set(seen)


def test_reuse_resets_inspection_after_missing_file(tmp_path):
    path = tmp_path / 'test.txt'
    path.write_text('test')
    with Scanner() as scanner:
        scanner.scan_file(path)
        path.unlink()
        report = scanner.scan_file(path)
        assert scanner.file_inspection['scope_state'] == 'unavailable'
        assert not scanner.file_inspection['size_known']
        assert not scanner.file_inspection['preview']
    assert report.verdict == Verdict.INCONCLUSIVE


def test_archive_readme_does_not_block_supported_package(tmp_path):
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, 'w') as archive:
        archive.writestr('mod.lua', "print('harmless')")
        archive.writestr('README.txt', 'Harmless installation notes')
    path = tmp_path / 'mod.zip'
    path.write_bytes(stream.getvalue())
    with Scanner() as scanner:
        report = scanner.scan_file(path)
        assert scanner.file_inspection['scope_state'] == 'supported'
    assert report.verdict == Verdict.SAFE


def test_media_disguised_executable_retains_evidence(tmp_path):
    content = synthetic_pe()
    identity = identify(content, '.mp3')
    assert identity['is_pe']
    assert type_mismatch_evidence(identity, 'sample.mp3', 'x'*64)
    path = tmp_path / 'sample.mp3'
    path.write_bytes(content)
    with Scanner() as scanner:
        assert scanner.scan_file(path).verdict != Verdict.SAFE


def test_empty_file_is_not_identified_as_useful_text(tmp_path):
    path = tmp_path / 'empty.txt'
    path.touch()
    with Scanner() as scanner:
        assert scanner.scan_file(path).verdict == Verdict.INCONCLUSIVE
        assert scanner.file_inspection['label_en'] == 'Empty file'
        assert scanner.file_inspection['scope_state'] == 'empty'


def test_short_unquoted_credentials_are_redacted_from_preview():
    content = b'password=abc\nauthorization=Basic YTo=\napi_key=xyz'
    info = describe(identify(content, '.txt'), 'notes.txt', len(content), True)
    assert 'abc' not in info['preview']
    assert 'YTo=' not in info['preview']
    assert 'xyz' not in info['preview']
    assert info['preview'].count('[REDACTED]') == 3


def test_secret_crossing_preview_edge_is_redacted_before_truncation():
    token = 'a'*24+'.'+'b'*6+'.'+'c'*27
    content = ('readme '*41+token+'\n').encode()
    info = describe(identify(content, '.txt'), 'notes.txt', len(content), True)
    assert '[REDACTED]' in info['preview']
    assert 'a'*24 not in info['preview']
    assert len(info['preview']) <= 320
