"""Generated harmless signatures and advisory similarity regression checks."""

from datetime import UTC, datetime
from functools import lru_cache
import hashlib
import struct

import pytest

from malguard_core.authenticode import analyze
from malguard_core.budget import BudgetLedger
from malguard_core.model import CoverageState, ErrorCode, EvidenceDomain
from malguard_core.similarity import (
    SimilarityProfile, compare_profiles, dotnet_structural_hash, imphash,
    normalize_api, normalize_mvid, semantic_import_hash,
)


def _pe(certificate: bytes | None = None) -> bytes:
    """Minimal inert PE data; section bytes are all zero and never executed."""
    data = bytearray(1024)
    data[:2] = b"MZ"
    struct.pack_into("<I", data, 60, 128)
    data[128:132] = b"PE\0\0"
    struct.pack_into("<HHIIIHH", data, 132, 0x14C, 1, 0, 0, 0, 224, 0x2102)
    struct.pack_into("<H", data, 152, 0x10B)
    struct.pack_into("<I", data, 152 + 60, 512)
    struct.pack_into("<I", data, 152 + 92, 16)
    section = 152 + 224
    data[section:section + 8] = b".data\0\0\0"
    struct.pack_into("<IIII", data, section + 8, 512, 0x1000, 512, 512)
    if certificate is not None:
        length = len(certificate) + 8
        aligned = (length + 7) & ~7
        struct.pack_into("<II", data, 152 + 128, len(data), aligned)
        data.extend(struct.pack("<IHH", length, 0x200, 2))
        data.extend(certificate)
        data.extend(bytes(aligned - length))
    return bytes(data)


@lru_cache(maxsize=2)
def _signed_pe(algorithm: str = "rsa") -> tuple[bytes, str]:
    """Generate a real test certificate and real CMS over harmless fixture bytes."""
    from asn1crypto import cms, x509 as asn1_x509
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec, padding, rsa
    from cryptography.x509.oid import NameOID
    from signify.asn1.spc import SpcIndirectDataContent, SpcPeImageData

    key = (rsa.generate_private_key(public_exponent=65537, key_size=2048)
           if algorithm == "rsa" else ec.generate_private_key(ec.SECP256R1()))
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "Synthetic test fixture")])
    certificate = (x509.CertificateBuilder().subject_name(name).issuer_name(name)
        .public_key(key.public_key()).serial_number(1)
        .not_valid_before(datetime(2020, 1, 1, tzinfo=UTC))
        .not_valid_after(datetime(2040, 1, 1, tzinfo=UTC))
        .sign(key, hashes.SHA256()))
    parsed_certificate = asn1_x509.Certificate.load(certificate.public_bytes(serialization.Encoding.DER))
    base = _pe()
    image_digest = hashlib.sha256(base[:216] + base[220:280] + base[288:]).digest()
    content = SpcIndirectDataContent({
        "data": {"type": "microsoft_spc_pe_image_data", "value": SpcPeImageData({
            "file": {"file": {"unicode": "Synthetic fixture"}},
        })},
        "message_digest": {"digest_algorithm": {"algorithm": "sha256"}, "digest": image_digest},
    })
    attrs = cms.CMSAttributes([
        {"type": "content_type", "values": ["microsoft_spc_indirect_data_content"]},
        {"type": "message_digest", "values": [hashlib.sha256(content.contents).digest()]},
    ])
    signature = (key.sign(attrs.dump(), padding.PKCS1v15(), hashes.SHA256())
                 if algorithm == "rsa" else key.sign(attrs.dump(), ec.ECDSA(hashes.SHA256())))
    signer = cms.SignerInfo({
        "version": "v1", "sid": {"issuer_and_serial_number": {
            "issuer": parsed_certificate.issuer, "serial_number": certificate.serial_number,
        }},
        "digest_algorithm": {"algorithm": "sha256"}, "signed_attrs": attrs,
        "signature_algorithm": {"algorithm": "rsassa_pkcs1v15" if algorithm == "rsa" else "sha256_ecdsa"},
        "signature": signature,
    })
    signed = cms.SignedData({
        "version": "v1", "digest_algorithms": [{"algorithm": "sha256"}],
        "encap_content_info": {"content_type": "microsoft_spc_indirect_data_content", "content": content},
        "certificates": [parsed_certificate], "signer_infos": [signer],
    })
    payload = cms.ContentInfo({"content_type": "signed_data", "content": signed}).dump()
    return _pe(payload), certificate.fingerprint(hashes.SHA256()).hex()


def test_unsigned_is_context_without_negative_weight():
    result = analyze(_pe(), "fixture", "fixture.asi", BudgetLedger())
    assert result.state is CoverageState.COMPLETE
    assert result.facts["authenticode_present"] is False
    assert not result.evidence


def test_real_generated_cms_and_image_integrity():
    data, fingerprint = _signed_pe()
    result = analyze(data, "fixture", "fixture.asi", BudgetLedger())
    assert result.state is CoverageState.COMPLETE, result.facts
    fact = result.facts["signatures"][0]
    assert fact["cms_signature_valid"] and fact["image_digest_valid"]
    assert fact["signer_sha256"] == fingerprint
    assert fact["chain_trust"] == "UNVERIFIED"
    assert all(e.domain is EvidenceDomain.CONTEXT and e.effective_weight == 0 for e in result.evidence)
    again = analyze(data, "fixture", "fixture.asi", BudgetLedger())
    assert result == again


def test_real_generated_ecdsa_signature_integrity():
    data, fingerprint = _signed_pe("ecdsa")
    result = analyze(data, "fixture", "fixture.asi", BudgetLedger())
    assert result.state is CoverageState.COMPLETE, result.facts
    fact = result.facts["signatures"][0]
    assert fact["cms_signature_valid"] and fact["image_digest_valid"]
    assert fact["signer_sha256"] == fingerprint


def test_tampered_image_blocks_complete_signature_coverage():
    data, _ = _signed_pe()
    tampered = bytearray(data)
    tampered[600] = 1
    result = analyze(bytes(tampered), "fixture", "fixture.asi", BudgetLedger())
    assert result.state is CoverageState.PARTIAL
    assert result.facts["signatures"][0]["image_digest_valid"] is False
    assert ErrorCode.INTEGRITY_FAILURE in result.errors
    assert any(e.rule_id == "AUTH.INTEGRITY_FAILURE" for e in result.evidence)


def test_tampered_cms_crypto_blocks_complete_coverage():
    from asn1crypto import cms
    data, _ = _signed_pe()
    table, _ = struct.unpack_from("<II", data, 280)
    size = struct.unpack_from("<I", data, table)[0]
    envelope = cms.ContentInfo.load(data[table + 8:table + size], strict=True)
    signer = envelope["content"]["signer_infos"][0]
    value = bytearray(signer["signature"].native)
    value[0] ^= 1
    signer["signature"] = bytes(value)
    result = analyze(_pe(envelope.dump()), "fixture", "fixture.asi", BudgetLedger())
    assert result.state is CoverageState.PARTIAL
    assert result.facts["signatures"][0]["cms_signature_valid"] is False
    assert result.facts["signatures"][0]["image_digest_valid"] is True
    assert ErrorCode.INTEGRITY_FAILURE in result.errors


def test_explicit_offline_revocation_is_not_a_safety_override():
    data, fingerprint = _signed_pe()
    result = analyze(data, "fixture", "fixture.asi", BudgetLedger(),
                     {"revoked_signer_sha256": [fingerprint]})
    assert result.facts["signatures"][0]["revoked"] is True
    assert any(e.rule_id == "AUTH.REVOKED_SIGNER" and e.domain is EvidenceDomain.REPUTATION
               for e in result.evidence)
    assert not any(e.mitigating for e in result.evidence)


@pytest.mark.parametrize("payload", [b"not CMS", b"\x30\x80\x00\x00", b"\x30\x82\xff\xff", b"\x30\x81\x01\x00"])
def test_malformed_cms_never_complete(payload):
    result = analyze(_pe(payload), "fixture", "fixture.asi", BudgetLedger())
    assert result.state is CoverageState.PARTIAL
    assert ErrorCode.MALFORMED_INPUT in result.errors


def test_signature_budget_is_shared_and_deterministic():
    result = analyze(_signed_pe()[0], "fixture", "fixture.asi", BudgetLedger({"parser_iterations": 1}))
    assert result.state is CoverageState.SKIPPED_LIMIT
    assert result.errors == (ErrorCode.ITERATION_BUDGET_EXHAUSTED,)


def test_signature_reader_cannot_bypass_global_byte_budget():
    result = analyze(_signed_pe()[0], "fixture", "fixture.asi", BudgetLedger({"read_bytes": 2}))
    assert result.state is CoverageState.SKIPPED_LIMIT
    assert ErrorCode.ITERATION_BUDGET_EXHAUSTED in result.errors


def test_certificate_overlap_rejected():
    data = bytearray(_pe(b"\x30\x00"))
    struct.pack_into("<II", data, 280, 512, 16)
    result = analyze(bytes(data), "fixture", "fixture.asi", BudgetLedger())
    assert result.state is CoverageState.PARTIAL
    assert ErrorCode.MALFORMED_INPUT in result.errors


def test_signer_revocation_schema_is_fail_closed():
    result = analyze(_signed_pe()[0], "fixture", "fixture.asi", BudgetLedger(),
                     {"revoked_signer_sha256": ["bad fingerprint"]})
    assert result.state is CoverageState.PARTIAL
    assert ErrorCode.MALFORMED_INPUT in result.errors


def test_authenticode_parser_disagreement_is_explicit(monkeypatch):
    from signify.authenticode.signed_file.pe import SignedPEFile
    monkeypatch.setattr(SignedPEFile, "get_fingerprint", lambda self, algorithm: bytes(32))
    result = analyze(_signed_pe()[0], "fixture", "fixture.asi", BudgetLedger())
    assert result.state is CoverageState.PARTIAL
    assert ErrorCode.PARSER_DISAGREEMENT in result.errors
    assert any(e.domain is EvidenceDomain.STRUCTURE for e in result.evidence)


def test_der_nested_sequence_capacity_is_bounded():
    payload = b"\x05\x00"
    for _ in range(26):
        payload = b"\x30" + bytes([len(payload)]) + payload
    result = analyze(_pe(payload), "fixture", "fixture.asi", BudgetLedger())
    assert result.state is CoverageState.PARTIAL
    assert ErrorCode.UNSUPPORTED_FORMAT in result.errors


def test_cms_trailing_unaccounted_data_is_rejected():
    data, _ = _signed_pe()
    start = struct.unpack_from("<I", data, 280)[0]
    length = struct.unpack_from("<I", data, start)[0]
    payload = data[start + 8:start + length] + b"hidden trailing bytes"
    result = analyze(_pe(payload), "fixture", "fixture.asi", BudgetLedger())
    assert result.state is CoverageState.PARTIAL
    assert ErrorCode.MALFORMED_INPUT in result.errors


def test_aw_normalization_and_order_independent_semantic_hash():
    first = ["KERNEL32.dll!CreateFileA", "KERNEL32.dll!CreateProcessA"]
    second = ["kernel32.dll!CreateProcessW", "kernel32.dll!CreateFileW", "kernel32.dll!CreateFileW"]
    assert semantic_import_hash(first) == semantic_import_hash(second)
    assert imphash(first) != imphash(second)
    assert normalize_api("CustomDraw") == "customdraw"
    assert imphash(["KERNEL32.dll!VirtualAlloc"]) == hashlib.md5(b"kernel32.virtualalloc", usedforsecurity=False).hexdigest()


def test_dotnet_structural_hash_keeps_reference_names_case_sensitive():
    assert dotnet_structural_hash(["GTA", "System"], ["System.Net.Http.HttpClient"]) == dotnet_structural_hash(
        ["System", "GTA", "GTA"], ["System.Net.Http.HttpClient"])
    assert dotnet_structural_hash(["GTA"], []) != dotnet_structural_hash(["gta"], [])
    assert normalize_mvid("{00000000-0000-0000-0000-000000000001}") == "00000000-0000-0000-0000-000000000001"


def test_similarity_requires_all_corroborating_fields():
    digest = hashlib.md5(b"fixture", usedforsecurity=False).hexdigest()
    base = SimilarityProfile("PE32_DLL", "x86", 1000, ("NETWORK", "PROCESS"), imphash=digest)
    other = SimilarityProfile("PE32_DLL", "x86", 1100, ("NETWORK", "PROCESS"), imphash=digest)
    match = compare_profiles(base, other)
    assert match is not None and match.confidence == 0.5
    assert match.signals == ("imphash",)
    variants = [
        SimilarityProfile("PE32_EXE", "x86", 1000, base.capabilities, imphash=digest),
        SimilarityProfile("PE32_DLL", "x64", 1000, base.capabilities, imphash=digest),
        SimilarityProfile("PE32_DLL", "x86", 10000, base.capabilities, imphash=digest),
        SimilarityProfile("PE32_DLL", "x86", 1000, (), imphash=digest),
    ]
    assert all(compare_profiles(base, item) is None for item in variants)


def test_mvid_is_advisory_even_with_corroboration():
    mvid = "00000000-0000-0000-0000-000000000001"
    base = SimilarityProfile("DOTNET_DLL", "x86", 1000, ("NETWORK",), mvid=mvid)
    match = compare_profiles(base, base)
    assert match is not None and match.confidence <= 0.5
    assert not hasattr(match, "verdict")


def test_empty_imports_or_placeholder_mvid_cannot_create_similarity():
    base = SimilarityProfile("PE32_DLL", "x86", 1000, ("NETWORK",),
                             imphash=imphash(()), dotnet_hash=dotnet_structural_hash((), ()),
                             mvid="00000000-0000-0000-0000-000000000000")
    assert compare_profiles(base, base) is None


@pytest.mark.parametrize("arguments", [
    {"size": True}, {"imphash": "not a hash"}, {"mvid": "not a UUID"},
])
def test_profile_schema_is_validated(arguments):
    values = {"true_type": "PE32_DLL", "architecture": "x86", "size": 1000, "capabilities": ()}
    values.update(arguments)
    with pytest.raises(ValueError):
        SimilarityProfile(**values)
