"""Independent structured-analysis regressions using harmless built bytes."""

from __future__ import annotations

import base64
import struct

import pefile
import pytest

from malguard_core.budget import BudgetLedger
from malguard_core.dotnet import analyze as analyze_dotnet
from malguard_core.dotnet import parse_metadata
from malguard_core.model import CoverageState, ErrorCode, EvidenceDomain
from malguard_core.pe import PEFormatError, analyze as analyze_pe, validate
from tests.builders.pe_dotnet import managed_pe, native_pe


def pe(data: bytes):
    return analyze_pe(data, "synthetic", "fixture.dll", BudgetLedger())


def net(data: bytes):
    return analyze_dotnet(data, "synthetic", "fixture.dll", BudgetLedger())


@pytest.mark.parametrize("is_64", [False, True])
@pytest.mark.parametrize("dll", [False, True])
def test_valid_synthetic_pe_architecture_and_kind(is_64, dll):
    result = pe(native_pe(dll=dll, is_64=is_64))
    assert result.state == CoverageState.COMPLETE
    assert result.facts["architecture"] == ("x64" if is_64 else "x86")
    assert result.facts["is_dll"] is dll
    assert result.facts["structure_status"] == "VALID"


def test_imports_are_real_thunks_and_aw_variants_normalize():
    result = pe(native_pe(imports=("CreateFileA", "CreateFileW", "VirtualAllocEx", "WriteProcessMemory", "CreateRemoteThread")))
    assert result.state == CoverageState.COMPLETE
    assert result.facts["imports"] == ["CreateFile", "CreateRemoteThread", "VirtualAllocEx", "WriteProcessMemory"]
    assert len(result.facts["import_records"]) == 5
    assert len(result.facts["imphash"]) == 32


def test_raw_api_name_without_import_has_no_import_identity():
    assert pe(native_pe(strings=b"Assembly.Load VirtualAllocEx\x00")).facts["imports"] == []


@pytest.mark.parametrize("length", [0, 1, 2, 63, 64, 128, 151, 250, 511, 600])
def test_truncated_pe_does_not_crash(length):
    result = pe(native_pe()[:length])
    assert result.state != CoverageState.COMPLETE
    assert result.facts["structure_status"] == "MALFORMED"


def test_absurd_section_count_rejected_before_selected_parser(monkeypatch):
    data = bytearray(native_pe())
    struct.pack_into("<H", data, 0x80 + 6, 0xFFFF)
    monkeypatch.setattr(pefile, "PE", lambda **kwargs: pytest.fail("unbounded selected parser invoked"))
    result = pe(bytes(data))
    assert ErrorCode.MALFORMED_INPUT in result.errors


@pytest.mark.parametrize("offset,value", [(60, 0xFFFFFFFE), (0x80 + 24 + 56, 0xFFFFFFFF), (0x80 + 24 + 92, 0xFFFFFFFF), (0x80 + 24 + 224 + 20, 0xFFFFFF00)])
def test_integer_and_header_extremes_rejected(offset, value):
    data = bytearray(native_pe())
    struct.pack_into("<I", data, offset, value)
    assert pe(bytes(data)).state != CoverageState.COMPLETE


def test_rwx_and_high_entropy_are_only_opacity():
    result = pe(native_pe(strings=bytes(range(256)) * 32, section_flags=0xE0000020))
    assert {"PE.RWX", "PE.ENTROPY"} <= {item.rule_id for item in result.evidence}
    assert all(item.domain != EvidenceDomain.HARM for item in result.evidence)


def test_packer_section_is_opacity_not_harm():
    result = pe(native_pe(section_name=b"UPX0"))
    assert any(item.rule_id == "PE.PROTECTOR" for item in result.evidence)
    assert all(item.domain != EvidenceDomain.HARM for item in result.evidence)


def test_overlay_is_reported_without_harm():
    result = pe(native_pe(overlay=b"Harmless synthetic overlay"))
    assert result.facts["overlay_size"] == 26
    assert all(item.domain != EvidenceDomain.HARM for item in result.evidence)


def test_embedded_resource_pe_is_validated_and_captured():
    payload = native_pe()
    result = pe(native_pe(resource=payload))
    assert result.state == CoverageState.COMPLETE
    assert base64.b64decode(result.facts["resources"][0]["data_b64"]) == payload
    assert result.facts["resources"][0]["embedded_pe"] is True
    assert any(item.rule_id == "PE.EMBEDDED" for item in result.evidence)


def test_mz_string_without_valid_nested_structure_is_not_embedded_pe():
    result = pe(native_pe(resource=b"MZ" + b"harmless" * 20))
    assert not any(item.rule_id == "PE.EMBEDDED" for item in result.evidence)


def test_internal_selected_parser_disagreement_retains_imports(monkeypatch):
    real = pefile.PE

    def divergent(**kwargs):
        parsed = real(**kwargs)
        parsed.FILE_HEADER.Machine = 0x8664
        return parsed

    monkeypatch.setattr(pefile, "PE", divergent)
    result = pe(native_pe(imports=("VirtualAllocEx", "WriteProcessMemory", "CreateRemoteThread")))
    assert result.facts["imports"] == ["CreateRemoteThread", "VirtualAllocEx", "WriteProcessMemory"]
    assert result.facts["parser_disagreement"] is True
    assert ErrorCode.PARSER_DISAGREEMENT in result.errors


def test_selected_parser_failure_retains_rwx_and_resources(monkeypatch):
    def fail(**kwargs):
        raise pefile.PEFormatError("synthetic parser failure")

    monkeypatch.setattr(pefile, "PE", fail)
    result = pe(native_pe(resource=native_pe(), section_flags=0xE0000020))
    assert {"PE.RWX", "PE.EMBEDDED", "PE.DISAGREEMENT"} <= {item.rule_id for item in result.evidence}


def test_nonexecutable_entry_marks_malformed_structure():
    result = pe(native_pe(section_flags=0x40000040))
    assert result.facts["structure_status"] == "MALFORMED"
    assert any(item.rule_id == "PE.ENTRY" for item in result.evidence)


def test_unmapped_entry_rejected():
    data = bytearray(native_pe())
    struct.pack_into("<I", data, 0x80 + 24 + 16, 0xFFFFFF00)
    with pytest.raises(PEFormatError):
        validate(bytes(data), BudgetLedger())


def test_read_and_iteration_budgets_distinct_from_wallclock():
    result = analyze_pe(native_pe(), "fixture", "fixture.dll", BudgetLedger({"read_bytes": 1}))
    assert result.state == CoverageState.SKIPPED_LIMIT
    assert result.errors == (ErrorCode.ITERATION_BUDGET_EXHAUSTED,)


def test_real_shvdn_metadata_is_complete_and_nonharmful():
    result = net(managed_pe())
    assert result.state == CoverageState.COMPLETE
    assert result.facts["assembly_refs"] == ["ScriptHookVDotNet3", "mscorlib"]
    assert any(item.rule_id == "NET.SHVDN" for item in result.evidence)
    assert all(item.domain != EvidenceDomain.HARM for item in result.evidence)
    assert len(result.facts["mvid"]) == 36
    assert len(result.facts["structural_hash"]) == 64


def test_httpclient_version_check_has_no_harm():
    result = net(managed_pe(calls=(("System.Net.Http.HttpClient", "GetStringAsync", ("string",)),), user_strings=("https://example.invalid/version",)))
    assert result.state == CoverageState.COMPLETE
    assert not any(item.domain == EvidenceDomain.HARM for item in result.evidence)


def test_process_start_alone_has_no_harm():
    result = net(managed_pe(calls=(("System.Diagnostics.Process", "Start", ("string",)),)))
    assert not any(item.domain == EvidenceDomain.HARM for item in result.evidence)


def test_assembly_load_string_is_distinct_from_byte_array():
    result = net(managed_pe(calls=(("System.Reflection.Assembly", "Load", ("string",)),)))
    assert not any(item.domain == EvidenceDomain.HARM for item in result.evidence)


def test_byte_array_loader_and_embedded_resource_detected():
    calls = (("System.Reflection.Assembly", "Load", ("byte[]",)), ("System.Reflection.MethodBase", "Invoke", ("object",)), ("System.Reflection.Assembly", "GetManifestResourceStream", ("string",)))
    result = net(managed_pe(calls=calls, resources=(("HarmlessFixture", native_pe()),)))
    assert result.state == CoverageState.COMPLETE
    assert {"NET.MEMORY_LOADER", "NET.EMBEDDED"} <= {item.rule_id for item in result.evidence}
    assert any(item.family == "LOADER_IN_MEMORY_EXECUTION" for item in result.evidence)


def test_download_byte_loader_two_independent_harm_families():
    result = net(managed_pe(calls=(("System.Net.WebClient", "DownloadData", ("string",)), ("System.Reflection.Assembly", "Load", ("byte[]",)))))
    assert {item.family for item in result.evidence if item.domain == EvidenceDomain.HARM} == {"REMOTE_CODE_EXECUTION", "LOADER_IN_MEMORY_EXECUTION"}


def test_decode_plus_reflection_is_opacity():
    result = net(managed_pe(calls=(("System.Convert", "FromBase64String", ("string",)), ("System.Reflection.MethodBase", "Invoke", ("object",)))))
    assert any(item.rule_id == "NET.REFLECTION_ENCRYPTED" for item in result.evidence)
    assert not any(item.domain == EvidenceDomain.HARM for item in result.evidence)


def test_weird_unicode_metadata_names_are_opacity():
    result = net(managed_pe(method_name="\u202eSynthetic"))
    assert any(item.rule_id == "NET.JUNK" for item in result.evidence)
    assert not any(item.domain == EvidenceDomain.HARM for item in result.evidence)


def test_protector_metadata_is_opacity():
    result = net(managed_pe(method_name="ConfuserExSynthetic"))
    assert any(item.rule_id == "NET.PROTECTOR" for item in result.evidence)
    assert not any(item.domain == EvidenceDomain.HARM for item in result.evidence)


def test_pinvoke_is_real_implmap_metadata():
    result = net(managed_pe(pinvoke=("OpenProcess", "WriteProcessMemory")))
    assert result.state == CoverageState.COMPLETE
    assert [record["name"] for record in result.facts["pinvoke"]] == ["OpenProcess", "WriteProcessMemory"]


def test_resource_entropy_is_opacity():
    result = net(managed_pe(resources=(("HarmlessBytes", bytes(range(256)) * 8),)))
    assert any(item.rule_id == "NET.RESOURCE_ENTROPY" for item in result.evidence)
    assert not any(item.domain == EvidenceDomain.HARM for item in result.evidence)


def test_junk_metadata_counts_are_bounded():
    result = net(managed_pe(corrupt_metadata=True))
    assert result.state == CoverageState.SKIPPED_LIMIT
    assert ErrorCode.ITERATION_BUDGET_EXHAUSTED in result.errors


def test_il_corruption_blocks_complete_but_keeps_metadata():
    result = net(managed_pe(corrupt_il=True))
    assert result.state == CoverageState.PARTIAL
    assert result.facts["assembly_refs"] == ["ScriptHookVDotNet3", "mscorlib"]
    assert any(item.rule_id == "NET.IL_OPAQUE" for item in result.evidence)


def test_plain_resource_api_strings_are_not_managed_calls():
    result = net(managed_pe(resources=(("Text", b"System.Reflection.Assembly Load Invoke DownloadData"),)))
    assert not any(item.domain == EvidenceDomain.HARM for item in result.evidence)


def test_browser_path_alone_has_no_harm():
    result = net(managed_pe(user_strings=(r"C:\Users\Synthetic\Browser\Login Data",)))
    assert not any(item.domain == EvidenceDomain.HARM for item in result.evidence)


def test_metadata_credential_and_upload_chain_remains_harmful_with_gta_ref():
    calls = (("System.IO.File", "ReadAllBytes", ("string",)), ("System.Security.Cryptography.ProtectedData", "Unprotect", ("byte[]",)), ("System.Net.WebClient", "UploadData", ("byte[]",)))
    result = net(managed_pe(calls=calls, user_strings=(r"Browser\Login Data",)))
    assert {"CREDENTIAL_ACCESS", "EXFILTRATION"} <= {item.family for item in result.evidence if item.domain == EvidenceDomain.HARM}
    assert all(not item.mitigating for item in result.evidence if item.domain == EvidenceDomain.HARM)


def test_dnfile_disagreement_does_not_discard_loader_evidence(monkeypatch):
    import dnfile

    monkeypatch.setattr(dnfile, "dnPE", lambda **kwargs: None)
    result = net(managed_pe(calls=(("System.Reflection.Assembly", "Load", ("byte[]",)), ("System.Reflection.MethodBase", "Invoke", ("object",)))))
    assert ErrorCode.PARSER_DISAGREEMENT in result.errors
    assert any(item.rule_id == "NET.MEMORY_LOADER" for item in result.evidence)


def test_invalid_heap_index_rejected():
    data = bytearray(managed_pe())
    metadata = parse_metadata(validate(bytes(data), BudgetLedger()))
    module_row = metadata.row_offsets[0][0]
    struct.pack_into("<H", data, module_row + 2, 65535)
    result = net(bytes(data))
    assert result.state == CoverageState.PARTIAL
    assert result.facts["structure_status"] == "MALFORMED"


def test_invalid_il_call_token_rejected():
    data = bytearray(managed_pe(calls=(("System.Diagnostics.Process", "Start", ("string",)),)))
    metadata = parse_metadata(validate(bytes(data), BudgetLedger()))
    method_rva = metadata.tables[6][0][0]
    struct.pack_into("<I", data, metadata.layout.rva(method_rva) + 2, 0x0A00FFFF)
    result = net(bytes(data))
    assert result.facts["structure_status"] == "MALFORMED"
    assert result.state == CoverageState.PARTIAL


def test_repeated_analysis_is_deterministic():
    data = managed_pe(calls=(("System.Reflection.Assembly", "Load", ("byte[]",)),))
    assert net(data) == net(data)


@pytest.mark.parametrize("is_64", [False, True])
def test_exports_forwarders_and_tls_are_static_facts(is_64):
    result = pe(native_pe(is_64=is_64, exports=(("DirectInput8Create", "dinput8.DirectInput8Create"), ("SyntheticExport", None)), tls_callbacks=True))
    assert result.state == CoverageState.COMPLETE
    assert result.facts["exports"] == ["DirectInput8Create", "SyntheticExport"]
    assert result.facts["forwarded_exports"] == [{"name": "DirectInput8Create", "target": "dinput8.DirectInput8Create"}]
    assert result.facts["tls_callbacks"] == [0x1000]


@pytest.mark.parametrize("offset", [0, 1, 0x80, 0x81, 0x82, 0x83])
def test_signature_corruption_retains_managed_harm_families(offset):
    data = bytearray(managed_pe(calls=(("System.Net.WebClient", "DownloadData", ("string",)), ("System.Reflection.Assembly", "Load", ("byte[]",)))))
    before = net(bytes(data))
    data[offset] ^= 0xFF
    after = net(bytes(data))
    assert after.facts["recovered_metadata"] is True
    assert after.facts["structure_status"] == "MALFORMED"
    assert after.state == CoverageState.PARTIAL
    assert {item.family for item in before.evidence if item.domain == EvidenceDomain.HARM} <= {item.family for item in after.evidence if item.domain == EvidenceDomain.HARM}


def test_recovery_does_not_relax_section_or_heap_bounds():
    data = bytearray(managed_pe())
    data[0x80] ^= 0xFF
    struct.pack_into("<I", data, 0x80 + 24 + 224 + 20, 0xFFFFFFFE)
    result = net(bytes(data))
    assert result.facts["structure_status"] == "MALFORMED"
    assert not result.facts.get("recovered_metadata", False)


def test_mutated_headers_and_metadata_never_crash():
    for original, analyzer in ((native_pe(imports=("CreateFileW",)), pe), (managed_pe(calls=(("System.Reflection.Assembly", "Load", ("byte[]",)),)), net)):
        for index in range(0, len(original), 13):
            data = bytearray(original)
            data[index] ^= 0xFF
            result = analyzer(bytes(data))
            assert isinstance(result.state, CoverageState)
            assert all(item.location.offset is None or item.location.offset < len(data) for item in result.evidence)
