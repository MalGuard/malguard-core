"""Harmless recovery/carving regressions; input fixtures are never executed."""

from __future__ import annotations

import base64
import hashlib
import struct

import pytest

from malguard_core import Scanner
from malguard_core.budget import BudgetLedger
from malguard_core.dotnet import analyze as analyze_dotnet
from malguard_core.dotnet import parse_metadata
from malguard_core.model import CoverageState, ErrorCode, EvidenceDomain, Verdict
from malguard_core.pe import PEFormatError, analyze as analyze_pe, is_pe_candidate, validate
from tests.builders.pe_dotnet import managed_pe, native_pe


_LOADER_CALLS = (
    ("System.Net.WebClient", "DownloadData", ("string",)),
    ("System.Reflection.Assembly", "Load", ("byte[]",)),
)


@pytest.fixture(scope="module")
def scanner():
    with Scanner() as instance:
        yield instance


def damaged(data: bytes, field: str) -> bytes:
    result = bytearray(data)
    if field == "mz":
        result[0] ^= 0xFF
    elif field == "nt_signature":
        result[0x80] ^= 0xFF
    elif field == "nt_pointer":
        struct.pack_into("<I", result, 60, 0xFFFFFFFE)
    elif field == "section_count":
        struct.pack_into("<H", result, 0x80 + 6, 0xFFFF)
    else:
        raise ValueError("unknown harmless header mutation")
    return bytes(result)


def pe(data: bytes, ledger: BudgetLedger | None = None):
    return analyze_pe(data, "synthetic-parent", "fixture.dll", ledger or BudgetLedger())


def net(data: bytes, ledger: BudgetLedger | None = None):
    return analyze_dotnet(data, "synthetic-managed", "fixture.dll", ledger or BudgetLedger())


@pytest.mark.parametrize("field", ["mz", "nt_signature", "nt_pointer", "section_count"])
def test_managed_header_recovery_retains_independent_harm_without_changing_bytes(field):
    original = managed_pe(calls=_LOADER_CALLS)
    data = damaged(original, field)
    digest = hashlib.sha256(data).digest()
    with pytest.raises(PEFormatError):
        validate(data, BudgetLedger())
    result = net(data)
    assert result.state == CoverageState.PARTIAL
    assert result.facts["recovered_metadata"] is True
    assert result.facts["structure_status"] == "MALFORMED"
    assert {item.family for item in result.evidence if item.domain == EvidenceDomain.HARM} == {
        "REMOTE_CODE_EXECUTION", "LOADER_IN_MEMORY_EXECUTION",
    }
    assert hashlib.sha256(data).digest() == digest


@pytest.mark.parametrize("field", ["mz", "nt_signature", "nt_pointer", "section_count"])
def test_native_header_recovery_retains_real_imports(field):
    original = native_pe(imports=("OpenProcess", "VirtualAllocEx", "WriteProcessMemory", "CreateRemoteThread"))
    result = pe(damaged(original, field))
    assert result.state == CoverageState.PARTIAL
    assert result.facts["structure_status"] == "MALFORMED"
    assert result.facts["recovered_structure"] is True
    assert result.facts["imports"] == pe(original).facts["imports"]


@pytest.mark.parametrize("field", ["mz", "nt_signature", "nt_pointer", "section_count"])
def test_native_resource_keeps_recognized_malformed_pe_as_child(field):
    payload = damaged(managed_pe(calls=_LOADER_CALLS), field)
    result = pe(native_pe(resource=payload))
    resource = result.facts["resources"][0]
    assert resource["embedded_pe"] is True
    assert base64.b64decode(resource["data_b64"], validate=True) == payload
    embedded = next(item for item in result.evidence if item.rule_id == "PE.EMBEDDED")
    assert embedded.domain == EvidenceDomain.OPACITY
    assert embedded.base_weight == 18


@pytest.mark.parametrize("field", ["mz", "nt_signature", "nt_pointer", "section_count"])
def test_managed_resource_keeps_recognized_malformed_pe_as_child(field):
    payload = damaged(native_pe(), field)
    result = net(managed_pe(resources=(("HarmlessSyntheticChild", payload),)))
    resource = result.facts["resources"][0]
    assert resource["embedded_pe"] is True
    assert base64.b64decode(resource["data_b64"], validate=True) == payload
    assert any(item.rule_id == "NET.EMBEDDED" for item in result.evidence)
    assert not any(item.domain == EvidenceDomain.HARM for item in result.evidence)


@pytest.mark.parametrize("payload", [b"MZ", b"MZ" + b"harmless" * 30, b"Harmless Synthetic Assembly.Load text" * 3])
def test_mz_or_method_strings_alone_do_not_create_embedded_child(payload):
    assert is_pe_candidate(payload, BudgetLedger()) is False
    assert pe(native_pe(resource=payload)).facts["resources"][0]["embedded_pe"] is False
    assert net(managed_pe(resources=(("Text", payload),))).facts["resources"][0]["embedded_pe"] is False


@pytest.mark.parametrize("field", [None, "mz", "nt_signature", "nt_pointer", "section_count"])
def test_overlay_carving_retains_recognized_children(field):
    payload = managed_pe(calls=_LOADER_CALLS)
    if field is not None:
        payload = damaged(payload, field)
    prefix = b"Harmless overlay prefix\x00"
    result = pe(native_pe(overlay=prefix + payload))
    children = result.facts["embedded_artifacts"]
    assert len(children) == 1
    child = children[0]
    assert child["offset"] == result.facts["overlay_offset"] + len(prefix)
    assert base64.b64decode(child["data_b64"], validate=True) == payload
    assert child["type"] == "pe"
    assert child["structure_status"] == ("VALID" if field is None else "MALFORMED")
    assert any(item.rule_id == "PE.CARVED" for item in result.evidence)


def test_internal_section_candidate_carving_is_independent_of_resource_tables():
    payload = managed_pe(calls=_LOADER_CALLS)
    result = pe(native_pe(strings=b"Harmless prefix\x00" + payload))
    children = result.facts["embedded_artifacts"]
    assert len(children) == 1
    assert base64.b64decode(children[0]["data_b64"], validate=True) == payload


def test_resources_are_not_duplicated_by_carving():
    result = pe(native_pe(resource=managed_pe(calls=_LOADER_CALLS)))
    assert result.facts["resources"][0]["embedded_pe"] is True
    assert result.facts["embedded_artifacts"] == []


def test_resource_parser_failure_retains_previously_captured_child_and_evidence():
    data = bytearray(native_pe(resource=managed_pe(calls=_LOADER_CALLS)))
    layout = validate(bytes(data), BudgetLedger())
    root, _ = layout.directory(2)
    directory = layout.rva(root)
    # A second final-level entry overlaps the first data descriptor. Its
    # invalid target is rejected after the first harmless child was captured.
    struct.pack_into("<H", data, directory + 48 + 14, 2)
    result = pe(bytes(data))
    assert result.state == CoverageState.PARTIAL
    assert result.facts["structure_status"] == "MALFORMED"
    assert result.facts["resources"][0]["embedded_pe"] is True
    assert any(item.rule_id == "PE.EMBEDDED" for item in result.evidence)


def test_recovery_rejects_ambiguous_section_table_extent():
    data = bytearray(damaged(managed_pe(calls=_LOADER_CALLS), "section_count"))
    table = 0x80 + 24 + 224
    data[table + 40 + 5] = 1
    with pytest.raises(PEFormatError):
        validate(bytes(data), BudgetLedger(), recovery=True)
    result = net(bytes(data))
    assert result.facts["structure_status"] == "MALFORMED"
    assert not result.facts.get("recovered_metadata", False)


def test_recovery_rejects_out_of_bounds_existing_section_row():
    data = bytearray(damaged(managed_pe(calls=_LOADER_CALLS), "section_count"))
    struct.pack_into("<I", data, 0x80 + 24 + 224 + 20, 0xFFFFFF00)
    with pytest.raises(PEFormatError):
        validate(bytes(data), BudgetLedger(), recovery=True)


def test_carving_candidate_limits_keep_earlier_child_records():
    payload = managed_pe(calls=_LOADER_CALLS)
    data = native_pe(overlay=payload + b"MZharmless" * 40)
    result = pe(data)
    assert result.state == CoverageState.SKIPPED_LIMIT
    assert ErrorCode.ITERATION_BUDGET_EXHAUSTED in result.errors
    assert len(result.facts["embedded_artifacts"]) == 1
    assert base64.b64decode(result.facts["embedded_artifacts"][0]["data_b64"], validate=True) == payload


def test_carving_limits_do_not_erase_import_identities():
    symbols = ("OpenProcess", "VirtualAllocEx", "WriteProcessMemory", "CreateRemoteThread")
    result = pe(native_pe(imports=symbols, overlay=b"MZharmless" * 40))
    assert result.state == CoverageState.SKIPPED_LIMIT
    assert result.facts["imports"] == sorted(symbols)


@pytest.mark.parametrize("field", ["row_offset", "directory_rva", "declared_length"])
def test_managed_resource_corruption_keeps_independent_il_harm(field):
    data = bytearray(managed_pe(calls=_LOADER_CALLS, resources=(("Child", native_pe()),)))
    layout = validate(bytes(data), BudgetLedger())
    metadata = parse_metadata(layout)
    if field == "row_offset":
        struct.pack_into("<I", data, metadata.row_offsets[40][0], 0xFFFFFFFE)
    elif field == "directory_rva":
        struct.pack_into("<I", data, layout.rva(layout.directory(14)[0]) + 24, 0xFFFFFFFE)
    else:
        struct.pack_into("<I", data, layout.rva(metadata.resource_rva), 0xFFFFFFFE)
    result = net(bytes(data))
    assert result.facts["structure_status"] == "MALFORMED"
    assert result.facts["incomplete_resources"] is True
    assert {item.family for item in result.evidence if item.domain == EvidenceDomain.HARM} == {
        "REMOTE_CODE_EXECUTION", "LOADER_IN_MEMORY_EXECUTION",
    }


def test_managed_resource_budget_failure_keeps_independent_il_harm():
    result = net(managed_pe(calls=_LOADER_CALLS, resources=(("Child", native_pe()),)), BudgetLedger({"resource_entries": 0}))
    assert result.state == CoverageState.SKIPPED_LIMIT
    assert result.facts["incomplete_resources"] is True
    assert {item.family for item in result.evidence if item.domain == EvidenceDomain.HARM} == {
        "REMOTE_CODE_EXECUTION", "LOADER_IN_MEMORY_EXECUTION",
    }


def test_recovery_and_carving_are_deterministic():
    data = native_pe(resource=damaged(native_pe(), "section_count"), overlay=managed_pe(calls=_LOADER_CALLS))
    assert pe(data) == pe(data)


@pytest.mark.parametrize("container", ["resource", "overlay"])
@pytest.mark.parametrize("field", ["mz", "nt_signature", "nt_pointer", "section_count"])
def test_default_isolated_child_pipeline_cannot_improve_harmful_verdict(scanner, tmp_path, container, field):
    original = managed_pe(calls=_LOADER_CALLS)
    changed = damaged(original, field)
    wrap = (lambda payload: native_pe(resource=payload)) if container == "resource" else (
        lambda payload: native_pe(overlay=b"Harmless prefix\x00" + payload)
    )
    path = tmp_path / "fixture.dll"
    path.write_bytes(wrap(original))
    before = scanner.scan_file(path)
    path.write_bytes(wrap(changed))
    after = scanner.scan_file(path)
    assert before.verdict == after.verdict == Verdict.MALICIOUS
    assert after.risk_score >= before.risk_score
    assert len(after.artifacts) == 2
    child = next(artifact for artifact in after.artifacts if artifact.parent_artifact_id == after.root_artifact_id)
    assert child.hashes.sha256 == hashlib.sha256(changed).hexdigest()
