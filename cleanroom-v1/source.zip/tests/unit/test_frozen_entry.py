"""Trusted frozen entry/worker behavior using harmless generated inputs."""

import io
import json
import sys
from pathlib import Path

import pytest

from malguard_cli import frozen
from malguard_core.workers.pool import worker_launch


def test_unfrozen_worker_uses_isolated_trusted_interpreter(monkeypatch):
    monkeypatch.delattr(sys, "frozen", raising=False)
    command, directory = worker_launch()
    assert command[:3] == [sys.executable, "-I", "-u"]
    assert Path(command[3]).name == "server.py"
    assert directory == Path(command[3]).parent


def test_frozen_worker_uses_fixed_private_switch(monkeypatch, tmp_path):
    executable = tmp_path / "installed app" / "MalGuard.exe"
    monkeypatch.setattr(sys, "frozen", True, raising=False)
    monkeypatch.setattr(sys, "executable", str(executable))
    command, directory = worker_launch()
    assert command == [str(executable.resolve()), "--malguard-worker"]
    assert directory == executable.parent
    assert "-I" not in command


def test_standalone_self_test_completes_signed_rules_and_nested_workers(capsys):
    assert frozen.main(["--self-test"]) == 0
    output = json.loads(capsys.readouterr().out)
    assert output["self_test_passed"]
    assert output["sample_execution"] is False
    assert [item["artifact_count"] for item in output["checks"]] == [1, 3]
    assert all(item["coverage"] == 100 for item in output["checks"])


def test_standalone_scan_preserves_public_cli_contract(tmp_path, capsys):
    source = tmp_path / "harmless.lua"
    source.write_text("return 0", encoding="utf-8")
    assert frozen.main([str(source), "--format", "json"]) == 0
    output = json.loads(capsys.readouterr().out)
    assert output["verdict"] == "SAFE"
    assert source.read_text() == "return 0"


@pytest.mark.parametrize("entry", [frozen.main, frozen.scan_main])
def test_redirected_windows_help_uses_english_and_supports_persian(monkeypatch, entry):
    buffer = io.BytesIO()
    redirected = io.TextIOWrapper(buffer, encoding="cp1252")
    monkeypatch.setattr(sys, "stdout", redirected)
    with pytest.raises(SystemExit) as result:
        entry(["--help"])
    assert result.value.code == 0
    redirected.flush()
    output = buffer.getvalue().decode("utf-8")
    assert "usage:" in output
    assert "Local static analysis" in output
    assert "--language" in output and "{en,fa}" in output
    from malguard_cli.main import write_output
    write_output("گزارش فارسی")
    redirected.flush()
    assert "گزارش فارسی" in buffer.getvalue().decode("utf-8")


def test_interactive_entry_saves_report_without_modifying_input(monkeypatch, tmp_path, capsys):
    source = tmp_path / "ماد بی خطر.lua"
    source.write_text("return 0", encoding="utf-8")
    responses = iter([str(source), ""])
    monkeypatch.setattr("builtins.input", lambda prompt: next(responses))
    monkeypatch.setenv("LOCALAPPDATA", str(tmp_path / "local"))
    assert frozen.main([]) == 0
    paths = list((tmp_path / "local/MalGuard/Reports").glob("scan-*.json"))
    assert len(paths) == 1
    assert json.loads(paths[0].read_text(encoding="utf-8"))["verdict"] == "SAFE"
    assert source.read_text() == "return 0"
    assert "JSON report saved to:" in capsys.readouterr().out
