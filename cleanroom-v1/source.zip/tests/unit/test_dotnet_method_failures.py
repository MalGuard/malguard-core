"""Independent method failures retain only fully admitted synthetic IL facts."""

import struct

import pytest

from malguard_core.budget import BudgetLedger
from malguard_core.dotnet import analyze, parse_metadata
from malguard_core.model import CoverageState, ErrorCode, EvidenceDomain
from malguard_core.pe import validate
from tests.builders.pe_dotnet import managed_pe


CALLS = (
    ("System.Net.WebClient", "DownloadData", ("string",)),
    ("System.Reflection.Assembly", "Load", ("byte[]",)),
)
HARM_FAMILIES = {"LOADER_IN_MEMORY_EXECUTION", "REMOTE_CODE_EXECUTION"}


def _fixture(second_body: bytes):
    data = bytearray(managed_pe(calls=CALLS, pinvoke=("Unused",)))
    metadata = parse_metadata(validate(bytes(data), BudgetLedger()))
    section = metadata.layout.sections[0]
    second_offset = section.raw_offset + section.virtual_size
    assert second_offset + len(second_body) <= section.raw_offset + section.raw_size
    data[second_offset:second_offset + len(second_body)] = second_body
    second_rva = section.virtual_address + second_offset - section.raw_offset
    row = metadata.row_offsets[6][1]
    struct.pack_into("<I", data, row, second_rva)
    struct.pack_into("<H", data, row + 6, 0x16)
    return data, metadata


def _harm(result):
    return {item.family for item in result.evidence if item.domain is EvidenceDomain.HARM}


@pytest.mark.parametrize("invalid", ["bad_call", "unmapped"])
def test_later_invalid_method_keeps_completed_method_facts(invalid):
    data, metadata = _fixture(bytes.fromhex("1a28ff00000a2a"))
    if invalid == "unmapped":
        struct.pack_into("<I", data, metadata.row_offsets[6][1], 0x7FFFFFFF)
    result = analyze(bytes(data), "synthetic", "fixture.dll", BudgetLedger())
    assert result.state is CoverageState.PARTIAL
    assert result.facts["structure_status"] == "MALFORMED"
    assert result.errors == (ErrorCode.MALFORMED_INPUT,)
    assert [method["index"] for method in result.facts["methods"]] == [1]
    assert HARM_FAMILIES <= _harm(result)
    opaque = next(item for item in result.evidence if item.rule_id == "NET.IL_OPAQUE")
    if invalid == "unmapped":
        assert opaque.location.offset is None


@pytest.mark.parametrize("invalid", ["bad_call", "bad_opcode", "unmapped"])
def test_invalid_first_method_does_not_block_valid_later_method(invalid):
    original = managed_pe(calls=CALLS, pinvoke=("Unused",))
    metadata = parse_metadata(validate(original, BudgetLedger()))
    first_offset = metadata.layout.rva(metadata.tables[6][0][0])
    body_size = (original[first_offset] >> 2) + 1
    data, metadata = _fixture(original[first_offset:first_offset + body_size])
    if invalid == "bad_call":
        struct.pack_into("<I", data, first_offset + 2, 0x0A00FFFF)
    elif invalid == "bad_opcode":
        data[first_offset + 1] = 0xFF
    else:
        struct.pack_into("<I", data, metadata.row_offsets[6][0], 0x7FFFFFFF)
    result = analyze(bytes(data), "synthetic", "fixture.dll", BudgetLedger())
    assert result.state is CoverageState.PARTIAL
    assert result.facts["structure_status"] == "MALFORMED"
    assert [method["index"] for method in result.facts["methods"]] == [2]
    assert HARM_FAMILIES <= _harm(result)


def test_invalid_method_does_not_admit_its_partial_call_chain():
    data = bytearray(managed_pe(calls=(*CALLS, ("System.Diagnostics.Process", "Start", ("string",)))))
    metadata = parse_metadata(validate(bytes(data), BudgetLedger()))
    first_offset = metadata.layout.rva(metadata.tables[6][0][0])
    # The first two external calls are valid. The third invalid token means
    # this entire method is excluded rather than admitted as a partial chain.
    struct.pack_into("<I", data, first_offset + 12, 0x0A00FFFF)
    result = analyze(bytes(data), "synthetic", "fixture.dll", BudgetLedger())
    assert result.state is CoverageState.PARTIAL
    assert result.facts["structure_status"] == "MALFORMED"
    assert result.facts["methods"] == []
    assert not _harm(result)


@pytest.mark.parametrize("limits,dimension", [
    ({"parser_iterations": 420}, "parser_iterations"),
    ({"read_bytes": 1048}, "read_bytes"),
])
def test_later_method_global_budget_failure_retains_completed_facts_and_harm(limits, dimension):
    # This fat method fits within section padding but requires further bounded
    # reads and 81 IL instructions after the first method has been admitted.
    body = struct.pack("<HHII", 0x3003, 8, 81, 0) + bytes(80) + b"\x2a"
    data, _ = _fixture(body)
    ledger = BudgetLedger(limits)
    result = analyze(bytes(data), "synthetic", "fixture.dll", ledger)
    assert result.state is CoverageState.SKIPPED_LIMIT
    assert result.facts["structure_status"] == "VALID"
    assert result.errors == (ErrorCode.ITERATION_BUDGET_EXHAUSTED,)
    assert ledger.exhausted == (dimension,)
    assert [method["index"] for method in result.facts["methods"]] == [1]
    assert HARM_FAMILIES <= _harm(result)
    assert ledger.consumed("evidence") == len(result.evidence)


def test_self_call_closure_emits_direct_method_evidence_once():
    original = managed_pe(calls=CALLS, pinvoke=("Unused",))
    metadata = parse_metadata(validate(original, BudgetLedger()))
    first_offset = metadata.layout.rva(metadata.tables[6][0][0])
    external_calls = original[first_offset + 1:first_offset + 11]
    code = external_calls + b"\x28\x01\x00\x00\x06\x2a"
    body = bytes([(len(code) << 2) | 2]) + code
    data, metadata = _fixture(body)
    # The first method now uses the copied body and calls itself. The unused
    # second method stays unimplemented so no method has shared body bytes.
    struct.pack_into("<I", data, metadata.row_offsets[6][0],
                     struct.unpack_from("<I", data, metadata.row_offsets[6][1])[0])
    struct.pack_into("<I", data, metadata.row_offsets[6][1], 0)
    ledger = BudgetLedger()
    result = analyze(bytes(data), "synthetic", "fixture.dll", ledger)
    assert result.state is CoverageState.COMPLETE
    assert HARM_FAMILIES <= _harm(result)
    assert len(result.evidence) == len({item.id for item in result.evidence})
    assert ledger.consumed("evidence") == len(result.evidence) == 3

