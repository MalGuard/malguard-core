"""Harmless synthetic boundaries, intake, encodings and deterministic models."""

import base64
from dataclasses import FrozenInstanceError
import hashlib
import os
import random
import struct

import pytest

from malguard_core.budget import BudgetExceeded, BudgetLedger
from malguard_core.decoding import decode_bytes, decode_strings
from malguard_core.intake import BoundedByteSource, IntakeError, analyze_filename, extension_of, identify, type_mismatch_evidence
from malguard_core.model import ArtifactStatus, CoverageState, ErrorCode, EvidenceDomain, EvidenceLocation, Severity, StageResult, make_evidence
from malguard_core.settings import ScanSettings
from malguard_core.strings import ExtractedString, extract_strings


def synthetic_pe(*, is_dll: bool = True, plus: bool = False, clr: bool = False) -> bytes:
    """Only headers and zero bytes; no executable code or usable entry point."""
    data = bytearray(1024)
    data[:2] = b"MZ"
    struct.pack_into("<I", data, 0x3C, 0x80)
    data[0x80:0x84] = b"PE\0\0"
    optional_size = 240 if plus else 224
    struct.pack_into("<HHIIIHH", data, 0x84, 0x8664 if plus else 0x14C, 1, 0, 0, 0, optional_size, 0x2002 if is_dll else 2)
    optional = 0x98
    struct.pack_into("<H", data, optional, 0x20B if plus else 0x10B)
    struct.pack_into("<I", data, optional + 16, 0)
    struct.pack_into("<II", data, optional + 32, 4096, 512)
    struct.pack_into("<II", data, optional + 56, 8192, 512)
    directories = 112 if plus else 96
    struct.pack_into("<I", data, optional + directories - 4, 16)
    section = optional + optional_size
    data[section:section + 8] = b".text\0\0\0"
    struct.pack_into("<IIII", data, section + 8, 512, 0x1000, 512, 512)
    struct.pack_into("<I", data, section + 36, 0x60000020)
    if clr:
        struct.pack_into("<II", data, optional + directories + 14 * 8, 0x1020, 72)
        struct.pack_into("<I", data, 0x220, 72)
    return bytes(data)


@pytest.mark.parametrize("offset,length", [(-1, 1), (0, -1), (True, 1), (0, True), (2**63, 0), (2**63 - 1, 1), (3, 2), (0, 5)])
def test_hostile_reads_are_rejected(offset, length):
    source = BoundedByteSource(b"1234", BudgetLedger(), 4)
    with pytest.raises(ValueError):
        source.read(offset, length)


def test_per_read_and_global_budget_are_enforced():
    ledger = BudgetLedger({"read_bytes": 5})
    source = BoundedByteSource(b"123456", ledger, 3)
    assert source.read(0, 3) == b"123"
    with pytest.raises(ValueError):
        source.read(0, 4)
    assert source.read_tail(2) == b"56"
    with pytest.raises(BudgetExceeded) as error:
        source.read_head(1)
    assert error.value.error_code is ErrorCode.ITERATION_BUDGET_EXHAUSTED
    assert error.value.resource == "read_bytes"
    assert ledger.usage()["read_bytes"] == 5


def test_chunk_bounds_and_child_global_budget():
    ledger = BudgetLedger({"file_bytes": 5})
    parent = BoundedByteSource(b"123", ledger, 2)
    child = BoundedByteSource(b"45", ledger, 1)
    assert list(parent.iter_chunks(offset=1, length=2)) == [b"23"]
    assert child.read_all() == b"45"
    with pytest.raises(BudgetExceeded):
        BoundedByteSource(b"6", ledger)


def test_atomic_budgets_and_snapshot():
    ledger = BudgetLedger({"strings": 1, "string_bytes": 3})
    with pytest.raises(BudgetExceeded):
        ledger.consume_many({"strings": 1, "string_bytes": 4})
    assert ledger.consumed("strings") == 0
    assert ledger.snapshot().exhausted == ("string_bytes",)
    with pytest.raises(ValueError):
        ledger.consume("strings", True)
    with pytest.raises(ValueError):
        ledger.consume("unrecognized", 1)


def test_file_capture_hashes_and_size_limit(tmp_path):
    path = tmp_path / "harmless.lua"
    data = b"print('synthetic test')\n"
    path.write_bytes(data)
    source = BoundedByteSource.from_path(path, BudgetLedger(), 5)
    assert source.read_all() == data
    hashes = source.hashes()
    assert hashes.sha256 == hashlib.sha256(data).hexdigest()
    assert hashes.sha1 == hashlib.sha1(data, usedforsecurity=False).hexdigest()
    assert hashes.md5 == hashlib.md5(data, usedforsecurity=False).hexdigest()
    with pytest.raises(IntakeError) as error:
        BoundedByteSource.from_path(path, BudgetLedger(), max_file_size=2)
    assert error.value.error_code is ErrorCode.ITERATION_BUDGET_EXHAUSTED
    with pytest.raises(IntakeError):
        BoundedByteSource.from_path(tmp_path, BudgetLedger())


@pytest.mark.skipif(not hasattr(os, "symlink"), reason="symlinks unavailable")
def test_symlink_rejected(tmp_path):
    path = tmp_path / "target.txt"
    path.write_bytes(b"harmless")
    link = tmp_path / "link.txt"
    try:
        link.symlink_to(path)
    except OSError:
        pytest.skip("symlink permission unavailable")
    with pytest.raises(IntakeError):
        BoundedByteSource.from_path(link, BudgetLedger())


@pytest.mark.parametrize("plus,is_dll,expected", [(False, True, "PE32_DLL"), (False, False, "PE32_EXE"), (True, True, "PE32_PLUS_DLL"), (True, False, "PE32_PLUS_EXE")])
def test_real_pe_shape_identification(plus, is_dll, expected):
    result = identify(synthetic_pe(is_dll=is_dll, plus=plus), ".asi")
    assert result["true_type"] == expected
    assert result["structure_status"] is ArtifactStatus.VALID


def test_clr_and_masquerade_identification():
    assert identify(synthetic_pe(clr=True), ".dll")["is_dotnet"]
    for extension in (".asi", ".dll"):
        result = identify(synthetic_pe(is_dll=False), extension)
        evidence = type_mismatch_evidence(result, "harmless" + extension, "root")
        assert evidence[0].severity is Severity.CRITICAL


def test_truncated_corrupt_and_absurd_sections():
    good = synthetic_pe()
    for length in (0, 1, 2, 20, 63, 100, 150, 200, 300):
        result = identify(good[:length], ".dll")
        assert result["structure_status"] is not ArtifactStatus.VALID
    corrupt = bytearray(good)
    struct.pack_into("<H", corrupt, 0x86, 65535)
    assert identify(bytes(corrupt), ".dll")["structure_status"] is ArtifactStatus.MALFORMED
    assert identify(b"MZ" + bytes(100), ".dll")["structure_status"] is ArtifactStatus.MALFORMED


@pytest.mark.parametrize("data,extension,true_type", [(b"local x = 1\n", ".lua", "LUA_SOURCE"), (b"Write-Host 'hello'", ".ps1", "POWERSHELL"), (b"\x1bLua\x54", "", "LUA_BYTECODE"), (b"\x1bLJ\x02", "", "LUAJIT_BYTECODE"), (b"PK\x05\x06" + bytes(18), ".zip", "ZIP"), (b"7z\xbc\xaf\x27\x1c" + bytes(26), ".7z", "7Z"), (b"Rar!\x1a\x07\x01\0" + bytes(20), ".rar", "RAR")])
def test_script_archive_identification(data, extension, true_type):
    assert identify(data, extension)["true_type"] == true_type


def test_filename_normalization_deception():
    assert extension_of("directory\\MyMod.DLL") == ".dll"
    assert analyze_filename("photo.jpg.exe", "root")[0].family == "MASQUERADE"
    assert analyze_filename("safe\u202egpj.exe", "root")
    assert not analyze_filename("version.dll", "root")
    assert not analyze_filename("mod.v1.asi", "root")


@pytest.mark.parametrize("encoding", ["utf-16le", "utf-16be"])
def test_unmarked_utf16_source_identification(encoding):
    result = identify("local value = 1\n".encode(encoding), ".lua")
    assert result["true_type"] == "LUA_SOURCE"
    assert result["is_script"]


@pytest.mark.parametrize("chunk_size", [1, 2, 3, 5, 16, 4096])
def test_ascii_utf16_stream_boundaries(chunk_size):
    wide = "WriteProcessMemory".encode("utf-16le")
    data = b"plainASCII\0!" + wide + b"\0\0"
    ledger = BudgetLedger()
    strings = extract_strings(BoundedByteSource(data, ledger, chunk_size), ledger)
    assert any(item.text == "plainASCII" and item.offset == 0 for item in strings)
    assert any(item.text == "WriteProcessMemory" and item.offset == 12 and item.encoding == "utf-16le" for item in strings)


def test_string_limit_retains_earlier_results():
    ledger = BudgetLedger({"strings": 1})
    with pytest.raises(BudgetExceeded) as error:
        extract_strings(BoundedByteSource(b"credential\0second-string\0", ledger), ledger)
    assert error.value.partial_results[0].text == "credential"


def test_bounded_encodings_splits_reversals_and_char_arrays():
    token = "WriteProcessMemory"
    values = (base64.b64encode(token.encode()).decode(), token.encode().hex(), token[::-1], '"Write" + "ProcessMemory"', "string.char(" + ",".join(str(ord(char)) for char in token) + ")")
    source = tuple(ExtractedString(value, index, "ascii") for index, value in enumerate(values))
    decoded = decode_strings(source, BudgetLedger())
    for index in range(len(values)):
        assert any(token in item.text and item.offset == index for item in decoded)
    assert all(item.decoded for item in decoded)


def test_base64_utf16_and_recursive_base64():
    token = "Invoke-Expression"
    nested = base64.b64encode(base64.b64encode(token.encode())).decode()
    utf16 = base64.b64encode(token.encode("utf-16le")).decode()
    decoded = decode_strings((ExtractedString(nested, 0, "ascii"), ExtractedString(utf16, 1, "ascii")), BudgetLedger())
    assert any(item.text == token and item.offset == 0 for item in decoded)
    assert any(item.text == token and item.offset == 1 for item in decoded)


@pytest.mark.parametrize("key", [1, 42, 127, 200, 255])
def test_xor_mutations_detected_without_full_key_bruteforce(key):
    payload = b"WriteProcessMemory\0CreateRemoteThread\0Login Data"
    data = bytes(byte ^ key for byte in payload)
    ledger = BudgetLedger()
    decoded = decode_bytes(data, ledger)
    assert any("WriteProcessMemory" in item.text for item in decoded)
    assert ledger.consumed("parser_iterations") < 4096


def test_clean_large_raw_bytes_do_not_exhaust_xor_budget():
    ledger = BudgetLedger()
    assert not decode_bytes(bytes(65536), ledger)
    assert not ledger.exhausted


def test_evidence_ids_are_deterministic_and_frozen():
    args = ("TEST.RULE", "S0", EvidenceDomain.CONTEXT, "TEST", "synthetic", Severity.LOW, EvidenceLocation("root", 1, 2), "Synthetic harmless fact.", "واقعیت آزمایشی بی‌ضرر.")
    a = make_evidence(*args, attributes=(("b", 2), ("a", 1)))
    b = make_evidence(*args, confidence=1, attributes=(("a", 1), ("b", 2)))
    assert a.id == b.id
    assert a.effective_weight == 4
    with pytest.raises(FrozenInstanceError):
        a.family = "changed"
    with pytest.raises(ValueError):
        make_evidence(*args, confidence=float("nan"))
    with pytest.raises(ValueError):
        EvidenceLocation("root", 2**63 - 1, 1)


def test_analyzer_facts_reject_objects_and_verdicts():
    for facts in ({"verdict": "SAFE"}, {"object": object()}, {"nested": {"final_verdict": "SAFE"}}, {1: "value"}, {"number": float("inf")}):
        with pytest.raises(ValueError):
            StageResult("S0", facts=facts)
    stage = StageResult("S0", CoverageState.COMPLETE, facts={"strings": ["harmless"]})
    assert stage.facts == {"strings": ["harmless"]}


def test_settings_are_validated_and_immutable():
    settings = ScanSettings(budget_limits={"strings": 2})
    assert settings.budget_limits["strings"] == 2
    with pytest.raises(TypeError):
        settings.budget_limits["strings"] = 3
    with pytest.raises(ValueError):
        ScanSettings(per_read_limit=0)
    with pytest.raises(ValueError):
        ScanSettings(budget_limits={"unknown": 3})


def test_random_malformed_inputs_never_crash_identification():
    rng = random.Random(71)
    for length in range(256):
        data = rng.randbytes(length)
        result = identify(data, ".dll")
        assert result["structure_status"] in ArtifactStatus
