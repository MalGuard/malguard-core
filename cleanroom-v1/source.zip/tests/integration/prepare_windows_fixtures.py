"""Prepare inert bytes for standalone EXE parity checks, never executed."""

from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

from malguard_core import Scanner
from tests.builders.archive_fixtures import (
    central_local_mismatch, encrypted_zip, rar4_stored, seven_zip_bytes, zip_bytes,
)
from tests.builders.behavior import (
    credential_transfer, encoded_powershell, gta_trainer_source, lua_remote_loader,
)
from tests.builders.pe_dotnet import managed_pe, native_pe


def prepare(directory: Path) -> dict[str, object]:
    directory.mkdir(parents=True, exist_ok=False)
    harm = native_pe(strings=credential_transfer())
    damaged = bytearray(harm)
    damaged[0x80:0x84] = b"BAD!"
    payloads = {
        "ماد بی خطر با فاصله.lua": b"local version = 'inert fixture'\nprint(version)\n",
        "http-only.lua": b'PerformHttpRequest("https://example.invalid/version", function(s, body) print(body) end)',
        "remote-loader.lua": lua_remote_loader(),
        "credential-transfer.dll": harm,
        "damaged-harm.dll": bytes(damaged),
        "legitimate-style.asi": native_pe(imports=("VirtualProtect", "scriptRegister", "nativeInit", "nativeCall")),
        "gta-only-trainer.cs": gta_trainer_source(),
        "virtualalloc.dll": native_pe(imports=("VirtualAlloc",)),
        "browser-path.dll": native_pe(strings=b"Chrome\\User Data\\Login Data\x00"),
        "shvdn.dll": managed_pe(),
        "version-check.dll": managed_pe(calls=(("System.Net.Http.HttpClient", "GetStringAsync", ("string",)),)),
        "memory-loader.dll": managed_pe(calls=(("System.Reflection.Assembly", "Load", ("byte[]",)),
                                              ("System.Reflection.MethodInfo", "Invoke", ("object", "object"))),
                                         resources=(("payload", native_pe()),)),
        "embedded-harm.dll": native_pe(resource=harm),
        "nested.zip": zip_bytes([("inner.zip", zip_bytes([("loader.dll", harm)]))]),
        "benign.7z": seven_zip_bytes([("safe.lua", b"return 0")]),
        "benign.rar": rar4_stored([("safe.lua", b"return 0")]),
        "encrypted.zip": encrypted_zip(),
        "mismatch.zip": central_local_mismatch(),
        "encoded.ps1": encoded_powershell(),
    }
    required = {
        "credential-transfer.dll": "MALICIOUS", "damaged-harm.dll": "MALICIOUS",
        "nested.zip": "MALICIOUS", "encrypted.zip": "INCONCLUSIVE",
        "ماد بی خطر با فاصله.lua": "SAFE", "gta-only-trainer.cs": "SAFE",
        "http-only.lua": "SAFE", "shvdn.dll": "SAFE", "version-check.dll": "SAFE",
    }
    rows = []
    with Scanner() as scanner:
        for name, data in payloads.items():
            path = directory / name
            path.write_bytes(data)
            report = scanner.scan_file(path)
            if name in required and report.verdict.value != required[name]:
                raise AssertionError(f"Required fixture behavior failed: {name}: {report.verdict.value}")
            if name in ("legitimate-style.asi", "virtualalloc.dll", "browser-path.dll"):
                assert report.verdict.value != "MALICIOUS"
            rows.append({"name": name, "sha256": hashlib.sha256(data).hexdigest(),
                         "verdict": report.verdict.value, "risk": report.risk_score,
                         "coverage": report.coverage_score, "artifacts": len(report.artifacts)})
    dataset = directory / "dataset"
    (dataset / "benign").mkdir(parents=True)
    (dataset / "malicious").mkdir()
    (dataset / "benign/fixture.lua").write_bytes(b"return 0")
    (dataset / "malicious/fixture.dll").write_bytes(harm)
    manifest: dict[str, object] = {"schema_version": 1, "synthetic_only": True,
                                  "sample_execution": False, "cases": rows}
    (directory / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2)
                                               + "\n", encoding="utf-8")
    return manifest


if __name__ == "__main__":
    print(json.dumps(prepare(Path(sys.argv[1])), ensure_ascii=False, indent=2))
