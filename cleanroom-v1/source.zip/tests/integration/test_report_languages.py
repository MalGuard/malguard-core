"""Language selection changes presentation, never evidence or verdicts."""

import pytest

from malguard_core import Scanner
from malguard_core.model import Verdict
from tests.builders.pe_dotnet import native_pe


def test_english_persian_reports_preserve_the_same_scan(tmp_path):
    path = tmp_path / "benign.asi"
    path.write_bytes(native_pe())
    with Scanner() as scanner:
        report = scanner.scan_file(path)
    before = report.to_json()
    assert report.verdict is Verdict.SAFE
    assert "No evidence of malicious behavior" in report.to_text(language="en")
    assert "تضمین ایمنی نیست" in report.to_text(language="fa")
    assert report.to_text() == report.to_text(language="fa")
    assert report.to_json() == before
    with pytest.raises(ValueError, match="Unsupported report language"):
        report.to_text(language="unknown")


def test_invalid_structure_explanation_in_both_languages(tmp_path):
    path = tmp_path / "text.asi"
    path.write_bytes(b"Synthetic text fixture for selection, not an actual Windows DLL.\n")
    with Scanner() as scanner:
        report = scanner.scan_file(path)
    assert report.verdict is Verdict.INVALID
    assert "This file is plain text" in report.to_text(language="en")
    assert "تغییر پسوند" in report.to_text(language="fa")
