"""Installed CLI regressions using only harmless static source fixtures.

Run these with the interpreter that has the wheel installed. Every scanner
subprocess uses isolated Python outside the checkout; no fixture is executed.
"""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import sysconfig
from pathlib import Path

import pytest


def _run(directory: Path, *arguments: str, evaluate: bool = False, offline: bool = False):
    module = "malguard_cli.evaluation" if evaluate else "malguard_cli"
    environment = os.environ.copy()
    if offline:
        for name in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "http_proxy", "https_proxy", "all_proxy"):
            environment[name] = "http://127.0.0.1:1"
        environment["NO_PROXY"] = environment["no_proxy"] = ""
    return subprocess.run(  # noqa: S603 -- trusted installed scanner, never a fixture
        [sys.executable, "-I", "-m", module, *arguments],
        cwd=directory,
        env=environment,
        capture_output=True,
        encoding="utf-8",
        errors="strict",
        check=False,
        timeout=60,
    )


def _sample(directory: Path) -> Path:
    path = directory / "ماد آزمایشی با فاصله.lua"
    path.write_text("local version = 'harmless synthetic fixture'\nprint(version)\n", encoding="utf-8")
    return path


def _dataset(directory: Path) -> Path:
    dataset = directory / "مجموعه با فاصله"
    (dataset / "benign").mkdir(parents=True)
    (dataset / "malicious").mkdir()
    _sample(dataset / "benign")
    return dataset


@pytest.mark.parametrize("name", ["malguard", "malguard-evaluate"])
def test_installed_console_entrypoints(name, tmp_path):
    executable = Path(sysconfig.get_path("scripts")) / (name + (".exe" if os.name == "nt" else ""))
    result = subprocess.run(  # noqa: S603 -- fixed trusted distribution entry point
        [str(executable), "--help"], cwd=tmp_path, capture_output=True,
        encoding="utf-8", check=False, timeout=30,
    )
    assert result.returncode == 0
    assert "usage:" in result.stdout
    if name == "malguard":
        assert "Local static analysis" in result.stdout
        assert "--language {en,fa}" in result.stdout
        sample = _sample(tmp_path)
        translated = subprocess.run(  # noqa: S603 -- trusted installed scanner only
            [str(executable), str(sample), "--language", "fa"],
            cwd=tmp_path, capture_output=True, encoding="utf-8", check=False, timeout=60,
        )
        assert translated.returncode == 0
        assert any("\u0600" <= char <= "\u06ff" for char in translated.stdout)
        assert not translated.stderr
    else:
        assert any("\u0600" <= char <= "\u06ff" for char in result.stdout)
    assert not result.stderr


@pytest.mark.parametrize("evaluate", [False, True])
def test_installed_console_scans_and_writes_reports(evaluate, tmp_path):
    name = "malguard-evaluate" if evaluate else "malguard"
    executable = Path(sysconfig.get_path("scripts")) / (name + (".exe" if os.name == "nt" else ""))
    source = _dataset(tmp_path) if evaluate else _sample(tmp_path)
    output = tmp_path / "گزارش فرمان نصب شده.json"
    command = [str(executable), str(source), "--output", str(output)]
    if not evaluate:
        command.extend(("--format", "json"))
    result = subprocess.run(  # noqa: S603 -- trusted installed CLI, never a fixture
        command, cwd=tmp_path, capture_output=True, encoding="utf-8",
        check=False, timeout=60,
    )
    assert result.returncode == 0
    assert not result.stdout and not result.stderr
    report = json.loads(output.read_text(encoding="utf-8"))
    if evaluate:
        assert report["sample_count"] == 1
        assert report["metrics"]["true_negatives"] == 1
    else:
        assert report["verdict"] == "SAFE"


@pytest.mark.parametrize("evaluate,arguments", [
    (False, ()),
    (False, ("sample.lua", "--format", "yaml")),
    (False, ("sample.lua", "--unknown-option")),
    (True, ()),
])
def test_cli_usage_errors(evaluate, arguments, tmp_path):
    result = _run(tmp_path, *arguments, evaluate=evaluate)
    assert result.returncode == 2
    assert "usage:" in result.stderr
    assert not result.stdout


def test_persian_and_space_paths_have_deterministic_json_and_utf8_text(tmp_path):
    sample = _sample(tmp_path)
    original = sample.read_bytes()
    first = _run(tmp_path, str(sample), "--format", "json")
    second = _run(tmp_path, str(sample), "--format", "json")
    assert first.returncode == second.returncode == 0
    assert not first.stderr and not second.stderr
    report = json.loads(first.stdout)
    assert report == json.loads(second.stdout)
    assert report["verdict"] == "SAFE"
    assert report["hashes"]["sha256"] == hashlib.sha256(original).hexdigest()
    assert report["artifacts"][0]["logical_path"] == str(sample)
    output = tmp_path / "گزارش با فاصله.json"
    written = _run(tmp_path, str(sample), "--format", "json", "--output", str(output))
    assert written.returncode == 0
    assert not written.stdout and not written.stderr
    assert output.read_bytes().endswith(b"\n")
    assert json.loads(output.read_text(encoding="utf-8")) == report
    text = _run(tmp_path, str(sample))
    assert text.returncode == 0
    assert any("\u0600" <= char <= "\u06ff" for char in text.stdout)
    assert sample.read_bytes() == original


@pytest.mark.parametrize("target_kind", ["report", "input", "symlink", "hardlink"])
def test_scan_output_refuses_existing_targets_without_changing_content(target_kind, tmp_path):
    sample = _sample(tmp_path)
    original = sample.read_bytes()
    output = tmp_path / "report.json"
    if target_kind == "input":
        output = sample
    elif target_kind == "symlink":
        try:
            output.symlink_to(sample)
        except OSError:
            pytest.skip("Symbolic links require platform privileges")
        if not output.is_symlink() or not output.exists():
            pytest.skip("Runtime did not create a usable symbolic-link fixture")
    elif target_kind == "hardlink":
        os.link(sample, output)
    else:
        output.write_bytes(b"Existing report must remain intact\n")
    previous = output.read_bytes()
    result = _run(tmp_path, str(sample), "--format", "json", "--output", str(output))
    assert result.returncode == 4
    assert "FileExistsError" in result.stderr
    assert not result.stdout
    assert output.read_bytes() == previous
    assert sample.read_bytes() == original


@pytest.mark.parametrize("target_kind", ["directory", "missing_parent", "parent_file"])
def test_scan_output_errors_are_controlled(target_kind, tmp_path):
    sample = _sample(tmp_path)
    if target_kind == "directory":
        output = tmp_path / "directory"
        output.mkdir()
    elif target_kind == "parent_file":
        parent = tmp_path / "parent"
        parent.write_text("harmless placeholder", encoding="utf-8")
        output = parent / "report.json"
    else:
        output = tmp_path / "missing" / "report.json"
    result = _run(tmp_path, str(sample), "--output", str(output))
    assert result.returncode == 4
    assert not result.stdout
    assert "Traceback" not in result.stderr
    assert "Error" in result.stderr


@pytest.mark.parametrize("input_kind", ["missing", "directory", "symlink"])
def test_unreadable_input_reports_inconclusive_with_io_error(input_kind, tmp_path):
    sample = tmp_path / "input.lua"
    if input_kind == "directory":
        sample.mkdir()
    elif input_kind == "symlink":
        target = _sample(tmp_path)
        try:
            sample.symlink_to(target)
        except OSError:
            pytest.skip("Symbolic links require platform privileges")
    result = _run(tmp_path, str(sample), "--format", "json")
    assert result.returncode == 3
    assert not result.stderr
    report = json.loads(result.stdout)
    assert report["verdict"] == "INCONCLUSIVE"
    assert report["structure_status"] == "BLOCKED"
    assert report["incomplete_stages"][0]["error_code"] == "IO_ERROR"
    assert report["incomplete_stages"][0]["stage"] == "S0"


def test_scan_succeeds_with_unreachable_proxies(tmp_path):
    sample = _sample(tmp_path)
    ordinary = _run(tmp_path, str(sample), "--format", "json")
    offline = _run(tmp_path, str(sample), "--format", "json", offline=True)
    assert ordinary.returncode == offline.returncode == 0
    assert not offline.stderr
    assert json.loads(ordinary.stdout) == json.loads(offline.stdout)


def test_evaluator_bookkeeping_on_harmless_labels_and_persian_paths(tmp_path):
    dataset = _dataset(tmp_path)
    # The label checks confusion-matrix bookkeeping, not detection accuracy.
    _sample(dataset / "malicious")
    output = tmp_path / "نتیجه ارزیابی.json"
    result = _run(tmp_path, str(dataset), "--output", str(output), evaluate=True, offline=True)
    assert result.returncode == 0
    assert not result.stdout and not result.stderr
    report = json.loads(output.read_text(encoding="utf-8"))
    assert report["sample_count"] == 2
    assert report["scan_failures"] == 0
    assert report["scan_mode"] == "STATIC_ONLY"
    assert report["acceptance_targets_evaluated"] is False
    assert report["metrics"]["true_negatives"] == 1
    assert report["metrics"]["false_negatives"] == 1
    assert report["metrics"]["true_positives"] == 0
    assert report["metrics"]["precision"] is None
    assert all(row["verdict"] == "SAFE" for row in report["samples"])


@pytest.mark.parametrize("target_kind", ["report", "input", "directory", "missing_parent"])
def test_evaluation_output_refuses_overwrites_and_bad_paths(target_kind, tmp_path):
    dataset = _dataset(tmp_path)
    sample = next((dataset / "benign").iterdir())
    original = sample.read_bytes()
    output = tmp_path / "evaluation.json"
    previous = None
    if target_kind == "input":
        output = sample
        previous = original
    elif target_kind == "report":
        previous = b"Existing evaluation\n"
        output.write_bytes(previous)
    elif target_kind == "directory":
        output.mkdir()
    else:
        output = tmp_path / "missing" / "evaluation.json"
    result = _run(tmp_path, str(dataset), "--output", str(output), evaluate=True)
    assert result.returncode == 4
    assert not result.stdout
    assert "Traceback" not in result.stderr
    assert "Error" in result.stderr
    if previous is not None:
        assert output.read_bytes() == previous
    assert sample.read_bytes() == original


@pytest.mark.parametrize("missing_kind", ["dataset", "malicious_directory"])
def test_evaluation_requires_both_label_directories(missing_kind, tmp_path):
    dataset = tmp_path / "dataset"
    if missing_kind == "malicious_directory":
        (dataset / "benign").mkdir(parents=True)
    result = _run(tmp_path, str(dataset), evaluate=True)
    assert result.returncode == 4
    assert "ValueError" in result.stderr
    assert not result.stdout


def test_empty_evaluation_rates_remain_undefined(tmp_path):
    dataset = tmp_path / "empty dataset"
    for label in ("benign", "malicious"):
        (dataset / label).mkdir(parents=True)
    result = _run(tmp_path, str(dataset), evaluate=True)
    assert result.returncode == 0
    report = json.loads(result.stdout)
    assert report["sample_count"] == 0
    assert report["scan_failures"] == 0
    assert all(report["metrics"][metric] is None for metric in (
        "precision", "recall", "false_positive_rate", "safe_rate",
    ))


def test_evaluation_reports_skipped_symlinks(tmp_path):
    dataset = _dataset(tmp_path)
    sample = next((dataset / "benign").iterdir())
    alias = dataset / "malicious" / "alias.lua"
    try:
        alias.symlink_to(sample)
    except OSError:
        pytest.skip("Symbolic links require platform privileges")
    if not alias.is_symlink() or not alias.exists():
        pytest.skip("Runtime did not create a usable symbolic-link fixture")
    result = _run(tmp_path, str(dataset), evaluate=True)
    assert result.returncode == 4
    assert not result.stderr
    report = json.loads(result.stdout)
    assert report["sample_count"] == 1
    assert report["scan_failures"] == 0
    assert len(report["skipped"]) == 1
    assert report["skipped"][0]["reason"] == "NOT_REGULAR_FILE"
