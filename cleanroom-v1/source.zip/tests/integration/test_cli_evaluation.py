"""Harmless corpus bookkeeping and output safety regressions."""

from enum import StrEnum
from types import SimpleNamespace

import pytest

from malguard_cli.evaluation import evaluate
from malguard_cli.main import write_output


class Verdict(StrEnum):
    SAFE = "SAFE"
    MALICIOUS = "MALICIOUS"
    SUSPICIOUS = "SUSPICIOUS"
    INCONCLUSIVE = "INCONCLUSIVE"


def test_evaluation_preserves_uncertain_false_negatives(tmp_path):
    for label in ("benign", "malicious"):
        (tmp_path / label).mkdir()
    cases = {
        "benign/clean.txt": Verdict.SAFE,
        "benign/flag.txt": Verdict.MALICIOUS,
        "malicious/positive.txt": Verdict.MALICIOUS,
        "malicious/uncertain.txt": Verdict.INCONCLUSIVE,
        "malicious/weak.txt": Verdict.SUSPICIOUS,
    }
    for name in cases:
        (tmp_path / name).write_text("Harmless labeled bookkeeping fixture")

    def scan(path):
        return SimpleNamespace(verdict=cases[path.relative_to(tmp_path).as_posix()], risk_score=0, coverage_score=100)

    result = evaluate(tmp_path, scan)
    metrics = result["metrics"]
    assert metrics["true_positives"] == 1
    assert metrics["false_positives"] == 1
    assert metrics["false_negatives"] == 2
    assert metrics["true_negatives"] == 1
    assert metrics["recall"] == pytest.approx(1 / 3)
    assert metrics["malicious_or_suspicious_recall"] == pytest.approx(2 / 3)
    assert metrics["safe_rate"] == pytest.approx(1 / 5)


def test_evaluation_failure_never_counts_as_safe(tmp_path):
    for label in ("benign", "malicious"):
        (tmp_path / label).mkdir()
    (tmp_path / "malicious" / "synthetic.txt").write_text("Harmless")

    def fail(path):
        raise ValueError("Synthetic analyzer failure")

    result = evaluate(tmp_path, fail)
    assert result["scan_failures"] == 1
    assert result["metrics"]["false_negatives"] == 1
    assert result["counts_by_label"]["malicious"]["INCONCLUSIVE"] == 1


def test_empty_corpus_has_undefined_rates(tmp_path):
    for label in ("benign", "malicious"):
        (tmp_path / label).mkdir()
    result = evaluate(tmp_path, lambda path: None)
    assert result["sample_count"] == 0
    assert result["metrics"]["precision"] is None
    assert result["metrics"]["recall"] is None


def test_output_cannot_overwrite_scanned_input(tmp_path):
    sample = tmp_path / "sample.lua"
    sample.write_text("print('harmless')")
    with pytest.raises(FileExistsError):
        write_output("report", sample)
    assert sample.read_text() == "print('harmless')"
