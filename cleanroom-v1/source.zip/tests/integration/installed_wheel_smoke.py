"""Check the installed distribution using harmless source and archive fixtures.

Run with ``python -I tests/integration/installed_wheel_smoke.py`` after installing
a locally built wheel. Isolated Python and a temporary working directory ensure
the checkout cannot supply imports or missing packaged security resources.
"""

from __future__ import annotations

import importlib.metadata
import importlib.resources
import io
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path


def _cli(path: Path, directory: Path, output_format: str) -> tuple[int, str]:
    # This command runs the trusted scanner module, never the scanned path.
    command = [
        sys.executable, "-I", "-m", "malguard_cli", str(path),
        "--format", output_format,
    ]
    completed = subprocess.run(  # noqa: S603
        command, cwd=directory, capture_output=True, check=False, timeout=60,
        encoding="utf-8", errors="strict",
    )
    if completed.stderr:
        raise RuntimeError(f"Installed CLI emitted an error: {completed.stderr}")
    return completed.returncode, completed.stdout


def main() -> int:
    import malguard_core
    from malguard_core.adapters import import_capa_json
    from malguard_core.budget import BudgetLedger
    from malguard_core.model import EvidenceDomain

    checkout = Path(__file__).resolve().parents[2]
    installed = Path(malguard_core.__file__).resolve()
    if installed.is_relative_to(checkout / "malguard_core"):
        raise RuntimeError("Smoke check imported the source checkout instead of the wheel")
    distribution = importlib.metadata.distribution("malguard")
    if distribution.version != malguard_core.ENGINE_VERSION:
        raise RuntimeError("Installed package metadata and engine versions disagree")
    package_resources = importlib.resources.files("malguard_core")
    if not package_resources.joinpath("py.typed").is_file():
        raise RuntimeError("The wheel omits the public typing marker")
    resources = package_resources.joinpath("reputation", "data")
    required = (
        "manifest.json", "manifest.sig", "blocklist.json", "allowlist.json",
        "iocs.json", "revoked_signers.json", "rules/gta_guard.yar",
    )
    if any(not resources.joinpath(name).is_file() for name in required):
        raise RuntimeError("The wheel omits a required signed security resource")
    with tempfile.TemporaryDirectory(prefix="malguard-installed-smoke-") as temporary:
        directory = Path(temporary)
        sample = directory / "harmless.lua"
        sample.write_text("local version = 'synthetic-1'\nprint(version)\n", encoding="utf-8")
        report = malguard_core.scan_file(sample)
        if report.verdict is not malguard_core.Verdict.SAFE:
            raise RuntimeError(f"Benign installed-wheel API scan returned {report.verdict}")
        capa_document = json.dumps({
            "meta": {"sample": {"sha256": report.hashes.sha256}, "version": "synthetic-fixture-1"},
            "rules": {},
        }).encode("utf-8")
        capa_result = import_capa_json(capa_document, report.artifacts[0].artifact_id,
                                       report.hashes.sha256, BudgetLedger())
        if (capa_result.stage != "S3" or len(capa_result.evidence) != 1
                or capa_result.evidence[0].domain is not EvidenceDomain.CONTEXT
                or capa_result.evidence[0].base_weight != 0):
            raise RuntimeError("Installed capa adapter did not return context-only evidence")
        first_code, first_text = _cli(sample, directory, "json")
        second_code, second_text = _cli(sample, directory, "json")
        first, second = json.loads(first_text), json.loads(second_text)
        if first_code != 0 or second_code != 0 or first != second:
            raise RuntimeError("Installed CLI failed or its repeated reports differ")
        if first != json.loads(report.to_json()):
            raise RuntimeError("Installed API and CLI report serialization disagree")
        text_code, text = _cli(sample, directory, "text")
        if text_code != 0 or not any("\u0600" <= char <= "\u06ff" for char in text):
            raise RuntimeError("Installed CLI did not produce a successful Persian summary")
        inner = io.BytesIO()
        with zipfile.ZipFile(inner, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("mod.lua", "print('synthetic nested archive fixture')\n")
        package = directory / "package.zip"
        with zipfile.ZipFile(package, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("nested.zip", inner.getvalue())
        package_code, package_text = _cli(package, directory, "json")
        package_report = json.loads(package_text)
        if package_code != 0 or package_report["verdict"] != "SAFE":
            raise RuntimeError("Installed CLI could not complete a clean nested archive scan")
        if len(package_report["artifacts"]) != 3:
            raise RuntimeError("Installed archive pipeline did not analyze every child")
        dataset = directory / "synthetic-evaluation"
        (dataset / "benign").mkdir(parents=True)
        (dataset / "malicious").mkdir()
        (dataset / "benign" / "mod.lua").write_text("print('harmless evaluation fixture')\n", encoding="utf-8")
        evaluation = subprocess.run(  # noqa: S603
            [sys.executable, "-I", "-m", "malguard_cli.evaluation", str(dataset)],
            cwd=directory, capture_output=True, check=False, timeout=60,
            encoding="utf-8", errors="strict",
        )
        if evaluation.returncode != 0 or evaluation.stderr:
            raise RuntimeError("The installed evaluation command failed")
        evaluated = json.loads(evaluation.stdout)
        if (evaluated["sample_count"] != 1 or evaluated["scan_failures"] != 0
                or evaluated["metrics"]["true_negatives"] != 1
                or evaluated["scan_mode"] != "STATIC_ONLY"
                or evaluated["acceptance_targets_evaluated"] is not False):
            raise RuntimeError("The installed evaluation command produced inconsistent bookkeeping")
    print("Installed wheel verified: signed resources, API, deterministic JSON, Persian CLI, nested archives, evaluation CLI, capa JSON adapter.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
