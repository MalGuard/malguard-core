/* Trusted artifact delivery QA in real Chromium. Downloads never execute. */
"use strict";

const assert = require("node:assert/strict");
const crypto = require("node:crypto");
const fs = require("node:fs");
const http = require("node:http");
const path = require("node:path");
const { chromium } = require("playwright");

async function main() {
  const args = process.argv.slice(2);
  assert.equal(args.length, 6, "Provide --setup, --portable and --output paths");
  const values = {};
  for (let index = 0; index < args.length; index += 2) {
    assert.ok(["--setup", "--portable", "--output"].includes(args[index]));
    assert.ok(!Object.hasOwn(values, args[index]));
    values[args[index]] = path.resolve(args[index + 1]);
  }
  const output = values["--output"];
  assert.ok(!fs.existsSync(output), "QA output must be new");
  const files = [values["--setup"], values["--portable"]];
  assert.equal(path.basename(files[0]), "MalGuard-Setup-x64.exe");
  assert.equal(path.basename(files[1]), "MalGuard-Windows-x64.zip");
  const labels = ["دانلود فایل نصب ویندوز ۶۴ بیتی", "دانلود نسخهٔ قابل‌حمل ZIP"];
  const html = `<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8">
<title>دریافت MalGuard</title><style>body{font-family:Tahoma,sans-serif;max-width:760px;margin:64px auto;line-height:2;padding:20px;background:#f6f8fa;color:#17212b}a{display:block;background:white;border:1px solid #b7c9dc;padding:20px;margin:20px 0;border-radius:8px;color:#134d85}code{direction:ltr;display:inline-block}</style></head><body>
<h1>MalGuard / GTA Guard</h1><p>اسکنر ایستای آفلاین برای فایل‌ها و بسته‌های ماد GTA V</p>
<a href="/artifact/0">${labels[0]}</a><a href="/artifact/1">${labels[1]}</a>
<p>فایل بررسی‌شده اجرا نمی‌شود. نتیجهٔ SAFE تضمین امنیت نیست.</p>
<p>ساخت و آزمایش در Wine انجام شده؛ آزمون Windows 10/11 واقعی همچنان لازم است.</p>
<p>گزارش‌های برنامه در <code>%LOCALAPPDATA%\\MalGuard\\Reports</code> ذخیره می‌شوند.</p>
</body></html>`;
  const server = http.createServer((request, response) => {
    if (request.url === "/") {
      response.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
      response.end(html);
    } else if (request.url === "/favicon.ico") {
      response.writeHead(204);
      response.end();
    } else if (["/artifact/0", "/artifact/1"].includes(request.url)) {
      const file = files[Number(request.url.slice(-1))];
      response.writeHead(200, {
        "Content-Type": "application/octet-stream",
        "Content-Disposition": `attachment; filename="${path.basename(file)}"`,
        "Content-Length": fs.statSync(file).size,
      });
      fs.createReadStream(file).pipe(response);
    } else {
      response.writeHead(404);
      response.end();
    }
  });
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", resolve);
  });
  let browser;
  try {
    browser = await chromium.launch({ executablePath: "/usr/bin/chromium", headless: true,
                                     args: ["--no-sandbox", "--disable-dev-shm-usage"] });
    const context = await browser.newContext({ acceptDownloads: true,
                                              viewport: { width: 1280, height: 800 } });
    const page = await context.newPage();
    const errors = [];
    page.on("pageerror", error => errors.push(String(error)));
    page.on("console", message => { if (message.type() === "error") errors.push(message.text()); });
    const address = server.address();
    const response = await page.goto(`http://127.0.0.1:${address.port}/`, { waitUntil: "networkidle" });
    assert.equal(response.status(), 200);
    assert.equal(await page.locator("html").getAttribute("dir"), "rtl");
    assert.match(await page.locator("body").innerText(), /GTA Guard/);
    const downloads = [];
    const folder = path.join(path.dirname(output), "browser-downloads");
    fs.mkdirSync(folder, { recursive: true });
    for (let index = 0; index < files.length; index++) {
      const pending = page.waitForEvent("download");
      await page.getByRole("link", { name: labels[index], exact: true }).click();
      const download = await pending;
      assert.equal(download.suggestedFilename(), path.basename(files[index]));
      const saved = path.join(folder, download.suggestedFilename());
      await download.saveAs(saved);
      assert.equal(await download.failure(), null);
      const expected = crypto.createHash("sha256").update(fs.readFileSync(files[index])).digest("hex");
      const actual = crypto.createHash("sha256").update(fs.readFileSync(saved)).digest("hex");
      assert.equal(actual, expected);
      downloads.push({ name: path.basename(saved), size: fs.statSync(saved).size, sha256: actual });
    }
    assert.deepEqual(errors, []);
    const screenshot = path.join(path.dirname(output), "windows-download-browser.png");
    await page.screenshot({ path: screenshot, fullPage: true });
    fs.writeFileSync(output, JSON.stringify({ schema_version: 1, passed: true,
      chromium: browser.version(), playwright: require("playwright/package.json").version,
      native_browser_downloads: downloads, console_errors: errors, screenshot,
      sample_execution: false, native_windows_10_11_qualification: false,
      note: "Local delivery preview and real Chromium downloads, not native Windows testing." }, null, 2) + "\n",
      { encoding: "utf8", flag: "wx" });
    console.log(JSON.stringify({ passed: true, verified_downloads: downloads.length }));
  } finally {
    if (browser) await browser.close();
    await new Promise(resolve => server.close(resolve));
  }
}

main().catch(error => { console.error(error); process.exitCode = 1; });
