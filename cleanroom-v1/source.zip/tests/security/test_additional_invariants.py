"""Adversarial QA for evidence retention and primitive IPC schema boundaries.

All bytes are generated inert fixtures. The only processes launched are the
trusted static parser workers; no scanned fixture is imported or executed.
"""

import base64
import io
import os
import struct
import subprocess
import sys
import hashlib
import json
from dataclasses import replace

import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from malguard_core import Scanner
from malguard_core.budget import BudgetLedger
from malguard_core.model import (
    Artifact, ArtifactStatus, CoverageEntry, CoverageState, ErrorCode,
    EvidenceDomain, EvidenceLocation, Hashes, Severity, Verdict, make_evidence,
)
from malguard_core.scoring import assess
from malguard_core.reputation import ReputationStore
from malguard_core.scripts import analyze as analyze_script
from malguard_core.settings import ScanSettings
from malguard_core.similarity import imphash
from malguard_core.verdict import VerdictEngine
from malguard_core.workers import WorkerPool
from malguard_core.workers import pool as pool_module
from malguard_core.workers import protocol
from tests.builders.archive_fixtures import zip_bytes
from tests.builders.pe_dotnet import managed_pe, native_pe
from tests.security.test_signed_security_data import build_bundle, verifier
from tests.unit import test_auth_similarity as auth_fixtures


def _scan(scanner, tmp_path, name, data):
    path = tmp_path / name
    path.write_bytes(data)
    return scanner.scan_file(path)


@pytest.fixture
def scanner():
    with Scanner() as instance:
        yield instance


@pytest.mark.parametrize("extension", ["bin", "dat", "unknown"])
def test_corrupting_pe_magic_with_unclaimed_extension_retains_harm(scanner, tmp_path, extension):
    fixture = native_pe(
        imports=("OpenProcess", "VirtualAllocEx", "WriteProcessMemory", "CreateRemoteThread"),
        strings=b"chrome.exe\0",
    )
    baseline = _scan(scanner, tmp_path, "original." + extension, fixture)
    corrupted = _scan(scanner, tmp_path, "corrupted." + extension, b"ZZ" + fixture[2:])
    assert baseline.verdict is Verdict.SUSPICIOUS
    assert corrupted.verdict is Verdict.SUSPICIOUS
    assert any(item.family == "PROCESS_INJECTION" for item in corrupted.evidence)


def test_unrelated_decoded_literal_never_reduces_existing_harm(scanner, tmp_path):
    fixture = native_pe(imports=("GetAsyncKeyState", "WriteFile"), strings=b"keylog\0")
    added = native_pe(
        imports=("GetAsyncKeyState", "WriteFile"),
        strings=b"keylog\0" + base64.b64encode(b"harmless unrelated explanatory label") + b"\0",
    )
    baseline = _scan(scanner, tmp_path, "baseline.asi", fixture)
    modified = _scan(scanner, tmp_path, "unrelated_data.asi", added)
    assert baseline.verdict is Verdict.SUSPICIOUS
    assert modified.verdict is Verdict.SUSPICIOUS
    assert modified.risk_score >= baseline.risk_score
    def strongest_weights(report):
        result = {}
        for item in report.evidence:
            if item.domain is EvidenceDomain.HARM:
                result[item.rule_id] = max(result.get(item.rule_id, 0), item.effective_weight)
        return result

    original_weights = strongest_weights(baseline)
    new_weights = strongest_weights(modified)
    assert all(new_weights[rule] >= weight for rule, weight in original_weights.items())


@pytest.mark.parametrize("container", ["native", "managed"])
def test_malformed_embedded_pe_header_cannot_remove_child_or_make_safe(scanner, tmp_path, container):
    child = native_pe()
    corrupted = bytearray(child)
    struct.pack_into("<H", corrupted, 0x86, 0xFFFF)

    def wrap(payload):
        if container == "native":
            return native_pe(resource=payload)
        return managed_pe(resources=(("HarmlessFixture", payload),))

    baseline = _scan(scanner, tmp_path, "original.dll", wrap(child))
    changed = _scan(scanner, tmp_path, "corrupted.dll", wrap(bytes(corrupted)))
    assert baseline.verdict is Verdict.SUSPICIOUS
    assert changed.verdict is Verdict.SUSPICIOUS
    assert len(changed.artifacts) >= 2
    assert changed.risk_score >= baseline.risk_score


def test_executable_overlay_child_receives_normal_managed_pipeline(scanner, tmp_path):
    child = managed_pe(calls=(("System.Net.WebClient", "DownloadData", ("string",)),
                              ("System.Reflection.Assembly", "Load", ("byte[]",))))
    baseline = _scan(scanner, tmp_path, "child.dll", child)
    wrapped = _scan(scanner, tmp_path, "wrapper.asi", native_pe(overlay=child))
    assert baseline.verdict is Verdict.MALICIOUS
    assert wrapped.verdict is Verdict.MALICIOUS
    assert wrapped.risk_score >= baseline.risk_score
    assert len(wrapped.artifacts) >= 2
    assert any(item.true_type == "DOTNET_DLL" and item.parent_artifact_id
               for item in wrapped.artifacts)


def test_signed_similarity_profile_is_used_by_scan_file_without_override(tmp_path):
    imports = ("VirtualAlloc",)
    fixture = native_pe(imports=imports)
    profile = {"true_type": "PE32_DLL", "architecture": "x86", "size": len(fixture),
               "capabilities": ["local_allocate"],
               "imphash": imphash(["kernel32.dll!VirtualAlloc"])}
    record = {"sha256": hashlib.sha256(b"Harmless distinct synthetic reference").hexdigest(),
              "description_en": "Harmless synthetic similarity reference.",
              "description_fa": "مرجع شباهت آزمایشی بی‌ضرر.",
              "reviewed_by": "Synthetic fixture builder", "reference": "urn:malguard:synthetic-qa",
              "similarity": profile}
    key = Ed25519PrivateKey.generate()
    store = ReputationStore(verifier(key).verify(build_bundle(tmp_path / "bundle", key, blocklist=[record])))
    with Scanner(reputation=store) as instance:
        report = _scan(instance, tmp_path, "fixture.asi", fixture)
    assert any(item.family == "SIMILARITY" for item in report.evidence)
    assert report.verdict is Verdict.SAFE
    assert not any(item.family == "EXACT_BLOCKLIST" for item in report.evidence)


def test_signed_shared_host_ioc_is_used_without_harm_or_secret_disclosure(tmp_path):
    secret = "harmless-synthetic-secret-value"
    url = "https://github.com/synthetic-qa/fixture?token=" + secret
    record = {"kind": "domain", "value": "github.com", "reference": "urn:malguard:synthetic-qa",
              "reviewed_by": "Synthetic fixture builder", "description_en": "Harmless synthetic shared-host record.",
              "description_fa": "رکورد آزمایشی دامنهٔ مشترک بی‌ضرر.", "severity": "HIGH", "confidence": 1.0}
    key = Ed25519PrivateKey.generate()
    store = ReputationStore(verifier(key).verify(build_bundle(tmp_path / "bundle", key, iocs=[record])))
    with Scanner(reputation=store) as instance:
        report = _scan(instance, tmp_path, "fixture.asi", native_pe(strings=url.encode("ascii") + b"\0"))
    matches = [item for item in report.evidence if item.family == "VERIFIED_IOC"]
    assert matches and all(item.effective_weight == 0 for item in matches)
    assert report.verdict is Verdict.SAFE
    assert secret not in report.to_json()
    assert secret not in report.to_text()


def _allowlist_record(data):
    return {"sha256": hashlib.sha256(data).hexdigest(), "component": "Harmless synthetic component",
            "version": "fixture-1", "official_provenance": "https://example.invalid/synthetic-fixture",
            "expected_type": "PE32_DLL", "reviewed_by": "Synthetic fixture builder",
            "reference": "urn:malguard:synthetic-qa", "size": len(data)}


@pytest.mark.parametrize("allowlisted", [False, True])
def test_verified_specific_high_ioc_blocks_safe_even_with_exact_allowlist(tmp_path, allowlisted):
    url = "https://example.invalid/harmless-reviewed-fixture"
    fixture = native_pe(strings=url.encode("ascii") + b"\0")
    record = {"kind": "url", "value": url, "reference": "urn:malguard:synthetic-qa",
              "reviewed_by": "Synthetic fixture builder", "description_en": "Harmless synthetic trust-boundary fixture.",
              "description_fa": "نمونهٔ آزمایشی بی‌ضرر مرز اعتماد.", "severity": "HIGH", "confidence": 1.0}
    key = Ed25519PrivateKey.generate()
    allowlist = [_allowlist_record(fixture)] if allowlisted else []
    store = ReputationStore(verifier(key).verify(build_bundle(tmp_path / "bundle", key, iocs=[record], allowlist=allowlist)))
    with Scanner(reputation=store) as instance:
        report = _scan(instance, tmp_path, "fixture.asi", fixture)
    assert report.verdict is Verdict.SUSPICIOUS
    assert any(item.family == "VERIFIED_IOC" and item.kind == "url" for item in report.evidence)
    assert not any(item.domain is EvidenceDomain.HARM for item in report.evidence)


def _valid_signed_fixture(monkeypatch):
    """Reuse the inert CMS builder with a fully valid native PE header."""
    def wrap_certificate(certificate=None):
        data = bytearray(native_pe())
        if certificate is not None:
            length = len(certificate) + 8
            aligned = (length + 7) & ~7
            optional = struct.unpack_from("<I", data, 60)[0] + 24
            struct.pack_into("<II", data, optional + 128, len(data), aligned)
            data.extend(struct.pack("<IHH", length, 0x200, 2))
            data.extend(certificate)
            data.extend(bytes(aligned - length))
        return bytes(data)

    # Bypass the other module's cache and restore its builder before returning.
    with monkeypatch.context() as patch:
        patch.setattr(auth_fixtures, "_pe", wrap_certificate)
        return auth_fixtures._signed_pe.__wrapped__()


@pytest.mark.parametrize("allowlisted", [False, True])
def test_verified_revoked_signer_blocks_safe_without_malicious_override(tmp_path, monkeypatch, allowlisted):
    fixture, fingerprint = _valid_signed_fixture(monkeypatch)
    key = Ed25519PrivateKey.generate()
    allowlist = [_allowlist_record(fixture)] if allowlisted else []
    directory = build_bundle(tmp_path / "bundle", key, allowlist=allowlist)
    revocations = {"records": [{"certificate_sha256": fingerprint, "reviewed_by": "Synthetic fixture builder",
                                "reference": "urn:malguard:synthetic-qa"}]}
    payload = json.dumps(revocations).encode("utf-8")
    (directory / "revoked_signers.json").write_bytes(payload)
    manifest = json.loads((directory / "manifest.json").read_bytes())
    manifest["files"]["revoked_signers.json"] = hashlib.sha256(payload).hexdigest()
    manifest_bytes = json.dumps(manifest, sort_keys=True).encode("utf-8")
    (directory / "manifest.json").write_bytes(manifest_bytes)
    (directory / "manifest.sig").write_bytes(key.sign(manifest_bytes))
    store = ReputationStore(verifier(key).verify(directory))
    with Scanner(reputation=store) as instance:
        report = _scan(instance, tmp_path, "fixture.asi", fixture)
    assert report.verdict is Verdict.SUSPICIOUS
    assert any(item.family == "SIGNER_REVOCATION" for item in report.evidence)
    assert not any(item.domain is EvidenceDomain.HARM for item in report.evidence)
    assert all(entry.state is CoverageState.COMPLETE for entry in report.root_artifact.coverage)


@pytest.mark.parametrize("unproven_call", [
    "VirtualAllocEx(unprovenHandle, 0, 1, 0, 0);",
    "CreateRemoteThread(unprovenHandle, 0, 0, 0, 0, 0, 0);",
    "QueueUserAPC(callback, unprovenThread, 0);",
    "NtMapViewOfSection(section, unprovenHandle, 0, 0, 0, 0, 0, 0, 0, 0);",
])
def test_gta_context_requires_every_remote_process_handle_to_be_linked(unproven_call):
    source = ('var game = Process.GetProcessesByName("GTA5");\n'
              'var h = OpenProcess(1, false, game[0].Id);\n'
              'WriteProcessMemory(h, buffer);\n' + unproven_call).encode("ascii")
    result = analyze_script(source, "synthetic", "fixture.cs", BudgetLedger())
    assert not result.facts["gta_only"]
    assert "HACKTOOL_PUA" not in result.facts["classification_tags"]


@pytest.mark.parametrize("extension", ["cs", "lua"])
def test_case_distinct_unproven_handle_cannot_gain_gta_memory_exemption(scanner, tmp_path, extension):
    declaration = "var" if extension == "cs" else "local"
    opening = "void Fixture(IntPtr H, byte[] buffer) {\n" if extension == "cs" else "function fixture(H, buffer)\n"
    closing = "\n}" if extension == "cs" else "\nend"
    source = (opening + declaration + ' game = Process.GetProcessesByName("GTA5");\n' +
              declaration + ' h = OpenProcess(1, false, game[0].Id);\n' +
              'WriteProcessMemory(H, buffer);' + closing).encode("ascii")
    report = _scan(scanner, tmp_path, "fixture." + extension, source)
    assert report.verdict is Verdict.SUSPICIOUS
    assert "HACKTOOL_PUA" not in report.classification_tags


@pytest.mark.parametrize("mutation", ["compound_handle", "increment_handle", "replace_process_element"])
def test_target_or_handle_mutation_invalidates_gta_exclusive_proof(scanner, tmp_path, mutation):
    source = 'var game = Process.GetProcessesByName("GTA5");\n'
    if mutation == "replace_process_element":
        source += 'game[0] = Process.GetProcessById(1234);\n'
    source += 'var h = OpenProcess(1, false, game[0].Id);\n'
    if mutation == "compound_handle":
        source += 'h += 1;\n'
    elif mutation == "increment_handle":
        source += 'h++;\n'
    source += 'WriteProcessMemory(h, buffer);'
    report = _scan(scanner, tmp_path, "mutated.cs", source.encode("ascii"))
    assert report.verdict is Verdict.SUSPICIOUS
    assert "HACKTOOL_PUA" not in report.classification_tags


def test_same_spelling_in_unrelated_functions_does_not_prove_gta_handle_scope(scanner, tmp_path):
    source = (b'void GameOnly(){var game=Process.GetProcessesByName("GTA5");'
              b'var h=OpenProcess(1,false,game[0].Id);}\n'
              b'void Other(IntPtr h,byte[] buffer){WriteProcessMemory(h,buffer);}')
    report = _scan(scanner, tmp_path, "scoped.cs", source)
    assert report.verdict is Verdict.SUSPICIOUS
    assert "HACKTOOL_PUA" not in report.classification_tags


@pytest.mark.parametrize("nested", [False, True])
def test_overlong_extension_is_bounded_before_report_models(scanner, tmp_path, nested):
    name = "file." + "a" * 100
    data = b"print('harmless fixture')"
    report = _scan(scanner, tmp_path, "package.zip" if nested else name,
                   zip_bytes([(name, data)]) if nested else data)
    assert all(len(item.declared_type) <= 64 for item in report.artifacts)
    assert report.verdict is not Verdict.MALICIOUS


@pytest.mark.parametrize("facts", [
    {"imports": 1},
    {"imports": "OpenProcess"},
    {"imports": [False]},
    {"resources": [None]},
    {"resources": "resource"},
    {"is_dotnet": "false"},
    {"is_dll": 1},
    {"parser_disagreement": "false"},
    {"structure_status": "SAFE"},
])
def test_worker_rejects_wrong_types_in_coordinator_consumed_facts(monkeypatch, facts):
    original_exchange = pool_module._exchange

    def corrupt_response(process, message, timeout):
        response = original_exchange(process, message, timeout)
        if message.get("stage") == "pe":
            response["result"]["facts"] = facts
        return response

    monkeypatch.setattr(pool_module, "_exchange", corrupt_response)
    with WorkerPool(ScanSettings()) as pool:
        result = pool.run("pe", native_pe(), "synthetic", "fixture.asi", BudgetLedger())
        assert result.state is CoverageState.FAILED
        assert ErrorCode.PROTOCOL_VIOLATION in result.errors
        assert pool._process is None


@pytest.mark.parametrize("facts", [{"imports": 1}, {"resources": [None]}])
def test_hostile_worker_fact_shape_produces_report_instead_of_api_exception(monkeypatch, tmp_path, facts):
    original_exchange = pool_module._exchange

    def corrupt_response(process, message, timeout):
        response = original_exchange(process, message, timeout)
        if message.get("stage") == "pe":
            response["result"]["facts"] = facts
        return response

    monkeypatch.setattr(pool_module, "_exchange", corrupt_response)
    with Scanner() as instance:
        report = _scan(instance, tmp_path, "fixture.asi", native_pe())
    assert report.verdict is Verdict.INCONCLUSIVE
    assert any(entry.error_code is ErrorCode.PROTOCOL_VIOLATION
               for entry in report.root_artifact.coverage)


def test_complete_worker_result_cannot_hide_required_stage_error(monkeypatch):
    original_exchange = pool_module._exchange

    def contradictory_response(process, message, timeout):
        response = original_exchange(process, message, timeout)
        if message.get("stage") == "pe":
            response["result"]["state"] = CoverageState.COMPLETE.value
            response["result"]["errors"] = [ErrorCode.WORKER_FAILURE.value]
        return response

    monkeypatch.setattr(pool_module, "_exchange", contradictory_response)
    with WorkerPool(ScanSettings()) as pool:
        result = pool.run("pe", native_pe(), "synthetic", "fixture.asi", BudgetLedger())
    assert result.state is CoverageState.FAILED
    assert ErrorCode.PROTOCOL_VIOLATION in result.errors


@pytest.mark.parametrize("missing", ["imports", "resources", "structure_status"])
def test_complete_pe_worker_result_requires_completion_facts(monkeypatch, missing):
    original_exchange = pool_module._exchange

    def incomplete_response(process, message, timeout):
        response = original_exchange(process, message, timeout)
        if message.get("stage") == "pe":
            del response["result"]["facts"][missing]
        return response

    monkeypatch.setattr(pool_module, "_exchange", incomplete_response)
    with WorkerPool(ScanSettings()) as pool:
        result = pool.run("pe", native_pe(), "synthetic", "fixture.asi", BudgetLedger())
    assert result.state is CoverageState.FAILED
    assert ErrorCode.PROTOCOL_VIOLATION in result.errors


def test_verdict_engine_defensively_blocks_safe_on_completed_stage_error():
    artifact = Artifact("synthetic", "fixture.asi", ".asi", "PE32_DLL", 1.0, 1,
                        Hashes(), ArtifactStatus.VALID,
                        coverage=(CoverageEntry("S0", CoverageState.COMPLETE),
                                  CoverageEntry("S2", CoverageState.COMPLETE,
                                                error_code=ErrorCode.WORKER_FAILURE)))
    decision = VerdictEngine().decide(artifact, assess(()), 100, ())
    assert decision.verdict is Verdict.INCONCLUSIVE


def test_nested_archive_children_use_one_root_budget(tmp_path):
    nested = zip_bytes([("one.lua", b"return 1"), ("two.lua", b"return 2")])
    package = zip_bytes([("main.lua", b"return 0"), ("nested.zip", nested)])
    settings = replace(ScanSettings(), budget_limits={"children": 3})
    with Scanner(settings) as instance:
        report = _scan(instance, tmp_path, "nested.zip", package)
    assert report.verdict is Verdict.INCONCLUSIVE
    assert len(report.artifacts) <= 4
    assert any(entry.error_code is ErrorCode.ITERATION_BUDGET_EXHAUSTED
               for item in report.artifacts for entry in item.coverage)


def test_read_budget_exhaustion_does_not_invent_malformed_structure(tmp_path):
    fixture = native_pe()
    settings = replace(ScanSettings(), budget_limits={"read_bytes": len(fixture) * 2})
    with Scanner(settings) as instance:
        report = _scan(instance, tmp_path, "harmless.asi", fixture)
    assert report.verdict is Verdict.INCONCLUSIVE
    assert report.structure_status is ArtifactStatus.BLOCKED
    assert any(entry.error_code is ErrorCode.ITERATION_BUDGET_EXHAUSTED
               for entry in report.root_artifact.coverage)


@pytest.mark.skipif(os.name != "posix", reason="Synthetic FIFO is POSIX-specific")
def test_regular_file_intake_rejects_fifo_without_waiting_for_writer(tmp_path):
    fifo = tmp_path / "named_pipe.asi"
    os.mkfifo(fifo)
    command = [sys.executable, "-c",
               "import sys; from malguard_core import scan_file; print(scan_file(sys.argv[1]).verdict.value)",
               str(fifo)]
    # The executable and -c program are trusted; the FIFO is a path argument.
    completed = subprocess.run(command, capture_output=True, text=True, timeout=2, check=False)  # noqa: S603
    assert completed.returncode == 0
    assert completed.stdout.strip() == Verdict.INCONCLUSIVE.value


def test_unrelated_archive_children_do_not_manufacture_malicious_combination(scanner, tmp_path):
    keyboard = native_pe(imports=("GetAsyncKeyState", "WriteFile"), strings=b"keylog\0")
    persistence = native_pe(imports=("RegSetValueExW",), strings=b"Software\\Microsoft\\Windows\\CurrentVersion\\Run\0")
    report = _scan(scanner, tmp_path, "mod.zip", zip_bytes([("keyboard.asi", keyboard), ("autorun.asi", persistence)]))
    assert report.verdict is Verdict.SUSPICIOUS
    assert {"KEYLOGGING", "PERSISTENCE"} <= {item.family for item in report.evidence if item.domain is EvidenceDomain.HARM}


@pytest.mark.parametrize("status", list(ArtifactStatus))
def test_high_opacity_from_many_independent_families_is_never_malicious(status):
    location = EvidenceLocation("synthetic")
    evidence = tuple(make_evidence(
        "QA.OPACITY." + str(index), "S7", EvidenceDomain.OPACITY,
        "OPACITY_" + str(index), "synthetic", Severity.CRITICAL, location,
        "Harmless synthetic opacity fact.", "قرینهٔ آزمایشی پوشیدگی بی‌ضرر.",
    ) for index in range(30))
    assessment = assess(evidence)
    artifact = Artifact("synthetic", "fixture.asi", ".asi", "PE32_DLL", 1.0, 1,
                        Hashes(), status, evidence=evidence,
                        coverage=(CoverageEntry("S0", CoverageState.COMPLETE),))
    decision = VerdictEngine().decide(artifact, assessment, 100, evidence)
    assert assessment.harm_total == 0
    assert assessment.risk == 20
    assert decision.verdict is Verdict.SUSPICIOUS


def test_single_harm_family_cannot_manufacture_malicious_by_duplicate_facts():
    location = EvidenceLocation("synthetic")
    evidence = tuple(make_evidence(
        "QA.INJECTION", "S3", EvidenceDomain.HARM, "PROCESS_INJECTION", "synthetic",
        Severity.CRITICAL, location, "Harmless repeated synthetic fact.", "قرینهٔ تکراری آزمایشی بی‌ضرر.",
        attributes=(("duplicate_label", str(index)),),
    ) for index in range(200))
    assessment = assess(evidence)
    artifact = Artifact("synthetic", "fixture.asi", ".asi", "PE32_DLL", 1.0, 1,
                        Hashes(), ArtifactStatus.VALID,
                        coverage=(CoverageEntry("S0", CoverageState.COMPLETE),))
    assert assessment.risk == 28
    assert VerdictEngine().decide(artifact, assessment, 100, evidence).verdict is Verdict.SUSPICIOUS


@pytest.mark.parametrize("payload", [
    b'{"stage":"pe","stage":"yara"}',
    b'{"result":{"facts":{"imports":[],"imports":1}}}',
    b'{"x":NaN}',
    b'{"x":1e999}',
])
def test_frame_rejects_ambiguous_or_nonfinite_json(payload):
    with pytest.raises(protocol.ProtocolError):
        protocol.read_frame(io.BytesIO(struct.pack(">I", len(payload)) + payload))
