"""Trusted release path and uninstall safety, using inert PE fixtures."""

import importlib.util
from pathlib import Path

import pytest

from tests.builders.pe_dotnet import native_pe


specification = importlib.util.spec_from_file_location(
    "malguard_release", Path(__file__).resolve().parents[2] / "packaging/windows/package_release.py")
assert specification and specification.loader
release = importlib.util.module_from_spec(specification)
specification.loader.exec_module(release)


def test_uninstaller_lists_only_owned_files_and_empty_directories(tmp_path):
    payload = tmp_path / "payload"
    (payload / "_internal").mkdir(parents=True)
    (payload / "MalGuard.exe").write_bytes(b"trusted build marker")
    (payload / "_internal/$LOCALAPPDATA.txt").write_bytes(b"inert license")
    output = release.owned_files(payload)
    assert 'Delete "$INSTDIR\\_internal\\$$LOCALAPPDATA.txt"' in output
    assert "Delete /" not in output and "RMDir /" not in output
    assert "*" not in output
    assert output.index("Delete") < output.index("RMDir")


def test_32bit_release_is_rejected(tmp_path):
    executable = tmp_path / "inert.exe"
    executable.write_bytes(native_pe(is_64=False))
    with pytest.raises(ValueError, match="AMD64"):
        release.require_amd64_pe(executable)


def test_symlink_payload_is_rejected_before_output_created(tmp_path):
    payload = tmp_path / "payload"
    payload.mkdir()
    (payload / "MalGuard.exe").write_bytes(native_pe(is_64=True))
    (payload / "_internal").mkdir()
    try:
        (payload / "_internal/link").symlink_to(tmp_path / "unrelated")
    except OSError:
        pytest.skip("Symlinks require privileges on this platform")
    output = tmp_path / "release"
    with pytest.raises(ValueError, match="symlinks"):
        release.prepare(payload, output, tmp_path, "unused-build-tool")
    assert not output.exists()
