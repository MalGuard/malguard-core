"""All hashes, signing keys and reputation entries are harmless test fixtures."""

import hashlib
import json
import os
from pathlib import Path

import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization

from malguard_core.integrity import BundleError, BundleVerifier, EpochStateError, ProtectedEpochState, bundle_snapshot
from malguard_core.model import Hashes
from malguard_core.reputation import ReputationStore, load_default_store
from malguard_core.rules import RulesManager


def build_bundle(base: Path, key: Ed25519PrivateKey, *, epoch: int = 1, blocklist=None, allowlist=None, iocs=None, rule=None):
    base.mkdir()
    (base / "rules").mkdir()
    payloads = {"blocklist.json": {"records": blocklist or []}, "allowlist.json": {"records": allowlist or []}, "iocs.json": {"records": iocs or []}, "revoked_signers.json": {"records": []}}
    for name, payload in payloads.items():
        (base / name).write_text(json.dumps(payload), encoding="utf-8")
    source = rule if rule is not None else Path("rules/gta_guard.yar").read_text(encoding="utf-8")
    (base / "rules" / "fixture.yar").write_text(source, encoding="utf-8")
    hashes = {p.relative_to(base).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in base.rglob("*") if p.is_file()}
    manifest = {"bundle_version": f"synthetic-{epoch}", "epoch": epoch, "minimum_engine_version": "1.0.0", "ruleset_version": "1.0.0", "created_at": "2026-10-03T00:00:00Z", "key_id": "temporary-test-key", "files": hashes}
    data = json.dumps(manifest, sort_keys=True).encode()
    (base / "manifest.json").write_bytes(data)
    (base / "manifest.sig").write_bytes(key.sign(data))
    return base


def verifier(key, state=None):
    public = key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    return BundleVerifier({"temporary-test-key": public}, state=state)


def test_packaged_empty_signed_bundle_is_valid():
    store = load_default_store()
    assert not store._allowed and not store._blocked and not store.iocs


@pytest.mark.skipif(not hasattr(os, "mkfifo"), reason="FIFO races require POSIX")
def test_bundle_payload_racing_fifo_is_rejected_without_blocking(tmp_path, monkeypatch):
    path = tmp_path / "payload.json"
    path.write_bytes(b"harmless synthetic bundle payload")
    checked_regular = path.lstat()
    path.unlink()
    os.mkfifo(path)
    original_lstat = Path.lstat

    def racing_lstat(candidate, *args, **kwargs):
        # Simulate replacement immediately after the regular-file precheck.
        return checked_regular if candidate == path else original_lstat(candidate, *args, **kwargs)

    monkeypatch.setattr(Path, "lstat", racing_lstat)
    with pytest.raises(BundleError, match="Opened bundle payload"):
        BundleVerifier._read(path, 4096)


def test_exact_signed_synthetic_blocklist_hit(tmp_path):
    key = Ed25519PrivateKey.generate()
    sample = b"Harmless synthetic reputation sample"
    digest = hashlib.sha256(sample).hexdigest()
    record = {"sha256": digest, "description_en": "Synthetic fixture", "description_fa": "نمونهٔ آزمایشی", "reviewed_by": "Fixture builder", "reference": "urn:malguard:synthetic-test"}
    bundle = verifier(key).verify(build_bundle(tmp_path / "bundle", key, blocklist=[record]))
    result = ReputationStore(bundle).analyze(Hashes(sha256=digest), "fixture")
    assert result.facts["hard_malicious_override"]
    assert result.evidence[0].family == "EXACT_BLOCKLIST"


def test_signature_tampering_rejected(tmp_path):
    key = Ed25519PrivateKey.generate()
    base = build_bundle(tmp_path / "bundle", key)
    signature = bytearray((base / "manifest.sig").read_bytes())
    signature[0] ^= 1
    (base / "manifest.sig").write_bytes(signature)
    with pytest.raises(BundleError, match="signature"):
        verifier(key).verify(base)


def test_unsigned_bundle_rejected(tmp_path):
    key = Ed25519PrivateKey.generate()
    base = build_bundle(tmp_path / "bundle", key)
    (base / "manifest.sig").unlink()
    with pytest.raises(BundleError):
        verifier(key).verify(base)


def test_hash_tampering_rejected(tmp_path):
    key = Ed25519PrivateKey.generate()
    base = build_bundle(tmp_path / "bundle", key)
    (base / "allowlist.json").write_text('{"records": [{"sha256": "poison"}]}')
    with pytest.raises(BundleError, match="hash mismatch"):
        verifier(key).verify(base)


def test_unsigned_local_allowlist_never_accepted():
    with pytest.raises(BundleError, match="Unsigned"):
        ReputationStore({"allowlist": ["harmless.dll"]})


def test_allowlist_requires_exact_type_and_review_metadata(tmp_path):
    key = Ed25519PrivateKey.generate()
    digest = hashlib.sha256(b"Harmless reviewed component").hexdigest()
    record = {"sha256": digest, "component": "Synthetic component", "version": "fixture-1", "official_provenance": "https://example.invalid/fixture", "expected_type": "PE32_DLL", "reviewed_by": "Fixture builder", "reference": "urn:malguard:synthetic-test", "size": 27}
    store = ReputationStore(verifier(key).verify(build_bundle(tmp_path / "bundle", key, allowlist=[record])))
    assert store.analyze(Hashes(sha256=digest), "fixture", true_type="PE32_DLL", file_size=27).facts["verified_allowlist"]
    assert not store.analyze(Hashes(sha256=digest), "fixture", true_type="PE32_EXE", file_size=27).facts["verified_allowlist"]


def test_rollback_and_same_epoch_replacement_rejected(tmp_path):
    key = Ed25519PrivateKey.generate()
    state = ProtectedEpochState(tmp_path / "protected-state")
    validate = verifier(key, state)
    validate.verify(build_bundle(tmp_path / "new", key, epoch=3))
    with pytest.raises(EpochStateError, match="rollback"):
        validate.verify(build_bundle(tmp_path / "old", key, epoch=2))
    with pytest.raises(EpochStateError, match="epoch reuse"):
        validate.verify(build_bundle(tmp_path / "same", key, epoch=3, rule="rule altered { condition: true }"))


def test_broken_rule_update_preserves_last_good_and_epoch(tmp_path):
    key = Ed25519PrivateKey.generate()
    state = ProtectedEpochState(tmp_path / "protected-state")
    validate = verifier(key, state)
    good = validate.verify(build_bundle(tmp_path / "good", key, epoch=1))
    manager = RulesManager(good, validate)
    broken = build_bundle(tmp_path / "broken", key, epoch=2, rule="rule broken { condition: }")
    assert not manager.update(broken)
    assert manager.active_bundle.epoch == 1
    assert len(list(manager.active_rules)) == 9
    replacement = build_bundle(tmp_path / "replacement", key, epoch=2)
    assert manager.update(replacement)
    assert manager.active_bundle.epoch == 2


def test_rule_without_required_metadata_cannot_replace_last_good(tmp_path):
    key = Ed25519PrivateKey.generate()
    validate = verifier(key, ProtectedEpochState(tmp_path / "protected-state"))
    good = validate.verify(build_bundle(tmp_path / "good", key))
    manager = RulesManager(good, validate)
    assert not manager.update(build_bundle(tmp_path / "metadata-free", key, epoch=2, rule="rule weak { condition: true }"))
    assert manager.active_bundle.epoch == 1


def test_signed_worker_snapshot_reverified_without_caller_keys():
    store = load_default_store()
    from malguard_core.reputation.trust import PUBLIC_KEYS
    snapshot = bundle_snapshot(store.bundle)
    roundtrip = BundleVerifier(PUBLIC_KEYS).verify_snapshot(snapshot)
    assert roundtrip.manifest_sha256 == store.bundle.manifest_sha256
    snapshot["payloads"]["allowlist.json"] = "cG9pc29u"
    with pytest.raises(BundleError, match="hash mismatch"):
        BundleVerifier(PUBLIC_KEYS).verify_snapshot(snapshot)


def test_snapshot_unsigned_extra_does_not_advance_epoch(tmp_path):
    key = Ed25519PrivateKey.generate()
    validate = verifier(key, ProtectedEpochState(tmp_path / "state"))
    good = validate.verify(build_bundle(tmp_path / "good", key, epoch=1))
    snapshot = bundle_snapshot(verifier(key).verify(build_bundle(tmp_path / "update", key, epoch=2)))
    snapshot["payloads"]["unsigned.json"] = "e30="
    with pytest.raises(BundleError, match="Unsigned extra"):
        validate.verify_snapshot(snapshot, commit=True)
    assert validate.verify_snapshot(bundle_snapshot(good)).epoch == 1


def test_verified_bundle_cannot_be_fabricated_from_loose_json():
    from malguard_core.integrity import VerifiedBundle
    with pytest.raises(BundleError, match="signature verification"):
        VerifiedBundle("poison", 1, "poison", "untrusted", "", b"", b"", {"allowlist.json": b"{}"})


def test_reviewed_ioc_shared_hostname_zero_weight_and_exact_url_redacted(tmp_path):
    key = Ed25519PrivateKey.generate()
    records = [
        {"kind": "domain", "value": "github.com", "reference": "urn:malguard:synthetic", "reviewed_by": "Fixture builder", "description_en": "Synthetic shared-host record", "description_fa": "رکورد آزمایشی میزبان مشترک", "severity": "HIGH", "confidence": 1.0},
        {"kind": "url", "value": "https://example.invalid/synthetic-fixture?token=harmlesssyntheticsecret", "reference": "urn:malguard:synthetic", "reviewed_by": "Fixture builder", "description_en": "Synthetic exact URL record", "description_fa": "رکورد آزمایشی نشانی دقیق", "severity": "HIGH", "confidence": .95},
    ]
    store = ReputationStore(verifier(key).verify(build_bundle(tmp_path / "bundle", key, iocs=records)))
    result = store.analyze_iocs(("github.com", "https://github.com/fixture", records[1]["value"]), "fixture")
    assert len(result.evidence) == 2
    shared = next(item for item in result.evidence if item.kind == "domain")
    assert shared.base_weight == 0
    assert not any("harmlesssyntheticsecret" in str(item) for item in result.evidence)
    assert not store.analyze_iocs(("https://example.invalid/unreviewed",), "fixture").evidence


def test_ioc_cannot_claim_specificity_with_hostname_only(tmp_path):
    key = Ed25519PrivateKey.generate()
    record = {"kind": "url", "value": "https://example.invalid/", "reference": "urn:malguard:synthetic", "reviewed_by": "Fixture builder", "description_en": "Synthetic fixture", "description_fa": "نمونهٔ آزمایشی", "severity": "HIGH", "confidence": .95}
    bundle = verifier(key).verify(build_bundle(tmp_path / "bundle", key, iocs=[record]))
    with pytest.raises(BundleError, match="specific exact path"):
        ReputationStore(bundle)


def test_similarity_requires_corroboration_and_never_overrides(tmp_path):
    from malguard_core.similarity import SimilarityProfile, imphash
    key = Ed25519PrivateKey.generate()
    imports = ("kernel32.dll!OpenProcess", "kernel32.dll!WriteProcessMemory")
    profile = {"true_type": "PE32_DLL", "architecture": "x86", "size": 1024, "capabilities": ["openprocess", "writeprocessmemory"], "imphash": imphash(imports)}
    record = {"sha256": hashlib.sha256(b"Harmless synthetic similarity reference").hexdigest(), "description_en": "Synthetic fixture", "description_fa": "نمونهٔ آزمایشی", "reviewed_by": "Fixture builder", "reference": "urn:malguard:synthetic", "similarity": profile}
    store = ReputationStore(verifier(key).verify(build_bundle(tmp_path / "bundle", key, blocklist=[record])))
    result = store.analyze_similarity(SimilarityProfile(**profile), "fixture")
    assert result.evidence and not result.facts["hard_malicious_override"]
    altered = {**profile, "architecture": "x64"}
    assert not store.analyze_similarity(SimilarityProfile(**altered), "fixture").evidence
    altered = {**profile, "capabilities": []}
    assert not store.analyze_similarity(SimilarityProfile(**altered), "fixture").evidence
