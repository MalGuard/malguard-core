"""Package completeness must not inherit an unrelated parent repository ignore."""

import shutil
import subprocess
import sys
import zipfile
from pathlib import Path


def test_parent_gitignore_cannot_remove_engine_modules(tmp_path):
    root = Path(__file__).resolve().parents[2]
    subprocess.run(["git", "init", "--quiet", str(tmp_path)], check=True,  # noqa: S603,S607 -- fixed trusted tool
                   capture_output=True, timeout=30)
    (tmp_path / ".gitignore").write_text("coverage/\nmodel/\n")
    project = tmp_path / "isolated-engine"
    project.mkdir()
    shutil.copy2(root / "pyproject.toml", project / "pyproject.toml")
    for name in ("malguard_core", "malguard_cli"):
        shutil.copytree(root / name, project / name,
                        ignore=shutil.ignore_patterns("__pycache__"))
    subprocess.run([sys.executable, "-m", "build", "--wheel", "--no-isolation"],  # noqa: S603 -- trusted build backend, not a scanned file
                   cwd=project, check=True, capture_output=True, timeout=60)
    wheel = next((project / "dist").glob("*.whl"))
    with zipfile.ZipFile(wheel) as archive:
        names = set(archive.namelist())
        for directory in ("malguard_core", "malguard_cli"):
            for file in (project / directory).rglob("*"):
                if file.is_file():
                    name = file.relative_to(project).as_posix()
                    assert name in names, name
                    assert archive.read(name) == file.read_bytes(), name
