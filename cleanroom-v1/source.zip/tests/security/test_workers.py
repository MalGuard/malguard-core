"""Hostile primitive IPC, admission and isolated-worker containment checks."""

from __future__ import annotations

import base64
import binascii
import io
import math
import os
import struct
from dataclasses import replace
from pathlib import Path

import pytest

from malguard_core.budget import BudgetLedger
from malguard_core.model import (
    CoverageState, ErrorCode, EvidenceDomain, EvidenceLocation, Severity,
    StageResult, make_evidence,
)
from malguard_core.settings import DEFAULT_BUDGETS, ScanSettings
from malguard_core.workers import WorkerPool
from malguard_core.workers import pool as pool_module
from malguard_core.workers import protocol, server
from tests.builders.archive_fixtures import central_local_mismatch, zip_bytes
from tests.builders.pe_dotnet import native_pe


def request(stage="archives", data=b"synthetic"):
    return {"schema_version": protocol.SCHEMA_VERSION, "request_id": 1,
            "stage": stage, "artifact_id": "ipc-fixture", "logical_path": "mod.zip",
            "data_b64": base64.b64encode(data).decode("ascii"), "data_size": len(data),
            "max_file_size": 4096, "budgets": dict(DEFAULT_BUDGETS), "extra": {}}


def response(req=None, *, evidence=(), children=(), usage=None):
    req = request() if req is None else req
    child_bytes = 0
    for child_record in children:
        try:
            child_bytes += len(base64.b64decode(child_record.get("data_b64", ""), validate=True))
        except (ValueError, binascii.Error):
            # Deliberately malformed fixtures must reach protocol validation.
            child_bytes += 0
    counters = dict.fromkeys(req["budgets"], 0)
    counters.update(evidence=len(evidence), children=len(children), decompressed_bytes=child_bytes)
    if usage is not None:
        counters.update(usage)
    result = StageResult("S6", evidence=tuple(evidence), facts={"children": list(children), "archive_type": "ZIP",
                                                             "parser_disagreement": False, "malformed": False,
                                                             "incomplete_children": False})
    return {"schema_version": protocol.SCHEMA_VERSION, "request_id": req["request_id"],
            "stage": req["stage"], "result": protocol.primitive(result), "usage": counters,
            "rss_bytes": 1}


def evidence():
    return make_evidence("MG.TEST.IPC", "S6", EvidenceDomain.STRUCTURE, "ARCHIVE_LAYOUT",
                         "archive_structure", Severity.MEDIUM,
                         EvidenceLocation("ipc-fixture", offset=0, length=1),
                         "Harmless synthetic evidence.", "شاهد مصنوعی بی‌خطر")


def child(**overrides):
    values = {"logical_path": "mod.zip!/safe.lua", "member_name": "safe.lua", "declared_size": 8,
              "data_b64": base64.b64encode(b"return 0").decode("ascii"),
              "readable": True, "encrypted": False, "reason": ""}
    values.update(overrides)
    return values


def decode_invalid(message, req=None):
    with pytest.raises((protocol.ProtocolError, ValueError)):
        protocol.decode_result(message, request() if req is None else req)


class HeaderOnly:
    def __init__(self, length):
        self.length = length
        self.calls = 0

    def read(self, count):
        self.calls += 1
        assert count == 4, "hostile frame length reached body allocation"
        return struct.pack(">I", self.length)


@pytest.mark.parametrize("length", [0, protocol.MAX_FRAME + 1, 0xFFFFFFFF])
def test_frame_length_rejected_before_reading_body(length):
    stream = HeaderOnly(length)
    with pytest.raises(protocol.ProtocolError):
        protocol.read_frame(stream)
    assert stream.calls == 1


@pytest.mark.parametrize("payload", [b"not json", b"[]", b'{"a":1,"a":2}',
                                   b'{"x":NaN}', b'{"x":Infinity}', b'{"x":-Infinity}',
                                   b'{"x":1e999}', b'"string"'])
def test_invalid_json_rejected(payload):
    with pytest.raises(protocol.ProtocolError):
        protocol.read_frame(io.BytesIO(struct.pack(">I", len(payload)) + payload))


def test_truncated_frames_rejected():
    with pytest.raises(EOFError):
        protocol.read_frame(io.BytesIO(b"\x00\x00"))
    with pytest.raises(EOFError):
        protocol.read_frame(io.BytesIO(struct.pack(">I", 50) + b"{}"))


def test_json_roundtrip_contains_only_primitives():
    values = {"schema_version": 1, "values": [1, True, None, "آرشیو"]}
    assert protocol.read_frame(io.BytesIO(protocol.encode(values))) == values
    with pytest.raises(protocol.ProtocolError):
        protocol.encode({"object": object()})


@pytest.mark.parametrize("value", [True, -1, 1 << 63, 1.2, "1", None])
def test_integer_types_and_overflows_rejected(value):
    with pytest.raises(protocol.ProtocolError):
        protocol.integer(value)


@pytest.mark.parametrize("changes", [{"schema_version": True}, {"schema_version": 2},
                                     {"request_id": True}, {"request_id": 2},
                                     {"stage": "pe"}, {"rss_bytes": -1}])
def test_response_identity_rejected(changes):
    message = response()
    message.update(changes)
    decode_invalid(message)


def test_extra_response_field_rejected():
    message = response()
    message["unexpected"] = True
    decode_invalid(message)


@pytest.mark.parametrize("field,value", [("state", "SAFE"), ("stage", "S2"),
                                          ("errors", ["invented"]), ("limitations", ["a" * 8193])])
def test_result_enum_stage_limits_rejected(field, value):
    message = response()
    message["result"][field] = value
    decode_invalid(message)


@pytest.mark.parametrize("field,value", [("domain", "invented"), ("severity", "SEVERE"),
                                          ("base_weight", 100), ("confidence", -0.1),
                                          ("confidence", 1.1), ("confidence", math.inf),
                                          ("confidence", True), ("reliability", -1),
                                          ("mitigating", 1), ("id", "0" * 64)])
def test_forged_evidence_rejected(field, value):
    message = response(evidence=(evidence(),))
    message["result"]["evidence"][0][field] = value
    decode_invalid(message)


@pytest.mark.parametrize("field,value", [("artifact_id", "other"), ("offset", -1),
                                          ("offset", 100), ("offset", True),
                                          ("length", 100), ("member", "a" * 8193)])
def test_evidence_location_bounds_rejected(field, value):
    message = response(evidence=(evidence(),))
    message["result"]["evidence"][0]["location"][field] = value
    decode_invalid(message)


@pytest.mark.parametrize("value", [{"verdict": "SAFE"}, {"bad": object()}, {"large": 1 << 63},
                                   {"nonfinite": math.nan}])
def test_facts_cannot_contain_verdict_or_unsafe_values(value):
    message = response()
    message["result"]["facts"] = value
    decode_invalid(message)


def test_nested_fact_depth_rejected():
    value = 0
    for _ in range(34):
        value = [value]
    message = response()
    message["result"]["facts"] = {"nested": value}
    decode_invalid(message)


@pytest.mark.parametrize("changes", [{"logical_path": "a" * 8193}, {"readable": 1},
                                     {"encrypted": 1}, {"data_b64": "invalid$"},
                                     {"declared_size": -1}, {"reason": "a" * 8193},
                                     {"member_name": "a" * 8193}, {"unexpected": "data"},
                                     {"readable": False}, {"encrypted": True},
                                     {"declared_size": 7}])
def test_hostile_child_schema_or_semantics_rejected(changes):
    decode_invalid(response(children=(child(**changes),)))


def test_child_expansion_must_fit_issued_and_charged_budget():
    req = request()
    req["budgets"]["decompressed_bytes"] = 7
    decode_invalid(response(req, children=(child(),)), req)
    decode_invalid(response(children=(child(),), usage={"decompressed_bytes": 0}))
    decode_invalid(response(children=(child(),), usage={"children": 0}))


def test_evidence_must_be_debited_to_shared_ledger():
    decode_invalid(response(evidence=(evidence(),), usage={"evidence": 0}))


def test_usage_unknown_missing_and_over_budget_rejected():
    for mutate in (lambda values: values.pop("children"),
                   lambda values: values.update(unknown=1),
                   lambda values: values.update(children=5000),
                   lambda values: values.update(children=True)):
        message = response()
        mutate(message["usage"])
        decode_invalid(message)


@pytest.mark.parametrize("changes", [{"schema_version": True}, {"schema_version": 2},
                                     {"request_id": True}, {"stage": []},
                                     {"data_size": 100}, {"data_b64": "bad$"},
                                     {"extra": []}, {"max_file_size": 1 << 63}])
def test_worker_request_schema_rejected(changes):
    message = request()
    message.update(changes)
    with pytest.raises(protocol.ProtocolError):
        server._request(message)


def test_worker_rejects_omitted_budget_dimensions():
    message = request()
    del message["budgets"]["evidence"]
    with pytest.raises(protocol.ProtocolError):
        server._request(message)


def test_worker_request_does_not_replenish_supplied_zero_budget():
    message = request()
    message["budgets"] = dict.fromkeys(DEFAULT_BUDGETS, 0)
    data, ledger = server._request(message)
    assert data == b"synthetic"
    assert all(ledger.remaining(key) == 0 for key in DEFAULT_BUDGETS)


def test_invalid_admission_rejected_without_resource_calls(monkeypatch):
    if os.name == "posix":
        import resource
        calls = []
        monkeypatch.setattr(resource, "setrlimit", lambda *args: calls.append(args))
    else:
        calls = []
    with pytest.raises(protocol.ProtocolError):
        server._admit({"schema_version": True, "admit": True, "memory_mb": 128, "cpu_seconds": 1})
    assert calls == []


@pytest.mark.parametrize("stage,data", [("pe", native_pe()),
                                        ("archives", zip_bytes([("main.lua", b"return 0")])),
                                        ("yara", b"print('harmless fixture')")])
def test_actual_isolated_stage_runs(stage, data):
    with WorkerPool(ScanSettings()) as pool:
        result = pool.run(stage, data, "isolated-fixture", "fixture.bin", BudgetLedger())
        assert result.state is CoverageState.COMPLETE
        assert not result.errors


def test_worker_recycles_after_configured_analysis_count():
    fixture = zip_bytes([("safe.lua", b"return 0")])
    settings = replace(ScanSettings(), worker_recycle_count=2)
    with WorkerPool(settings) as pool:
        assert pool.run("archives", fixture, "a", "mod.zip", BudgetLedger()).state is CoverageState.COMPLETE
        first_pid = pool._process.pid
        pool.run("archives", fixture, "a", "mod.zip", BudgetLedger())
        assert pool._process is None
        pool.run("archives", fixture, "a", "mod.zip", BudgetLedger())
        assert pool._process.pid != first_pid


def test_worker_recycles_after_cumulative_bytes():
    fixture = zip_bytes([("safe.lua", b"return 0")])
    settings = replace(ScanSettings(), worker_recycle_bytes=len(fixture) * 2)
    with WorkerPool(settings) as pool:
        pool.run("archives", fixture, "a", "mod.zip", BudgetLedger())
        assert pool._process is not None
        pool.run("archives", fixture, "a", "mod.zip", BudgetLedger())
        assert pool._process is None


def test_parser_error_recycles_worker_and_preserves_result():
    fixture = zip_bytes([("safe.lua", b"return 0")])
    with WorkerPool(ScanSettings()) as pool:
        pool.run("archives", fixture, "a", "mod.zip", BudgetLedger())
        process = pool._process
        result = pool.run("archives", central_local_mismatch(), "a", "mod.zip", BudgetLedger())
        assert ErrorCode.PARSER_DISAGREEMENT in result.errors
        assert result.evidence
        assert pool._process is None
        assert process.poll() is not None


@pytest.mark.parametrize("failure,expected_state,expected_code", [
    (TimeoutError("synthetic safety timeout"), CoverageState.TIMEOUT, ErrorCode.WALLCLOCK_TIMEOUT),
    (EOFError("synthetic worker exit"), CoverageState.FAILED, ErrorCode.WORKER_FAILURE),
    (protocol.ProtocolError("synthetic invalid result"), CoverageState.FAILED, ErrorCode.PROTOCOL_VIOLATION),
])
def test_worker_faults_debit_stage_quotas_and_recycle(monkeypatch, failure, expected_state, expected_code):
    settings = ScanSettings()
    ledger = BudgetLedger({"archive_entries": 4, "decompressed_bytes": 128,
                           "parser_iterations": 200, "children": 4, "evidence": 16})
    with WorkerPool(settings) as pool:
        pool._start()
        process = pool._process
        def fail_exchange(*args, **kwargs):
            raise failure
        monkeypatch.setattr(pool_module, "_exchange", fail_exchange)
        result = pool.run("archives", b"PK\x03\x04", "a", "mod.zip", ledger)
        assert result.state is expected_state
        assert expected_code in result.errors
        assert pool._process is None
        assert process.poll() is not None
        for name in ("archive_entries", "decompressed_bytes", "parser_iterations", "children", "evidence"):
            assert ledger.remaining(name) == 0


def test_abnormal_reported_memory_recycles_worker(monkeypatch):
    original_exchange = pool_module._exchange
    def growing_worker(process, message, timeout):
        result = original_exchange(process, message, timeout)
        if "stage" in message:
            result["rss_bytes"] = 1024 * 1024 * 1024
        return result
    monkeypatch.setattr(pool_module, "_exchange", growing_worker)
    with WorkerPool(ScanSettings()) as pool:
        result = pool.run("archives", zip_bytes([("safe.lua", b"return 0")]), "a", "mod.zip", BudgetLedger())
        assert result.state is CoverageState.COMPLETE
        assert pool._process is None


def test_worker_entrypoint_is_fixed_and_hostile_bytes_are_ipc_only(monkeypatch):
    original_popen = pool_module.subprocess.Popen
    calls = []
    def observed_popen(args, **kwargs):
        calls.append((args, kwargs))
        return original_popen(args, **kwargs)
    monkeypatch.setattr(pool_module.subprocess, "Popen", observed_popen)
    payload = b"print('harmless'); synthetic-hostile-command-label"
    with WorkerPool(ScanSettings()) as pool:
        pool.run("yara", payload, "a", "fixture.lua", BudgetLedger())
    assert len(calls) == 1
    args, options = calls[0]
    assert args[1:3] == ["-I", "-u"]
    assert Path(args[3]).name == "server.py"
    assert options["shell"] is False
    assert not any("synthetic-hostile" in str(arg) for arg in args)


def test_worker_code_contains_no_pickle_deserialization():
    import ast
    directory = Path(protocol.__file__).parent
    for path in directory.glob("*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                assert all(alias.name.split(".")[0] != "pickle" for alias in node.names)
            if isinstance(node, ast.ImportFrom):
                assert (node.module or "").split(".")[0] != "pickle"


@pytest.mark.skipif(os.name != "nt", reason="Windows Job Objects require Windows runtime")
def test_windows_job_admission_and_kill_on_close():
    with WorkerPool(ScanSettings()) as pool:
        result = pool.run("archives", zip_bytes([("safe.lua", b"return 0")]), "a", "mod.zip", BudgetLedger())
        assert result.state is CoverageState.COMPLETE
        assert pool._job is not None
        process = pool._process
        pool.close()
        assert process.poll() is not None
