"""Harmless generated metadata tests; neither malware nor network is used."""

import base64
import hashlib
import json
import importlib.util
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, NoEncryption, PrivateFormat, PublicFormat

from malguard_core.api.scanner import Scanner
from malguard_core.integrity import BundleError, ProtectedEpochState
from malguard_core.reputation import ReputationStore
from malguard_core.reputation.trust import PUBLIC_KEYS
from malguard_core.updates import UpdateError, authenticate, install, load_cached, status_for
_source = Path(__file__).resolve().parents[2] / "packaging/online/publish_feed.py"
_spec = importlib.util.spec_from_file_location("malguard_ci_publisher", _source)
assert _spec is not None and _spec.loader is not None
_publisher = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_publisher)
build_snapshot = _publisher.build_snapshot
metadata_records = _publisher.metadata_records


@pytest.fixture
def publisher(monkeypatch):
    key = Ed25519PrivateKey.generate()
    monkeypatch.setitem(PUBLIC_KEYS, "malguard-online-2026-10",
                        key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw))
    private = key.private_bytes(Encoding.Raw, PrivateFormat.Raw, NoEncryption())
    rules = (Path(__file__).resolve().parents[2] / "rules/gta_guard.yar").read_bytes()

    def publish(contents=b"harmless synthetic fixture", epoch=100, previous=None,
                now=None, rule_source=None):
        metadata = json.dumps({"query_status": "ok", "data": [
            {"sha256_hash": hashlib.sha256(contents).hexdigest()}]}).encode()
        snapshot = build_snapshot(metadata, private, epoch, now or datetime.now(UTC),
                                  rule_source or rules, previous)
        return json.dumps(snapshot).encode()
    return publish


def test_verified_feed_installs_and_reputation_precedes_broken_parser(publisher, tmp_path):
    content = b"MZ harmless deliberately incomplete synthetic structure"
    data = publisher(content)
    directory = tmp_path / "cache"
    state = ProtectedEpochState(tmp_path / "epochs")
    status = install(data, directory, state)
    assert status.fresh and status.record_count == 1
    assert status.signature_verified and status.created_at and status.key_id == "malguard-online-2026-10"
    bundle, status = load_cached(directory)
    sample = tmp_path / "broken.asi"
    sample.write_bytes(content)
    with Scanner(reputation=ReputationStore(bundle)) as scanner:
        report = scanner.scan_file(sample)
    assert report.verdict.value == "MALICIOUS"


def test_invalid_signature_preserves_last_good(publisher, tmp_path):
    directory = tmp_path / "cache"
    state = ProtectedEpochState(tmp_path / "epochs")
    valid = publisher()
    install(valid, directory, state)
    modified = json.loads(publisher(epoch=101, previous=valid))
    modified["signature_b64"] = base64.b64encode(bytes(64)).decode()
    with pytest.raises(BundleError):
        install(json.dumps(modified).encode(), directory, state)
    assert (directory / "latest.json").read_bytes() == valid


def test_rollback_rejected(publisher, tmp_path):
    directory = tmp_path / "cache"
    state = ProtectedEpochState(tmp_path / "epochs")
    install(publisher(epoch=200), directory, state)
    with pytest.raises(ValueError):
        install(publisher(epoch=100), directory, state)
    assert load_cached(directory)[1].epoch == 200


def test_update_cannot_remove_known_block_identity(publisher, tmp_path):
    directory = tmp_path / "cache"
    state = ProtectedEpochState(tmp_path / "epochs")
    install(publisher(b"synthetic one"), directory, state)
    with pytest.raises(UpdateError):
        install(publisher(b"synthetic two", epoch=101), directory, state)
    assert load_cached(directory)[1].record_count == 1


def test_publisher_accumulates_and_never_invents_records(publisher, tmp_path):
    first = publisher(b"first synthetic")
    second = publisher(b"second synthetic", epoch=101, previous=first)
    assert status_for(authenticate(second)).record_count == 2
    records = json.loads(authenticate(second).payloads["blocklist.json"])["records"]
    assert {record["sha256"] for record in records} == {
        hashlib.sha256(b"first synthetic").hexdigest(), hashlib.sha256(b"second synthetic").hexdigest()}


@pytest.mark.parametrize("age", [timedelta(days=3), -timedelta(hours=1)])
def test_old_or_future_signed_metadata_is_not_fresh(publisher, age):
    now = datetime.now(UTC)
    assert not status_for(authenticate(publisher(now=now-age)), now=now).fresh


@pytest.mark.parametrize("value", [b'{}', b'{"query_status":"no_results"}',
    b'{"query_status":"ok","data":[]}', b'{"query_status":"ok","data":[{"sha256_hash":"bad"}]}',
    b'{"query_status":"ok","data":{}}', b'{"query_status":"ok","query_status":"ok","data":[]}'])
def test_bad_or_empty_metadata_is_not_published(value):
    with pytest.raises(ValueError):
        metadata_records(value)


def test_broken_rules_cannot_replace_good_feed(publisher, tmp_path):
    directory = tmp_path / "cache"
    state = ProtectedEpochState(tmp_path / "epochs")
    valid = publisher()
    install(valid, directory, state)
    with pytest.raises(ValueError):
        publisher(epoch=101, previous=valid, rule_source=b"invalid YARA syntax")
    assert (directory / "latest.json").read_bytes() == valid


def test_unsigned_local_allowlist_not_trusted(tmp_path):
    directory = tmp_path / "cache"
    directory.mkdir(mode=0o700)
    (directory / "latest.json").write_text('{"allowlist":["any"]}')
    assert not load_cached(directory)[1].available
    assert not load_cached(directory)[1].signature_verified


def test_stale_online_analysis_blocks_safe_but_retains_malicious(tmp_path):
    benign = tmp_path / "mod.lua"
    benign.write_text("print('harmless')")
    harmful = tmp_path / "fixture.bin"
    harmful.write_bytes(b"Login Data\0Local State\0password_value\0CryptUnprotectData\0HttpSendRequest\0POST\0")
    with Scanner(reputation_fresh=False) as scanner:
        assert scanner.scan_file(benign).verdict.value == "INCONCLUSIVE"
        assert scanner.scan_file(harmful).verdict.value == "MALICIOUS"


def test_refresh_counts_only_new_unique_hashes(publisher, tmp_path):
    directory = tmp_path / "cache"
    state = ProtectedEpochState(tmp_path / "epochs")
    first = publisher(b"first synthetic")
    initial = install(first, directory, state)
    assert (initial.new_record_count, initial.existing_record_count,
            initial.previous_record_count, initial.update_outcome) == (1, 0, 0, "updated")
    repeated = install(publisher(b"first synthetic", epoch=101, previous=first), directory, state)
    assert (repeated.new_record_count, repeated.existing_record_count,
            repeated.update_outcome) == (0, 1, "up_to_date")
    previous = (directory / "latest.json").read_bytes()
    added = install(publisher(b"second synthetic", epoch=102, previous=previous), directory, state)
    assert (added.new_record_count, added.existing_record_count,
            added.previous_record_count, added.record_count) == (1, 1, 1, 2)
    assert not added.rules_changed and added.update_outcome == "updated"


def test_rules_change_is_reported_even_without_new_hashes(publisher, tmp_path):
    directory = tmp_path / "cache"
    state = ProtectedEpochState(tmp_path / "epochs")
    first = publisher()
    install(first, directory, state)
    rules = (Path(__file__).resolve().parents[2] / "rules/gta_guard.yar").read_bytes()
    result = install(publisher(epoch=101, previous=first, rule_source=rules+b"\n// updated fixture\n"),
                     directory, state)
    assert result.new_record_count == 0 and result.existing_record_count == 1
    assert result.rules_changed and result.update_outcome == "updated"


def test_install_progress_requires_signature_before_comparison(publisher, tmp_path):
    events = []
    directory = tmp_path / "cache"
    state = ProtectedEpochState(tmp_path / "epochs")
    valid = publisher()
    install(valid, directory, state, progress=events.append)
    assert [e["stage"] for e in events] == ["verifying", "comparing", "installing"]
    invalid = json.loads(publisher(epoch=101, previous=valid))
    invalid["signature_b64"] = base64.b64encode(bytes(64)).decode()
    events.clear()
    with pytest.raises(BundleError):
        install(json.dumps(invalid).encode(), directory, state, progress=events.append)
    assert [e["stage"] for e in events] == ["verifying"]
    assert (directory / "latest.json").read_bytes() == valid


def test_download_progress_counts_actual_bytes(monkeypatch):
    import io
    import malguard_core.updates as updates
    payload = b"harmless transport fixture" * 8000
    class Response(io.BytesIO):
        status = 200
        headers = {"Content-Length": str(len(payload))}
    class Opener:
        def open(self, request, timeout):
            assert request.full_url == updates.UPDATE_URL and timeout == 30
            return Response(payload)
    monkeypatch.setattr(updates, "build_opener", lambda *args: Opener())
    events = []
    assert updates.download(progress=events.append) == payload
    counts = [event["receivedBytes"] for event in events]
    assert counts[0] == 0 and counts[-1] == len(payload)
    assert counts == sorted(set(counts)) and len(counts) > 3
    assert all(event["totalBytes"] == len(payload) for event in events)


@pytest.mark.parametrize("length,expected", [(None, True), ("10", False), ("0", False),
                                              (str(24*1024*1024), False)])
def test_download_unknown_size_or_incorrect_declared_size(monkeypatch, length, expected):
    import io
    import malguard_core.updates as updates
    class Response(io.BytesIO):
        status = 200
        headers = {} if length is None else {"Content-Length": length}
    class Opener:
        def open(self, request, timeout):
            return Response(b"fixture")
    monkeypatch.setattr(updates, "build_opener", lambda *args: Opener())
    events = []
    if expected:
        assert updates.download(progress=events.append) == b"fixture"
        assert events[-1]["totalBytes"] is None and events[-1]["receivedBytes"] == 7
    else:
        with pytest.raises(UpdateError):
            updates.download(progress=events.append)


def test_desktop_job_reports_authenticated_completion_and_duplicate_counts(publisher, tmp_path, monkeypatch):
    import malguard_core.updates as updates
    import malguard_core.updates.desktop as jobs
    directory = tmp_path / "cache"
    monkeypatch.setattr(updates, "default_cache_directory", lambda: directory)
    monkeypatch.setattr(jobs, "default_cache_directory", lambda: directory)
    monkeypatch.setattr(updates, "ProtectedEpochState", lambda: ProtectedEpochState(tmp_path / "epochs"))
    first = publisher()
    monkeypatch.setattr(updates, "download", lambda **kwargs: first)
    request_id = "12345678-abcd-abcd-abcd-123456789abc"
    assert jobs.run_job(request_id) == 0
    result = jobs.read_job(request_id)
    assert result["stage"] == "complete" and result["result"]["new_record_count"] == 1
    assert result["result"]["signature_verified"] and result["result"]["fresh"]
    with pytest.raises(UpdateError):
        jobs.run_job(request_id)
    second_id = "12345678-abcd-abcd-abcd-123456789abd"
    monkeypatch.setattr(updates, "download", lambda **kwargs: publisher(epoch=101, previous=first))
    assert jobs.run_job(second_id) == 0
    repeated = jobs.read_job(second_id)
    assert repeated["result"]["new_record_count"] == 0
    assert repeated["result"]["update_outcome"] == "up_to_date"
    altered = json.loads((directory / "latest.json").read_bytes())
    altered["signature_b64"] = base64.b64encode(bytes(64)).decode()
    (directory / "latest.json").write_text(json.dumps(altered))
    with pytest.raises(UpdateError):
        jobs.read_job(second_id)


def test_desktop_update_failure_does_not_claim_cached_data_is_new(publisher, tmp_path, monkeypatch):
    import malguard_core.updates as updates
    import malguard_core.updates.desktop as jobs
    directory = tmp_path / "cache"
    valid = publisher()
    install(valid, directory, ProtectedEpochState(tmp_path / "epochs"))
    monkeypatch.setattr(updates, "default_cache_directory", lambda: directory)
    monkeypatch.setattr(jobs, "default_cache_directory", lambda: directory)
    def offline(**kwargs):
        raise OSError("Synthetic disconnected transport")
    monkeypatch.setattr(updates, "download", offline)
    request_id = "12345678-abcd-abcd-abcd-123456789abe"
    assert jobs.run_job(request_id) == 4
    result = jobs.read_job(request_id)
    assert result["stage"] == "failed" and result["result"]["update_outcome"] == "failed"
    assert result["result"]["new_record_count"] is None
    assert (directory / "latest.json").read_bytes() == valid


@pytest.mark.parametrize("request_id", ["../arbitrary", "", "x"*100, "12345678-ABCD-abcd-abcd-123456789abc"])
def test_desktop_update_identifier_cannot_select_a_path(tmp_path, request_id):
    from malguard_core.updates.desktop import job_path
    with pytest.raises(UpdateError):
        job_path(request_id, tmp_path)
