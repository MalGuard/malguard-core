"""Bounded malformed format probes, never execution or real malware."""

import random
import struct

import pytest

from malguard_core import Scanner
from malguard_core.model import ErrorCode, Verdict
from malguard_core.settings import ScanSettings
from tests.builders.archive_fixtures import central_local_mismatch, overlapping_zip, zip64_overflow, zip_bytes
from tests.builders.pe_dotnet import native_pe


@pytest.mark.parametrize("name,data", [("local_mismatch.zip", central_local_mismatch()), ("overlap.zip", overlapping_zip()),
                                        ("zip64.zip", zip64_overflow()), ("truncated.asi", b"MZ" + bytes(30)),
                                        ("bytecode.lua", b"\x1bLua\x54" + bytes(20))])
def test_hostile_formats_never_safe(tmp_path, name, data):
    path = tmp_path / name
    path.write_bytes(data)
    with Scanner() as scanner:
        report = scanner.scan_file(path)
    assert report.verdict is not Verdict.SAFE
    assert report.to_json()


def test_absurd_section_count_and_offsets_do_not_crash(tmp_path):
    data = bytearray(native_pe())
    struct.pack_into("<H", data, 0x86, 65535)
    path = tmp_path / "absurd.asi"
    path.write_bytes(data)
    with Scanner() as scanner:
        report = scanner.scan_file(path)
    assert report.verdict in {Verdict.INVALID, Verdict.INCONCLUSIVE, Verdict.SUSPICIOUS}


def test_expansion_budget_shared_with_nested_archives(tmp_path):
    nested = zip_bytes([("inner.zip", zip_bytes([("first.lua", b"return 1\n" * 64), ("second.lua", b"return 2\n" * 64)]))])
    path = tmp_path / "bounded.zip"
    path.write_bytes(nested)
    with Scanner(ScanSettings(budget_limits={"decompressed_bytes": 1024})) as scanner:
        report = scanner.scan_file(path)
    assert report.verdict is not Verdict.SAFE
    assert any(entry.error_code is ErrorCode.ITERATION_BUDGET_EXHAUSTED for artifact in report.artifacts for entry in artifact.coverage)


def test_low_work_budget_not_reported_as_wallclock_timeout(tmp_path):
    path = tmp_path / "fixture.asi"
    path.write_bytes(native_pe())
    with Scanner(ScanSettings(budget_limits={"parser_iterations": 4})) as scanner:
        report = scanner.scan_file(path)
    errors = {entry.error_code for artifact in report.artifacts for entry in artifact.coverage}
    assert ErrorCode.ITERATION_BUDGET_EXHAUSTED in errors
    assert ErrorCode.WALLCLOCK_TIMEOUT not in errors
    assert report.verdict is not Verdict.SAFE


def test_seeded_malformed_bytes_are_deterministic_and_safe_from_crashes(tmp_path):
    rng = random.Random(109)
    with Scanner() as scanner:
        for index, length in enumerate((0, 1, 7, 63, 128, 512, 2048)):
            path = tmp_path / f"noise-{index}.asi"
            path.write_bytes(rng.randbytes(length))
            report = scanner.scan_file(path)
            assert report.verdict is not Verdict.SAFE
            assert report == scanner.scan_file(path)
