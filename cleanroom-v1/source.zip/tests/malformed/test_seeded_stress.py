"""Reproducible, inert format stress through the actual isolated Scanner.

No scanned bytes are loaded, imported, compiled, or executed. Fixed seeds vary
public format fields in synthetic fixtures; these are not corpus recall tests.
"""

from __future__ import annotations

import base64
import json
import random
import struct
from dataclasses import replace

import pytest

from malguard_core import Scanner
from malguard_core.model import ErrorCode, EvidenceDomain, Verdict
from malguard_core.settings import ScanSettings
from tests.builders.archive_fixtures import central_offsets, zip_bytes
from tests.builders.pe_dotnet import managed_pe, native_pe


SEED = 0x4D475354
HARM_IMPORTS = ("ReadFile", "CryptUnprotectData", "HttpSendRequestA")
HARM_BYTES = (
    b"Login Data\0Local State\0password_value\0CryptUnprotectData\0HttpSendRequest\0POST\0"
)
MANAGED_CALLS = (
    ("System.Net.WebClient", "DownloadData", ("string",)),
    ("System.Reflection.Assembly", "Load", ("byte[]",)),
)


def _malformed_cases():
    """144 explicit bad-field probes with bounded seeded values, 48 per format."""
    rng = random.Random(SEED)
    cases = []
    pe_kinds = (
        "optional_magic", "optional_size", "machine_mismatch", "file_alignment",
        "header_size", "image_size", "directory_count", "raw_offset",
        "raw_size", "virtual_address", "entry_rva", "directory_pair",
    )
    net_kinds = (
        "root_signature", "root_version", "stream_count", "stream_offset",
        "stream_size", "duplicate_stream", "overlap_stream", "stream_name",
        "table_reserved", "heap_flags", "valid_mask", "row_count",
    )
    zip_kinds = (
        "entry_count", "central_size", "central_offset", "end_comment",
        "disk_number", "local_flags", "local_method", "local_crc",
        "local_size", "local_pointer", "central_name", "truncate_end",
    )
    for round_number in range(4):
        for kind in pe_kinds:
            is_64 = bool(round_number % 2)
            data = bytearray(native_pe(is_64=is_64, imports=("GetTickCount",)))
            optional = 0x98
            section = optional + (240 if is_64 else 224)
            bad = rng.randrange(0xF0000000, 0xFFFFFFFF)
            offset, fmt, value = {
                "optional_magic": (optional, "H", 0xF000 + round_number),
                "optional_size": (0x94, "H", 0xFFF0 + round_number),
                "machine_mismatch": (0x84, "H", 0x14C if is_64 else 0x8664),
                "file_alignment": (optional + 36, "I", 513 + 2 * round_number),
                "header_size": (optional + 60, "I", bad),
                "image_size": (optional + 56, "I", round_number),
                "directory_count": (optional + (108 if is_64 else 92), "I", 17 + round_number),
                "raw_offset": (section + 20, "I", bad),
                "raw_size": (section + 16, "I", bad),
                "virtual_address": (section + 12, "I", 0x1001 + round_number),
                "entry_rva": (optional + 16, "I", bad),
                "directory_pair": (optional + (112 if is_64 else 96), "I", bad),
            }[kind]
            struct.pack_into("<" + fmt, data, offset, value)
            cases.append((f"pe-{kind}-{round_number}.asi", bytes(data)))
        for kind in net_kinds:
            data = bytearray(managed_pe(user_strings=("Inert seeded QA marker",)))
            root = data.index(b"BSJB")
            version_length = struct.unpack_from("<I", data, root + 12)[0]
            count_offset = root + ((16 + version_length + 3) & ~3)
            first = count_offset + 4
            second = first + 12
            tables = root + struct.unpack_from("<I", data, first)[0]
            bad = rng.randrange(0xF0000000, 0xFFFFFFFF)
            if kind == "duplicate_stream":
                data[second + 8:second + 12] = b"#~\0\0"
            elif kind == "overlap_stream":
                data[first:first + 4] = data[second:second + 4]
            elif kind == "stream_name":
                data[first + 8] = 0xF0 + round_number
            else:
                offset, fmt, value = {
                    "root_signature": (root, "I", bad),
                    "root_version": (root + 12, "I", bad),
                    "stream_count": (count_offset + 2, "H", 17 + round_number),
                    "stream_offset": (first, "I", bad),
                    "stream_size": (first + 4, "I", bad),
                    "table_reserved": (tables, "I", 1 + round_number),
                    "heap_flags": (tables + 6, "B", 0x80 + round_number),
                    "valid_mask": (tables + 8, "Q", 1 << (63 - round_number)),
                    "row_count": (tables + 24, "I", bad),
                }[kind]
                struct.pack_into("<" + fmt, data, offset, value)
            cases.append((f"net-{kind}-{round_number}.dll", bytes(data)))
        for kind in zip_kinds:
            data = bytearray(zip_bytes([("safe.lua", b"return 1"), ("settings.cfg", b"v=1")]))
            central = central_offsets(data)[0]
            end = data.rfind(b"PK\x05\x06")
            bad = rng.randrange(0xF0000000, 0xFFFFFFFF)
            if kind == "truncate_end":
                data = data[:len(data) - (1 + 5 * round_number)]
            else:
                offset, fmt, value = {
                    "entry_count": (end + 10, "H", 3 + round_number),
                    "central_size": (end + 12, "I", bad),
                    "central_offset": (end + 16, "I", bad),
                    "end_comment": (end + 20, "H", 64 + round_number),
                    "disk_number": (end + 4, "H", 1 + round_number),
                    "local_flags": (6, "H", 1),
                    "local_method": (8, "H", 1 + round_number),
                    "local_crc": (14, "I", bad),
                    "local_size": (22, "I", bad),
                    "local_pointer": (central + 42, "I", bad),
                    "central_name": (central + 28, "H", 0xFFF0 + round_number),
                }[kind]
                struct.pack_into("<" + fmt, data, offset, value)
            cases.append((f"zip-{kind}-{round_number}.zip", bytes(data)))
    return cases


MALFORMED_CASES = _malformed_cases()


@pytest.fixture(scope="module")
def scanner():
    with Scanner() as instance:
        assert instance.settings.isolate_parsers
        yield instance


def _scan(scanner, tmp_path, name, data):
    path = tmp_path / name
    path.write_bytes(data)
    report = scanner.scan_file(path)
    repeated = scanner.scan_file(path)
    assert report == repeated, name
    assert report.to_text() == repeated.to_text(), name
    assert report.to_json() == scanner.scan_file(path).to_json(), name
    assert json.loads(report.to_json())["verdict"] == report.verdict.value
    assert 0 <= report.risk_score <= 100
    assert 0 <= report.coverage_score <= 100
    assert len({item.artifact_id for item in report.artifacts}) == len(report.artifacts)
    artifact_ids = {item.artifact_id for item in report.artifacts}
    assert all(set(item.child_artifact_ids) <= artifact_ids for item in report.artifacts)
    assert all(item.location.artifact_id in artifact_ids for item in report.evidence)
    return report


@pytest.mark.parametrize("name,data", MALFORMED_CASES, ids=[item[0] for item in MALFORMED_CASES])
def test_seeded_bad_fields_never_crash_or_report_safe(scanner, tmp_path, name, data):
    report = _scan(scanner, tmp_path, name, data)
    assert report.verdict not in {Verdict.SAFE, Verdict.MALICIOUS}, name
    assert any(entry.error_code is not None for item in report.artifacts for entry in item.coverage)


BENIGN_CASES = (
    ("docs.asi", native_pe(strings=b"Login Data\0password_value\0POST\0")),
    ("crypto.asi", native_pe(imports=("CryptUnprotectData",))),
    ("http.asi", native_pe(imports=("HttpSendRequestA",), strings=b"POST\0")),
    ("memory.asi", native_pe(imports=("VirtualAllocEx", "WriteProcessMemory"))),
    ("keys.asi", native_pe(imports=("GetAsyncKeyState",))),
    ("loader.dll", managed_pe(calls=(("System.Reflection.Assembly", "Load", ("string",)),))),
    ("update.dll", managed_pe(calls=(("System.Net.WebClient", "DownloadData", ("string",)),))),
    ("resources.dll", managed_pe(resources=(("Readme", b"Login Data\0HttpSendRequest\0"),))),
    ("doc.cs", b'// DownloadData() Assembly.Load(byte[]) CryptUnprotectData\nvar value = 1;'),
    ("quoted.lua", b'local help = "loadstring(body) CryptUnprotectData POST"; return help'),
    ("update.lua", b'PerformHttpRequest("https://example.invalid/update", function(s,b) print(b) end)'),
    ("mixed.zip", zip_bytes([("readme.txt", b"Login Data\0password_value"), ("main.lua", b"return 1")])),
)


@pytest.mark.parametrize("name,data", BENIGN_CASES, ids=[item[0] for item in BENIGN_CASES])
def test_benign_lookalikes_never_manufacture_malicious(scanner, tmp_path, name, data):
    assert _scan(scanner, tmp_path, name, data).verdict is not Verdict.MALICIOUS


def _harm_weights(report):
    weights = {}
    for item in report.evidence:
        if item.domain is EvidenceDomain.HARM:
            weights[item.rule_id] = max(weights.get(item.rule_id, 0), item.effective_weight)
    return weights


@pytest.mark.parametrize("mutation", (
    "rwx", "protector_section", "packer_literals", "entropy_overlay", "timestamp",
    "certificate_bounds", "alignment", "directory_count", "benign_base64", "gta_context",
))
def test_added_native_opacity_and_structure_retain_harm(scanner, tmp_path, mutation):
    original = native_pe(imports=HARM_IMPORTS, strings=HARM_BYTES)
    kwargs = {"imports": HARM_IMPORTS, "strings": HARM_BYTES}
    if mutation == "rwx":
        kwargs["section_flags"] = 0xE0000020
    elif mutation == "protector_section":
        kwargs["section_name"] = b".vmp0"
    elif mutation == "packer_literals":
        kwargs["strings"] += b"UPX!\0VMProtect\0Themida\0"
    elif mutation == "entropy_overlay":
        kwargs["overlay"] = random.Random(SEED).randbytes(8192)
    elif mutation == "benign_base64":
        kwargs["strings"] += base64.b64encode(b"inert explanatory test label") + b"\0"
    elif mutation == "gta_context":
        kwargs["strings"] += b"GTA5.exe\0ScriptHookV\0trainer\0"
    changed = bytearray(native_pe(**kwargs))
    if mutation == "timestamp":
        struct.pack_into("<I", changed, 0x88, 0xFFFFFFFF)
    elif mutation == "certificate_bounds":
        struct.pack_into("<II", changed, 0x98 + 96 + 4 * 8, 0xFFFFFFF8, 0x1000)
    elif mutation == "alignment":
        struct.pack_into("<I", changed, 0x98 + 36, 513)
    elif mutation == "directory_count":
        struct.pack_into("<I", changed, 0x98 + 92, 17)
    before = _scan(scanner, tmp_path, "native-before.asi", original)
    after = _scan(scanner, tmp_path, "native-after.asi", bytes(changed))
    assert before.verdict is after.verdict is Verdict.MALICIOUS
    assert after.risk_score >= before.risk_score
    if mutation not in {"certificate_bounds", "alignment", "directory_count"}:
        # Corrupt mappings may legitimately lose the confidence upgrade from
        # admitted imports. Their independent raw HARM, verdict, and risk remain.
        assert all(_harm_weights(after).get(rule, 0) >= weight
                   for rule, weight in _harm_weights(before).items())


@pytest.mark.parametrize("mutation", ("packing_literals", "bad_resource_range", "bad_resource_pair"))
def test_added_managed_opacity_and_independent_resource_damage_retain_harm(
    scanner, tmp_path, mutation,
):
    original = managed_pe(calls=MANAGED_CALLS)
    changed = bytearray(managed_pe(
        calls=MANAGED_CALLS,
        user_strings=("ConfuserEx", "SmartAssembly") if mutation == "packing_literals" else (),
    ))
    if mutation != "packing_literals":
        clr_rva = struct.unpack_from("<I", changed, 0x98 + 96 + 14 * 8)[0]
        clr = 0x200 + clr_rva - 0x1000
        struct.pack_into("<II", changed, clr + 24, 0xFFFFFFF0,
                         0x1000 if mutation == "bad_resource_range" else 0)
    before = _scan(scanner, tmp_path, "managed-before.dll", original)
    after = _scan(scanner, tmp_path, "managed-after.dll", bytes(changed))
    assert before.verdict is after.verdict is Verdict.MALICIOUS
    assert after.risk_score >= before.risk_score


@pytest.mark.parametrize("failure", (
    "bad_call", "bad_opcode", "short_operand", "bad_branch", "bad_switch",
    "fat_code_overflow", "unmapped_rva",
))
def test_later_bad_managed_method_does_not_erase_completed_first_method(scanner, tmp_path, failure):
    # This exact builder fixture has an intact first loader method and an
    # unimplemented second MethodDef. Make only the second method invalid.
    original = managed_pe(calls=MANAGED_CALLS, pinvoke=("Unused",))
    changed = bytearray(original)
    second_row = 1012
    body_offset = 1428
    assert len(original) == 1536
    assert struct.unpack_from("<I", original, second_row)[0] == 0
    assert struct.unpack_from("<H", original, second_row + 6)[0] == 0x2016
    assert original[body_offset:body_offset + 7] == bytes(7)
    second_rva = 0xFFFFFFFF if failure == "unmapped_rva" else 0x1000 + body_offset - 0x200
    struct.pack_into("<I", changed, second_row, second_rva)
    struct.pack_into("<H", changed, second_row + 6, 0x16)
    body = {
        "bad_call": bytes.fromhex("1a28ff00000a2a"),
        "bad_opcode": bytes.fromhex("0aff2a"),
        "short_operand": bytes.fromhex("0e280100"),
        "bad_branch": bytes.fromhex("222b01280100000a2a"),
        "bad_switch": bytes.fromhex("1a45ffffffff2a"),
        "fat_code_overflow": struct.pack("<HHII", 0x3003, 8, 0xFFFFFFFF, 0),
        "unmapped_rva": b"",
    }[failure]
    changed[body_offset:body_offset + len(body)] = body
    # The first method and all its referenced metadata precede these patches.
    assert changed[:second_row] == original[:second_row]
    before = _scan(scanner, tmp_path, "first-valid.dll", original)
    after = _scan(scanner, tmp_path, "later-invalid.dll", bytes(changed))
    assert before.verdict is after.verdict is Verdict.MALICIOUS
    assert after.risk_score >= before.risk_score
    assert set(_harm_weights(before)) <= set(_harm_weights(after))
    assert any(entry.error_code is ErrorCode.MALFORMED_INPUT
               for item in after.artifacts for entry in item.coverage if entry.stage == "S4")


def _mutate_later_member(data, mutation):
    changed = bytearray(data)
    central = central_offsets(data)[1]
    local = struct.unpack_from("<I", data, central + 42)[0]
    if mutation == "encrypted":
        struct.pack_into("<H", changed, central + 8, 1)
        struct.pack_into("<H", changed, local + 6, 1)
    elif mutation == "strong_encryption":
        struct.pack_into("<H", changed, central + 8, 0x40)
        struct.pack_into("<H", changed, local + 6, 0x40)
    elif mutation == "name_mismatch":
        changed[local + 30] ^= 1
    elif mutation == "crc_mismatch":
        changed[local + 30 + len(b"opaque.lua")] ^= 1
    elif mutation == "unsupported_method":
        struct.pack_into("<H", changed, central + 10, 99)
        struct.pack_into("<H", changed, local + 8, 99)
    return bytes(changed)


@pytest.mark.parametrize("kind", ("native", "managed"))
@pytest.mark.parametrize("mutation", (
    "encrypted", "strong_encryption", "name_mismatch", "crc_mismatch", "unsupported_method",
))
def test_later_unreadable_member_retains_first_harm(scanner, tmp_path, kind, mutation):
    harm = native_pe(imports=HARM_IMPORTS, strings=HARM_BYTES) if kind == "native" else managed_pe(calls=MANAGED_CALLS)
    original = zip_bytes([("payload.dll", harm), ("opaque.lua", b"return 1")])
    before = _scan(scanner, tmp_path, "archive-before.zip", original)
    after = _scan(scanner, tmp_path, "archive-after.zip", _mutate_later_member(original, mutation))
    assert before.verdict is after.verdict is Verdict.MALICIOUS
    assert after.risk_score >= before.risk_score
    assert any(item.true_type == "UNREADABLE" for item in after.artifacts)


@pytest.mark.parametrize("dimension,limit", (
    ("children", 2), ("archive_entries", 2), ("decompressed_bytes", 200),
    ("file_bytes", 200), ("parser_iterations", 128), ("metadata_rows", 1),
    ("yara_bytes", 16), ("strings", 2), ("string_bytes", 32),
    ("read_bytes", 128), ("resource_entries", 1), ("evidence", 0),
))
def test_shared_small_budgets_are_deterministic_and_reset_for_next_root(tmp_path, dimension, limit):
    inner = zip_bytes([("first.lua", b"return 1" * 32), ("second.lua", b"return 2" * 32)])
    managed = dimension in {"metadata_rows", "resource_entries", "evidence"}
    data = (managed_pe(resources=(("one", b"inert one"), ("two", b"inert two")))
            if managed else zip_bytes([("inner.zip", inner), ("last.lua", b"return 3")]))
    settings = ScanSettings(budget_limits={dimension: limit})
    with Scanner(settings) as instance:
        limited = _scan(instance, tmp_path, "limited.dll" if managed else "limited.zip", data)
        assert limited.verdict is not Verdict.SAFE
        assert any(entry.error_code is ErrorCode.ITERATION_BUDGET_EXHAUSTED
                   for item in limited.artifacts for entry in item.coverage)
        assert not any(entry.error_code is ErrorCode.WALLCLOCK_TIMEOUT
                       for item in limited.artifacts for entry in item.coverage)
        assert not any(entry.error_code in {ErrorCode.WORKER_FAILURE, ErrorCode.PROTOCOL_VIOLATION}
                       for item in limited.artifacts for entry in item.coverage)
        fresh = _scan(instance, tmp_path, "fresh.lua", b"return 0")
        assert fresh.verdict is Verdict.SAFE
        if dimension == "children":
            assert len(limited.artifacts) <= limit + 1


@pytest.mark.parametrize("extra_levels", (1, 2, 5))
def test_default_depth_limit_blocks_descendants_and_retains_shallow_harm(scanner, tmp_path, extra_levels):
    nested = zip_bytes([("deep.lua", b"return 0")])
    for _ in range(ScanSettings().max_depth + extra_levels):
        nested = zip_bytes([("inner.zip", nested)])
    package = zip_bytes([
        ("payload.asi", native_pe(imports=HARM_IMPORTS, strings=HARM_BYTES)),
        ("nested.zip", nested),
    ])
    report = _scan(scanner, tmp_path, "depth.zip", package)
    assert report.verdict is Verdict.MALICIOUS
    assert any(entry.error_code is ErrorCode.ITERATION_BUDGET_EXHAUSTED
               for item in report.artifacts for entry in item.coverage)
    assert max(item.archive_depth for item in report.artifacts) <= ScanSettings().max_depth + 1


def test_later_expansion_limit_retains_completed_harmful_child(tmp_path):
    harm = native_pe(imports=HARM_IMPORTS, strings=HARM_BYTES)
    package = zip_bytes([("payload.asi", harm), ("padding.lua", b"return 0\n" * 1024)])
    with Scanner(ScanSettings(budget_limits={"decompressed_bytes": len(harm)})) as instance:
        report = _scan(instance, tmp_path, "expansion.zip", package)
    assert report.verdict is Verdict.MALICIOUS
    assert any(entry.error_code is ErrorCode.ITERATION_BUDGET_EXHAUSTED
               for item in report.artifacts for entry in item.coverage)


@pytest.mark.parametrize("recycle", ("count", "bytes"))
def test_scanner_reports_stay_identical_across_actual_worker_recycling(tmp_path, recycle):
    data = native_pe(imports=HARM_IMPORTS, strings=HARM_BYTES)
    settings = replace(ScanSettings(), **({"worker_recycle_count": 1} if recycle == "count"
                                         else {"worker_recycle_bytes": len(data)}))
    with Scanner(settings) as instance:
        first = _scan(instance, tmp_path, "recycle.asi", data)
        assert instance._pool._process is None
        second = _scan(instance, tmp_path, "recycle.asi", data)
        assert first == second
        assert instance._pool._process is None
        assert first.verdict is Verdict.MALICIOUS


def test_default_worker_recycling_preserves_same_report(tmp_path):
    data = native_pe()
    with Scanner() as instance:
        first = _scan(instance, tmp_path, "default-recycle.asi", data)
        pids = set()
        for _ in range(instance.settings.worker_recycle_count):
            report = instance.scan_file(tmp_path / "default-recycle.asi")
            assert report == first
            if instance._pool._process is not None:
                pids.add(instance._pool._process.pid)
        assert len(pids) >= 2
