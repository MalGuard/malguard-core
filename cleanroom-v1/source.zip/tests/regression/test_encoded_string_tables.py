"""Encoded native NUL-delimited tables must survive static decoding."""

import base64

import pytest

from malguard_core import Scanner
from malguard_core.budget import BudgetLedger
from malguard_core.decoding import decode_strings
from malguard_core.model import Verdict
from malguard_core.strings import ExtractedString
from tests.builders.pe_dotnet import native_pe
from tests.mutation.test_harmless_mutations import IMPORTS, TOKENS


@pytest.mark.parametrize("encoding", ["base64", "hex", "double-base64"])
def test_null_separated_credential_table_retains_detection(tmp_path, encoding):
    raw = b"\0".join(token.encode() for token in TOKENS) + b"\0"
    encoded = raw.hex().encode() if encoding == "hex" else base64.b64encode(raw)
    if encoding == "double-base64":
        encoded = base64.b64encode(encoded)
    path = tmp_path / "table.asi"
    path.write_bytes(native_pe(imports=IMPORTS, strings=encoded))
    with Scanner() as scanner:
        report = scanner.scan_file(path)
    assert report.verdict is Verdict.MALICIOUS


def test_zero_padding_is_not_decoded_text():
    source = ExtractedString(base64.b64encode(bytes(48)).decode(), 0, "ascii")
    assert not decode_strings((source,), BudgetLedger())


def test_xor_then_base64_inside_the_same_inert_table(tmp_path):
    table = b"Login Data\0Local State\0password_value\0" + base64.b64encode(b"POST\0multipart/form-data\0") + b"\0"
    encoded = bytes(byte ^ 200 for byte in table)
    path = tmp_path / "mixed.asi"
    path.write_bytes(native_pe(imports=IMPORTS, strings=encoded))
    with Scanner() as scanner:
        report = scanner.scan_file(path)
    assert report.verdict is Verdict.MALICIOUS
