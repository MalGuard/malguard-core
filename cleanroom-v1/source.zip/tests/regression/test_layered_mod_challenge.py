"""The shared challenge remains inert and requires no reputation record."""

from malguard_core import Scanner
from malguard_core.model import EvidenceDomain, Verdict
from tests.builders.layered_mod_challenge import layered_challenge


def test_layered_static_indicators_detected_without_blocklist(tmp_path):
    path = tmp_path / "fixture.asi"
    path.write_bytes(layered_challenge())
    with Scanner() as scanner:
        report = scanner.scan_file(path)
    assert report.verdict is Verdict.MALICIOUS
    assert {item.family for item in report.evidence if item.domain is EvidenceDomain.HARM} >= {
        "CREDENTIAL_ACCESS", "EXFILTRATION", "PROCESS_INJECTION",
    }
    assert not any(item.rule_id == "reputation.exact_blocklist" for item in report.evidence)
