"""Harmless late/overlap fixtures expose prefix-only decoding blind spots."""

import pytest

from malguard_core import Scanner
from malguard_core.budget import BudgetExceeded, BudgetLedger
from malguard_core.decoding import decode_artifact_bytes
from malguard_core.model import CoverageState, EvidenceDomain, Verdict
from malguard_core.settings import ScanSettings
from tests.builders.pe_dotnet import native_pe
from tests.builders.mod_test_kit import fixture_bytes
from tests.mutation.test_harmless_mutations import IMPORTS, TOKENS


def encoded_indicators() -> bytes:
    raw = b"\0".join(token.encode("ascii") for token in TOKENS) + b"\0"
    return bytes(value ^ 200 for value in raw)


@pytest.mark.parametrize("offset", [65530, 96 * 1024, 1024 * 1024 + 17])
def test_absolute_xor_location_and_boundary_coverage(offset):
    data = bytes(offset) + encoded_indicators()
    result = decode_artifact_bytes(data, BudgetLedger())
    assert any(item.text == "Login Data" and item.offset == offset for item in result)
    assert len({(item.offset, item.encoding, item.text) for item in result}) == len(result)
    assert result == decode_artifact_bytes(data, BudgetLedger())


def test_late_harm_does_not_depend_on_a_hash_blocklist(tmp_path):
    path = tmp_path / "late.asi"
    path.write_bytes(native_pe(imports=IMPORTS, overlay=bytes(96 * 1024) + encoded_indicators()))
    with Scanner() as scanner:
        report = scanner.scan_file(path)
    assert report.verdict is Verdict.MALICIOUS
    assert {item.family for item in report.evidence if item.domain is EvidenceDomain.HARM} >= {
        "CREDENTIAL_ACCESS", "EXFILTRATION",
    }
    assert not any(item.rule_id == "reputation.exact_blocklist" for item in report.evidence)


def test_window_budget_exhaustion_retains_prior_candidates():
    ledger = BudgetLedger({"parser_iterations": 70000})
    with pytest.raises(BudgetExceeded) as caught:
        decode_artifact_bytes(encoded_indicators() + bytes(128 * 1024), ledger)
    assert caught.value.resource == "parser_iterations"
    assert any(item.text == "Login Data" for item in caught.value.partial_results)


def test_late_unexamined_bytes_never_receive_safe(tmp_path):
    path = tmp_path / "limited.asi"
    path.write_bytes(native_pe(imports=IMPORTS, overlay=bytes(96 * 1024) + encoded_indicators()))
    with Scanner(ScanSettings(budget_limits={"parser_iterations": 70000})) as scanner:
        report = scanner.scan_file(path)
    assert report.verdict is not Verdict.SAFE
    assert any(entry.stage == "S0" and entry.state is CoverageState.SKIPPED_LIMIT
               for entry in report.root_artifact.coverage)


def test_clean_large_pe_remains_safe(tmp_path):
    path = tmp_path / "benign.asi"
    path.write_bytes(native_pe(overlay=bytes(2 * 1024 * 1024)))
    with Scanner() as scanner:
        report = scanner.scan_file(path)
    assert report.verdict is Verdict.SAFE


def test_plain_text_named_asi_is_invalid_with_a_clear_explanation(tmp_path):
    path = tmp_path / "test.asi"
    path.write_bytes(b"Harmless fixture for selection and routing tests.\n")
    with Scanner() as scanner:
        report = scanner.scan_file(path)
    assert report.verdict is Verdict.INVALID
    assert report.true_file_type == "TEXT"
    assert "به معنی تشخیص بدافزار نیست" in report.to_text()
    assert "تغییر پسوند" in report.to_text()


@pytest.mark.parametrize("name", list(fixture_bytes()))
def test_delivered_inert_kit_expected_results(tmp_path, name):
    data, expected = fixture_bytes()[name]
    path = tmp_path / name
    path.write_bytes(data)
    with Scanner() as scanner:
        report = scanner.scan_file(path)
    assert report.verdict.value == expected
    assert not any(item.rule_id == "reputation.exact_blocklist" for item in report.evidence)
