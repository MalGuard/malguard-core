"""Harmless, deterministic synthetic PE and ECMA-335 fixture construction.

These byte structures are never loaded or executed. No real malware, real
publisher identity, threat-intelligence hash, or external sample is included.
"""

from __future__ import annotations

import struct


def align(value: int, alignment: int) -> int:
    return (value + alignment - 1) & ~(alignment - 1)


class SectionBuilder:
    def __init__(self) -> None:
        self.data = bytearray(b"\xC3" + b"\x00" * 255)

    def put(self, data: bytes, alignment: int = 4) -> int:
        offset = align(len(self.data), alignment)
        self.data.extend(b"\x00" * (offset - len(self.data)))
        self.data.extend(data)
        return offset

    def rva(self, offset: int) -> int:
        return 0x1000 + offset


def _wrap(section: SectionBuilder, *, dll: bool = True, is_64: bool = False, section_name: bytes = b".text", section_flags: int = 0x60000020, directories: dict[int, tuple[int, int]] | None = None, overlay: bytes = b"") -> bytes:
    nt = 0x80
    optional_size = 240 if is_64 else 224
    header = bytearray(0x200)
    header[:2] = b"MZ"
    struct.pack_into("<I", header, 60, nt)
    header[nt:nt + 4] = b"PE\x00\x00"
    struct.pack_into("<HHIIIHH", header, nt + 4, 0x8664 if is_64 else 0x14C, 1, 0, 0, 0, optional_size, 0x2102 if dll else 0x0102)
    optional = nt + 24
    struct.pack_into("<H", header, optional, 0x20B if is_64 else 0x10B)
    raw_size = align(len(section.data), 0x200)
    struct.pack_into("<III", header, optional + 4, raw_size, 0, 0)
    struct.pack_into("<II", header, optional + 16, 0x1000, 0x1000)
    if is_64:
        struct.pack_into("<Q", header, optional + 24, 0x140000000)
    else:
        struct.pack_into("<II", header, optional + 24, 0x1000, 0x400000)
    struct.pack_into("<II", header, optional + 32, 0x1000, 0x200)
    struct.pack_into("<HH", header, optional + 40, 6, 0)
    struct.pack_into("<HH", header, optional + 48, 6, 0)
    struct.pack_into("<II", header, optional + 56, align(0x1000 + raw_size, 0x1000), 0x200)
    struct.pack_into("<HH", header, optional + 68, 3, 0x140)
    if is_64:
        struct.pack_into("<QQQQ", header, optional + 72, 0x100000, 0x1000, 0x100000, 0x1000)
        count_offset, directory_offset = optional + 108, optional + 112
    else:
        struct.pack_into("<IIII", header, optional + 72, 0x100000, 0x1000, 0x100000, 0x1000)
        count_offset, directory_offset = optional + 92, optional + 96
    struct.pack_into("<I", header, count_offset, 16)
    for index, (rva, size) in (directories or {}).items():
        struct.pack_into("<II", header, directory_offset + index * 8, rva, size)
    section_offset = optional + optional_size
    header[section_offset:section_offset + 8] = section_name[:8].ljust(8, b"\x00")
    struct.pack_into("<IIII", header, section_offset + 8, len(section.data), 0x1000, raw_size, 0x200)
    struct.pack_into("<I", header, section_offset + 36, section_flags)
    return bytes(header + section.data + b"\x00" * (raw_size - len(section.data)) + overlay)


def native_pe(*, imports: tuple[str, ...] = (), dll: bool = True, is_64: bool = False, strings: bytes = b"", section_flags: int = 0x60000020, section_name: bytes = b".text", overlay: bytes = b"", resource: bytes | None = None, exports: tuple[tuple[str, str | None], ...] = (), tls_callbacks: bool = False) -> bytes:
    section = SectionBuilder()
    directories = {}
    if strings:
        section.put(strings)
    if imports:
        names = []
        for name in imports:
            names.append(section.rva(section.put(b"\x00\x00" + name.encode("ascii") + b"\x00", 2)))
        dll_name = section.rva(section.put(b"kernel32.dll\x00"))
        width = 8 if is_64 else 4
        thunks = section.put(b"".join(name.to_bytes(width, "little") for name in names) + b"\x00" * width, width)
        iat = section.put(bytes(section.data[thunks:thunks + (len(names) + 1) * width]), width)
        descriptor = section.put(struct.pack("<5I", section.rva(thunks), 0, 0, dll_name, section.rva(iat)) + b"\x00" * 20)
        directories[1] = section.rva(descriptor), 40
    if exports:
        export_offset = section.put(b"\x00" * 40)
        module_name = section.rva(section.put(b"SyntheticFixture.dll\x00"))
        function_addresses = []
        names = []
        for name, target in exports:
            names.append(section.rva(section.put(name.encode("ascii") + b"\x00")))
            function_addresses.append(section.rva(section.put(target.encode("ascii") + b"\x00")) if target else 0x1000)
        function_offset = section.put(b"".join(struct.pack("<I", address) for address in function_addresses))
        name_offset = section.put(b"".join(struct.pack("<I", address) for address in names))
        ordinal_offset = section.put(b"".join(struct.pack("<H", index) for index in range(len(exports))))
        struct.pack_into("<IIHHIIIIIII", section.data, export_offset, 0, 0, 0, 0, module_name, 1, len(exports), len(exports), section.rva(function_offset), section.rva(name_offset), section.rva(ordinal_offset))
        directories[0] = section.rva(export_offset), len(section.data) - export_offset
    if tls_callbacks:
        image_base = 0x140000000 if is_64 else 0x400000
        width = 8 if is_64 else 4
        array_offset = section.put((image_base + 0x1000).to_bytes(width, "little") + b"\x00" * width, width)
        header = struct.pack("<QQQQII" if is_64 else "<IIIIII", 0, 0, 0, image_base + section.rva(array_offset), 0, 0)
        tls_offset = section.put(header, width)
        directories[9] = section.rva(tls_offset), len(header)
    if resource is not None:
        root = bytearray(96)
        struct.pack_into("<HH", root, 12, 0, 1)
        struct.pack_into("<II", root, 16, 10, 0x80000018)
        struct.pack_into("<HH", root, 24 + 12, 0, 1)
        struct.pack_into("<II", root, 40, 1, 0x80000030)
        struct.pack_into("<HH", root, 48 + 12, 0, 1)
        struct.pack_into("<II", root, 64, 0x409, 72)
        resource_offset = section.put(bytes(root))
        data_offset = section.put(resource)
        struct.pack_into("<IIII", section.data, resource_offset + 72, section.rva(data_offset), len(resource), 0, 0)
        directories[2] = section.rva(resource_offset), 96
    return _wrap(section, dll=dll, is_64=is_64, section_name=section_name, section_flags=section_flags, directories=directories, overlay=overlay)


def compressed(value: int) -> bytes:
    if value < 0x80:
        return bytes([value])
    if value < 0x4000:
        return bytes([0x80 | (value >> 8), value & 0xFF])
    if value < 0x20000000:
        return bytes([0xC0 | (value >> 24), (value >> 16) & 0xFF, (value >> 8) & 0xFF, value & 0xFF])
    raise ValueError("compressed integer out of range")


def managed_pe(*, assembly_refs: tuple[str, ...] = ("mscorlib", "ScriptHookVDotNet3"), calls: tuple[tuple[str, str, tuple[str, ...]], ...] = (), resources: tuple[tuple[str, bytes], ...] = (), user_strings: tuple[str, ...] = (), pinvoke: tuple[str, ...] = (), method_name: str = "FixtureMethod", corrupt_metadata: bool = False, corrupt_il: bool = False) -> bytes:
    section = SectionBuilder()
    strings = bytearray(b"\x00")
    blobs = bytearray(b"\x00")
    user_heap = bytearray(b"\x00")
    string_cache: dict[str, int] = {}

    def string(text: str) -> int:
        if text not in string_cache:
            string_cache[text] = len(strings)
            strings.extend(text.encode("utf-8") + b"\x00")
        return string_cache[text]

    def blob(value: bytes) -> int:
        index = len(blobs)
        blobs.extend(compressed(len(value)) + value)
        return index

    type_names = sorted({type_name for type_name, _, _ in calls})
    type_indices = {name: index for index, name in enumerate(type_names, 1)}
    type_rows = []
    for name in type_names:
        namespace, _, short_name = name.rpartition(".")
        type_rows.append((6, string(short_name), string(namespace)))
    primitive = {"byte[]": b"\x1D\x05", "string": b"\x0E", "object": b"\x1C", "int32": b"\x08", "byte": b"\x05"}
    member_rows = []
    for type_name, member, parameters in calls:
        signature = b"\x00" + compressed(len(parameters)) + b"\x01" + b"".join(primitive[param] for param in parameters)
        member_rows.append(((type_indices[type_name] << 3) | 1, string(member), blob(signature)))
    code = bytearray()
    for index, _ in enumerate(calls, 1):
        code.extend(b"\x28" + struct.pack("<I", 0x0A000000 | index))
    for text in user_strings:
        encoded = text.encode("utf-16le") + b"\x00"
        index = len(user_heap)
        user_heap.extend(compressed(len(encoded)) + encoded)
        code.extend(b"\x72" + struct.pack("<I", 0x70000000 | index) + b"\x26")
    code.append(0x2A)
    if corrupt_il:
        code[0] = 0xFF
    if len(code) < 64:
        body = bytes([(len(code) << 2) | 2]) + code
    else:
        body = struct.pack("<HHII", 0x3003, 8, len(code), 0) + code
    method_offset = section.put(body)
    method_signature = blob(b"\x00\x00\x01")
    method_rows = [(section.rva(method_offset), 0, 0x16, string(method_name), method_signature, 1)]
    module_refs = []
    impl_rows = []
    for index, name in enumerate(pinvoke, 2):
        method_rows.append((0, 0, 0x2016, string("Native" + name), method_signature, 1))
        module_refs.append((string("kernel32.dll"),))
        impl_rows.append((0x100, (index << 1) | 1, string(name), len(module_refs)))
    resource_rows = []
    resource_blob = bytearray()
    for name, value in resources:
        resource_rows.append((len(resource_blob), 1, string(name), 0))
        resource_blob.extend(struct.pack("<I", len(value)) + value)
    resource_offset = section.put(bytes(resource_blob)) if resource_blob else 0
    rows = {
        0: [(0, string("SyntheticFixture.dll"), 1, 0, 0)],
        2: [(0, string("<Module>"), 0, 0, 1, 1), (1, string("Fixture"), string("Synthetic"), 0, 1, 1)],
        6: method_rows,
        32: [(0x8004, 1, 0, 0, 0, 0, 0, string("SyntheticFixture"), 0)],
        35: [(1, 0, 0, 0, 0, 0, string(name), 0, 0) for name in assembly_refs],
    }
    if type_rows:
        rows[1] = type_rows
    if member_rows:
        rows[10] = member_rows
    if module_refs:
        rows[26], rows[28] = module_refs, impl_rows
    if resource_rows:
        rows[40] = resource_rows
    valid = sum(1 << table for table in rows)
    tables = bytearray(struct.pack("<IBBBBQQ", 0, 2, 0, 0, 1, valid, 0))
    for _, values in sorted(rows.items()):
        tables.extend(struct.pack("<I", len(values)))
    from malguard_core.dotnet import SCHEMAS
    for table, values in sorted(rows.items()):
        for row in values:
            for column, value in zip(SCHEMAS[table], row, strict=True):
                tables.extend(value.to_bytes(4 if column == "u4" else 2, "little"))
    if corrupt_metadata:
        struct.pack_into("<I", tables, 24, 0xFFFFFFFF)
    stream_data = {"#~": bytes(tables), "#Strings": bytes(strings), "#Blob": bytes(blobs), "#GUID": bytes(range(16)), "#US": bytes(user_heap)}
    version = b"v4.0.30319\x00\x00"
    root = bytearray(struct.pack("<IHHII", 0x424A5342, 1, 1, 0, len(version)) + version + struct.pack("<HH", 0, len(stream_data)))
    headers = []
    for name, value in stream_data.items():
        pointer = len(root)
        encoded_name = name.encode("ascii") + b"\x00"
        root.extend(b"\x00" * 8 + encoded_name + b"\x00" * (align(len(encoded_name), 4) - len(encoded_name)))
        headers.append((pointer, value))
    for pointer, value in headers:
        offset = align(len(root), 4)
        root.extend(b"\x00" * (offset - len(root)))
        struct.pack_into("<II", root, pointer, offset, len(value))
        root.extend(value)
    metadata_offset = section.put(bytes(root))
    clr = bytearray(72)
    struct.pack_into("<IHHIIII", clr, 0, 72, 2, 5, section.rva(metadata_offset), len(root), 1, 0)
    if resource_blob:
        struct.pack_into("<II", clr, 24, section.rva(resource_offset), len(resource_blob))
    clr_offset = section.put(bytes(clr))
    return _wrap(section, directories={14: (section.rva(clr_offset), 72)})
