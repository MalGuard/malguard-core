"""Generate reproducible, inert scanner fixtures, never real malware."""

import argparse
import hashlib
import json
from pathlib import Path

from tests.builders.archive_fixtures import zip_bytes
from tests.builders.pe_dotnet import native_pe
from tests.mutation.test_harmless_mutations import IMPORTS, mutate_payload


def fixture_bytes() -> dict[str, tuple[bytes, str]]:
    xor, _ = mutate_payload("xor")
    late = native_pe(imports=IMPORTS, overlay=bytes(96 * 1024) + xor)
    return {
        "GTA-Guard-Benign-Structure.asi": (native_pe(strings=b"Synthetic inert GTA fixture\0"), "SAFE"),
        "GTA-Guard-Inert-Challenge.asi": (late, "MALICIOUS"),
        "GTA-Guard-Inert-Challenge-Corrupt.asi": (late[:60] + b"\xff" * 4 + late[64:], "MALICIOUS"),
        "GTA-Guard-Inert-Nested-Package.zip": (
            zip_bytes([("assets.zip", zip_bytes([("textures/fixture.asi", late)]))]), "MALICIOUS",
        ),
        "GTA-Guard-Inert-Base64.asi": (native_pe(imports=IMPORTS, strings=mutate_payload("base64")[0]), "MALICIOUS"),
        "GTA-Guard-Text-Renamed.asi": (b"Harmless plain text, not a real ASI plugin.\n", "INVALID"),
    }


def write_kit(output: Path) -> dict:
    output.mkdir(parents=True, exist_ok=False)
    records = []
    for filename, (data, verdict) in fixture_bytes().items():
        (output / filename).write_bytes(data)
        records.append({"filename": filename, "size": len(data),
                        "sha256": hashlib.sha256(data).hexdigest(), "expected_verdict": verdict})
    manifest = {"schema_version": 1, "real_malware": False, "sample_execution": False,
                "purpose": "Harmless static detection challenges, not functioning GTA mods",
                "requires_hash_blocklist": False, "files": records}
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (output / "README-fa.txt").write_text(
        "این بسته فقط برای اسکن ایستا است؛ فایل‌ها ماد قابل استفاده نیستند.\n"
        "هیچ کد سرقت، تزریق، ارتباط شبکه یا ماندگاری در نمونه‌ها پیاده‌سازی نشده است.\n"
        "فایل‌های ASI ساختار و نشانگرهای ساختگی دارند؛ آن‌ها را اجرا یا داخل GTA نصب نکنید.\n"
        "نتیجهٔ MALICIOUS برای نشانگرهای شبیه‌سازی‌شده انتظار می‌رود، نه برای رفتار مخرب واقعی.\n"
        "نمونهٔ Challenge نشانگرهای XOR را پس از ۹۶ کیلوبایت قرار می‌دهد.\n"
        "نسخهٔ قبلی در این آزمایش SAFE می‌داد؛ موتور اصلاح‌شده MALICIOUS می‌دهد.\n"
        "این آزمون سختی نسبی یک سناریو را می‌سنجد و معیار دقت روی بدافزار واقعی نیست.\n",
        encoding="utf-8",
    )
    return manifest


def main() -> int:
    parser = argparse.ArgumentParser(description="Build inert GTA scanner test files; never execute them.")
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    manifest = write_kit(args.output)
    print(json.dumps({"output": str(args.output), "fixtures": len(manifest["files"])}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
