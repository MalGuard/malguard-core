"""Harmless archive fixtures built from public format structures.

Every payload is inert text or supplied synthetic bytes. No archive member is
ever executed; malformed fixtures deliberately perturb metadata only.
"""

from __future__ import annotations

import binascii
import io
import struct
import warnings
import zipfile


def zip_bytes(members: list[tuple[str, bytes]], *, compression: int = zipfile.ZIP_STORED) -> bytes:
    buffer = io.BytesIO()
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", UserWarning)
        with zipfile.ZipFile(buffer, "w", compression=compression) as archive:
            for name, content in members:
                item = zipfile.ZipInfo(name, date_time=(2020, 1, 1, 0, 0, 0))
                item.compress_type = compression
                archive.writestr(item, content)
    return buffer.getvalue()


def central_offsets(data: bytes) -> list[int]:
    end = data.rfind(b"PK\x05\x06")
    count = struct.unpack_from("<H", data, end + 10)[0]
    pos = struct.unpack_from("<I", data, end + 16)[0]
    output = []
    for _ in range(count):
        output.append(pos)
        name, extra, comment = struct.unpack_from("<HHH", data, pos + 28)
        pos += 46 + name + extra + comment
    return output


def encrypted_zip() -> bytes:
    data = bytearray(zip_bytes([("hidden.lua", b"print('inert synthetic member')")]))
    struct.pack_into("<H", data, 6, 1)
    struct.pack_into("<H", data, central_offsets(data)[0] + 8, 1)
    return bytes(data)


def central_local_mismatch() -> bytes:
    data = bytearray(zip_bytes([("one.lua", b"print('harmless')")]))
    data[30] = ord("x")
    return bytes(data)


def overlapping_zip() -> bytes:
    data = bytearray(zip_bytes([("same.lua", b"print('one')"), ("same.lua", b"print('one')")]))
    second = central_offsets(data)[1]
    struct.pack_into("<I", data, second + 42, 0)
    return bytes(data)


def zip64_overflow() -> bytes:
    data = bytearray(zip_bytes([("test.lua", b"return 1")]))
    end = data.rfind(b"PK\x05\x06")
    struct.pack_into("<I", data, end + 16, 0xFFFFFFFF)
    return bytes(data)


def zip64_stored() -> bytes:
    name, payload = b"zero.lua", b"return 0"
    crc = binascii.crc32(payload) & 0xFFFFFFFF
    extra = struct.pack("<HHQQ", 1, 16, len(payload), len(payload))
    local = struct.pack("<4s5H3I2H", b"PK\x03\x04", 45, 0, 0, 0, 0, crc,
                        0xFFFFFFFF, 0xFFFFFFFF, len(name), len(extra)) + name + extra + payload
    central = struct.pack("<4s6H3I5H2I", b"PK\x01\x02", 45, 45, 0, 0, 0, 0, crc,
                          0xFFFFFFFF, 0xFFFFFFFF, len(name), len(extra), 0, 0, 0, 0, 0) + name + extra
    zoffset = len(local) + len(central)
    zend = struct.pack("<4sQ2H2I4Q", b"PK\x06\x06", 44, 45, 45, 0, 0, 1, 1, len(central), len(local))
    locator = struct.pack("<4sIQI", b"PK\x06\x07", 0, zoffset, 1)
    end = struct.pack("<4s4H2IH", b"PK\x05\x06", 0, 0, 0xFFFF, 0xFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0)
    return local + central + zend + locator + end


def descriptor_zip(*, zip64: bool = False) -> bytes:
    class Nonseekable(io.BytesIO):
        def seekable(self) -> bool:
            return False

        def seek(self, offset: int, whence: int = 0) -> int:
            raise OSError("synthetic nonseekable writer")

    stream = Nonseekable()
    with zipfile.ZipFile(stream, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        with archive.open("descriptor.lua", "w", force_zip64=zip64) as member:
            member.write(b"print('harmless descriptor fixture')")
    return stream.getvalue()


def seven_zip_bytes(members: list[tuple[str, bytes]], *, encrypted: bool = False) -> bytes:
    import py7zr
    stream = io.BytesIO()
    with py7zr.SevenZipFile(stream, "w", password="synthetic-test" if encrypted else None) as archive:
        for name, content in members:
            archive.writestr(content, name)
    return stream.getvalue()


def rar4_stored(members: list[tuple[str, bytes]], *, encrypted: bool = False,
                compressed: bool = False) -> bytes:
    def header(kind: int, flags: int, body: bytes) -> bytes:
        fixed = struct.pack("<BHH", kind, flags, len(body) + 7) + body
        return struct.pack("<H", binascii.crc32(fixed) & 0xFFFF) + fixed

    output = bytearray(b"Rar!\x1a\x07\x00")
    output.extend(header(0x73, 0, bytes(6)))
    for name, content in members:
        filename = name.encode("ascii")
        flags = 0x8000 | (0x4 if encrypted else 0)
        body = struct.pack("<IIBIIBBHI", len(content), len(content), 2,
                           binascii.crc32(content) & 0xFFFFFFFF, 0, 20,
                           0x31 if compressed else 0x30, len(filename), 0x20) + filename
        output.extend(header(0x74, flags, body))
        output.extend(content)
    output.extend(header(0x7B, 0, b""))
    return bytes(output)
