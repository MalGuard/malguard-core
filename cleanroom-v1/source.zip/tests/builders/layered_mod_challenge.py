"""An inert PE with layered indicator encodings, not functional malware."""

import base64

from tests.builders.pe_dotnet import native_pe
from tests.mutation.test_harmless_mutations import IMPORTS, TOKENS


def layered_challenge() -> bytes:
    # Names are static fixture data. No function call bodies implement them.
    tokens = (*TOKENS, "chrome.exe", "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run")
    indicators = "\n".join(tokens).encode("ascii")
    layered = base64.b64encode(indicators.hex().encode("ascii"))
    imports = (*IMPORTS, "OpenProcess", "VirtualAllocEx", "WriteProcessMemory",
               "CreateRemoteThread", "RegSetValueExW")
    return native_pe(imports=imports, strings=b"INERT_SYNTHETIC_FIXTURE_DO_NOT_INSTALL\0" + layered + b"\0")
