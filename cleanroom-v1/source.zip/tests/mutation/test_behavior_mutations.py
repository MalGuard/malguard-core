"""Inert mutation fixtures measure detection survival without executing a sample."""

from __future__ import annotations

from types import SimpleNamespace

import pytest

from malguard_core.budget import BudgetLedger
from malguard_core.model import EvidenceDomain
from malguard_core.native import analyze as native_analyze
from malguard_core.scripts import analyze as script_analyze
from tests.builders.behavior import INJECTION_APIS, lua_remote_loader


@pytest.mark.parametrize("variant", ["ascii", "utf16", "aw"])
def test_native_api_mutation_family_survives(variant):
    values = INJECTION_APIS
    if variant == "aw":
        values = ("OpenProcess", "VirtualAllocEx", "WriteProcessMemory", "CreateRemoteThread")
    codec = "utf-16-le" if variant == "utf16" else "ascii"
    data = b"\x00".join(value.encode(codec) for value in values)
    extracted = tuple(SimpleNamespace(text=value, offset=0, decoded=False, encoding=codec) for value in values)
    result = native_analyze(data, "a", "mod.asi", BudgetLedger(), extracted)
    assert {item.family for item in result.evidence if item.domain == EvidenceDomain.HARM} == {"PROCESS_INJECTION"}


@pytest.mark.parametrize("codec", ["ascii", "utf-16-le"])
def test_source_encoding_retains_remote_loader(codec):
    data = lua_remote_loader().decode("ascii").encode(codec)
    result = script_analyze(data, "a", "mod.lua", BudgetLedger())
    assert any(item.family == "REMOTE_CODE_EXECUTION" for item in result.evidence)


def test_unclosed_comment_after_behavior_retains_harm():
    result = script_analyze(lua_remote_loader() + b"\n--[[", "a", "mod.lua", BudgetLedger())
    assert any(item.family == "REMOTE_CODE_EXECUTION" for item in result.evidence)
