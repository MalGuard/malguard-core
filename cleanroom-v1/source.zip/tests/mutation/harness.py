"""Standalone measurements on ten harmless static fixture mutations."""

import argparse
import json
from pathlib import Path
from tempfile import TemporaryDirectory

from malguard_core import Scanner
from malguard_core.model import EvidenceDomain, Verdict
from tests.builders.archive_fixtures import zip_bytes
from tests.builders.pe_dotnet import native_pe
from tests.mutation.test_harmless_mutations import IMPORTS, mutate_payload


MUTATIONS = ("ascii", "utf16", "split", "base64", "hex", "xor", "reverse", "api_aw", "nested_archive", "corrupt_header")


def run_measurements() -> dict:
    records = []
    with TemporaryDirectory(prefix="malguard-inert-mutations-") as directory, Scanner() as scanner:
        for mutation in MUTATIONS:
            payload, extension = mutate_payload(mutation)
            imports = ("ReadFile", "CryptUnprotectData", "HttpSendRequestW") if mutation == "api_aw" else IMPORTS
            data = native_pe(imports=imports, strings=payload)
            if mutation == "nested_archive":
                data = zip_bytes([("nested.zip", zip_bytes([("payload.asi", data)]))])
                extension = "zip"
            elif mutation == "corrupt_header":
                data = data[:60] + bytes([255]) * 4 + data[64:]
            path = Path(directory) / (mutation + "." + extension)
            path.write_bytes(data)
            report = scanner.scan_file(path)
            records.append({
                "mutation": mutation, "verdict": report.verdict.value,
                "risk": report.risk_score, "coverage": report.coverage_score,
                "harm_families": sorted({item.family for item in report.evidence if item.domain is EvidenceDomain.HARM}),
                "malicious_detection_broken": report.verdict is not Verdict.MALICIOUS,
            })
    return {"schema_version": 1, "fixture_kind": "harmless synthetic static structures",
            "samples": len(records), "malicious_detected": sum(not record["malicious_detection_broken"] for record in records),
            "malicious_detection_breaks": [record["mutation"] for record in records if record["malicious_detection_broken"]],
            "records": records,
            "limitation": "This measures this synthetic fixture only; no malware-corpus recall or benign-corpus false-positive claim is established."}


def main() -> int:
    parser = argparse.ArgumentParser(description="Measure harmless static malware-scanner representation mutations.")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    measurements = run_measurements()
    payload = json.dumps(measurements, indent=2, sort_keys=True)
    if args.output:
        args.output.write_text(payload + "\n", encoding="utf-8")
    print(payload)
    return 1 if measurements["malicious_detection_breaks"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
