"""Measure static detection under harmless representation mutations."""

import base64
import json

import pytest

from malguard_core import Scanner
from malguard_core.model import EvidenceDomain, Verdict
from tests.builders.archive_fixtures import zip_bytes
from tests.builders.pe_dotnet import native_pe


TOKENS = ("Login Data", "Local State", "password_value", "CryptUnprotectData", "HttpSendRequest", "POST")
IMPORTS = ("ReadFile", "CryptUnprotectData", "HttpSendRequestA")


def mutate_payload(name: str) -> tuple[bytes, str]:
    raw = b"\0".join(token.encode() for token in TOKENS) + b"\0"
    if name == "utf16":
        return "\0".join(TOKENS).encode("utf-16le") + b"\0\0", "asi"
    if name == "split":
        return b"\0".join(('"' + token[:len(token)//2] + '" + "' + token[len(token)//2:] + '"').encode() for token in TOKENS), "asi"
    if name == "base64":
        return base64.b64encode(raw.replace(b"\0", b"\n")), "asi"
    if name == "hex":
        return raw.replace(b"\0", b"\n").hex().encode(), "asi"
    if name == "xor":
        return bytes(byte ^ 200 for byte in raw), "asi"
    if name == "reverse":
        return b"\0".join(token[::-1].encode() for token in TOKENS), "asi"
    return raw, "asi"


@pytest.mark.parametrize("mutation", ["ascii", "utf16", "split", "base64", "hex", "xor", "reverse", "api_aw", "nested_archive", "corrupt_header"])
def test_harmful_behavior_survives_supported_mutations(tmp_path, mutation):
    payload, extension = mutate_payload(mutation)
    imports = ("ReadFile", "CryptUnprotectData", "HttpSendRequestW") if mutation == "api_aw" else IMPORTS
    data = native_pe(imports=imports, strings=payload)
    if mutation == "nested_archive":
        data = zip_bytes([("nested.zip", zip_bytes([("payload.asi", data)]))])
        extension = "zip"
    elif mutation == "corrupt_header":
        data = data[:60] + b"\xff\xff\xff\xff" + data[64:]
    path = tmp_path / (mutation + "." + extension)
    path.write_bytes(data)
    with Scanner() as scanner:
        report = scanner.scan_file(path)
    # Measurement is written as a JSON artifact, independently of assertions.
    measurement = {"mutation": mutation, "verdict": report.verdict.value,
                   "risk": report.risk_score, "coverage": report.coverage_score,
                   "harm_families": sorted({item.family for item in report.evidence if item.domain is EvidenceDomain.HARM}),
                   "malicious_detection_broken": report.verdict is not Verdict.MALICIOUS}
    (tmp_path / "measurement.json").write_text(json.dumps(measurement, sort_keys=True), encoding="utf-8")
    assert report.verdict is Verdict.MALICIOUS, measurement


def test_api_aw_substitution_does_not_inflate_risk(tmp_path):
    payload, _ = mutate_payload("ascii")
    results = []
    with Scanner() as scanner:
        for variant in ("HttpSendRequestA", "HttpSendRequestW"):
            path = tmp_path / (variant + ".asi")
            path.write_bytes(native_pe(imports=("ReadFile", "CryptUnprotectData", variant), strings=payload))
            results.append(scanner.scan_file(path))
    assert results[0].risk_score == results[1].risk_score
    assert results[0].verdict is results[1].verdict is Verdict.MALICIOUS
