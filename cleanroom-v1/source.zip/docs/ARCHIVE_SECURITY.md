# Archive analysis boundaries

Archive members are memory buffers and logical report labels. The engine never
writes members to the filesystem and never starts an archive extractor. Parent
and nested members share the root work ledger. A completed readable member goes
through the same intake, reputation, raw, structured and correlation stages as
the root file.

ZIP supports stored and raw-DEFLATE members. Independent format validation checks
end records, ZIP64 records, central-directory counts and ranges, local headers,
data descriptors, names, sizes, flags and CRCs before bounded decompression. The
standard library ZIP parser supplies a second interpretation. Parser disagreement,
overlap, unindexed bytes, dangerous member paths, name collisions and nonempty
directory payloads block a clean result. A later malformed member retains earlier
validated readable children. Other compression methods and encrypted members are
reported as unreadable, even when the host has an external extractor installed.

7z start and next-header CRCs and ranges are checked independently. The next
header is limited to 8 MiB. `py7zr` writes exclusively through bounded in-memory
writer objects; their output cannot exceed each declared size. The engine checks
aggregate and member expansion ratios and shares expansion and entry limits.
Encrypted headers or members and ambiguous names prevent complete coverage. The
library's internal compressed-header parsing iterations cannot be individually
instrumented; worker process memory, CPU and wallclock bounds provide the safety
net around this stage. Windows Job Object enforcement needs Windows runtime
verification.

RAR4 supports unencrypted, unsplit, stored regular files. Independent sequential
block validation checks CRCs, header lengths, packed ranges and entry counts, then
`rarfile` reads only its internal clear-data stream. Compressed, redirected, split
and encrypted RAR4 members are blocked. RAR5 is recognized and explicitly
unsupported. No fallback may invoke WinRAR, unrar, 7-Zip or another external tool.

Limits are deterministic: archive entries, child artifacts, decompressed bytes,
parser iterations and evidence consume the shared ledger. The default member
limit is 64 MiB, and a greater-than-1000 expansion ratio for outputs above 1 MiB
blocks decompression. A 96 MiB JSON result reservation prevents worker IPC frame
overflow; completed children remain available when further output reaches that
limit. These policies can make legitimate very large or unusually compressible
packages inconclusive. They cannot confer safety on unreadable data.
