# Browser delivery QA

The standalone harness at `tests/browser/browser_delivery_qa.py` verifies the
CLI's UTF-8 Persian and JSON reports in actual local Chromium, and downloads the
delivery ZIP and wheel through the browser. Its HTML page exists only in a
temporary directory served on `127.0.0.1`; it is a trusted QA wrapper, not a
MalGuard product GUI. Nothing is published or uploaded.

The initial delivered artifact results, browser command arguments, interactive
snapshots, download hashes, and HTTP request statuses are recorded in
[browser-qa.json](browser-qa.json). Its delivery ZIP and wheel hashes describe
the original artifacts before the final rebuild. The baseline screenshots are
[Persian report](browser-qa/persian-report.png) and
[expanded JSON evidence](browser-qa/json-evidence.png).

Final rebuilt artifact verification is a separate run, performed after the
delivery ZIP and wheel are finalized. Its evidence is written to the external
sidecar `/workspace/malguard-final-browser-qa.json`, and its screenshots to
`/workspace/malguard-final-browser-screenshots`. These final sidecars are excluded
from the delivery ZIP, so recording the ZIP's own hash does not change the ZIP.
The baseline evidence is preserved; it must not be presented as verification of
the final rebuilt artifacts. Neither run creates or publishes a product GUI.

## Run

Use the project Python environment, an installed trusted `agent-browser`, and a
local Chromium executable. The harness deliberately has no dependency on a
remote browser service or an existing user browser profile.

```sh
.venv/bin/python tests/browser/browser_delivery_qa.py \
  --agent-browser /tmp/malguard-browser-qa-tools/node_modules/.bin/agent-browser \
  --chromium /usr/bin/chromium \
  --delivery-zip /workspace/malguard-delivery.zip \
  --wheel dist/malguard-1.0.0-py3-none-any.whl \
  --output-json docs/browser-qa.json \
  --screenshots docs/browser-qa

.venv/bin/ruff check tests/browser/browser_delivery_qa.py
```

After final artifact creation, run the same harness with external result paths:

```sh
.venv/bin/python tests/browser/browser_delivery_qa.py \
  --agent-browser /tmp/malguard-browser-qa-tools/node_modules/.bin/agent-browser \
  --chromium /usr/bin/chromium \
  --delivery-zip /workspace/malguard-delivery.zip \
  --wheel dist/malguard-1.0.0-py3-none-any.whl \
  --output-json /workspace/malguard-final-browser-qa.json \
  --screenshots /workspace/malguard-final-browser-screenshots
```

Do not rebuild or modify the checked ZIP or wheel after that run. Compare the
`Download delivery ZIP` and `Download Python wheel` hashes in the final JSON
sidecar with the finalized artifact hashes when reviewing the delivery.

In the managed execution environment, the run needs the tool's loopback network
permission (`with_additional_permissions.network.enabled=true`) to bind the
HTTP server and use the browser daemon. Every run supplies an explicit empty
agent-browser configuration, fresh temporary sockets, its own namespace and
session, and a `127.0.0.1` browser domain restriction. It clears inherited
agent-browser profile/state settings and proxy environment settings. It always
closes the browser and the HTTP server, then deletes the temporary files.

## Checks performed

- A deterministic synthetic ZIP contains only inert text/source descriptions.
  The CLI scans its bytes in both report formats. No source, PE, assembly, or
  archive member is executed, imported, compiled, or extracted to disk.
- Its Unicode filename includes a synthetic token and an HTML-looking `<img>`
  label; an archive member name includes a synthetic Discord webhook URL.
  Both secrets are redacted in the text/JSON reports before presentation.
- The trusted wrapper HTML-escapes the complete reports. Browser DOM assertions
  verify UTF-8, Persian language and RTL metadata, unchanged report text,
  unchanged JSON, and the absence of active image/script/frame/object elements.
  The HTML-looking logical path remains literal text and its event-looking
  label does not run.
- The agent-browser workflow opens the page, obtains interactive snapshots,
  clicks the JSON disclosure by its snapshot reference, obtains a new snapshot,
  and captures both page states. Fixed trusted DOM assertions read report data;
  they never evaluate the scanned strings as code.
- Native `agent-browser download` interactions retrieve JSON, Persian text,
  delivery ZIP, and wheel. Every downloaded file must have the same byte length
  and SHA-256 as its served source. The downloaded complete JSON object and all
  evidence records must equal the displayed report. Downloaded text must equal
  the displayed Persian report.
- Both source and downloaded ZIP/wheel files pass ZIP CRC verification and have
  matching member counts. The harness reads the archives only for integrity
  checks and does not extract or execute their members.
- The run collects uncaught browser errors, console messages, exact browser
  commands, and loopback requests. The initial recorded run has zero page errors
  and zero console messages. The final sidecar records the corresponding
  observations for rebuilt artifacts.

## Tool and setup observations

The actual run uses `agent-browser 0.38.2`, Chromium `151.0.7922.173` on Debian
13, and Python `3.12.14`; exact versions are included in the result JSON.
Initial startup without a socket-directory override encountered the restricted
default location. The isolated socket retry initially exited during daemon
startup until loopback network permission was enabled. With that permission,
agent-browser completed the entire browser workflow; no Playwright fallback
was needed. A first exploratory scan with system Python exposed unavailable
runtime analysis dependencies. The recorded run uses `.venv/bin/python`, which
contains the project's pinned scanner dependencies.

These results establish browser presentation and delivery integrity for the
recorded artifacts. The synthetic fixture's verdict, score, and evidence count
are recorded as observations; they are not an accuracy measurement or a claim
about real malware detection. This harness does not verify a Windows GUI,
real-sample acceptance rates, or malware behavior.
