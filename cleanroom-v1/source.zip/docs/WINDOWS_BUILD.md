# Windows x64 standalone build

The standalone application preserves `scan_file(path) -> Report`. It contains
CPython, the hash-locked runtime libraries, the signed built-in security bundle
and the scanner. No separate Python installation is needed on the user's machine.
The console application offers an interactive file-path prompt when double-clicked.
It saves UTF-8 JSON reports in `%LOCALAPPDATA%\MalGuard\Reports` using exclusive
new files. `--format`, `--output` and the scan exit codes are unchanged;
`--evaluate` routes to the existing static corpus evaluator.

The trusted EXE relaunches itself only with the exact private
`--malguard-worker` switch. The worker keeps binary framed JSON on stdin/stdout.
Public UTF-8 console configuration never runs on this protocol route. Workers
use the existing admission checks, Windows Job limits, global budget charging,
schema validation and failure recycling. `CREATE_NO_WINDOW` suppresses worker
console windows. A failed worker cannot return SAFE or replace collected HARM.
Scanned files are never used as process commands, imported or executed.

`packaging/windows/MalGuard.spec` produces an onedir AMD64 console application,
without UPX or administrator privileges. Keep `_internal` beside `MalGuard.exe`.
`package_release.py` refuses non-AMD64 executables and symlink payloads, collects
original redistribution notices and emits a portable ZIP and NSIS installer.
The installer requests current-user privileges, writes HKCU uninstall metadata
and creates shortcuts. It deletes only named owned files and empty directories
when uninstalled. Stored reports and unrelated user files are retained.
An optional shortcut failure is printed in installation details; payload or
registration failure returns a nonzero status. Neither installation nor scanning
adds exclusions to Windows security settings.

## Native build command

Use trusted 64-bit CPython 3.12 and NSIS **3.11** with its AMD64 Unicode stubs.
The pinned PyInstaller and hook versions were verified against live PyPI metadata;
the exact wheel hashes are in `build-requirements-lock.txt`. NSIS version and
license provenance must be supplied explicitly rather than downloaded by a sample
or a loose settings file. The PowerShell script creates a fresh virtual environment
and a new output directory, then self-tests the resulting trusted EXE.

```powershell
& .\packaging\windows\build.ps1 `
  -Python "C:\Python312\python.exe" `
  -MakeNsis "C:\Program Files\NSIS\makensis.exe" `
  -NsisLicense "C:\Program Files\NSIS\COPYING" `
  -Output "C:\Builds\MalGuard-release"
```

For an offline build, add `-Wheelhouse "C:\Builds\verified-wheels"` containing
every wheel in both hash-locked requirement files. TLS verification remains enabled
for an online build. The native PowerShell orchestration is reviewed but has not
been executed in this Linux workspace. The CI workflow now installs the project
before installed-entry-point tests and prepares a Windows frozen build/self-test;
no GitHub workflow run was dispatched or claimed.

## Standalone verification commands

Generate only harmless fixtures from the repository's builders:

```text
python -m tests.integration.prepare_windows_fixtures C:\Lab\synthetic-fixtures
python -I packaging\windows\smoke_exe.py --exe C:\Builds\MalGuard-release\MalGuard\MalGuard.exe --fixtures C:\Lab\synthetic-fixtures --output C:\Lab\exe-qa.json
python -I packaging\windows\smoke_install.py --release C:\Builds\MalGuard-release --output C:\Lab\installer-qa.json
```

The install test is intended for a disposable lab profile without an existing
installation. It installs in a Persian path with spaces, hashes every owned file,
runs the installed scanner, creates a JSON report, then verifies uninstall keeps
personal files and the report. Only our trusted application and installer execute.
Fixture PE, DLL, script and archive members are always inert scan inputs.

The actual Linux/Wine execution results and delivered artifact hashes are recorded
in `WINDOWS-VERIFICATION.md` and external JSON evidence. Wine is a compatibility
runtime: it cannot qualify native Windows 10/11 Job enforcement, ACLs, kernel
behavior, SmartScreen, Defender, installer UI or real-corpus detection targets.
No Windows code-signing certificate was available; the distributable EXEs are
unsigned. The scanner's embedded security data signatures are separate and
continue to be verified offline.
