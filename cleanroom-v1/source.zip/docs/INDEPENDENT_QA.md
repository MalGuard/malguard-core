# Independent delivery review

This review uses harmless synthetic bytes and the default `Scanner`, including
its real isolated YARA worker. No scanned source, PE, assembly or archive member
was executed, compiled, imported or used as an interpreter command. The review
was performed on Linux with CPython 3.12.14; Windows runtime behavior was not
verified. No production dependencies, GUI, build artifacts or delivery archive
were changed by this reviewer.

The durable reproductions are in
[`tests/security/test_delivery_review.py`](../tests/security/test_delivery_review.py).
The tests exercise the public scan API and inspect verdicts, evidence domains,
coverage and both report renderers. They distinguish a visible active chain from
inert source text rather than assuming that every raw token is executable.
After repairs, all 50 independent cases passed together with the existing source,
YARA and mutation regressions: 144 selected tests passed in 2.01 seconds.

## Findings reproduced before remediation

| Boundary | Harmless minimal case | Original observation |
| --- | --- | --- |
| C# declarations | An interface or `extern` declaration names `OpenProcess`, `WriteProcessMemory`, `VirtualAllocEx` and `CreateRemoteThread`. | `SUSPICIOUS`, risk 26, source `PROCESS_INJECTION`, despite no invocation. |
| Declaration plus data | A constant holds `Login Data password_value`; empty methods are named `CryptUnprotectData` and `UploadData`. | `MALICIOUS`, risk 51, two YARA HARM families. |
| Unrelated declaration | A credential-token data literal plus an empty `Invoke` method declaration. | `MALICIOUS`, risk 51; deleting the empty method gives `SAFE`, risk 0. |
| C# interpolated data | A `$"..."` string contains credential tokens and no interpolation expression. | `MALICIOUS`, risk 51. |
| Recognized comments | VB/VBS `REM`, INI `;`, or XML `<!-- -->` comment contains credential tokens. | `MALICIOUS`, risk 51, although source syntax proves the tokens inert. |
| Batch displayed text | Two `echo` lines display a scheduled-task command and a Defender-disabling command. | `MALICIOUS`, risk 52, from two source HARM families. |
| Source progress | A blank line precedes a batch `REM` comment. | A 14-byte source exhausted 1,000 parser iterations because the start-of-line comment recognizer matched across the newline without advancing. The default large budget was deliberately not exhausted. |
| PowerShell executable interpolation | `Write-Output "GTA5 $(Set-MpPreference -DisableRealtimeMonitoring $true)"`. | `SAFE`, risk 0, all stages `COMPLETE`; raw tampering evidence was downgraded to context although `$()` is executable. |
| Mutable GTA process array | `Array.Fill(targets, Process.GetProcessById(unknownPid))` occurs between GTA lookup and opening/writing the handle. | `SAFE`, risk 0, `HACKTOOL_PUA`; the changed array was still accepted as exclusive GTA proof. |
| Stale variable lineage | A Lua response variable is overwritten with local text before `loadstring`; a credential-read variable is overwritten with a settings-file read before decrypt/upload. | Source claimed a proven remote chain; the credential case was `MALICIOUS`, risk 51. |
| Scope and case identity | Identical local names in unrelated functions, or distinct C#/Lua names such as `raw`/`Raw`, were joined. | Definitive source chains were fabricated across separate bindings. |
| Nested explicit lineage | `client.UploadData(url, ProtectedData.Unprotect(File.ReadAllBytes("Login Data"), null, scope))`. | `SAFE`, risk 0, no evidence; the assignment-based equivalent was `MALICIOUS`. |
| Receiver naming | The assignment-based credential chain sends through `uploader.UploadData` instead of `client.UploadData`. | The explicit transfer lost its `EXFILTRATION` family. |
| Unrelated decoded data | An unused data literal encodes credential-chain syntax; the only execution sink receives the separate constant `"return 0"`. | `SUSPICIOUS`, risk 32, from two decoded HARM families although decoded data had no path into that sink. |
| Standard secret formats | `Authorization: Bearer <synthetic-token>` or quoted JSON `token`/`password` values occur in a report field. | Both JSON and text preserved the synthetic token. A real scanned filename independently demonstrated the Bearer leak. |

These cases establish behavior of the static recognizer, not functioning malware
or real credential theft. No malicious file corpus was acquired. A raw pattern
can remain useful evidence in binary, malformed or unsupported content, where a
completed lexical view cannot prove it inert. The source regressions above use
complete, recognizable syntax to establish the stronger distinction.

## Commands and results

All repository commands below ran from `/workspace/malguard`.

| Executed command | Observed result |
| --- | --- |
| `.venv/bin/python -m pytest tests/security/test_delivery_review.py -q --tb=short` | Initial 32-case regression set: 26 failed, 6 passed in 0.28 seconds. The failures reproduced the source handling issues above. |
| `.venv/bin/python -m pytest tests/security/test_delivery_review.py -q --tb=no` | Expanded 39-case set with report redaction and evidence-retention checks: 29 failed, 10 passed in 0.31 seconds before implementation fixes. |
| `.venv/bin/python -m pytest tests/security/test_delivery_review.py -q --tb=no` | Expanded 40-case set including unrelated decoded data: 30 failed, 10 passed in 0.35 seconds before implementation fixes. |
| `.venv/bin/python -m pytest tests/security/test_delivery_review.py -q --tb=no` | Intermediate 43-case set during repairs: 16 failed, 27 passed in 0.56 seconds. Inert-source, executable PowerShell interpolation and redaction cases passed; flow and bounded comment-progress repairs were still pending. |
| `.venv/bin/python -m pytest tests/security/test_delivery_review.py -q --tb=no` | Intermediate 50-case set during repairs: 1 failed, 49 passed in 0.86 seconds. The remaining failure exposed active calls being masked inside a C# control condition. |
| `.venv/bin/python -m pytest tests/security/test_delivery_review.py tests/unit/test_native_scripts.py tests/unit/test_yara_rules.py tests/mutation/test_behavior_mutations.py tests/mutation/test_harmless_mutations.py -q --tb=short` | Final directed verification: 144 passed in 2.01 seconds; exit 0. Includes all 50 independent cases, active source controls and the existing source/YARA/mutation regressions. |
| `.venv/bin/python --version` | Python 3.12.14. |
| `.venv/bin/python -m ruff check tests/security/test_delivery_review.py` | All checks passed; exit 0, repeated after the final regression additions. |

A separate read-only reviewer executed these exact exploratory commands:

```bash
PYTHONPATH=/workspace/malguard .venv/bin/python /tmp/malguard_inert_qa.py
PYTHONPATH=/workspace/malguard .venv/bin/python /tmp/malguard_gta_qa.py
PYTHONPATH=/workspace/malguard .venv/bin/python /tmp/malguard_flow_qa.py
PYTHONPATH=/workspace/malguard .venv/bin/python /tmp/malguard_fn_qa.py
```

Those scripts wrote temporary source files, called the default isolated Scanner
and the source analyzer, and printed evidence/verdict summaries. Their minimal
cases have durable equivalents in the regression module. `/tmp` is ephemeral;
the exploratory script paths are execution records, not required delivery files.
An initial exploratory configuration with isolation disabled intentionally
blocked YARA completion and was rerun with default isolation before findings
were retained.

The baseline positive controls passed: a real batch command after `&` remains
active; PowerShell single-quoted data and here-strings remain inert; disabling a
required YARA/isolation stage prevents `SAFE`; an unclosed source literal receives
partial coverage; source harm survives a later unclosed comment; ordinary query
tokens, webhook secrets and simple key/value formats were already redacted.

## Support limits

This directed review adds independent boundary tests; it does not establish a
representative detection rate, false-positive rate or corpus acceptance target.
The source model remains bounded and lexical. General alias analysis, full
language parsing, runtime behavior, arbitrary dynamic reflection, encrypted
payload recovery and native control flow are outside this evidence. Passing
synthetic regressions cannot guarantee that every source mutation is recognized.
Linux worker runs verify process/resource isolation on this environment; they do
not establish Windows Job Object/ACL behavior or a full filesystem/network
sandbox. The final directed run above verified the repaired source tree; installed
wheel, source distribution and delivery-archive verification are recorded by the
separate packaging reviewers.

## Final bounded-source verification — 2026-10-04

Further finite checks confirmed and repaired these concrete cases:

- An ancestor-scope credential read now reaches the matching child-block
  decrypt/upload; local shadows and intervening writes invalidate the binding.
- A root GTA-only trainer cannot suppress an unrelated decoded memory target.
  Each explicit source body receives its own target proof.
- VB interpolated expressions retain raw evidence and incomplete coverage;
  interpolated plain text remains inert.
- Quoted passphrases with spaces and escaped quotes are fully redacted from
  both JSON and text.
- A harmless first encoded PowerShell invocation cannot hide later invocations.
  Every visible argument is visited within candidate/byte caps; excess work
  blocks complete coverage.
- A quoted Lua body actually passed to load/loadstring is analyzed as source.
  Unrelated data literals never become source merely because an interpreter
  exists elsewhere. A known harmless constant interpreter body does not turn
  unrelated credential documentation into YARA HARM.

The final directed command was:

```bash
.venv/bin/python -m pytest tests/unit/test_decoded_source_relationships.py tests/unit/test_source_flow.py tests/security/test_delivery_review.py tests/unit/test_native_scripts.py tests/unit/test_yara_rules.py tests/mutation -q --tb=short
```

Actual result: **239 passed in 2.76s**, exit 0. The complete final source suite
then passed **906 tests with one Windows-only skip in 78.23s**. Ruff and both
Linux/win32 mypy configurations passed. These are synthetic regression results,
not corpus performance measurements. Unknown dynamic relationships and further
interpreter layers remain explicit incomplete/opacity conditions; the source
model is not a complete language compiler or execution engine.

The subsequent browser text review corrected the generic unknown dynamic-input finding so it no longer asserts a decoder or string encryption without a visible decoder call. The added harmless regression and full suite passed: **907 passed, 1 Windows-only skip in 81.10s**. Final installed and offline checks were repeated on that exact corrected wheel.
