# Dependency verification

Dependency versions and release files were checked against live PyPI metadata on
2026-10-03. `dependency-metadata.json` records the direct runtime, development and
build packages. `dependency-lock-metadata.json` records all 66 packages in the
hash-locked runtime/development/build graph, including the Windows-only pytest
dependency `colorama` and the `pip` dependency of `pip-api`.

The engine targets CPython 3.12 on Windows AMD64. The available execution host is
Linux with CPython 3.12.14. Wheel availability and metadata compatibility do not
establish Windows runtime correctness.

| Runtime dependency | Verified stable release | Python compatibility | Windows distribution |
| --- | --- | --- | --- |
| pefile | 2024.8.26 | `>=3.6.0` | Universal Python wheel |
| dnfile | 0.18.0 | `>=3.8` | Universal Python wheel |
| yara-x | 1.21.0 | `>=3.9` | CPython ABI3 Windows AMD64 wheel |
| py7zr | 1.1.3 | `>=3.10` | Universal Python wheel; Windows wheels resolved for native dependencies |
| rarfile | 4.5 | `>=3.10` | Universal Python wheel; external decompression is disabled by the engine |
| signify | 0.9.2 | `>=3.9` | Universal Python wheel |
| cryptography | 50.0.2 | `!=3.9.0,!=3.9.1,>=3.9` | CPython ABI3 Windows AMD64 wheel |
| packaging | 26.3 | `>=3.9` | Universal Python wheel |

Exact pins live in `pyproject.toml`; the complete graph and accepted release-file
SHA256 hashes live in `requirements-lock.txt`. Release hashes are package
integrity records, not malware intelligence. No scanned sample contributes a
dependency or trust record.

The following commands were executed successfully on the Linux host:

```bash
.venv/bin/python -m pip install --require-hashes -r requirements-lock.txt
.venv/bin/python -m pip check
.venv/bin/python -m pip download --platform win_amd64 --python-version 3.12 --implementation cp --abi cp312 --abi abi3 --only-binary=:all: --require-hashes -r requirements-lock.txt -d /tmp/malguard-windows-wheels
.venv/bin/python -m pip download --platform win_amd64 --python-version 3.12 --implementation cp --abi cp312 --abi abi3 --only-binary=:all: --require-hashes -r /tmp/malguard-colorama-windows.txt -d /tmp/malguard-windows-wheels
.venv/bin/pip-audit --disable-pip --no-deps -r requirements-lock.txt --format json --output docs/dependency-audit.json --cache-dir /tmp/malguard-pip-audit-cache
.venv/bin/pip-audit --disable-pip --no-deps -r /tmp/malguard-colorama-windows.txt --format json --output docs/dependency-audit-windows-only.json --cache-dir /tmp/malguard-pip-audit-cache
```

The temporary colorama requirements file contains the verified `colorama==0.4.6`
release hashes already stored in the lockfile. This separate download was needed
because pip evaluates `sys_platform` markers against the Linux download host.

Results: hash-locked installation completed, `pip check` reported no broken
requirements, 66 Windows-compatible wheels were downloaded and their SHA256
hashes independently compared with recorded PyPI release hashes. The main audit
covered 65 packages; the Windows-only audit covered colorama. Both audits exited
zero and reported no known vulnerabilities. Audit results are snapshots of the
advisory service on this date, not a claim that the dependencies have no defects.

`windows-wheel-verification.json` records the downloaded filenames and verified
hashes. `.github/workflows/malguard.yml` schedules CPython 3.12 runtime tests,
lint, Windows-platform type checking, builds and installed-wheel CLI checks on
both Windows and Linux. This workflow has not been run by this local environment.
Action release tags and the commit hashes pinned by that workflow were resolved
from live GitHub metadata; see `ci-action-metadata.json`.

For repeatable installation, create a CPython 3.12 virtual environment, install
the hash lockfile, then install a locally built MalGuard wheel with `--no-deps`.
Building with `python -m build --no-isolation` uses the verified, pinned hatchling
already installed from the lockfile. Dependency updates require a fresh metadata
review, full graph resolution, hash verification and platform runtime tests.
