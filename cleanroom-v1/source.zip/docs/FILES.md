# Created and revised project files

The original workspace contained no repository, engine or legacy tests. All project files are clean-room work. Virtual environments, caches and built distributions are excluded. No unrelated infrastructure was removed.

Current source, signed data, rule, documentation, CI and test inventory: **105 files**.

## Added during independent QA

- `docs/BROWSER_QA.md`
- `docs/FRESH_INSTALL_QA.md`
- `docs/INDEPENDENT_QA.md`
- `docs/STRESS_QA.json`
- `docs/STRESS_QA.md`
- `docs/browser-qa.json`
- `docs/browser-qa/json-evidence.png`
- `docs/browser-qa/persian-report.png`
- `docs/fresh-install-qa.json`
- `malguard_core/scripts/flow.py`
- `tests/browser/browser_delivery_qa.py`
- `tests/integration/test_release_user_paths.py`
- `tests/malformed/test_seeded_stress.py`
- `tests/security/test_delivery_review.py`
- `tests/unit/test_decoded_source_relationships.py`
- `tests/unit/test_dotnet_method_failures.py`
- `tests/unit/test_source_flow.py`

## Revised since the original delivery

- `docs/FILES.md`
- `README.md`
- `WORK_LOG.md`
- `docs/BUILD_VERIFICATION.md`
- `docs/VERIFICATION.md`
- `malguard_core/dotnet/__init__.py`
- `malguard_core/gta_context/__init__.py`
- `malguard_core/reporting/__init__.py`
- `malguard_core/rules/__init__.py`
- `malguard_core/scripts/__init__.py`

## Full inventory

- `.github/workflows/malguard.yml`
- `.gitignore`
- `ARCHITECTURE.md`
- `README.md`
- `WORK_LOG.md`
- `docs/ARCHIVE_SECURITY.md`
- `docs/BROWSER_QA.md`
- `docs/BUILD_VERIFICATION.md`
- `docs/DEPENDENCIES.md`
- `docs/FILES.md`
- `docs/FRESH_INSTALL_QA.md`
- `docs/INDEPENDENT_QA.md`
- `docs/SECURITY_DATA.md`
- `docs/STRESS_QA.json`
- `docs/STRESS_QA.md`
- `docs/VERIFICATION.md`
- `docs/browser-qa.json`
- `docs/browser-qa/json-evidence.png`
- `docs/browser-qa/persian-report.png`
- `docs/ci-action-metadata.json`
- `docs/dependency-audit-windows-only.json`
- `docs/dependency-audit.json`
- `docs/dependency-lock-metadata.json`
- `docs/dependency-metadata.json`
- `docs/fresh-install-qa.json`
- `docs/mutation-measurements.json`
- `docs/windows-wheel-verification.json`
- `malguard_cli/__init__.py`
- `malguard_cli/__main__.py`
- `malguard_cli/evaluation.py`
- `malguard_cli/main.py`
- `malguard_core/__init__.py`
- `malguard_core/adapters/__init__.py`
- `malguard_core/adapters/capa.py`
- `malguard_core/api/__init__.py`
- `malguard_core/api/scanner.py`
- `malguard_core/archives/__init__.py`
- `malguard_core/authenticode/__init__.py`
- `malguard_core/budget/__init__.py`
- `malguard_core/correlation/__init__.py`
- `malguard_core/coverage/__init__.py`
- `malguard_core/decoding/__init__.py`
- `malguard_core/dotnet/__init__.py`
- `malguard_core/gta_context/__init__.py`
- `malguard_core/intake/__init__.py`
- `malguard_core/integrity/__init__.py`
- `malguard_core/integrity/bundle.py`
- `malguard_core/integrity/state.py`
- `malguard_core/model/__init__.py`
- `malguard_core/native/__init__.py`
- `malguard_core/pe/__init__.py`
- `malguard_core/py.typed`
- `malguard_core/reporting/__init__.py`
- `malguard_core/reputation/__init__.py`
- `malguard_core/reputation/data/allowlist.json`
- `malguard_core/reputation/data/blocklist.json`
- `malguard_core/reputation/data/iocs.json`
- `malguard_core/reputation/data/manifest.json`
- `malguard_core/reputation/data/manifest.sig`
- `malguard_core/reputation/data/revoked_signers.json`
- `malguard_core/reputation/data/rules/gta_guard.yar`
- `malguard_core/reputation/trust.py`
- `malguard_core/rules/__init__.py`
- `malguard_core/scoring/__init__.py`
- `malguard_core/scripts/__init__.py`
- `malguard_core/scripts/flow.py`
- `malguard_core/settings.py`
- `malguard_core/similarity/__init__.py`
- `malguard_core/strings/__init__.py`
- `malguard_core/verdict/__init__.py`
- `malguard_core/workers/__init__.py`
- `malguard_core/workers/job.py`
- `malguard_core/workers/pool.py`
- `malguard_core/workers/protocol.py`
- `malguard_core/workers/server.py`
- `pyproject.toml`
- `requirements-lock.txt`
- `rules/gta_guard.yar`
- `tests/browser/browser_delivery_qa.py`
- `tests/builders/archive_fixtures.py`
- `tests/builders/behavior.py`
- `tests/builders/pe_dotnet.py`
- `tests/integration/installed_wheel_smoke.py`
- `tests/integration/test_cli_evaluation.py`
- `tests/integration/test_release_user_paths.py`
- `tests/malformed/test_hostile_inputs.py`
- `tests/malformed/test_seeded_stress.py`
- `tests/mutation/harness.py`
- `tests/mutation/test_behavior_mutations.py`
- `tests/mutation/test_harmless_mutations.py`
- `tests/regression/test_verdict_invariants.py`
- `tests/security/test_additional_invariants.py`
- `tests/security/test_delivery_review.py`
- `tests/security/test_signed_security_data.py`
- `tests/security/test_workers.py`
- `tests/unit/test_archives.py`
- `tests/unit/test_auth_similarity.py`
- `tests/unit/test_decoded_source_relationships.py`
- `tests/unit/test_dotnet_method_failures.py`
- `tests/unit/test_foundation.py`
- `tests/unit/test_native_scripts.py`
- `tests/unit/test_pe_dotnet.py`
- `tests/unit/test_recovery_carving.py`
- `tests/unit/test_source_flow.py`
- `tests/unit/test_yara_rules.py`

Final browser JSON/screenshots are external sidecars so that their delivery ZIP hash cannot refer to the archive containing them. The checked-in browser evidence is explicitly the initial baseline. Final live WORK_LOG.md may append the completed external verification after the immutable delivery is assembled.
