# Seeded static-analysis stress QA

The 2026-10-04 Linux repeat check passed **205 tests in 49.70 seconds**. The new
suite makes 779 root `scan_file` calls, based on its test structure, with recursive
children receiving the normal pipeline. Fixture scans repeat three times and
compare report objects, JSON, and text. No real malware, scanned-code execution,
imports of scanned artifacts, compilation, or loading of scanned PE files occurs.
The only child processes are the engine's trusted static-analysis workers.

The persisted `.venv` was checked before use: Python 3.12.14, pytest 9.1.1, Linux
x86_64 with glibc 2.41. Most cases use an unchanged `Scanner()` configuration,
including parser isolation and YARA. Only resource-limit and recycling cases
change settings; no parser or stage result is monkeypatched.

| Cases | Scope |
| ---: | --- |
| 144 | Seeded malformed PE, ECMA-335, and ZIP fields; 48 per format |
| 12 | Benign API, browser, reflection, HTTP, script, and resource look-alikes never produce `MALICIOUS` |
| 13 | Added native/managed opacity and independent structural damage retain harmful verdict and risk |
| 7 | A malformed later managed method retains an unchanged, independently valid first method's HARM |
| 10 | Encrypted, unsupported, name-mismatched, and CRC-invalid later ZIP members retain the first harmful child |
| 12 | Per-root budgets produce typed exhaustion, reset for the next root, and avoid timeout/worker/protocol errors |
| 3 | Default depth limits block deep descendants while retaining shallow harmful evidence |
| 1 | Later decompression exhaustion retains an already completed harmful child |
| 3 | Actual worker recycling by count, bytes, and the default 32-analysis policy preserves deterministic reports |

The malformed generator uses seed `0x4d475354` (1296520020). Its 144 parameter
cases contain 133 distinct inputs; deliberate repeated field variants also
exercise reuse after parser failure. The largest malformed input is 1536 bytes.
The sorted compact manifest of case names, byte counts, and SHA-256 hashes has
SHA-256 `87bea1876b03be1429ac7edd009e23b9865bfe36dd705b11ecd15718dbf8a3a9`.
The machine-readable record is [STRESS_QA.json](STRESS_QA.json).

This check exposed a managed-method retention bug. An intact first method
containing synthetic download and assembly-load calls originally returned
`MALICIOUS`, risk 50. Giving a separate later method an invalid call token or an
unmapped RVA changed the result to `INVALID`, risk 10, and discarded the first
method's HARM. The engine fix confines these failures to the affected method.
All seven real later-method mutations now pass; the invalid-token reproducer
returns `MALICIOUS`, risk 56, retains the original loader and remote-execution
families, and still reports S4 `PARTIAL` / `MALFORMED_INPUT`. No original harmful
method bytes are modified, and invalid-method partial calls are not admitted as
valid behavioral evidence.

The fix's focused method, PE/.NET, and recovery suites also passed 114 tests;
ruff and mypy passed. A runtime-neutral local type annotation and whitespace
cleanup followed the full stress run. The JSON record retains both the stress
run's source hashes and the current hashes.

Budget cases cover file bytes, read bytes, archive entries, decompressed bytes,
parser iterations, metadata rows, strings, string bytes, children, resource
entries, evidence, and YARA bytes. The tests require explicit
`ITERATION_BUDGET_EXHAUSTED` and verify a subsequent small root scan is `SAFE`.
For damaged mappings, raw HARM must retain verdict and risk; an import-derived
confidence upgrade is not required when the corresponding mapping is invalid.

Commands run from `/workspace/malguard`:

```bash
.venv/bin/python -m pytest tests/malformed/test_seeded_stress.py -q --durations=10 --junitxml=/tmp/malguard-stress-qa.xml
.venv/bin/python -m pytest tests/malformed/test_seeded_stress.py -q -k later_bad_managed_method --tb=short
.venv/bin/python -m pytest tests/malformed/test_seeded_stress.py -q -k shared_small_budgets --maxfail=3
.venv/bin/python -m ruff check tests/malformed/test_seeded_stress.py
```

Results: **205 passed**, **7 passed / 198 deselected**, **12 passed / 193
deselected**, and **All checks passed**, respectively. The seven-method check
passed in 2.59 seconds; the twelve-budget check passed in 3.88 seconds.

These results measure deterministic synthetic boundary handling and evidence
retention. They do not measure recall on a malware corpus, population false
positives, safety guarantees, or adversarial cases outside these fixtures.
This check ran on Linux and does not establish Windows Job Object, Windows
filesystem, or native Windows runtime behavior. It did not build deliverables.
