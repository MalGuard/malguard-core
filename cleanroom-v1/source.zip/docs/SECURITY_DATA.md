# Security-data provenance and trust

The shipped reputation bundle is `1.0.0-empty`, epoch 1, ruleset `1.0.0`. Its
blocklist, allowlist, IOC and signer-revocation files each contain an empty
`records` array. No malware hashes, malware-family identities, C2 infrastructure,
certificates or publishers are fabricated. Detection rules describe behavioral
combinations and reference published MITRE ATT&CK techniques; these references
do not assert attribution of any sample.

The bundle is stored inside `malguard_core/reputation/data/`. The trust anchor is
a locally generated build Ed25519 public key in `malguard_core/reputation/trust.py`,
with key ID `malguard-build-2026-10`. This key authenticates this build's data;
it is not a claim of an established external publisher identity. No signing
private key is included in the project. The built-in manifest is additionally
pinned by SHA256 in the engine, so the default scan does not rely on a writable
settings file or an unprotected local epoch file to establish its baseline.

`manifest.sig` authenticates the exact UTF-8 bytes of `manifest.json`. The manifest
contains bundle version, monotonic epoch, minimum engine version, ruleset version,
creation timestamp, key ID and SHA256 hashes of every payload. JSON parsing rejects
duplicate keys and nonfinite numbers. Bundle verification bounds file counts and
sizes, rejects unknown keys and unsafe payload paths, validates the signature,
checks all payload hashes and retains immutable byte snapshots. Workers receive
the authenticated snapshot rather than writable rule-file paths.

Exact allowlist records require SHA256, component, release version, official HTTPS
provenance, expected type and review fields. Optional size constraints are checked
when the artifact is analyzed. Filename alone grants no trust. Allowlist evidence
does not suppress harmful evidence or override the verdict ordering. Exact signed
blocklist evidence can identify a malformed sample before deep parsing.

External bundle updates require explicitly provisioned trust keys and
`ProtectedEpochState`. Equal epochs with different manifest hashes and lower
epochs are rejected. On Windows the state directory is under the system
ProgramData location with a protected administrators/system ACL; creating or
updating it requires the privileged updater context. Ordinary scanning uses the
pinned built-in bundle without creating privileged state. On POSIX the explicit
state store uses owner-only permissions, file locking and atomic replacements;
it does not protect against compromise of that same user account.

`RulesManager` verifies a candidate bundle and compiles its rules before accepting
the epoch and activating it. Invalid signatures, payload hashes, metadata or rule
syntax leave the currently compiled rules active. These source-level protections
are covered by synthetic security/rule tests; native Windows ACL behavior requires
Windows runtime validation.

Rotating the default build trust anchor requires distributing a reviewed engine
release with a new public key and pinned manifest. The locally generated original
private key is not a release-signing service and is not available for later
production updates. Operators deploying an update service must provision their
own offline signing key and distribute its public trust anchor through an
authenticated engine release.

Unsigned root-level rule copies and normal settings cannot alter the active
authenticated bundle. Signature validity establishes data integrity and the
provisioned signing identity. It does not prove rule quality, sample safety or
malicious-corpus recall.
