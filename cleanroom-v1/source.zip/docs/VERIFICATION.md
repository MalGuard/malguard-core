# Final verification record — 2026-10-04

The complete post-review source suite was executed with
`.venv/bin/python -m pytest -q --tb=short`: **907 passed, 1 skipped in 81.10s**,
exit 0. The only skip remains the native Windows Job Object runtime test.
This supersedes the earlier 518-test delivery baseline recorded below.

Final additional executed checks:

| Exact command | Observed result |
| --- | --- |
| `.venv/bin/python -m ruff check malguard_core malguard_cli tests` | All checks passed; exit 0. |
| `.venv/bin/python -m mypy --platform linux malguard_core malguard_cli` | No issues in 40 source files; exit 0. |
| `.venv/bin/python -m mypy --platform win32 malguard_core malguard_cli` | No issues in 40 source files; exit 0. |
| `.venv/bin/python -m pip check` | No broken requirements; exit 0. |
| `.venv/bin/python -m compileall -q malguard_core malguard_cli tests/integration/installed_wheel_smoke.py` | Exit 0. |
| `.venv/bin/python -m tests.mutation.harness --output docs/mutation-measurements.json` | All 10 synthetic variants retained MALICIOUS; exit 0. |
| `.venv/bin/python -m build --wheel --no-isolation` | Built the corrected wheel; exit 0. |
| `/tmp/malguard-fresh-qa/bin/python -m pytest -q /workspace/malguard/tests/integration/test_release_user_paths.py` | 29 passed in 8.39s against the newly installed wheel. |
| The same fresh-installed suite through the documented seccomp network-denial launcher | 29 passed in 8.30s; IPv4/IPv6 socket denial verified before execution. |

Normal and network-denied installed-wheel smoke checks both exited 0. All
48 wheel package files match current source byte-for-byte. The corrected wheel
SHA256 is `cf66ddf2589742ab1af92b7c2cb79fcb3fd704168ffc73fc72a5644f094e49cf`.
Fresh-install commands and the exact offline launcher are documented in
[FRESH_INSTALL_QA.md](FRESH_INSTALL_QA.md).

The review fixed confirmed defects in method-level .NET evidence retention,
inert-source classification, executable interpolation, variable scope/lifetime,
credential transfer lineage, GTA target proof across decoded source, multiple
encoded interpreter arguments, constant Lua interpreter inputs, and quoted
secret redaction. The final focused source/rules/mutation run passed 239 tests
in 2.76s before the complete suite. Detailed harmless reproductions are in
[INDEPENDENT_QA.md](INDEPENDENT_QA.md); the seeded malformed-input and resource
checks are in [STRESS_QA.md](STRESS_QA.md).

Real Chromium report rendering and four native downloads passed on the original
delivery. The final immutable delivery is checked again after packaging; that
run writes `/workspace/malguard-final-browser-qa.json` and
`/workspace/malguard-final-browser-screenshots/` as external evidence. This avoids
including an archive's own final hash inside that same archive. See
[BROWSER_QA.md](BROWSER_QA.md) for the exact command and checks. The final sidecar
is the authority for that last browser run; earlier browser JSON is explicitly
baseline evidence.

Windows 10/11, PyInstaller, native Windows trust/ACL/Job behavior, and real-corpus
accuracy remain unverified. No production recall, false-positive or SAFE-rate
target is claimed. No real malware or scanned code was executed.

## Earlier delivery verification — 2026-10-03

Verification environment: Linux, CPython 3.12.14, with the live-verified and hash-locked dependency graph. All detection fixtures were generated harmless synthetic structures. No scanned source, PE, assembly or archive member was executed. There was no pre-existing repository, engine or test suite in the workspace; all delivered project files are newly created clean-room work.

## VERIFIED

The final complete synthetic suite command was actually executed after review fixes:

```bash
.venv/bin/python -m pytest -q
```

Result: **518 passed, 1 skipped in 15.51s**, exit 0. The single skipped test is `tests/security/test_workers.py::test_windows_job_admission_and_kill_on_close`, which requires Windows. Unit, integration, regression, malformed-input, security and mutation directories are included in this run. The output names the Windows runtime skip at line 366 of that file.

Other final checks actually executed:

| Exact command | Actual result |
| --- | --- |
| `.venv/bin/python -m ruff check malguard_core malguard_cli tests` | All checks passed; exit 0. |
| `.venv/bin/python -m mypy --platform linux malguard_core malguard_cli` | Success: no issues found in 39 source files; exit 0. |
| `.venv/bin/python -m mypy --platform win32 malguard_core malguard_cli` | Success: no issues found in 39 source files; exit 0. |
| `.venv/bin/python -m pip check` | No broken requirements found; exit 0. |
| `.venv/bin/python -m tests.mutation.harness --output docs/mutation-measurements.json` | 10 synthetic variants retained MALICIOUS; no breaks; exit 0. |
| `.venv/bin/python -m pytest tests/security/test_signed_security_data.py tests/security/test_additional_invariants.py -q` | 71 passed in 3.66s; exit 0 after final signed-loader hardening. |

The mutation record is preserved in [mutation-measurements.json](mutation-measurements.json). ASCII, UTF-16, splitting, base64, hex, XOR, reversal, API A/W variants and nesting retained risk 64; corrupted PE header retained MALICIOUS with risk 79 and reduced coverage 92.73. These numbers characterize this synthetic fixture only.

[Build verification](BUILD_VERIFICATION.md) records the actual build, wheel installation, import/compile and outside-checkout CLI smoke commands. Wheel and source distribution were built with `.venv/bin/python -m build --no-isolation`. The isolated installed-package smoke verifies public API, typing marker, signed payloads, deterministic JSON, Persian text, nested archives, evaluation bookkeeping and the optional hash-bound capa JSON adapter. It executes the trusted scanner and CLI, never a scanned fixture. The dependency metadata, Windows-wheel hashes and live advisory audit snapshots are linked from [DEPENDENCIES.md](DEPENDENCIES.md); no known advisories in that snapshot is not a proof of absence of vulnerabilities.

Important exercised decisions and regressions include:

- Signed exact blocklist precedes deep parsing and can override malformed structure; unsigned data, invalid signatures, changed payloads and rollback are rejected.
- Signed-loader replacement with a FIFO cannot block after a regular-file precheck; the opened descriptor must still identify a bounded regular file.
- Raw, decoded and structured evidence survives parser/resource failure; an unrelated decoded candidate cannot lower existing raw evidence reliability.
- Malformed PE resources and overlays still expose bounded child artifacts. MZ, NT signature, NT pointer and absurd section-count mutations preserve the tested child hashes and harmful verdicts.
- Worker framing, identities, types, enum/range checks, artifact offsets, collection schemas, child bytes and reported budget use are validated. Missing work fields cannot reset a child's budget.
- Family saturation, independent harmful families, artifact-local correlation, mandatory verdict precedence, opacity-only behavior and incomplete clean gating are tested.
- GTA proof rejects unrelated handles, mixed targets, case abuse, variable/array mutations and equal-spelled variables in unrelated scopes. It cannot mitigate credential theft or security tampering.
- Authenticated specific URL/path IOCs and revoked signer records produce SUSPICIOUS even with an allowlist hit; they cannot create a fabricated HARM family or a malicious hard override. Hostname-only context and similarity remain advisory.
- Archive traversal, duplicate/colliding names, overlaps, mismatches, ZIP64 ambiguity, expansion/depth limits and unreadable children retain evidence and block complete clean coverage.
- Legitimate-style ASI hooks, GTA-only trainer source, SHVDN/HttpClient update checks, HTTP-only Lua, Process.Start, VirtualAlloc and isolated browser strings do not become MALICIOUS from those weak signals alone.

## REVIEWED

Separate implementation and QA passes reviewed the coordinator, intake, shared budgets, typed evidence, signed bundles/epoch state, worker IPC, Windows Job Object configuration, archive boundaries, PE/.NET recovery, source target linkage, scoring/verdict gates and report redaction. Independent QA added 54 regressions in `tests/security/test_additional_invariants.py`; that suite passed. Windows resource-control and protected ACL code was reviewed and type-checked, but local Linux runs cannot validate Windows API behavior.

The source/delivery inventory is [FILES.md](FILES.md). The exact risk, confidence, coverage and decision formulas, public API and limits are documented in [README.md](../README.md). [ARCHIVE_SECURITY.md](ARCHIVE_SECURITY.md) and [SECURITY_DATA.md](SECURITY_DATA.md) describe support and trust boundaries. No GUI was created.

## UNTESTED

- Representative real benign/protected GTA mod and malicious corpora; none of the requested recall, false-positive or SAFE-rate acceptance targets has been established.
- Every possible combined corruption, parser exploit, obfuscator, source alias or dynamic execution flow; passing these regressions does not establish a universal mutation-invariance guarantee.
- Windows 10/11 runtime, Windows trust-chain/time behavior and live certificate revocation.
- PyInstaller packaging and downstream installation in user Windows environments.
- GitHub Actions jobs: the prepared workflow has not been run from this environment.

## BLOCKED

The selected runtime is Linux, so native Windows Job Object/ACL execution and Windows 10/11 release qualification require a Windows runner or lab. No labeled user corpus was supplied, so empirical release acceptance cannot be measured here. The delivered evaluator performs static-only measurements when the user supplies a lab dataset; it does not include real malware.

Implementation boundaries remain explicit: compressed RAR/RAR5, Lua bytecode semantics, LNK/MSI structural analysis, arbitrary encrypted payloads, full native control-flow/deobfuscation, and current OS certificate trust are not claimed complete. Unsupported or recognized opaque required analyses restrict SAFE. Resource-limited workers are not a full OS security sandbox. The scanner finds evidence within completed bounded static analyses; it never guarantees safety or zero bugs.
