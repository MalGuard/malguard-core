# Build and runtime verification

The implementation targets CPython 3.12 and Windows 10/11. Local verification
uses Linux with CPython 3.12.14. A Windows-platform mypy pass checks platform
types; it does not execute Windows Job Objects, Windows ACLs or the Windows
loader. The scanner never invokes the Windows loader for a scanned artifact.

## Executed local checks

The following commands were actually executed from the project directory on
2026-10-03:

```bash
.venv/bin/mypy --platform win32 malguard_core malguard_cli
.venv/bin/mypy --platform linux malguard_core malguard_cli
.venv/bin/python -m compileall -q malguard_core malguard_cli tests/integration/installed_wheel_smoke.py
.venv/bin/python -c 'import malguard_core, malguard_cli; from malguard_core import scan_file, Report, Verdict; assert callable(scan_file); print("Engine", malguard_core.ENGINE_VERSION, "schema", malguard_core.SCHEMA_VERSION, "public API imported")'
.venv/bin/python -m malguard_cli --help
.venv/bin/python -m pytest -q tests/unit/test_pe_dotnet.py tests/unit/test_auth_similarity.py tests/security/test_signed_security_data.py tests/security/test_workers.py
```

Both mypy commands reported `Success: no issues found in 39 source files` and
exited zero. Compile/import/CLI help checks exited zero. The scoped synthetic
regression command reported `190 passed, 1 skipped in 2.80s`. The skipped check
requires a real Windows runtime for Job Object admission and kill-on-close.
These checks exercise synthetic static structures and trusted scanner workers;
they never execute a scanned source file, PE, assembly or archive member.

The project has no blanket mypy missing-import suppression. Overrides are limited
to `asn1crypto`, `pefile` and `rarfile`, which ship neither library stubs nor a
PEP 561 marker. Their outputs cross bounded adapters and validated schemas.
`malguard_core/py.typed` supplies the library's public annotations to consumers.

## Reproducible packaging checks

After installing the hash-locked dependencies, build using the pinned local
backend and install the resulting wheel without dependency resolution:

The commands below use the local Linux virtual-environment path. On Windows,
substitute `.venv\Scripts\python.exe` for `.venv/bin/python`.

```bash
.venv/bin/python -m build --no-isolation
.venv/bin/python -c 'import glob, subprocess, sys; wheels = glob.glob("dist/*.whl"); assert len(wheels) == 1, wheels; subprocess.run([sys.executable, "-m", "pip", "install", "--no-deps", "--force-reinstall", wheels[0]], check=True)'
.venv/bin/python -I tests/integration/installed_wheel_smoke.py
```

These packaging commands were subsequently executed successfully on the local
Linux host. The build command produced `malguard-1.0.0.tar.gz` and
`malguard-1.0.0-py3-none-any.whl`; the wheel was installed with `--no-deps`.
The isolated smoke command exited zero and verified the installed signed data,
public API, deterministic repeated JSON, Persian CLI, nested archive processing,
evaluation CLI and the context-only capa JSON adapter. This proves the worker entry point and security resources
function from the installed wheel without importing the source package.

The isolated smoke command rejects imports from the source package, verifies
installed distribution metadata, the typing marker and every signed security
resource, then checks the public API and JSON/Persian CLI output on harmless Lua.
Repeated reports must be identical. It also creates a harmless nested ZIP and
requires the installed worker pipeline to analyze all three artifacts. The
installed evaluation command scans a single harmless benign fixture with an
empty malicious directory; this checks CLI bookkeeping and does not measure
malicious-corpus detection or evaluate the production acceptance targets.
The smoke check also imports the installed optional capa JSON adapter, binds a
harmless JSON document to the actual fixture SHA256 and requires zero-weight
CONTEXT evidence. It never runs capa or a scanned artifact.

## Continuous integration and remaining platform verification

`.github/workflows/malguard.yml` runs the complete synthetic suite, lint, both
platform type checks, package builds and the installed-wheel smoke command on
CPython 3.12 using Ubuntu 24.04 and Windows Server 2025. Actions are pinned to
commits verified against their live release metadata; provenance is recorded in
`ci-action-metadata.json`. The workflow has not been executed from this local
environment. Windows Server CI is useful platform verification, but independent
Windows 10/11 runtime tests remain required before a Windows release.
The source distribution includes this workflow and its verification metadata.

No PyInstaller executable was produced. No real malware corpus was included or
evaluated. The specified production recall and false-positive rates remain
acceptance targets until a representative user-provided corpus is analyzed in
an isolated lab. Passing synthetic tests or building a wheel does not establish
those corpus results.

## Post-review build verification — 2026-10-04

The corrected source passed the complete suite: **907 passed, 1 Windows-only
skip in 81.10s**. Final Linux and win32 mypy passes each checked **40 source
files**, and Ruff, compileall, dependency consistency and the standalone
10-variant mutation harness passed.

`.venv/bin/python -m build --wheel --no-isolation` built the corrected wheel.
It was installed with `--no-index --no-deps --force-reinstall` into the existing
project environment and the separate fresh hash-locked venv. The wheel has
48 package files, all byte-identical to current source/data, with SHA256
`cf66ddf2589742ab1af92b7c2cb79fcb3fd704168ffc73fc72a5644f094e49cf`.
The fresh-installed smoke and 29 user-path cases passed both normally and with
inherited seccomp network denial; exact commands and outputs are recorded in
[FRESH_INSTALL_QA.md](FRESH_INSTALL_QA.md). Source distribution and final delivery
are assembled after these QA documents, with final checksums kept outside the
archives to avoid self-referential hashes.

The source distribution build command `.venv/bin/python -m build --sdist --no-isolation` also executed successfully, exit 0. The final delivery checksum file is verified separately after assembly.
