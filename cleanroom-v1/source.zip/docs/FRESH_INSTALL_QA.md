# Fresh installed-wheel QA — 2026-10-04

The delivered MalGuard 1.0.0 wheel passed a new installation on Linux x86_64
with CPython 3.12.14. The venv at `/tmp/malguard-fresh-qa` was created without
`--system-site-packages`; its configuration explicitly records
`include-system-site-packages = false`. Installation used the complete
hash-locked requirements and then the delivered wheel with `--no-deps`.
All 65 Linux-applicable pinned distributions match their required versions;
the Windows-only `colorama` requirement was correctly excluded.

The installed module paths and isolated interpreter search path were verified
to resolve inside this fresh venv. Tests launched the trusted installed scanner
outside the checkout. No scanned source, PE, assembly, archive member or real
malware was executed. Fixtures contain harmless synthetic Lua and ZIP bytes.

## Results actually obtained

| Check | Result |
| --- | --- |
| Delivery ZIP, wheel and sdist checksums | All three matched the original checksum file before and after QA. |
| Fresh hash-locked dependency installation | Exit 0. |
| Delivered wheel installation | Exit 0; installed version and engine version both 1.0.0. |
| `pip check` | Exit 0; no broken requirements. |
| Isolated installed-wheel smoke | Exit 0; signed resources, API, typing marker, deterministic JSON, Persian text, nested ZIPs, evaluator and capa adapter verified. |
| Installed console entry points | Both help commands and actual scan/report commands passed. |
| New installed user-path regressions | **29 passed in 3.68s**, exit 0. |
| Same smoke with network syscalls denied and unreachable proxies | Exit 0. |
| Same 29 path regressions with network syscalls denied and unreachable proxies | **29 passed in 4.62s**, exit 0. |
| Ruff on the added regression file | All checks passed; exit 0. |

The new regressions cover Persian and space-containing input/output/dataset
paths, repeatable JSON, UTF-8 report files, input hash preservation, real
installed console execution, CLI usage errors, existing report/input/link
overwrite refusal, invalid output parents, missing/directory/symlink inputs,
evaluation label-directory requirements, empty denominators, skipped links and
static-only confusion-matrix bookkeeping. A harmless file placed in the
`malicious/` directory checks label bookkeeping only; it is not a malware test.

Missing or nonregular scan inputs return exit **3** with an `INCONCLUSIVE`
JSON report, `S0` blocked and `IO_ERROR`. Existing output targets or unusable
output paths return exit **4**, preserve existing content and emit no Python
traceback. Incorrect argparse usage returns its standard exit **2**.

## Executed commands

The following commands were executed with the working directory `/tmp`, except
the Ruff command, whose working directory was `/workspace/malguard`.
Dependency installation alone was given additional network access; runtime
verification used the default restricted environment.

```bash
python3.12 -m venv /tmp/malguard-fresh-qa
/tmp/malguard-fresh-qa/bin/python -m pip install --require-hashes -r /workspace/malguard/requirements-lock.txt > /tmp/malguard-fresh-install.log 2>&1
/tmp/malguard-fresh-qa/bin/python -m pip install --no-deps /workspace/malguard/dist/malguard-1.0.0-py3-none-any.whl > /tmp/malguard-fresh-wheel-install.log 2>&1
/tmp/malguard-fresh-qa/bin/python -I /workspace/malguard/tests/integration/installed_wheel_smoke.py > /tmp/malguard-fresh-smoke.log 2>&1
/tmp/malguard-fresh-qa/bin/malguard --help
/tmp/malguard-fresh-qa/bin/malguard-evaluate --help
/tmp/malguard-fresh-qa/bin/python -m pytest -q /workspace/malguard/tests/integration/test_release_user_paths.py > /tmp/malguard-fresh-path-tests.log 2>&1
/tmp/malguard-fresh-qa/bin/python -m pip check > /tmp/malguard-fresh-pip-check.log 2>&1
/tmp/malguard-fresh-qa/bin/python -m ruff check tests/integration/test_release_user_paths.py
sha256sum -c /workspace/malguard-delivery.sha256
```

The Linux-only offline launcher installs a libseccomp filter before executing
the trusted scanner. The filter denies `socket`, `socketpair`, `connect`,
`sendto`, `sendmsg` and `sendmmsg` with `EPERM` and is inherited by worker
processes. The launcher confirms that both IPv4 and IPv6 socket creation fail
before starting the scanner. Its exact source and SHA256 are preserved in
[fresh-install-qa.json](fresh-install-qa.json), so the `/tmp` helper can be
recreated independently.

```bash
HTTP_PROXY=http://127.0.0.1:1 HTTPS_PROXY=http://127.0.0.1:1 ALL_PROXY=http://127.0.0.1:1 http_proxy=http://127.0.0.1:1 https_proxy=http://127.0.0.1:1 all_proxy=http://127.0.0.1:1 NO_PROXY= no_proxy= /tmp/malguard-fresh-qa/bin/python -I /tmp/malguard-fresh-network-deny.py /tmp/malguard-fresh-qa/bin/python -I /workspace/malguard/tests/integration/installed_wheel_smoke.py > /tmp/malguard-fresh-offline-smoke.log 2>&1
HTTP_PROXY=http://127.0.0.1:1 HTTPS_PROXY=http://127.0.0.1:1 ALL_PROXY=http://127.0.0.1:1 http_proxy=http://127.0.0.1:1 https_proxy=http://127.0.0.1:1 all_proxy=http://127.0.0.1:1 NO_PROXY= no_proxy= /tmp/malguard-fresh-qa/bin/python -I /tmp/malguard-fresh-network-deny.py /tmp/malguard-fresh-qa/bin/python -m pytest -q /workspace/malguard/tests/integration/test_release_user_paths.py > /tmp/malguard-fresh-offline-path-tests.log 2>&1
```

An attempted `strace -f -e trace=network` verification could not start its
traced process because this environment rejects `PTRACE_TRACEME`. No trace
results are claimed; the successful seccomp checks provide enforced network
denial instead. Early exploratory QA scripts were corrected to use the actual
report schema and evaluate dependency platform markers; those harness errors
were not scanner failures.

## Artifact provenance and limits

| Original artifact | SHA256 |
| --- | --- |
| `malguard-delivery.zip` | `40f732ad8b712d29d04793a96961efaf544b6ab836150bb7601a5ac111095603` |
| `malguard-1.0.0-py3-none-any.whl` | `0029879087764e21049289a039c8fb53ffea7e07011641a31d7205cf80cc1249` |
| `malguard-1.0.0.tar.gz` | `647e05e6d6fdcb7a8382da9c5adfacf845ccc3adfb0bdd550f07624742c7b647` |

At the initial comparison, all 90 ZIP file entries matched the checkout except
`WORK_LOG.md`, which was being updated during QA. Engine, packaged data,
lockfile, wheel and source distribution matched. This pass did not rebuild or
modify delivery artifacts; the test and QA documentation files were added to
the checkout after the original delivery snapshot.

This verifies installation and the exercised Linux workflows. Windows 10/11
runtime, Windows Job Objects and ACLs, PyInstaller packaging, browser/GUI
behavior and representative benign/malicious corpus accuracy remain unverified
by this pass. MalGuard exposes a library and CLI, not a browser interface.
The earlier **518 passed, 1 Windows skip** synthetic baseline and these
additional user-path tests do not establish recall, false-positive rates or
production acceptance targets.

## Corrected final wheel recheck — 2026-10-04

After the engine review, the fresh venv was updated with:

```bash
/tmp/malguard-fresh-qa/bin/python -m pip install --no-index --no-deps --force-reinstall /workspace/malguard/dist/malguard-1.0.0-py3-none-any.whl
/tmp/malguard-fresh-qa/bin/python -I /workspace/malguard/tests/integration/installed_wheel_smoke.py
/tmp/malguard-fresh-qa/bin/python -m pytest -q /workspace/malguard/tests/integration/test_release_user_paths.py
/tmp/malguard-fresh-qa/bin/python -m pip check
HTTP_PROXY=http://127.0.0.1:1 HTTPS_PROXY=http://127.0.0.1:1 ALL_PROXY=http://127.0.0.1:1 NO_PROXY= /tmp/malguard-fresh-qa/bin/python -I /tmp/malguard-fresh-network-deny.py /tmp/malguard-fresh-qa/bin/python -I /workspace/malguard/tests/integration/installed_wheel_smoke.py
HTTP_PROXY=http://127.0.0.1:1 HTTPS_PROXY=http://127.0.0.1:1 ALL_PROXY=http://127.0.0.1:1 NO_PROXY= /tmp/malguard-fresh-qa/bin/python -I /tmp/malguard-fresh-network-deny.py /tmp/malguard-fresh-qa/bin/python -m pytest -q /workspace/malguard/tests/integration/test_release_user_paths.py
```

All commands exited 0. The ordinary user-path suite passed **29 tests in 8.39s**;
the seccomp-enforced offline repeat passed **29 in 8.30s**. Both smoke runs
verified signed resources, isolated installed imports, public API, deterministic
JSON, Persian CLI, nested archives, evaluation and the capa JSON adapter. Both
IPv4 and IPv6 socket creation failed with EPERM before each offline run.
Dependency consistency passed. These new results supersede the original-wheel
runtime checks above; the original hashes remain historical evidence only.

The corrected wheel is 144229 bytes, SHA256
`cf66ddf2589742ab1af92b7c2cb79fcb3fd704168ffc73fc72a5644f094e49cf`.
All 48 packaged source/data files were compared byte-for-byte to the current
checkout. The original delivery is preserved separately as
`/workspace/malguard-baseline-2026-10-03.zip`. The final ZIP and sdist hashes are
recorded externally in `/workspace/malguard-delivery.sha256` after packaging.
