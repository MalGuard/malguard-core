# Desktop inspection 1.3.0 (engine 1.2.0)

This source candidate has not been released as a Windows installer. The public
1.2.0 installer and download site remain unchanged.

## File contents and validation scope

Desktop metadata comes from the same bounded, immutable S0 byte snapshot as the
report hashes. There is no second read after scanning. Standalone plain text,
media and document content cannot receive SAFE as a validated GTA mod. Plain
text inside a supported archive remains analysable context; a README does not
by itself block a complete supported package. Malicious or suspicious evidence
still takes precedence over unsupported or damaged formats.

Common WAVE, MPEG, ID3, FLAC, Ogg, ISO media, PNG, JPEG, GIF, WebP and PDF headers
are recognized independently of filename extensions. Header recognition does
not fully validate a media/document container. A file named `example.asi` whose
bytes are plain text gets a specific content/extension explanation, file size,
SHA-256 and a bounded redacted text preview. UTF-8/UTF-16 prefix boundaries are
handled without mistaking a split character for binary content. Previews use
at most 8192 captured bytes and display at most 320 characters before redaction.
Redaction happens before display truncation, including short assigned secrets.
They are samples, not the complete file contents. Scripts and configuration
analysis retain the existing conservative static pipeline.

The public immutable Report schema and verdict precedence are retained. Root
formats outside direct validation mark S0 partial with UNSUPPORTED_FORMAT.
`Scanner.file_inspection` is supplementary desktop metadata, not a new public
security verdict. INVALID/INCONCLUSIVE results show an unknown gauge, with no
needle at zero. Other results display the engine's actual 0–100 evidence score.
The score and confidence are engineering indicators, not measured probabilities.

## Actual progress and report card

The desktop CLI emits only fixed stage identifiers on stderr; stdout remains
one JSON result. Stages are announced immediately before the corresponding
operation. Required isolated parsers, shared ledgers and source-only analysis
are unchanged. Child analysis is represented by the active archive stage,
without a simulated percentage or timer that invents progress.

The native bridge reads bounded telemetry, accepts a fixed allowlist of stages
and sends events only to the main window. A per-scan identifier makes the UI
ignore delayed events from earlier scans. File selection and scanning serialize
through the native busy guard. New selections clear previous native reports.

The scan rectangle morphs into a circle with a rotating light, then expands
into the result. A flip reveals a report card with type, size, explanation,
hash, preview, evidence, coverage and signed-data details. English remains the
default, Persian uses RTL, hidden card faces are inert, and reduced motion is
supported. All sample text is inserted with textContent or drawn on Canvas.

PNG export is generated locally (1200px wide, at most 2600px high); it includes
summary evidence and the static-analysis limitation. The JSON export carries
all evidence. Native export accepts bounded PNG bytes and writes a newly chosen
file with create_new; it cannot accept a sample path or overwrite an input.

## Signed threat updates

The online cache is authenticated using the pinned Ed25519 key; payload hashes,
record schemas and rule compilation are checked. Status now exposes the signed
creation time and key identifier, as well as available/fresh/count/version.
An updater launch is a request, not proof of successful download. A status check
authenticates the current cache, which may still be the previous good version.

Scheduled updates use the Windows local clock at 03:00. The IExpress installer
sets StartWhenAvailable, so a missed task can run later subject to Windows task
conditions; it does not wake a powered-off machine. The legacy NSIS daily task
does not configure that catch-up setting. Manual updates use UAC because only
administrators/SYSTEM can write the protected update cache. The trusted updater
receives no selected sample path. Updates supply hashes/rules, not an app upgrade.

The feed verified on 2026-10-07 contained 1342 unique SHA-256 records, signed at
2026-10-07T10:37:16.216051+00:00, version mb-37608574476001. This is the published
feed's count, not confirmation of any user's local cache or a complete malware
catalogue. No malware sample was downloaded. An exact-hash reputation lookup
was verified to retain its hard malicious override.

## Reproduce validation

Install the locked Python graph and package before testing; installed subprocess
checks deliberately do not import from an untrusted working directory:

```sh
python -m pip install --require-hashes -r requirements-lock.txt
python -m pip install --no-deps --no-build-isolation .
python -m pytest -q
python -m ruff check .
python -m mypy malguard_core malguard_cli
cargo check --locked --manifest-path desktop/src-tauri/Cargo.toml
```

`cargo check` needs real platform development libraries and the resource directory
normally supplied by the frozen-engine build. A check-only resource directory
contains no executable engine and is excluded from source packaging. This check
is not an installer or native Windows runtime test.

Browser QA uses an actual installed Python scanner and Chromium, substituting
only the native file picker, IPC transport, protected cache location and save
dialog. Supply an existing hash-locked Playwright installation, a verified feed
and an output directory outside the packaged source:

```sh
PLAYWRIGHT_MODULE=/absolute/path/to/playwright/index.mjs \
MALGUARD_PYTHON=/absolute/path/to/venv/bin/python \
MALGUARD_QA_FEED=/absolute/path/to/latest.json \
MALGUARD_QA_OUTPUT=/tmp/malguard-desktop-qa \
node tests/desktop/browser.mjs
```

The test prevents external browser requests and uses harmless generated content.
The live feed download is a separate read-only verification. Native Windows
installation, UAC, Task Scheduler, WebView2 event permissions and PNG save dialogs
must still pass Windows CI/manual testing before publication. Detection accuracy
against a representative real malware/benign corpus has not been measured.

The previously reported slow Windows download/installation is still an open
separate issue; this change does not claim to fix it.
