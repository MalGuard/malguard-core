# Windows delivery verification — 2026-10-05

This supplements the preserved October 4 source delivery. It does not qualify
native Windows 10/11, a real malware corpus, or the requested release accuracy
targets. All scan fixtures were generated harmless bytes; none was executed.

## Verified artifacts

| Artifact | Bytes | SHA256 |
| --- | ---: | --- |
| MalGuard-Setup-x64.exe | 22,002,925 | `247f6200cc4e87ba0e6383cdc3ba37814f1aaf934254260bc0888fe98c146054` |
| MalGuard-Windows-x64.zip | 27,785,991 | `c87673801d4e8430c3dc038d987d4c5c52e336a00eb4bc93460693ec99212432` |
| MalGuard.exe, inside the complete portable folder | 7,113,726 | `ca3f7932d9de426b8ae2cf24fd45937191580a3db75205af7f849b180b6aa1a9` |

Both EXEs are actual PE32+ AMD64 executables with asInvoker manifests. They are
unsigned: no Windows code-signing certificate was available. This does not change
offline Ed25519 validation of the embedded signed rules/security bundle. The
portable ZIP passed CRC checks; all 222 entries matched the staged payload bytes.

## Executed checks

The Linux project uses CPython 3.12.14. The actual Windows build uses verified
CPython 3.12.15 Windows MSVC x64, PyInstaller 6.22.3, hooks 2026.8 and NSIS 3.11-1
AMD64 Unicode stubs. All Windows build and scan containers had `--network none`.
Python assets/wheels were downloaded before the offline build and SHA256 verified.

```text
.venv/bin/python -m pytest -q --tb=short
.venv/bin/python -m ruff check .
.venv/bin/python -m mypy --platform linux malguard_core malguard_cli
.venv/bin/python -m mypy --platform win32 malguard_core malguard_cli
.venv/bin/python -m compileall -q malguard_core malguard_cli packaging/windows tests
.venv/bin/python -m pip check
.venv/bin/python -m build --no-isolation --outdir /workspace/malguard-windows-build/python-dist
.venv/bin/python -I tests/integration/installed_wheel_smoke.py
.venv/bin/python -m tests.mutation.harness --output /workspace/malguard-windows-build/mutation-final.json
```

The full Linux suite includes unit, integration, regression, malformed-input,
security and mutation directories. The executed full run passed **917 tests**,
with **one skipped native-Windows Job test**, in **79.11 seconds** on the final
repeated run. Test-fixture portability fixes use `sysconfig` for scripts-directory
lookup and check whether a symbolic-link fixture was actually created. Ruff, both mypy
platform configurations (41 source files), compileall, dependency consistency,
the build and installed-wheel smoke passed. All 49 package files in the wheel
matched current source bytes. The Linux installed user-path suite passed 29 cases;
the ten harmless mutation variants all retained MALICIOUS. These are synthetic
results, not malware detection or false-positive rates.

The final frozen Windows binary was executed under Wine 10.0 using:

```text
/usr/lib/wine/wine64 /work/python/python.exe -I Z:\src\packaging\windows\smoke_exe.py --exe Z:\work\dist\MalGuard\MalGuard.exe --fixtures Z:\work\fixtures --output Z:\work\windows-exe-final-qa.json
```

**31 checks passed.** Nineteen scan fixtures matched Linux verdict, risk,
coverage, artifact counts and input hashes. They cover harmless GTA ASI/trainer,
SHVDN, HttpClient-only, VirtualAlloc-only, browser-path-only, Lua HTTP-only,
remote loaders, encoded PowerShell, credential/exfiltration combinations,
damaged PE headers, embedded payloads, nested ZIP, 7z, stored RAR and unreadable
encrypted children. Further checks verified UTF-8 help/text/Persian paths,
deterministic JSON, exclusive new reports, refusing input/report overwrite,
invalid switches, a hostile private-worker frame, interactive saving and
two-sample synthetic evaluator bookkeeping. A fake module in the working directory
did not shadow the packaged engine. The binary's self-test reported frozen=true,
win32, complete signed-rule analysis and complete three-artifact nested ZIP.

The final installer was executed in a disposable, initialized Wine profile:

```text
/usr/lib/wine/wine64 /work/python/python.exe -I Z:\src\packaging\windows\smoke_install.py --release Z:\work\final-release --output Z:\work\windows-installer-final-qa.json
```

**Five checks passed.** Installation in a Persian path with spaces matched all
221 manifest-listed files. Desktop and Start-menu shortcuts existed. The installed
EXE passed its self-test and interactive scan, wrote its report, then uninstalled
all owned files and shortcuts while preserving user files, sample bytes and JSON
reports. Initial shortcut failures were traced to an incomplete Wine shell COM
registry; trusted wineboot update and shell32 registration repaired the test
profile. No scanner safety stage was disabled. Installer shortcut errors are
optional warnings; payload/registration errors return nonzero status.

The existing Job admission/pool-closure test also passed under Wine. This exercises
the API calls and pool cleanup, not proof of native memory/CPU/breakaway enforcement.
Additional installed Windows-Python CLI tests passed **28 cases**, with **two
skipped unusable Wine symbolic-link fixtures**, in **13.02 seconds**. The executed
command was:

```text
/usr/lib/wine/wine64 /work/python/python.exe -I -m pytest tests/security/test_workers.py::test_windows_job_admission_and_kill_on_close tests/integration/test_release_user_paths.py -q --tb=short -p no:cacheprovider
```

No native Windows result is inferred from these compatibility-runtime checks.

Real Chromium **151.0.7922.173** / Playwright **1.62.1** executed:

```text
node tests/integration/browser_windows_download.cjs --setup /workspace/malguard-windows-build/final-release/MalGuard-Setup-x64.exe --portable /workspace/malguard-windows-build/final-release/MalGuard-Windows-x64.zip --output /workspace/malguard-windows-build/windows-browser-final-qa.json
```

Both native browser downloads matched the exact hashes above. The Persian RTL
local delivery preview loaded without page/console errors; its screenshot was
visually inspected. This was a temporary QA preview, not a new product GUI or
public site. Downloaded EXEs were not launched by the browser.

## Reviewed and untested

Reviewed changes cover UTF-8 public output, exact frozen worker dispatch, binary
worker streams, current-user installation, owned-file uninstall, signed resource
collection, license provenance, dependency pinning and the native build/CI scripts.
The `scan_file(path) -> Report` API and detection/scoring logic are preserved.

Native Windows 10/11 Job resource enforcement, protected-state ACLs, kernel parser
differences, desktop installer UI, Defender/SmartScreen behavior, ARM64 emulation,
the native PowerShell build and GitHub CI execution remain untested. No native
Windows runner or code-signing certificate is available here. No user labeled
corpus was supplied; real-corpus accuracy targets remain unmeasured. Passing these
checks does not establish zero bugs or universal mutation resistance. SAFE means
no malicious evidence was found by completed static analyses, never guaranteed safe.

## Evidence and changed files

Delivered evidence includes the final EXE, installer, browser and integrity JSON
records, release manifest, source/dependency input provenance, mutation record and
real test/build logs. External evidence avoids a self-referential artifact hash.
The October 4 delivery remains unchanged at SHA256
`e24914c8043928fb0ef39330bda308ae173347c97a6d4c631d62f6904b6d437d`.

Source changes: `malguard_core/workers/pool.py`, `workers/server.py`,
`malguard_cli/main.py`, `evaluation.py`, new `frozen.py`, `pyproject.toml`,
`.github/workflows/malguard.yml`, new complete `packaging/windows/` build/installer/
QA/license files, new frozen/release security tests, Windows fixture/download
harnesses, and installed user-path test portability fixes. Documentation and
`WORK_LOG.md` record the new authorized Windows deliverable. No old engine source
was used; no legacy source/tests existed in the original empty workspace.
