# MalGuard / GTA Guard

Desktop 1.3.0 / engine 1.2.0 source candidate adds byte-based file explanations,
real stage progress, an evidence gauge and a downloadable bilingual report card.
See [desktop inspection and validation](docs/DESKTOP_INSPECTION.md). A new Windows
installer has not yet been published.

Clean-room, offline static analysis for GTA V mod files and packages, with a Python 3.12 library and Persian command-line reports. Scanned content is never executed, imported, compiled, loaded as a DLL or assembly, or passed to a shell. The workspace initially contained no engine, repository or legacy tests; no previous MalGuard implementation was used.

The implementation and synthetic tests are available here. Windows runtime verification and evaluation against representative user-provided corpora remain release requirements. Synthetic results do not establish production detection rates or the requested corpus acceptance targets.

## Install and scan

Use CPython 3.12 on Windows 10/11. Linux is supported for development and verification. Dependency releases, Python compatibility and Windows wheels were checked against live package metadata on 2026-10-03; see [dependency verification](docs/DEPENDENCIES.md). All direct versions and transitive distributions are pinned with hashes.

```powershell
py -3.12 -m venv .venv
.venv\Scripts\python -m pip install --require-hashes -r requirements-lock.txt
.venv\Scripts\python -m pip install --no-deps --no-build-isolation .
.venv\Scripts\python -m malguard_cli "C:\Games\GTA V\mods\example.asi"
.venv\Scripts\python -m malguard_cli "C:\Downloads\mod.zip" --format json --output report.json
```

An offline installation can use a previously downloaded, hash-verified wheelhouse with `pip install --no-index --find-links wheelhouse --require-hashes -r requirements-lock.txt`. Scanning does not require a network connection. Output files must be new: the CLI refuses to overwrite an existing report or input file.

```python
from malguard_core import Scanner, scan_file

report = scan_file("example.asi")
print(report.to_text())
print(report.to_json())

with Scanner() as scanner:
    package_report = scanner.scan_file("mod.zip")
```

`scan_file(path) -> Report` is the public convenience API. A reusable `Scanner` owns persistent, recycled parser workers; concurrent calls on one scanner serialize. Reports and their artifact/evidence collections are immutable. The human report is primarily Persian; JSON carries English identifiers and both Persian and English explanations.

«بدون شواهد مخرب» یعنی: «در تحلیل‌های ایستای تکمیل‌شده، شواهدی از رفتار مخرب پیدا نشد.» این نتیجه تضمین ایمنی نیست. مراحل ناقص، دلیل نقص، پوشش و محدودیت‌ها در گزارش ثبت می‌شوند.

| Verdict | CLI exit | Meaning |
| --- | ---: | --- |
| SAFE | 0 | Completed applicable analyses found no meaningful unresolved harmful evidence. |
| SUSPICIOUS | 1 | Meaningful harmful, deceptive, opaque or authenticated adverse-reputation evidence remains. |
| MALICIOUS | 2 | A verified exact blocklist hit or decisive independent harmful families. |
| INVALID | 3 | Claimed/supported structure is malformed, after stronger evidence is evaluated. |
| INCONCLUSIVE | 3 | Required analysis is blocked, incomplete or insufficient. |
| CLI/output error | 4 | Invalid command usage handled by argparse uses its standard exit 2; scan/output failures use 4. |

`HACKTOOL_PUA` is a classification tag, independent of the security verdict. An explicit, unmodified GTA process-to-handle source relationship can explain trainer memory access. An isolated `GTA5.exe` or ScriptHookV string cannot. The source recognizer conservatively refuses ambiguous bindings, mixed targets, unrelated function scopes, mutation, unknown handles and unsupported relationships. GTA context never mitigates credential access, exfiltration, persistence or security tampering.

## Pipeline and boundaries

Every root file, archive member and carved PE payload follows S0 intake, S1 authenticated exact reputation, raw analysis, applicable structured analysis, evidence graph/correlation, coverage, risk and the sole `VerdictEngine`. No analyzer returns a verdict. Raw strings, bounded decodings and signed raw YARA-X run before risky structured parsing. A parser failure retains prior evidence; every recognized child uses the root's global ledger rather than receiving fresh budgets.

S0 opens only a regular local file, captures an immutable bounded snapshot, rejects links where the platform exposes them, and checks identity, size and timestamps for changes during capture. Windows device paths, UNC paths and extended namespace paths are rejected; use a conventional local drive path. `BoundedByteSource` validates signed ranges, per-read size and cumulative read work. Python integers do not wrap; explicit bounded arithmetic checks still precede range calculations. Report hashes are SHA256, SHA1 and MD5; SHA1/MD5 are identifiers rather than trust primitives.

PE, .NET, archive and YARA-X stages use trusted persistent interpreter workers with framed JSON, no pickle, admission before hostile input, strict request/result validation, bounded output, budget reconciliation, and recycling after errors, size/count thresholds or abnormal memory growth. Windows Job Objects set process memory, CPU time, active-process and kill-on-close limits without breakaway. Linux verification uses process groups and RLIMIT controls. These are process/resource isolation controls; they do not constitute a complete filesystem/network sandbox against arbitrary native-parser exploitation.

Work units are the primary limits; `ITERATION_BUDGET_EXHAUSTED` differs from `WALLCLOCK_TIMEOUT`. Defaults include a 64 MiB artifact cap, 1 MiB read cap, depth 4, 4096 archive entries/children, 256 MiB total expansion, 100000 metadata rows, 4096 resource entries, 2048 decoded candidates, 20000 evidence records, 256 MiB YARA input and 256 Mi parser work units per root. Workers default to 512 MiB memory, 10 CPU seconds and a 15-second wall-clock safety timeout. Additional parser-specific limits are conservative and can produce partial coverage. Disabling required isolation or YARA blocks completion rather than permitting SAFE.

## Static analyses

| Format | Implemented coverage |
| --- | --- |
| PE32/PE32+, EXE/DLL/ASI | Internal bounds validation, pefile differential, architecture, sections/permissions/entropy, entry point, imports, exports/forwarders, delay imports, TLS, resources, overlay, embedded PE candidates, CLR and bounded Authenticode. EXE renamed DLL/ASI is explicit masquerade. |
| .NET | CLR and ECMA metadata streams/tables/heaps, real method signatures and bounded IL token relationships, references, MVID, P/Invoke, embedded resources, loader/reflection/download relationships and opacity. dnfile provides an independent metadata check. |
| Native capabilities | Normalized API chains, credential-store access with read/decrypt activity, exfiltration sinks, persistence, keylogging, remote memory execution, security tampering, GTA/proxy context and opacity. Raw/decoded fallback survives malformed structure. |
| Lua, C#, VB, PowerShell, BAT, VBS | Bounded lexical source analysis, ordered scope-sensitive call/data relationships, remote-fetch plus dynamic execution, explicit PowerShell encoded-command and quoted/decoded Lua interpreter inputs, launch/persistence/credential/exfiltration combinations. Recognized comments, declarations and display operands are separated from invocations. HTTP, Process.Start, VirtualAlloc or a browser path alone cannot produce MALICIOUS. |
| INI/XML/CFG | Relevant configuration and embedded interpreter/security behavior; opaque or unsupported executable content blocks completion. |
| ZIP | Local/central consistency, descriptors/CRC, ranges/overlaps, ZIP64 validation, paths, duplicates/collisions, encrypted members and shared streaming expansion limits. |
| 7z | Bounded format preflight and isolated in-memory py7zr decompression with shared expansion limits. |
| RAR | Safely bounded stored RAR4 entries. Compressed RAR and RAR5 are reported incomplete; no external extractor is invoked. |

Recognized Lua/LuaJIT bytecode, LNK, MSI and unsupported executable formats receive raw analysis but incomplete structured coverage. The scanner never extracts members to filesystem paths. Traversal, absolute/drive/device/ADS paths, encrypted entries, duplicate/colliding names, unindexed content and ambiguities cannot earn SAFE.

PE recovery/carving accepts only bounded candidates with consistent mappings. Malformed child headers remain malformed; temporary validation views do not alter scanned hashes or bytes. Recovery has bounded search/lookback/candidate limits. Evidence already collected is preserved when recovery cannot establish a unique interpretation.

Authenticode checks image digest and supported CMS cryptographic signatures. A signature is context rather than proof of safety; an unsigned file is not malicious merely for being unsigned. Current Windows trust chains, certificate time/timestamp trust and online revocation are not established. Unsupported signature structures remain incomplete. Signed offline revoked-signer data is supported.

## Security data and rules

[Signed bundle documentation](docs/SECURITY_DATA.md) describes Ed25519 verification, payload hashes, epoch rollback prevention, compile-before-install and last-known-good updates. The packaged bootstrap bundle contains empty allowlist, blocklist, IOC and revoked-signer lists plus GTA-focused rules. Its temporary signing key was discarded; no private key or invented threat intelligence is shipped. The public anchor and bootstrap manifest digest are pinned in engine code.

Allowlist records require exact SHA256, verified provenance/version, expected type and review metadata. Filenames, MVIDs, signing presence, settings files and clean AV results grant no trust. Operator updates require authenticated bundles and protected monotonic epoch state. Additional operator signing keys must be provisioned in the trusted engine build/worker anchor; they are never accepted from settings or worker requests. An invalid rule update cannot replace the compiled last-known-good signed ruleset.

YARA-X rules require author, description, severity, reference and false-positive notes; categories cover loader, credential, Lua, disguised menu, embedded payload and protector/packer patterns. Packing/obfuscation is OPACITY, never a malicious family. Shared hostnames receive zero-weight context; reviewed specific URL/path IOCs may trigger SUSPICIOUS without fabricating behavioral HARM. Tokens/webhook secrets are redacted in both report formats. Similarity profiles use corroborated type/architecture/size/capabilities alongside imphash, .NET structural hashes/MVID or signer fingerprints; similarity never overrides a verdict. No network reputation adapter or ssdeep implementation is bundled. Optional capa ingestion accepts validated capability JSON only and never runs capa or a sample.

## Exact decision model

Evidence weight is `base_weight * confidence * reliability`, with severity bases `0, 4, 10, 18, 28`. Equivalent semantic evidence is deduplicated for scoring while all collected evidence remains in the report. Each artifact's family score is `min(cap, strongest + 0.50*second + 0.25*third)`, with HARM cap 32 and OPACITY cap 18. A specifically proven GTA memory family can receive at most 40% mitigation; unrelated harmful families cannot.

For each artifact, `H = sum(top three HARM family scores)`, `O = min(20, 0.60 * sum(top two OPACITY family scores))`, and `D = min(15, strongest STRUCTURE weight + 0.50*second + 0.25*third)`. Risk is `min(100, round_half_up(H+O+D))`. Package risk is the maximum artifact risk, with verified exact blocklist setting 100. Unrelated children do not combine families to manufacture MALICIOUS; parents inherit the strongest child verdict. Authenticated specific adverse IOC/revocation is a separate SUSPICIOUS gate and does not inflate this behavioral risk formula.

Without an exact authenticated blocklist override, MALICIOUS requires at least two independent HARM families, each score at least 16, decisive confidence at least 0.75, a decisive individual effective weight at least 16, and combined top-three decisive HARM score at least 48. OPACITY alone cannot satisfy this rule. SUSPICIOUS precedes malformed/incomplete decisions and can follow risk at least 25, a strong HARM family, strong masquerade, substantial unresolved opacity or authenticated specific adverse reputation. Verdict order is hard override, MALICIOUS, SUSPICIOUS, INVALID, INCONCLUSIVE, SAFE.

Coverage weights are S0=3, S1=1, S2=2, S3=3, S4=3, S5=3, S6=3 and S7=2; nonapplicable stages are excluded. Multipliers are COMPLETE=1, PARTIAL=.60, SKIPPED_LIMIT=.25, TIMEOUT=.10 and FAILED/UNAVAILABLE/BLOCKED=0. Duplicate stages conservatively use their worst coverage state. Coverage is 100 times weighted completed work divided by applicable weight. Package coverage is its minimum artifact coverage. For a nondecisive verdict, confidence is coverage minus 10 for disagreement and minus `min(15, .5*O)`; decisive MALICIOUS uses the decisive evidence confidence, and SUSPICIOUS has a 65 confidence floor. Confidence is an engineering indicator, not an empirically calibrated probability.

SAFE additionally requires risk at most 14, no HARM family at least 10, coverage at least 92, confidence at least 85, valid applicable structure, no unreadable child, failed required stage, unresolved disagreement, executable mismatch or unresolved opacity, and completed analysis or verified exact component context. An allowlist never erases harmful evidence. General static analysis cannot guarantee that arbitrary corruption, encryption or semantics-changing transformations preserve detectability; the regression invariants ensure retained evidence is never discarded merely because later analysis fails.

## Windows standalone version

The Windows x64 console application includes Python and the required runtime.
Install `MalGuard-Setup-x64.exe`, open the MalGuard shortcut and paste or drag a
mod-file path into the prompt. JSON reports are saved as new files in
`%LOCALAPPDATA%\MalGuard\Reports`. The portable ZIP must be extracted completely;
keep `_internal` beside `MalGuard.exe`. `MalGuard.exe --self-test` checks signed
resources and nested-archive workers without executing any fixture.

The actual EXE and installer were built and tested under Wine, with verified
Chromium downloads. [Windows verification](docs/WINDOWS-VERIFICATION.md) records
the exact results and remaining native Windows limits. [Build instructions](docs/WINDOWS_BUILD.md)
and the [Persian user guide](packaging/windows/README-FA.txt) accompany the source.
The application remains a static scanner with a console interface; no product GUI
was added. The EXEs are unsigned because no Windows code-signing certificate was available.

## Verify and evaluate

```bash
.venv/bin/python -m pytest -q
.venv/bin/python -m ruff check malguard_core malguard_cli tests
.venv/bin/python -m mypy --platform linux malguard_core malguard_cli
.venv/bin/python -m mypy --platform win32 malguard_core malguard_cli
.venv/bin/python -m pip check
.venv/bin/python -m tests.mutation.harness --output mutation-results.json
.venv/bin/python -m build --no-isolation
```

Windows uses `.venv\Scripts\python` for the same module commands. [Build/CI documentation](docs/BUILD_VERIFICATION.md) distinguishes checks actually run from Windows jobs prepared but not executed. Fixture builders generate harmless bytes, metadata, strings and archive layouts. No real malware is included or executed. The mutation harness measures ASCII/UTF-16, splitting, API variants, base64, hex, XOR, reversal, nesting and header corruption against synthetic signals; it does not measure corpus recall.

[Independent source/security QA](docs/INDEPENDENT_QA.md), [seeded malformed-input stress](docs/STRESS_QA.md), [fresh installed/offline workflows](docs/FRESH_INSTALL_QA.md) and [browser report/download checks](docs/BROWSER_QA.md) record the additional review. The browser page is a temporary local QA harness. The product remains the static library and CLI.

For a user-maintained labeled dataset, run in an isolated lab/VM:

```powershell
.venv\Scripts\python -m malguard_cli.evaluation C:\Lab\dataset --output evaluation.json
```

The dataset contains `benign/` and `malicious/` directories. The evaluator statically scans regular files, skips links, reports TP/FP/TN/FN, precision, recall, false-positive rate and per-verdict rates. MALICIOUS is the primary positive; SUSPICIOUS/INVALID/INCONCLUSIVE on a malicious-labeled sample count as false negatives there. A separate metric reports MALICIOUS-or-SUSPICIOUS recall. Missing denominators produce null rather than invented performance. No acceptance target is claimed from synthetic evaluation.

## Practical limits

Native machine-code control flow, arbitrary API hashing, direct-syscall semantics, stack strings, runtime target resolution, indirect reflection, advanced source aliases, encrypted payloads and arbitrary obfuscators cannot be reliably reconstructed by this static implementation. Detected opacity and unsupported/incomplete stages restrict clean gating, but a clean report cannot prove absence of unknown hidden behavior. Generic .NET control-flow reconstruction is bounded to modeled IL relationships. Recognizing a protector name is neither family attribution nor trust. Certificate root/time validation, native Windows 10/11 execution and representative corpus performance remain unverified. Windows PyInstaller packaging and Wine verification are recorded separately above. The product GUI is outside this project.
