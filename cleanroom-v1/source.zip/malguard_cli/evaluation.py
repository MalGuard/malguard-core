"""Measure static verdicts on a user supplied labeled corpus.

Only MALICIOUS is a positive prediction in the primary confusion matrix. Every
other verdict on a malicious-labeled sample is a false negative. Separate rates
preserve uncertainty, and a second recall includes SUSPICIOUS detections.
"""

from __future__ import annotations

import argparse
import json
import os
import stat
import sys
from collections import Counter
from pathlib import Path
from typing import TYPE_CHECKING

from malguard_cli.main import configure_output, write_output

if TYPE_CHECKING:
    from collections.abc import Callable, Sequence
    from malguard_core.model import Report


_VERDICTS = ("SAFE", "SUSPICIOUS", "MALICIOUS", "INVALID", "INCONCLUSIVE")


def _ratio(numerator: int, denominator: int) -> float | None:
    return numerator / denominator if denominator else None


def _files(directory: Path) -> tuple[list[Path], list[dict[str, str]]]:
    found: list[Path] = []
    skipped: list[dict[str, str]] = []

    def onerror(error: OSError) -> None:
        skipped.append({"path": str(error.filename), "reason": type(error).__name__})

    for base, directories, files in os.walk(directory, followlinks=False, onerror=onerror):
        for name in sorted(directories):
            candidate = Path(base) / name
            if candidate.is_symlink():
                skipped.append({"path": str(candidate), "reason": "SYMLINK"})
        directories[:] = sorted(name for name in directories if not (Path(base) / name).is_symlink())
        for name in sorted(files):
            path = Path(base) / name
            try:
                mode = path.lstat().st_mode
                if stat.S_ISREG(mode):
                    found.append(path)
                else:
                    skipped.append({"path": str(path), "reason": "NOT_REGULAR_FILE"})
            except OSError as error:
                skipped.append({"path": str(path), "reason": type(error).__name__})
    return sorted(found), skipped


def evaluate(dataset: Path, scan: Callable[[Path], Report]) -> dict[str, object]:
    """Read only benign/ and malicious/; never execute, import, or load samples."""
    dataset = Path(dataset)
    for label in ("benign", "malicious"):
        directory = dataset / label
        if not directory.is_dir() or directory.is_symlink():
            raise ValueError(f"Dataset requires an ordinary {label}/ directory")

    counts = {label: Counter({verdict: 0 for verdict in _VERDICTS}) for label in ("benign", "malicious")}
    samples: list[dict[str, object]] = []
    skipped: list[dict[str, str]] = []
    failures = 0
    for label in ("benign", "malicious"):
        paths, excluded = _files(dataset / label)
        skipped.extend(excluded)
        for path in paths:
            row: dict[str, object] = {"path": path.relative_to(dataset).as_posix(), "label": label}
            try:
                report = scan(path)
                verdict = report.verdict.value
                if verdict not in _VERDICTS:
                    raise ValueError("Scanner returned an unknown verdict")
                row.update(verdict=verdict, risk_score=report.risk_score, coverage_score=report.coverage_score)
            except Exception as error:
                # A failed analysis is uncertainty, never a benign prediction.
                verdict = "INCONCLUSIVE"
                row.update(verdict=verdict, error=type(error).__name__)
                failures += 1
            counts[label][verdict] += 1
            samples.append(row)

    benign = sum(counts["benign"].values())
    malicious = sum(counts["malicious"].values())
    total = benign + malicious
    tp = counts["malicious"]["MALICIOUS"]
    fp = counts["benign"]["MALICIOUS"]
    tn = benign - fp
    fn = malicious - tp
    metrics: dict[str, object] = {
        "true_positives": tp,
        "false_positives": fp,
        "true_negatives": tn,
        "false_negatives": fn,
        "precision": _ratio(tp, tp + fp),
        "recall": _ratio(tp, malicious),
        "false_positive_rate": _ratio(fp, benign),
        "malicious_or_suspicious_recall": _ratio(tp + counts["malicious"]["SUSPICIOUS"], malicious),
    }
    for verdict in _VERDICTS:
        metrics[f"{verdict.lower()}_rate"] = _ratio(sum(c[verdict] for c in counts.values()), total)
    return {
        "schema_version": "1.0",
        "prediction_positive": "MALICIOUS",
        "scan_mode": "STATIC_ONLY",
        "acceptance_targets_evaluated": False,
        "sample_count": total,
        "scan_failures": failures,
        "metrics": metrics,
        "counts_by_label": {label: dict(c) for label, c in counts.items()},
        "rates_by_label": {
            label: {v: _ratio(c[v], sum(c.values())) for v in _VERDICTS}
            for label, c in counts.items()
        },
        "skipped": skipped,
        "samples": samples,
    }


def main(argv: Sequence[str] | None = None) -> int:
    configure_output()
    parser = argparse.ArgumentParser(description="ارزیابی ایستای مجموعهٔ برچسب‌دار benign/ و malicious/")
    parser.add_argument("dataset", type=Path)
    parser.add_argument("--output", type=Path, help="فایل JSON جدید؛ فایل موجود بازنویسی نمی‌شود")
    args = parser.parse_args(argv)
    from malguard_core import Scanner

    try:
        with Scanner() as scanner:
            result = evaluate(args.dataset, scanner.scan_file)
        write_output(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2), args.output)
    except (OSError, ValueError) as error:
        print(f"خطای ارزیابی: {type(error).__name__}", file=sys.stderr)
        return 4
    return 4 if result["scan_failures"] or result["skipped"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
