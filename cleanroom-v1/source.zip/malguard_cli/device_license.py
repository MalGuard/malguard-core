"""Offline, signed authorization of a private frozen build on one Windows device."""

from __future__ import annotations

import base64
import binascii
import hashlib
import hmac
import json
import re
import sys
from pathlib import Path

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from malguard_cli.license_policy import PRIVATE_APP_VERSION, PRIVATE_LICENSE_PUBLIC_KEY_HEX

DOMAIN = b"MalGuard device license v1\x00"
MAX_LICENSE_BYTES = 4096


class LicenseError(ValueError):
    """A bounded public failure code, never raw device or license contents."""


def _unique_pairs(pairs: list[tuple[str, object]]) -> dict[str, object]:
    result: dict[str, object] = {}
    for key, value in pairs:
        if key in result:
            raise LicenseError("LICENSE_INVALID")
        result[key] = value
    return result


def verify_license(data: bytes, public_key_hex: str, fingerprint: str) -> None:
    """Reject wrong devices, modified licenses, ambiguous JSON and other versions."""
    if not 0 < len(data) <= MAX_LICENSE_BYTES:
        raise LicenseError("LICENSE_INVALID")
    try:
        item = json.loads(data.decode("utf-8"), object_pairs_hook=_unique_pairs)
        if not isinstance(item, dict) or set(item) != {
            "schema", "product", "app_version", "fingerprint", "signature"
        }:
            raise LicenseError("LICENSE_INVALID")
        if (type(item["schema"]) is not int or item["schema"] != 1
                or item["product"] != "MalGuard"
                or item["app_version"] != PRIVATE_APP_VERSION
                or not isinstance(item["fingerprint"], str)
                or re.fullmatch(r"[a-f0-9]{64}", item["fingerprint"]) is None
                or not isinstance(item["signature"], str)):
            raise LicenseError("LICENSE_INVALID")
        signature = base64.b64decode(item.pop("signature"), validate=True)
        payload = json.dumps(item, sort_keys=True, separators=(",", ":")).encode("utf-8")
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(public_key_hex)).verify(
            signature, DOMAIN + payload
        )
        if not hmac.compare_digest(item["fingerprint"], fingerprint):
            raise LicenseError("DEVICE_MISMATCH")
    except InvalidSignature as error:
        raise LicenseError("LICENSE_SIGNATURE_INVALID") from error
    except (UnicodeError, json.JSONDecodeError, binascii.Error, TypeError, ValueError) as error:
        if isinstance(error, LicenseError):
            raise
        raise LicenseError("LICENSE_INVALID") from error


def windows_fingerprint() -> str:
    """Read the 64-bit registry view; do not accept environment overrides."""
    if sys.platform != "win32":
        raise LicenseError("WINDOWS_REQUIRED")
    import winreg

    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography",
                            0, winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as key:
            value, kind = winreg.QueryValueEx(key, "MachineGuid")
        if kind != winreg.REG_SZ or not isinstance(value, str):
            raise LicenseError("DEVICE_UNAVAILABLE")
        value = value.strip().lower()
        if re.fullmatch(r"[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}", value) is None:
            raise LicenseError("DEVICE_UNAVAILABLE")
        return hashlib.sha256(value.encode("utf-8")).hexdigest()
    except OSError as error:
        raise LicenseError("DEVICE_UNAVAILABLE") from error


def license_path() -> Path:
    """Use Windows' system ProgramData folder, independent of process variables."""
    if sys.platform != "win32":
        raise LicenseError("WINDOWS_REQUIRED")
    import ctypes

    buffer = ctypes.create_unicode_buffer(260)
    if ctypes.windll.shell32.SHGetFolderPathW(None, 0x0023, None, 0, buffer) != 0:
        raise LicenseError("DEVICE_UNAVAILABLE")
    return Path(buffer.value) / "MalGuard" / "Licenses" / f"desktop-{PRIVATE_APP_VERSION}.json"


def authorization() -> dict[str, object]:
    """Public builds stay public; private builds require the pinned signed license."""
    if PRIVATE_LICENSE_PUBLIC_KEY_HEX is None:
        return {"private_build": False, "authorized": True, "reason": "PUBLIC_BUILD"}
    try:
        fingerprint = windows_fingerprint()
        with license_path().open("rb") as stream:
            data = stream.read(MAX_LICENSE_BYTES + 1)
        verify_license(data, PRIVATE_LICENSE_PUBLIC_KEY_HEX, fingerprint)
        return {"private_build": True, "authorized": True, "reason": "DEVICE_AUTHORIZED"}
    except FileNotFoundError:
        reason = "LICENSE_MISSING"
    except OSError:
        reason = "LICENSE_UNAVAILABLE"
    except LicenseError as error:
        reason = str(error)
    return {"private_build": True, "authorized": False, "reason": reason}
