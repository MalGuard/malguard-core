"""Standalone Windows entry, with the same bounded engine and worker protocol."""

from __future__ import annotations

import io
import json
import os
import sys
import tempfile
import zipfile
from pathlib import Path
from typing import TYPE_CHECKING

from malguard_cli.main import _EXIT_CODES, configure_output, main as scan_main, write_output

if TYPE_CHECKING:
    from collections.abc import Sequence


def self_test() -> int:
    """Scan inert generated Lua and nested ZIP bytes, never executing fixtures."""
    from malguard_core import ENGINE_VERSION, scan_file

    source = b"local version = 'MalGuard harmless self-test'\nprint(version)\n"
    with tempfile.TemporaryDirectory(prefix="malguard-self-test-") as directory:
        root = Path(directory)
        lua = root / "benign.lua"
        lua.write_bytes(source)
        nested = io.BytesIO()
        with zipfile.ZipFile(nested, "w") as archive:
            archive.writestr("benign.lua", source)
        package = root / "nested.zip"
        with zipfile.ZipFile(package, "w") as archive:
            archive.writestr("inner.zip", nested.getvalue())
        reports = (scan_file(lua), scan_file(package))
    passed = all(report.verdict.value == "SAFE" and report.coverage_score == 100
                 for report in reports) and len(reports[1].artifacts) == 3
    summary = {
        "self_test_passed": passed, "engine_version": ENGINE_VERSION,
        "python_version": sys.version.split()[0], "platform": sys.platform,
        "frozen": bool(getattr(sys, "frozen", False)),
        "sample_execution": False,
        "checks": [{"verdict": report.verdict.value, "coverage": report.coverage_score,
                    "artifact_count": len(report.artifacts),
                    "incomplete_stages": [{"stage": entry.stage, "state": entry.state.value,
                                           "error": entry.error_code.value if entry.error_code else None}
                                          for artifact in report.artifacts for entry in artifact.coverage
                                          if entry.applicable and entry.state.value != "COMPLETE"]}
                   for report in reports],
    }
    write_output(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0 if passed else 5


def _interactive() -> int:
    from malguard_core import scan_file

    print("MalGuard / GTA Guard — offline static scanner")
    print("Paste a file path, or drag a file into this window. The file will not be executed.")
    try:
        value = input("File path: ").strip().strip('"')
        if not value:
            return 2
        report = scan_file(Path(value))
        write_output(report.to_text())
        folder = Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "MalGuard" / "Reports"
        folder.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", suffix=".json",
                                         prefix="scan-", dir=folder, delete=False) as output:
            output.write(report.to_json() + "\n")
            report_path = output.name
        print("JSON report saved to: " + report_path)
        input("Press Enter to close.")
        return _EXIT_CODES[report.verdict.value]
    except (EOFError, KeyboardInterrupt):
        return 130
    except (OSError, ValueError) as error:
        print("Scan/report failed: " + type(error).__name__, file=sys.stderr)
        return 4


def main(argv: Sequence[str] | None = None) -> int:
    arguments = list(sys.argv[1:] if argv is None else argv)
    from malguard_cli.device_license import authorization

    permission = authorization()
    if arguments == ["--license-status"]:
        configure_output()
        write_output(json.dumps(permission))
        return 0 if permission["authorized"] else 78
    if not permission["authorized"]:
        if arguments != ["--malguard-worker"]:
            configure_output()
            write_output(json.dumps(permission))
        return 78
    if arguments == ["--malguard-worker"]:
        if sys.platform == "win32":
            import msvcrt
            for stream in (sys.stdin, sys.stdout):
                msvcrt.setmode(stream.fileno(), os.O_BINARY)
        from malguard_core.workers.server import main as worker_main
        return worker_main()
    # Windows console handles support Unicode, but redirected handles inherit
    # the legacy ANSI code page. Public text output must also preserve Persian
    # in pipes and files. Private worker frames above remain binary and exact.
    configure_output()
    if arguments and arguments[0] in {"--desktop-scan", "--security-status", "--refresh-security"}:
        from malguard_cli.desktop import main as desktop_main
        return desktop_main(arguments)
    if arguments == ["--self-test"]:
        return self_test()
    if arguments and arguments[0] == "--evaluate":
        from malguard_cli.evaluation import main as evaluate_main
        return evaluate_main(arguments[1:])
    if not arguments:
        if isinstance(sys.stdin, io.TextIOWrapper):
            sys.stdin.reconfigure(encoding="utf-8", errors="strict")
        return _interactive()
    return scan_main(arguments)


if __name__ == "__main__":
    raise SystemExit(main())
