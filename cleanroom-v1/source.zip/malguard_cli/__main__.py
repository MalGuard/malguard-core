"""Invoke the scan command with ``python -m malguard_cli``."""

from malguard_cli.main import main

if __name__ == "__main__":
    raise SystemExit(main())
