"""Narrow desktop bridge: local static scans and authenticated update status."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from malguard_cli.main import configure_output, write_output
from malguard_core.api.scanner import Scanner
from malguard_core.integrity import BundleVerifier
from malguard_core.reputation import ReputationStore
from malguard_core.reputation.trust import PUBLIC_KEYS
from malguard_core.rules import RulesManager
from malguard_core.updates import load_cached, refresh, status_json


def _progress(stage: str) -> None:
    # Separate bounded telemetry from the stable JSON report on stdout.
    try:
        sys.stderr.write(json.dumps({"event": "scan_stage", "stage": stage}) + "\n")
        sys.stderr.flush()
    except OSError:
        pass


def main(arguments: list[str]) -> int:
    configure_output()
    if arguments == ["--refresh-security"]:
        result = refresh()
        write_output(json.dumps(status_json(result), ensure_ascii=False))
        return 0 if result.fresh else 4
    if arguments == ["--security-status"]:
        _, result = load_cached()
        write_output(json.dumps(status_json(result), ensure_ascii=False))
        return 0
    if len(arguments) == 2 and arguments[0] == "--desktop-scan":
        _progress("updates")
        bundle, status = load_cached()
        reputation = ReputationStore(bundle) if bundle else None
        rules = RulesManager(bundle, BundleVerifier(PUBLIC_KEYS)) if bundle else None
        with Scanner(reputation=reputation, rules_manager=rules,
                     reputation_fresh=status.fresh, progress=_progress) as scanner:
            report = scanner.scan_file(Path(arguments[1]))
            inspection = scanner.file_inspection
        write_output(json.dumps({"report": json.loads(report.to_json()),
                                 "summary_fa": report.to_text(),
                                 "summary_en": report.to_text(language="en"),
                                 "file_inspection": inspection,
                                 "updates": status_json(status)}, ensure_ascii=False))
        return 0
    raise ValueError("Unsupported desktop command")
