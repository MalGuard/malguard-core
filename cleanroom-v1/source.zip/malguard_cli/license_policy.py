"""Build-time policy; private Windows builds pin their delivery owner's key."""

PRIVATE_LICENSE_PUBLIC_KEY_HEX: str | None = None
PRIVATE_APP_VERSION = "1.3.0"
