"""Command line entry points for the defensive static MalGuard scanner."""
