"""Scan an artifact without executing its contents."""

from __future__ import annotations

import argparse
import io
import sys
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Sequence


_EXIT_CODES = {"SAFE": 0, "SUSPICIOUS": 1, "MALICIOUS": 2, "INVALID": 3, "INCONCLUSIVE": 3}


def configure_output() -> None:
    """Preserve Persian in both Unicode consoles and legacy redirected pipes."""
    for stream in (sys.stdout, sys.stderr):
        if isinstance(stream, io.TextIOWrapper):
            stream.reconfigure(encoding="utf-8", errors="backslashreplace")


def write_output(content: str, path: Path | None = None) -> None:
    """Write UTF-8 output, refusing to overwrite an existing file or sample."""
    text = content.rstrip("\n") + "\n"
    if path is not None:
        with path.open("x", encoding="utf-8", newline="\n") as stream:
            stream.write(text)
        return
    try:
        sys.stdout.write(text)
    except UnicodeEncodeError:
        # Legacy Windows consoles can lack Persian characters; avoid a crash.
        if hasattr(sys.stdout, "buffer"):
            sys.stdout.buffer.write(text.encode("utf-8"))
        else:
            sys.stdout.write(text.encode("ascii", "backslashreplace").decode("ascii"))


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(
        prog="malguard",
        description="تحلیل ایستای آفلاین فایل یا بستهٔ ماد GTA V؛ فایل اجرا نمی‌شود.",
    )
    result.add_argument("path", type=Path, help="مسیر فایل مورد بررسی")
    result.add_argument("--format", choices=("text", "json"), default="text")
    result.add_argument("--output", type=Path, help="فایل خروجی جدید با UTF-8؛ بازنویسی مجاز نیست")
    return result


def main(argv: Sequence[str] | None = None) -> int:
    configure_output()
    args = parser().parse_args(argv)
    from malguard_core import scan_file

    try:
        report = scan_file(args.path)
        content = report.to_json() if args.format == "json" else report.to_text()
        write_output(content, args.output)
    except (OSError, ValueError) as error:
        print(f"خطای بررسی یا نوشتن خروجی: {type(error).__name__}", file=sys.stderr)
        return 4
    return _EXIT_CODES[report.verdict.value]


if __name__ == "__main__":
    raise SystemExit(main())
