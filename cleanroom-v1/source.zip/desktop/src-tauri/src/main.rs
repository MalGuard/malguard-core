#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use std::io::Read;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::sync::Mutex;
use std::sync::Arc;
use std::sync::atomic::{AtomicBool, Ordering};
use std::time::{Duration, Instant};
use tauri::Manager;

#[derive(Default)]
struct Selection {
    path: Mutex<Option<PathBuf>>,
    last_report: Mutex<Option<serde_json::Value>>,
    busy: Arc<AtomicBool>,
}

struct BusyGuard(Arc<AtomicBool>);
impl Drop for BusyGuard {
    fn drop(&mut self) { self.0.store(false, Ordering::Release); }
}

fn engine(app: &tauri::AppHandle) -> Result<PathBuf, String> {
    let root = app.path().resource_dir().map_err(|_| "مسیر برنامه در دسترس نیست")?;
    let exe = root.join("engine").join("MalGuard.exe");
    if !exe.is_file() { return Err("موتور اسکن نصب نشده است".into()); }
    Ok(exe)
}

fn run_engine(exe: &Path, mode: &str, file: Option<&Path>) -> Result<serde_json::Value, String> {
    let mut command = Command::new(exe);
    command.current_dir(exe.parent().ok_or("مسیر موتور معتبر نیست")?);
    command.arg(mode).stdin(Stdio::null()).stdout(Stdio::piped()).stderr(Stdio::null());
    if let Some(path) = file { command.arg(path); }
    #[cfg(windows)] {
        use std::os::windows::process::CommandExt;
        command.creation_flags(0x08000000);
    }
    let mut child = command.spawn().map_err(|_| "موتور اسکن باز نشد")?;
    let stdout = child.stdout.take().ok_or("خروجی موتور در دسترس نیست")?;
    let reader = std::thread::spawn(move || {
        let mut bytes = Vec::new();
        stdout.take(12 * 1024 * 1024 + 1).read_to_end(&mut bytes).map(|_| bytes)
    });
    let started = Instant::now();
    loop {
        match child.try_wait() {
            Ok(Some(code)) => {
                if !code.success() { return Err("بررسی کامل نشد؛ اطلاعات قبلی محفوظ است".into()); }
                break;
            }
            Ok(None) => {
                if started.elapsed() > Duration::from_secs(240) {
                    let _ = child.kill();
                    let _ = child.wait();
                    return Err("محدودیت زمان یا اندازهٔ خروجی موتور".into());
                }
                std::thread::sleep(Duration::from_millis(50));
            }
            Err(_) => { let _ = child.kill(); return Err("وضعیت موتور قابل بررسی نیست".into()); }
        }
    }
    let bytes = reader.join().map_err(|_| "خواندن خروجی ناموفق بود")?
        .map_err(|_| "خواندن خروجی ناموفق بود")?;
    if bytes.len() > 12 * 1024 * 1024 { return Err("خروجی موتور بیش از حد مجاز است".into()); }
    serde_json::from_slice(&bytes).map_err(|_| "گزارش موتور معتبر نیست".into())
}

#[tauri::command]
async fn choose_file(state: tauri::State<'_, Selection>) -> Result<Option<String>, String> {
    let chosen = tauri::async_runtime::spawn_blocking(|| rfd::FileDialog::new()
        .set_title("انتخاب فایل ماد GTA V").pick_file()).await.map_err(|_| "انتخاب فایل ناموفق بود")?;
    if let Some(path) = chosen {
        let label = path.to_string_lossy().to_string();
        *state.path.lock().map_err(|_| "وضعیت برنامه در دسترس نیست")? = Some(path);
        Ok(Some(label))
    } else { Ok(None) }
}

#[tauri::command]
async fn scan_selected(app: tauri::AppHandle, state: tauri::State<'_, Selection>) -> Result<serde_json::Value, String> {
    let file = state.path.lock().map_err(|_| "وضعیت برنامه در دسترس نیست")?
        .clone().ok_or("ابتدا فایل را انتخاب کنید")?;
    if state.busy.swap(true, Ordering::AcqRel) { return Err("یک بررسی در حال اجراست".into()); }
    let guard = BusyGuard(state.busy.clone());
    let exe = engine(&app)?;
    let report = tauri::async_runtime::spawn_blocking(move || {
        let _guard = guard;
        run_engine(&exe, "--desktop-scan", Some(&file))
    }).await.map_err(|_| "بررسی ناموفق بود")??;
    *state.last_report.lock().map_err(|_| "وضعیت برنامه در دسترس نیست")? = Some(report.clone());
    Ok(report)
}

#[tauri::command]
async fn save_report(state: tauri::State<'_, Selection>) -> Result<bool, String> {
    let report = state.last_report.lock().map_err(|_| "وضعیت برنامه در دسترس نیست")?
        .clone().ok_or("ابتدا یک بررسی کامل کنید")?;
    tauri::async_runtime::spawn_blocking(move || -> Result<bool, String> {
        let Some(path) = rfd::FileDialog::new().set_file_name("MalGuard-report.json").save_file()
            else { return Ok(false); };
        let bytes = serde_json::to_vec_pretty(&report).map_err(|_| "گزارش معتبر نیست")?;
        let mut file = std::fs::OpenOptions::new().write(true).create_new(true).open(path)
            .map_err(|_| "نام جدید انتخاب کنید؛ فایل موجود بازنویسی نمی‌شود")?;
        file.write_all(&bytes).map_err(|_| "گزارش ذخیره نشد")?;
        file.sync_all().map_err(|_| "گزارش ذخیره نشد")?;
        Ok(true)
    }).await.map_err(|_| "ذخیرهٔ گزارش ناموفق بود")?
}

#[tauri::command]
async fn security_status(app: tauri::AppHandle) -> Result<serde_json::Value, String> {
    let exe = engine(&app)?;
    tauri::async_runtime::spawn_blocking(move || run_engine(&exe, "--security-status", None))
        .await.map_err(|_| "بررسی وضعیت ناموفق بود")?
}

#[tauri::command]
fn refresh_security(app: tauri::AppHandle) -> Result<(), String> {
    let exe = engine(&app)?;
    #[cfg(windows)] {
        use std::os::windows::ffi::OsStrExt;
        #[link(name = "shell32")]
        extern "system" {
            fn ShellExecuteW(hwnd: isize, operation: *const u16, file: *const u16,
                parameters: *const u16, directory: *const u16, show: i32) -> isize;
        }
        let wide = |s: &std::ffi::OsStr| s.encode_wide().chain(Some(0)).collect::<Vec<u16>>();
        let verb = wide(std::ffi::OsStr::new("runas"));
        let file = wide(exe.as_os_str());
        let args = wide(std::ffi::OsStr::new("--refresh-security"));
        let directory = wide(exe.parent().ok_or("مسیر موتور معتبر نیست")?.as_os_str());
        // Elevate the installed trusted updater only; sample paths are absent.
        let result = unsafe { ShellExecuteW(0, verb.as_ptr(), file.as_ptr(), args.as_ptr(), directory.as_ptr(), 0) };
        if result <= 32 { return Err("اجازهٔ به‌روزرسانی داده نشد".into()); }
        Ok(())
    }
    #[cfg(not(windows))] { let _ = exe; Err("این بسته برای Windows ساخته شده است".into()) }
}

fn main() {
    tauri::Builder::default().manage(Selection::default())
        .invoke_handler(tauri::generate_handler![choose_file, scan_selected, save_report, security_status, refresh_security])
        .run(tauri::generate_context!()).expect("MalGuard desktop startup failed");
}
