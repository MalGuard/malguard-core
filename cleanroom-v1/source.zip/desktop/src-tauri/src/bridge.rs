//! Narrow validation for engine telemetry and generated report images.

pub fn update_id(id: &str) -> bool {
    id.len() == 36
        && id.bytes().enumerate().all(|(i, b)| {
            if [8, 13, 18, 23].contains(&i) {
                b == b'-'
            } else {
                b.is_ascii_digit() || (b'a'..=b'f').contains(&b)
            }
        })
}

#[cfg(any(windows, test))]
pub fn update_progress(bytes: &[u8], id: &str) -> Option<serde_json::Value> {
    if bytes.len() > 8192 || !update_id(id) {
        return None;
    }
    let value: serde_json::Value = serde_json::from_slice(bytes).ok()?;
    if value.get("requestId")?.as_str()? != id {
        return None;
    }
    let stage = value.get("stage")?.as_str()?;
    if ![
        "preparing",
        "downloading",
        "verifying",
        "comparing",
        "installing",
        "complete",
        "failed",
    ]
    .contains(&stage)
    {
        return None;
    }
    let received = value.get("receivedBytes").and_then(|v| v.as_u64());
    let total = value.get("totalBytes").and_then(|v| v.as_u64());
    if stage == "downloading"
        && (received.is_none()
            || received? > 23 * 1024 * 1024
            || total.is_some_and(|n| n == 0 || n > 23 * 1024 * 1024 || received.unwrap() > n))
    {
        return None;
    }
    Some(
        serde_json::json!({"requestId": id, "stage": stage, "receivedBytes": received, "totalBytes": total}),
    )
}

pub fn scan_stage(line: &[u8]) -> Option<&'static str> {
    if line.len() > 128 {
        return None;
    }
    let value: serde_json::Value = serde_json::from_slice(line).ok()?;
    if value.get("event")?.as_str()? != "scan_stage" {
        return None;
    }
    match value.get("stage")?.as_str()? {
        "updates" => Some("updates"),
        "capture" => Some("capture"),
        "reputation" => Some("reputation"),
        "strings" => Some("strings"),
        "native" => Some("native"),
        "script" => Some("script"),
        "rules" => Some("rules"),
        "pe" => Some("pe"),
        "dotnet" => Some("dotnet"),
        "archive" => Some("archive"),
        "context" => Some("context"),
        "finalizing" => Some("finalizing"),
        _ => None,
    }
}

pub fn validate_card(bytes: &[u8]) -> bool {
    // Only a bounded generated PNG is saved. No sample path is accepted here.
    if bytes.len() < 45
        || bytes.len() > 6 * 1024 * 1024
        || &bytes[..8] != b"\x89PNG\r\n\x1a\n"
        || &bytes[8..16] != b"\0\0\0\rIHDR"
        || &bytes[bytes.len() - 12..] != b"\0\0\0\0IEND\xaeB`\x82"
    {
        return false;
    }
    let width = u32::from_be_bytes(bytes[16..20].try_into().unwrap());
    let height = u32::from_be_bytes(bytes[20..24].try_into().unwrap());
    (1..=2000).contains(&width) && (1..=2600).contains(&height)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn update_progress_is_bound_to_job_and_actual_bounded_bytes() {
        let id = "12345678-abcd-abcd-abcd-123456789abc";
        assert!(update_id(id));
        assert!(!update_id("../outside"));
        let bytes = serde_json::to_vec(&serde_json::json!({"requestId": id,
            "stage": "downloading", "receivedBytes": 1024, "totalBytes": 2048}))
        .unwrap();
        let parsed = update_progress(&bytes, id).unwrap();
        assert_eq!(parsed["receivedBytes"], 1024);
        assert!(update_progress(&bytes, "12345678-abcd-abcd-abcd-123456789abd").is_none());
        for (stage, received, total) in [
            ("execute", 1, 2),
            ("downloading", 3, 2),
            ("downloading", 1, 30 * 1024 * 1024),
        ] {
            let bytes = serde_json::to_vec(&serde_json::json!({"requestId": id,
                "stage": stage, "receivedBytes": received, "totalBytes": total}))
            .unwrap();
            assert!(update_progress(&bytes, id).is_none());
        }
        assert!(update_progress(&[b' '; 8193], id).is_none());
    }
    #[test]
    fn telemetry_accepts_known_stages_only() {
        assert_eq!(
            scan_stage(br#"{"event":"scan_stage","stage":"pe"}"#),
            Some("pe")
        );
        assert_eq!(scan_stage(br#"{"event":"sample","stage":"pe"}"#), None);
        assert_eq!(
            scan_stage(br#"{"event":"scan_stage","stage":"execute"}"#),
            None
        );
        assert_eq!(scan_stage(b"bad json"), None);
        assert_eq!(scan_stage(&[b' '; 129]), None);
    }
    #[test]
    fn export_rejects_arbitrary_bytes_and_unbounded_dimensions() {
        assert!(!validate_card(b"not an image"));
        let mut image = b"\x89PNG\r\n\x1a\n\0\0\0\rIHDR".to_vec();
        image.extend_from_slice(&1200_u32.to_be_bytes());
        image.extend_from_slice(&1800_u32.to_be_bytes());
        image.extend_from_slice(&[0; 9]);
        image.extend_from_slice(b"\0\0\0\0IEND\xaeB`\x82");
        assert!(validate_card(&image));
        image[16..20].copy_from_slice(&2001_u32.to_be_bytes());
        assert!(!validate_card(&image));
    }
}
