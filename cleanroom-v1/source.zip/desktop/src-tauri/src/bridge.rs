//! Narrow validation for engine telemetry and generated report images.

pub fn scan_stage(line: &[u8]) -> Option<&'static str> {
    if line.len() > 128 {
        return None;
    }
    let value: serde_json::Value = serde_json::from_slice(line).ok()?;
    if value.get("event")?.as_str()? != "scan_stage" {
        return None;
    }
    match value.get("stage")?.as_str()? {
        "updates" => Some("updates"),
        "capture" => Some("capture"),
        "reputation" => Some("reputation"),
        "strings" => Some("strings"),
        "native" => Some("native"),
        "script" => Some("script"),
        "rules" => Some("rules"),
        "pe" => Some("pe"),
        "dotnet" => Some("dotnet"),
        "archive" => Some("archive"),
        "context" => Some("context"),
        "finalizing" => Some("finalizing"),
        _ => None,
    }
}

pub fn validate_card(bytes: &[u8]) -> bool {
    // Only a bounded generated PNG is saved. No sample path is accepted here.
    if bytes.len() < 45
        || bytes.len() > 6 * 1024 * 1024
        || &bytes[..8] != b"\x89PNG\r\n\x1a\n"
        || &bytes[8..16] != b"\0\0\0\rIHDR"
        || &bytes[bytes.len() - 12..] != b"\0\0\0\0IEND\xaeB`\x82"
    {
        return false;
    }
    let width = u32::from_be_bytes(bytes[16..20].try_into().unwrap());
    let height = u32::from_be_bytes(bytes[20..24].try_into().unwrap());
    (1..=2000).contains(&width) && (1..=2600).contains(&height)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn telemetry_accepts_known_stages_only() {
        assert_eq!(
            scan_stage(br#"{"event":"scan_stage","stage":"pe"}"#),
            Some("pe")
        );
        assert_eq!(scan_stage(br#"{"event":"sample","stage":"pe"}"#), None);
        assert_eq!(
            scan_stage(br#"{"event":"scan_stage","stage":"execute"}"#),
            None
        );
        assert_eq!(scan_stage(b"bad json"), None);
        assert_eq!(scan_stage(&[b' '; 129]), None);
    }
    #[test]
    fn export_rejects_arbitrary_bytes_and_unbounded_dimensions() {
        assert!(!validate_card(b"not an image"));
        let mut image = b"\x89PNG\r\n\x1a\n\0\0\0\rIHDR".to_vec();
        image.extend_from_slice(&1200_u32.to_be_bytes());
        image.extend_from_slice(&1800_u32.to_be_bytes());
        image.extend_from_slice(&[0; 9]);
        image.extend_from_slice(b"\0\0\0\0IEND\xaeB`\x82");
        assert!(validate_card(&image));
        image[16..20].copy_from_slice(&2001_u32.to_be_bytes());
        assert!(!validate_card(&image));
    }
}
