//! Wait for the fixed installed administrator updater, then authenticate its result.
use std::path::Path;

#[cfg(windows)]
pub fn run(exe: &Path, id: &str, app: &tauri::AppHandle) -> Result<serde_json::Value, String> {
    use std::ffi::{c_void, OsStr};
    use std::io::Read;
    use std::os::windows::ffi::OsStrExt;
    use std::path::PathBuf;
    use std::time::{Duration, Instant};
    use tauri::Emitter;

    #[repr(C)]
    struct ShellExecuteInfo {
        size: u32,
        mask: u32,
        window: isize,
        verb: *const u16,
        file: *const u16,
        arguments: *const u16,
        directory: *const u16,
        show: i32,
        instance: isize,
        id_list: *mut c_void,
        class: *const u16,
        class_key: isize,
        hotkey: u32,
        icon: isize,
        process: isize,
    }
    #[link(name = "shell32")]
    extern "system" {
        fn ShellExecuteExW(info: *mut ShellExecuteInfo) -> i32;
        fn SHGetFolderPathW(
            window: isize,
            folder: i32,
            token: isize,
            flags: u32,
            path: *mut u16,
        ) -> i32;
    }
    #[link(name = "kernel32")]
    extern "system" {
        fn WaitForSingleObject(handle: isize, timeout: u32) -> u32;
        fn GetExitCodeProcess(handle: isize, code: *mut u32) -> i32;
        fn TerminateProcess(handle: isize, code: u32) -> i32;
        fn CloseHandle(handle: isize) -> i32;
    }
    struct Handle(isize);
    impl Drop for Handle {
        fn drop(&mut self) {
            unsafe {
                CloseHandle(self.0);
            }
        }
    }
    let wide = |s: &OsStr| s.encode_wide().chain(Some(0)).collect::<Vec<u16>>();
    let verb = wide(OsStr::new("runas"));
    let file = wide(exe.as_os_str());
    let arguments = wide(OsStr::new(&format!("--desktop-update {}", id)));
    let directory = wide(exe.parent().ok_or("Invalid engine directory")?.as_os_str());
    let mut info = ShellExecuteInfo {
        size: std::mem::size_of::<ShellExecuteInfo>() as u32,
        mask: 0x40 | 0x100,
        window: 0,
        verb: verb.as_ptr(),
        file: file.as_ptr(),
        arguments: arguments.as_ptr(),
        directory: directory.as_ptr(),
        show: 0,
        instance: 0,
        id_list: std::ptr::null_mut(),
        class: std::ptr::null(),
        class_key: 0,
        hotkey: 0,
        icon: 0,
        process: 0,
    };
    if unsafe { ShellExecuteExW(&mut info) } == 0 || info.process == 0 {
        return Err("UPDATE_APPROVAL_DECLINED".into());
    }
    let process = Handle(info.process);
    let mut folder = vec![0u16; 32768];
    if unsafe { SHGetFolderPathW(0, 0x23, 0, 0, folder.as_mut_ptr()) } != 0 {
        return Err("UPDATE_PROGRESS_UNAVAILABLE".into());
    }
    let end = folder
        .iter()
        .position(|c| *c == 0)
        .ok_or("Invalid ProgramData path")?;
    let path =
        PathBuf::from(String::from_utf16(&folder[..end]).map_err(|_| "Invalid ProgramData path")?)
            .join("MalGuardSecurityUpdates")
            .join(format!("refresh-{}.json", id));
    let started = Instant::now();
    let mut trusted_directory = false;
    let mut last = Vec::new();
    loop {
        // The first read uses the engine's owner/DACL checks. Ordinary users
        // cannot replace subsequent records in this protected directory.
        let bytes = if path.is_file() && !trusted_directory {
            match super::run_engine(exe, "--desktop-update-status", Some(Path::new(id)), None) {
                Ok(value) => {
                    trusted_directory = true;
                    serde_json::to_vec(&value).unwrap_or_default()
                }
                Err(_) => Vec::new(),
            }
        } else if trusted_directory {
            let mut bytes = Vec::new();
            if let Ok(file) = std::fs::File::open(&path) {
                let _ = file.take(8193).read_to_end(&mut bytes);
            }
            bytes
        } else {
            Vec::new()
        };
        if bytes != last {
            if let Some(progress) = super::bridge::update_progress(&bytes, id) {
                let _ = app.emit_to("main", "update-progress", progress);
            }
            last = bytes;
        }
        match unsafe { WaitForSingleObject(process.0, 200) } {
            0 => break,
            258 => {}
            _ => return Err("UPDATE_PROCESS_UNAVAILABLE".into()),
        }
        if started.elapsed() > Duration::from_secs(150) {
            unsafe {
                TerminateProcess(process.0, 4);
                WaitForSingleObject(process.0, 2000);
            }
            return Err("UPDATE_TIMED_OUT".into());
        }
    }
    let mut exit = 0;
    if unsafe { GetExitCodeProcess(process.0, &mut exit) } == 0 || ![0, 4].contains(&exit) {
        return Err("UPDATE_DID_NOT_COMPLETE".into());
    }
    let result = super::run_engine(exe, "--desktop-update-status", Some(Path::new(id)), None)?;
    if ![Some("complete"), Some("failed")].contains(&result.get("stage").and_then(|s| s.as_str())) {
        return Err("UPDATE_DID_NOT_COMPLETE".into());
    }
    Ok(result)
}

#[cfg(not(windows))]
pub fn run(_: &Path, _: &str, _: &tauri::AppHandle) -> Result<serde_json::Value, String> {
    Err("This package requires Windows".into())
}
