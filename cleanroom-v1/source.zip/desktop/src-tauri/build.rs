fn main() {
    println!("cargo:rerun-if-env-changed=GITHUB_SHA");
    tauri_build::build();
}
