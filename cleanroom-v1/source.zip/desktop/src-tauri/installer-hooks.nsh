!macro NSIS_HOOK_PREINSTALL
  ${If} $INSTDIR != "$PROGRAMFILES64\MalGuard"
    IfSilent +2
    MessageBox MB_OK|MB_ICONSTOP "The signed SYSTEM updater requires installation in Program Files\MalGuard."
    SetErrorLevel 30
    Abort
  ${EndIf}
!macroend

!macro NSIS_HOOK_POSTINSTALL
  ; Capture bounded, non-secret diagnostics from the trusted protection helper.
  nsExec::ExecToStack /TIMEOUT=30000 '"$WINDIR\SysWOW64\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "$INSTDIR\engine\protect-install.ps1" -Directory "$INSTDIR"'
  Pop $0
  Pop $1
  FileOpen $2 "$INSTDIR\installer-protection.log" w
  FileWrite $2 "Protection exit: $0$\r$\nWindows directory: $WINDIR$\r$\nInstallation directory: $INSTDIR$\r$\n$1$\r$\n"
  FileClose $2
  ${If} $0 != 0
    IfSilent +2
    MessageBox MB_OK|MB_ICONSTOP "Updater code protection failed. No SYSTEM update task will be registered."
    SetErrorLevel 31
    Abort
  ${EndIf}
  ; Replace the previous console application's owned per-user shortcuts.
  SetShellVarContext current
  CreateDirectory "$SMPROGRAMS\MalGuard"
  CreateShortCut "$SMPROGRAMS\MalGuard\MalGuard.lnk" "$INSTDIR\${MAINBINARYNAME}.exe"
  CreateShortCut "$DESKTOP\MalGuard.lnk" "$INSTDIR\${MAINBINARYNAME}.exe"
  SetShellVarContext all
  ; Trusted installed engine only; no scanned file is ever launched.
  nsExec::ExecToLog /TIMEOUT=120000 '"$INSTDIR\engine\MalGuard.exe" --refresh-security'
  Pop $0
  nsExec::ExecToLog '"$SYSDIR\schtasks.exe" /Create /TN "MalGuard Signed Security Update" /TR "\"$INSTDIR\engine\MalGuard.exe\" --refresh-security" /SC DAILY /ST 03:00 /RU SYSTEM /RL HIGHEST /F'
  Pop $0
  ${If} $0 != 0
    DetailPrint "Daily update scheduling failed. Use the update button after installation."
  ${EndIf}
!macroend

!macro NSIS_HOOK_PREUNINSTALL
  SetShellVarContext current
  Delete "$SMPROGRAMS\MalGuard\MalGuard.lnk"
  RMDir "$SMPROGRAMS\MalGuard"
  Delete "$DESKTOP\MalGuard.lnk"
  SetShellVarContext all
  nsExec::ExecToLog '"$SYSDIR\schtasks.exe" /Delete /TN "MalGuard Signed Security Update" /F'
  Pop $0
  ; Retain reports and signed security history; never recursively delete user data.
!macroend
