!macro NSIS_HOOK_POSTINSTALL
  ; Replace the previous console application's owned per-user shortcuts.
  SetShellVarContext current
  CreateDirectory "$SMPROGRAMS\MalGuard"
  CreateShortCut "$SMPROGRAMS\MalGuard\MalGuard.lnk" "$INSTDIR\${MAINBINARYNAME}.exe"
  CreateShortCut "$DESKTOP\MalGuard.lnk" "$INSTDIR\${MAINBINARYNAME}.exe"
  SetShellVarContext all
  ; Trusted installed engine only; no scanned file is ever launched.
  nsExec::ExecToLog /TIMEOUT=120000 '"$INSTDIR\engine\MalGuard.exe" --refresh-security'
  Pop $0
  nsExec::ExecToLog '"$SYSDIR\schtasks.exe" /Create /TN "MalGuard Signed Security Update" /TR "\"$INSTDIR\engine\MalGuard.exe\" --refresh-security" /SC DAILY /ST 03:00 /RU SYSTEM /RL HIGHEST /F'
  Pop $0
  ${If} $0 != 0
    DetailPrint "Daily update scheduling failed. Use the update button after installation."
  ${EndIf}
!macroend

!macro NSIS_HOOK_PREUNINSTALL
  SetShellVarContext current
  Delete "$SMPROGRAMS\MalGuard\MalGuard.lnk"
  RMDir "$SMPROGRAMS\MalGuard"
  Delete "$DESKTOP\MalGuard.lnk"
  SetShellVarContext all
  nsExec::ExecToLog '"$SYSDIR\schtasks.exe" /Delete /TN "MalGuard Signed Security Update" /F'
  Pop $0
  ; Retain reports and signed security history; never recursively delete user data.
!macroend
