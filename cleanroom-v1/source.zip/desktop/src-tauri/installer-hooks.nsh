!macro NSIS_HOOK_POSTINSTALL
  ; Trusted installed engine only; no scanned file is ever launched.
  ExecWait '"$INSTDIR\engine\MalGuard.exe" --refresh-security' $0
  ExecWait '"$SYSDIR\schtasks.exe" /Create /TN "MalGuard Signed Security Update" /TR "\"$INSTDIR\engine\MalGuard.exe\" --refresh-security" /SC DAILY /ST 03:00 /RU SYSTEM /RL HIGHEST /F' $0
  ${If} $0 != 0
    DetailPrint "Daily update scheduling failed. Use the update button after installation."
  ${EndIf}
!macroend

!macro NSIS_HOOK_PREUNINSTALL
  ExecWait '"$SYSDIR\schtasks.exe" /Delete /TN "MalGuard Signed Security Update" /F' $0
  ; Retain reports and signed security history; never recursively delete user data.
!macroend
