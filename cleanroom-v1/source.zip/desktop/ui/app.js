"use strict";
const el = (id) => document.getElementById(id);
const invoke = (name, args = {}) => window.__TAURI__.core.invoke(name, args);
const catalogs = {
  en: {
    local: "LOCAL · STATIC ANALYSIS",
    version: "Desktop 1.3 · Windows",
    language: "Language",
    eyebrow: "GTA V · MOD INSPECTION",
    title: "Inspect before you install.",
    intro:
      "Understand the file, examine the evidence, then decide. Analysis stays on your device. Your files are never uploaded or executed.",
    intelligence: "Signed threat intelligence",
    update: "Get signed update",
    status: "Check status",
    updateDetails: "How updates work",
    schedule:
      "Daily at 03:00 in your Windows local time, while the PC is on and online. The installer task may catch up after a missed run.",
    admin:
      "Manual updates ask for administrator approval to write signed data into the protected cache. They update threat hashes and rules, not the application. Your selected file is never sent to the updater.",
    feedScope:
      "The count is the number of verified SHA-256 records in this feed, not a count of every threat. A hash match identifies those exact bytes; no match does not prove safety.",
    step: "01 / FILE INSPECTION",
    scanHeading: "What are you installing?",
    private: "Private by design",
    noFile: "Choose a file to begin.",
    formats: "ASI / DLL · ZIP / 7Z / RAR · Lua / C# · INI / CFG / XML",
    typeFirst: "The contents are identified before a result is given.",
    choose: "Choose file",
    scan: "Start inspection →",
    working: "Inspecting",
    staticOnly: "Static analysis · no execution",
    completed: "STATIC INSPECTION COMPLETE",
    more: "View report card ↗",
    back: "↶ Back to result",
    save: "Save full JSON report",
    downloadCard: "Download card · PNG",
    cardKicker: "FILE INSPECTION RECORD",
    preview: "Bounded text preview · secrets redacted",
    previewSample:
      "Preview from the first {bytes} bytes; this is not the full file.",
    evidence: "Evidence & analysis coverage",
    cardDisclaimer:
      "This is a static inspection record, not a certificate of safety. The score measures collected evidence, not the probability of infection.",
    fullReport: "Full analysis details",
    footer:
      "No evidence found is not a guarantee of safety. Missing intelligence, unsupported formats or incomplete required analysis prevent a SAFE result.",
    checking: "Checking signed data…",
    fresh: "Signed cache verified · current",
    hashes: "unique SHA-256 records",
    stale: "Signed cache verified · stale. Refresh it; SAFE remains blocked.",
    missing:
      "No authenticated online cache is available. SAFE remains blocked.",
    signedFacts: "Signed: {date} · Signer: {key} · Version: {version}",
    saved: "Report saved to a new file.",
    cardSaved: "Report card saved to a new PNG file.",
    started:
      "Updater requested; completion is not yet confirmed. Check status to authenticate the cached data.",
    starting: "Starting local engine",
    scanning: "Inspecting captured bytes. File contents are never executed.",
    done: "Inspection complete.",
    failed: "Inspection did not complete. No safety approval was issued.",
    invalidReport: "Invalid engine report",
    metrics:
      "Analysis coverage: {coverage}% · Verdict confidence: {confidence}%",
    risk: "Evidence risk",
    unknown: "Unknown",
    riskNote: "0–100 · collected evidence",
    unknownNote: "Not validated · no safety approval",
    SAFE: "No malicious evidence found",
    SUSPICIOUS: "Suspicious evidence found",
    MALICIOUS: "Malicious evidence found",
    INVALID: "Structure could not be validated",
    INCONCLUSIVE: "Could not establish safety",
    unsupportedTitle: "This file is outside GTA mod validation",
    mismatchTitle: "File contents do not match its claimed format",
    malformedTitle: "The recognized format has an invalid internal structure",
    emptyTitle: "This file is empty",
    unavailableTitle: "File contents could not be captured reliably",
    unsupportedVerdict: "Outside mod validation",
    unsupportedAdvice:
      "Do not install this file as a GTA mod based on this result. Obtain the original mod package and inspect it.",
    SAFEAdvice:
      "No malicious evidence was found in completed checks. Review the source and permissions before installing; static analysis cannot guarantee safety.",
    SUSPICIOUSAdvice:
      "Do not install until the suspicious evidence has been investigated.",
    MALICIOUSAdvice:
      "Do not place this file in GTA or run it. The report retains the evidence.",
    INVALIDAdvice:
      "Obtain a complete original package and inspect it again. A format error does not establish that the file is safe.",
    INCONCLUSIVEAdvice:
      "Required checks did not establish safety. Resolve the listed limitations before installing.",
    headerOnly:
      "Identification is based on a format header; the media/document structure was not fully validated.",
    filename: "File",
    fileType: "Detected content",
    size: "Size",
    scope: "Validation scope",
    scope_supported: "Recognized analysis format",
    scope_unsupported: "Outside direct mod validation",
    scope_mismatch: "Content / extension mismatch",
    scope_malformed: "Internal structure invalid",
    scope_empty: "Empty file",
    scope_unavailable: "Content unavailable",
    sha: "SHA-256 · captured bytes",
    coverage: "Coverage",
    confidence: "Verdict confidence",
    engine: "Engine / ruleset",
    threatData: "Threat data",
    signature: "Signature",
    verified: "Verified",
    notVerified: "Unavailable",
    encoding: "Text encoding",
    reason: "Explanation",
    supported: "Formats analyzed",
    noEvidence:
      "No malicious evidence was recorded. This alone does not establish safety.",
    moreEvidence: "{count} more evidence records in the full JSON report.",
    stage_COMPLETE: "Complete",
    stage_PARTIAL: "Partial",
    stage_FAILED: "Failed",
    stage_BLOCKED: "Blocked",
    stage_UNAVAILABLE: "Unavailable",
    stage_SKIPPED_LIMIT: "Limit reached",
    stage_TIMEOUT: "Timed out",
    stage_NOT_APPLICABLE: "Not applicable",
    stage_unknown: "Not complete",
    updates: "Verifying signed intelligence",
    capture: "Capturing bytes & identifying format",
    reputation: "Checking authenticated hashes",
    strings: "Inspecting strings & bounded decoding",
    native: "Inspecting native indicators",
    script: "Analysing script structure",
    rules: "Matching static rules",
    pe: "Parsing Windows PE structure",
    dotnet: "Inspecting .NET metadata",
    archive: "Inspecting archive & nested files",
    context: "Assessing evidence & coverage",
    finalizing: "Preparing the result",
  },
  fa: {
    local: "تحلیل ایستا · روی دستگاه شما",
    version: "نسخهٔ گرافیکی ۱.۳ · Windows",
    language: "زبان",
    eyebrow: "GTA V · بررسی فایل ماد",
    title: "قبل از نصب ماد، بررسی کنید.",
    intro:
      "نوع فایل را بشناسید، شواهد را ببینید و سپس تصمیم بگیرید. تحلیل روی دستگاه شما می‌ماند؛ فایل شما هرگز آپلود یا اجرا نمی‌شود.",
    intelligence: "اطلاعات تهدید امضاشده",
    update: "دریافت به‌روزرسانی امضاشده",
    status: "بررسی وضعیت",
    updateDetails: "به‌روزرسانی چگونه کار می‌کند؟",
    schedule:
      "هر روز ساعت ۳ به وقت محلی ویندوز، وقتی رایانه روشن و آنلاین باشد. وظیفهٔ نصب‌کننده ممکن است نوبت ازدست‌رفته را پس از روشن‌شدن جبران کند.",
    admin:
      "به‌روزرسانی دستی برای نوشتن دادهٔ امضاشده در محل محافظت‌شده، اجازهٔ مدیر سیستم می‌خواهد. هش‌ها و قواعد تهدید به‌روز می‌شوند، نه خود برنامه. فایل انتخابی شما به به‌روزرسان ارسال نمی‌شود.",
    feedScope:
      "عدد نمایش‌داده‌شده تعداد رکوردهای SHA-256 تأییدشدهٔ همین فهرست است، نه تعداد همهٔ تهدیدها. تطبیق هش فقط همان بایت‌ها را شناسایی می‌کند؛ نبود تطبیق، ایمنی را ثابت نمی‌کند.",
    step: "۰۱ / بررسی فایل",
    scanHeading: "چه فایلی را نصب می‌کنید؟",
    private: "با حفظ حریم خصوصی",
    noFile: "برای شروع، یک فایل انتخاب کنید.",
    formats: "ASI / DLL · ZIP / 7Z / RAR · Lua / C# · INI / CFG / XML",
    typeFirst: "پیش از اعلام نتیجه، محتوای فایل شناسایی می‌شود.",
    choose: "انتخاب فایل",
    scan: "شروع بررسی ←",
    working: "در حال بررسی",
    staticOnly: "تحلیل ایستا · بدون اجرا",
    completed: "بررسی ایستا تکمیل شد",
    more: "نمایش کارت گزارش ↖",
    back: "↷ بازگشت به نتیجه",
    save: "ذخیرهٔ گزارش کامل JSON",
    downloadCard: "دانلود کارت · PNG",
    cardKicker: "گزارش بررسی فایل",
    preview: "پیش‌نمایش محدود متن · اطلاعات حساس حذف شده",
    previewSample: "نمونه از {bytes} بایت نخست؛ تمام محتوای فایل نیست.",
    evidence: "شواهد و پوشش تحلیل",
    cardDisclaimer:
      "این کارت گزارش بررسی ایستا است، نه گواهی ایمنی. امتیاز میزان شواهد جمع‌آوری‌شده است، نه احتمال آلودگی.",
    fullReport: "جزئیات کامل تحلیل",
    footer:
      "پیدانشدن شواهد، تضمین ایمنی نیست. اطلاعات تهدید ناموجود، قالب خارج از پوشش یا تحلیل ضروری ناقص، اجازهٔ صدور نتیجهٔ SAFE نمی‌دهد.",
    checking: "در حال بررسی دادهٔ امضاشده…",
    fresh: "فهرست ذخیره‌شده تأیید شد · به‌روز",
    hashes: "رکورد یکتای SHA-256",
    stale:
      "امضای فهرست تأیید شد · داده قدیمی است. به‌روز کنید؛ نتیجهٔ سالم صادر نمی‌شود.",
    missing: "فهرست آنلاین تأییدشده در دسترس نیست؛ نتیجهٔ سالم صادر نمی‌شود.",
    signedFacts: "زمان امضا: {date} · کلید: {key} · نسخه: {version}",
    saved: "گزارش در فایل جدید ذخیره شد.",
    cardSaved: "کارت گزارش در فایل PNG جدید ذخیره شد.",
    started:
      "به‌روزرسان درخواست شد؛ پایان دریافت هنوز تأیید نشده است. با بررسی وضعیت، دادهٔ ذخیره‌شده را تأیید کنید.",
    starting: "در حال آغاز موتور محلی",
    scanning: "بایت‌های دریافت‌شده بررسی می‌شوند؛ محتوای فایل اجرا نمی‌شود.",
    done: "بررسی تمام شد.",
    failed: "بررسی تکمیل نشد؛ تأیید ایمنی صادر نشده است.",
    invalidReport: "گزارش موتور معتبر نیست",
    metrics: "پوشش تحلیل: {coverage}٪ · اطمینان به نتیجه: {confidence}٪",
    risk: "ریسک بر پایهٔ شواهد",
    unknown: "نامشخص",
    riskNote: "۰ تا ۱۰۰ · شواهد جمع‌آوری‌شده",
    unknownNote: "تأیید نشده · بدون تأیید ایمنی",
    SAFE: "شواهد مخرب پیدا نشد",
    SUSPICIOUS: "شواهد مشکوک پیدا شد",
    MALICIOUS: "شواهد مخرب پیدا شد",
    INVALID: "ساختار قابل تأیید نیست",
    INCONCLUSIVE: "ایمنی قابل تأیید نیست",
    unsupportedTitle: "این فایل خارج از پوشش تأیید ماد GTA است",
    mismatchTitle: "محتوای فایل با قالب ادعاشده مطابقت ندارد",
    malformedTitle: "ساختار داخلی قالب شناسایی‌شده معتبر نیست",
    emptyTitle: "این فایل خالی است",
    unavailableTitle: "محتوای فایل به‌طور قابل اتکا دریافت نشد",
    unsupportedVerdict: "خارج از پوشش تأیید ماد",
    unsupportedAdvice:
      "با اتکا به این نتیجه، این فایل را به‌عنوان ماد در GTA نصب نکنید. بستهٔ اصلی ماد را دریافت و بررسی کنید.",
    SAFEAdvice:
      "در بررسی‌های تکمیل‌شده شواهد مخرب پیدا نشد. پیش از نصب، منبع و مجوزها را بررسی کنید؛ تحلیل ایستا تضمین ایمنی نیست.",
    SUSPICIOUSAdvice: "تا بررسی شواهد مشکوک، این فایل را نصب نکنید.",
    MALICIOUSAdvice:
      "این فایل را در GTA قرار ندهید یا اجرا نکنید. شواهد در گزارش ثبت شده است.",
    INVALIDAdvice:
      "بستهٔ اصلی و کامل را دریافت و دوباره بررسی کنید. خطای قالب، ایمنی فایل را ثابت نمی‌کند.",
    INCONCLUSIVEAdvice:
      "بررسی‌های ضروری ایمنی را ثابت نکردند. پیش از نصب، محدودیت‌های گزارش را برطرف کنید.",
    headerOnly:
      "تشخیص از سرآیند قالب است؛ ساختار کامل رسانه یا سند تأیید نشده است.",
    filename: "فایل",
    fileType: "محتوای شناسایی‌شده",
    size: "اندازه",
    scope: "پوشش تأیید",
    scope_supported: "قالب شناخته‌شده برای تحلیل",
    scope_unsupported: "خارج از تأیید مستقیم ماد",
    scope_mismatch: "ناهمخوانی محتوا و پسوند",
    scope_malformed: "ساختار داخلی نامعتبر",
    scope_empty: "فایل خالی",
    scope_unavailable: "محتوا در دسترس نیست",
    sha: "SHA-256 · بایت‌های دریافت‌شده",
    coverage: "پوشش",
    confidence: "اطمینان به نتیجه",
    engine: "موتور / قواعد",
    threatData: "اطلاعات تهدید",
    signature: "امضا",
    verified: "تأییدشده",
    notVerified: "در دسترس نیست",
    encoding: "کدگذاری متن",
    reason: "توضیح",
    supported: "قالب‌های قابل تحلیل",
    noEvidence:
      "شواهد مخرب ثبت نشده است. این موضوع به‌تنهایی ایمنی را ثابت نمی‌کند.",
    moreEvidence: "{count} رکورد شواهد دیگر در گزارش کامل JSON موجود است.",
    stage_COMPLETE: "کامل",
    stage_PARTIAL: "ناقص",
    stage_FAILED: "ناموفق",
    stage_BLOCKED: "مسدود",
    stage_UNAVAILABLE: "ناموجود",
    stage_SKIPPED_LIMIT: "محدودیت بودجه",
    stage_TIMEOUT: "پایان زمان",
    stage_NOT_APPLICABLE: "نامرتبط",
    stage_unknown: "تکمیل نشده",
    updates: "تأیید اطلاعات امضاشده",
    capture: "دریافت بایت‌ها و تشخیص قالب",
    reputation: "تطبیق هش‌های تأییدشده",
    strings: "بررسی رشته‌ها و رمزگشایی محدود",
    native: "بررسی نشانه‌های بومی",
    script: "تحلیل ساختار اسکریپت",
    rules: "تطبیق قواعد ایستا",
    pe: "تحلیل ساختار PE ویندوز",
    dotnet: "بررسی فرادادهٔ دات‌نت",
    archive: "بررسی آرشیو و فایل‌های داخل آن",
    context: "سنجش شواهد و پوشش تحلیل",
    finalizing: "آماده‌سازی نتیجه",
  },
};
const stages = new Set([
  "updates",
  "capture",
  "reputation",
  "strings",
  "native",
  "script",
  "rules",
  "pe",
  "dotnet",
  "archive",
  "context",
  "finalizing",
]);
let language = "en",
  lastResult = null,
  lastStatus = null,
  activeScanId = null,
  currentStage = null,
  completedAt = null,
  build = "";
try {
  const saved = localStorage.getItem("malguard-language");
  if (Object.hasOwn(catalogs, saved)) language = saved;
} catch {}
function t(key, values = {}) {
  let value = catalogs[language][key] || catalogs.en[key] || key;
  for (const [name, text] of Object.entries(values))
    value = value.replaceAll("{" + name + "}", String(text));
  return value;
}
function number(value) {
  return new Intl.NumberFormat(language === "fa" ? "fa-IR" : "en-US", {
    maximumFractionDigits: 1,
  }).format(value);
}
function size(value, known = true) {
  if (known === false) return t("unknown");
  return number(value) + " " + (language === "fa" ? "بایت" : "bytes");
}
function date(value) {
  const parsed = new Date(value);
  return Number.isFinite(parsed.getTime())
    ? parsed.toLocaleString(language === "fa" ? "fa-IR" : "en-US")
    : t("notVerified");
}
function txt(id, value) {
  if (id === "scanStatus") el(id).removeAttribute("data-i18n");
  el(id).textContent = value;
}
function scanMessage(key) {
  txt("scanStatus", t(key));
  el("scanStatus").dataset.i18n = key;
}
function phase(value) {
  el("scanShell").dataset.phase = value;
  el("filePrompt").hidden = value !== "ready";
  el("scanProgress").hidden = value !== "scanning";
  el("result").hidden = value !== "complete";
}
function flip(back) {
  el("reportFlip").classList.toggle("is-flipped", back);
  el("resultFront").inert = back;
  el("resultFront").setAttribute("aria-hidden", String(back));
  el("resultBack").inert = !back;
  el("resultBack").setAttribute("aria-hidden", String(!back));
  el("detailsButton").setAttribute("aria-expanded", String(back));
}
function reportRoot(report) {
  return (
    report.artifacts.find(
      (item) => item.artifact_id === report.root_artifact_id,
    ) ||
    report.artifacts.find((item) => !item.parent_id) ||
    report.artifacts[0]
  );
}
function outside() {
  return lastResult.file_inspection.scope_state !== "supported";
}
function riskValue() {
  const r = lastResult.report;
  return ["INVALID", "INCONCLUSIVE"].includes(r.verdict) ? null : r.risk_score;
}
function headline() {
  const r = lastResult.report;
  return outside() && r.verdict === "INCONCLUSIVE"
    ? t("unsupportedVerdict")
    : t(r.verdict);
}
function advice() {
  return outside() &&
    !["MALICIOUS", "SUSPICIOUS"].includes(lastResult.report.verdict)
    ? t("unsupportedAdvice")
    : t(lastResult.report.verdict + "Advice");
}
function svgNode(tag, attrs = {}) {
  const node = document.createElementNS("http://www.w3.org/2000/svg", tag);
  for (const [key, value] of Object.entries(attrs))
    node.setAttribute(key, String(value));
  return node;
}
function gauge(target) {
  const risk = riskValue(),
    unknown = risk === null,
    svg = svgNode("svg", {
      viewBox: "0 0 200 118",
      role: "img",
      "aria-label":
        t("risk") + ": " + (unknown ? t("unknown") : risk + " / 100"),
    });
  const point = (angle) => [
    100 + 78 * Math.cos((angle * Math.PI) / 180),
    96 + 78 * Math.sin((angle * Math.PI) / 180),
  ];
  const arc = (a, b, color) => {
    const p = point(a),
      q = point(b);
    svg.append(
      svgNode("path", {
        d: `M ${p[0]} ${p[1]} A 78 78 0 0 1 ${q[0]} ${q[1]}`,
        fill: "none",
        stroke: color,
        "stroke-width": 9,
        "stroke-linecap": "round",
      }),
    );
  };
  if (unknown) arc(180, 360, "#73818a");
  else {
    arc(180, 233, "#3cb98f");
    arc(237, 296, "#ddb64c");
    arc(300, 360, "#e17672");
  }
  for (const [label, angle] of [
    [0, 180],
    [50, 270],
    [100, 360],
  ]) {
    const p = [
      100 + 94 * Math.cos((angle * Math.PI) / 180),
      96 + 94 * Math.sin((angle * Math.PI) / 180),
    ];
    const node = svgNode("text", {
      x: p[0],
      y: p[1] + 3,
      "text-anchor": "middle",
      class: "gauge-label",
    });
    node.textContent = label;
    svg.append(node);
  }
  if (!unknown)
    svg.append(
      svgNode("line", {
        x1: 100,
        y1: 96,
        x2: 40,
        y2: 96,
        transform: `rotate(${risk * 1.8} 100 96)`,
        class: "gauge-needle",
      }),
    );
  svg.append(svgNode("circle", { cx: 100, cy: 96, r: 5, class: "gauge-hub" }));
  const label = document.createElement("p");
  label.className = "gauge-name";
  label.textContent = t("risk");
  const value = document.createElement("p");
  value.className = "gauge-value";
  value.textContent = unknown
    ? t("unknown")
    : number(risk) + " / " + number(100);
  const note = document.createElement("p");
  note.className = "gauge-foot";
  note.textContent = t(unknown ? "unknownNote" : "riskNote");
  el(target).replaceChildren(svg, label, value, note);
}
function factRows() {
  const f = lastResult.file_inspection,
    r = lastResult.report,
    root = reportRoot(r),
    s = lastResult.updates;
  return [
    [t("fileType"), f["label_" + language]],
    [t("size"), size(f.file_size, f.size_known)],
    [t("scope"), t("scope_" + f.scope_state)],
    [t("coverage"), number(r.coverage_score) + "%"],
    [t("confidence"), number(r.confidence) + "%"],
    [t("engine"), r.engine_version + " / " + r.ruleset_version, "code"],
    [
      t("threatData"),
      s.signature_verified
        ? s.version + " · " + number(s.record_count) + " " + t("hashes")
        : t("notVerified"),
    ],
    [
      t("signature"),
      s.signature_verified
        ? t("verified") + " · " + date(s.created_at)
        : t("notVerified"),
    ],
    ...(f.encoding ? [[t("encoding"), f.encoding]] : []),
    [t("sha"), root.hashes.sha256 || t("notVerified"), "hash"],
    [
      t("reason"),
      f["note_" + language] + (f.header_only ? " " + t("headerOnly") : ""),
      "wide",
    ],
    ...(outside()
      ? [[t("supported"), f.supported_formats.join(" · "), "wide"]]
      : []),
  ];
}
function evidenceLines() {
  const e = lastResult.report.evidence;
  const lines = e
    .slice(0, 5)
    .map(
      (item) =>
        item.rule_id +
        " · " +
        (item["explanation_" + language] ||
          item.explanation_en ||
          item["description_" + language] ||
          item.description_en ||
          item.rule_id),
    );
  if (!lines.length) lines.push(t("noEvidence"));
  if (e.length > 5)
    lines.push(t("moreEvidence", { count: number(e.length - 5) }));
  return lines;
}
function renderResult() {
  if (!lastResult) return;
  const r = lastResult.report,
    f = lastResult.file_inspection,
    root = reportRoot(r);
  txt("verdict", headline());
  el("verdict").dataset.verdict = r.verdict;
  txt("resultFilename", f.filename);
  txt(
    "resultFacts",
    f["label_" + language] + " · " + size(f.file_size, f.size_known),
  );
  txt("resultAdvice", advice());
  txt(
    "metrics",
    t("metrics", {
      coverage: number(r.coverage_score),
      confidence: number(r.confidence),
    }),
  );
  el("fileWarning").hidden = !outside();
  const key = {
    unsupported: "unsupportedTitle",
    mismatch: "mismatchTitle",
    malformed: "malformedTitle",
    empty: "emptyTitle",
    unavailable: "unavailableTitle",
  }[f.scope_state];
  txt("warningHeading", t(key || "unsupportedTitle"));
  txt(
    "warningFacts",
    f.filename +
      " · " +
      f["label_" + language] +
      " · " +
      size(f.file_size, f.size_known),
  );
  txt(
    "warningReason",
    f["note_" + language] + (f.header_only ? " " + t("headerOnly") : ""),
  );
  txt("warningAdvice", advice());
  gauge("riskGauge");
  gauge("cardGauge");
  txt("cardVerdict", headline());
  txt("cardFilename", f.filename);
  txt("cardAdvice", advice());
  const facts = el("cardFacts");
  facts.replaceChildren();
  for (const [label, value, style] of factRows()) {
    const row = document.createElement("div");
    row.className = "fact" + (["hash", "wide"].includes(style) ? " wide" : "");
    const dt = document.createElement("dt"),
      dd = document.createElement("dd");
    dt.textContent = label;
    dd.textContent = value;
    if (style === "hash") dd.className = "hash";
    dd.dir = style === "hash" || style === "code" ? "ltr" : "auto";
    row.append(dt, dd);
    facts.append(row);
  }
  el("previewBox").hidden = !f.preview;
  txt("contentPreview", f.preview || "");
  txt("previewNote", t("previewSample", { bytes: number(f.preview_bytes) }));
  el("evidenceList").replaceChildren();
  for (const line of evidenceLines()) {
    const li = document.createElement("li");
    li.textContent = line;
    el("evidenceList").append(li);
  }
  el("stageList").replaceChildren();
  for (const entry of root.coverage) {
    const li = document.createElement("li");
    li.dataset.state = entry.state;
    li.textContent =
      entry.stage +
      " · " +
      t(
        Object.hasOwn(catalogs.en, "stage_" + entry.state)
          ? "stage_" + entry.state
          : "stage_unknown",
      );
    el("stageList").append(li);
  }
  txt("summary", lastResult["summary_" + language]);
  el("summary").lang = language;
  el("summary").dir = language === "fa" ? "rtl" : "ltr";
  txt("cardBuild", build);
  txt("cardDate", date(completedAt));
}
function renderStatus() {
  if (!lastStatus) return;
  const valid =
    lastStatus.available === true && lastStatus.signature_verified === true;
  el("intelligenceHeading").closest(".intelligence").dataset.fresh = String(
    valid && lastStatus.fresh,
  );
  txt(
    "updateStatus",
    valid
      ? t(lastStatus.fresh ? "fresh" : "stale") +
          " · " +
          number(lastStatus.record_count) +
          " " +
          t("hashes")
      : t("missing"),
  );
  txt(
    "updateFacts",
    valid
      ? t("signedFacts", {
          date: date(lastStatus.created_at),
          key: lastStatus.key_id,
          version: lastStatus.version,
        })
      : t("missing"),
  );
}
function setLanguage(value) {
  language = Object.hasOwn(catalogs, value) ? value : "en";
  document.documentElement.lang = language;
  document.documentElement.dir = language === "fa" ? "rtl" : "ltr";
  el("languageSelect").value = language;
  for (const node of document.querySelectorAll("[data-i18n]"))
    node.textContent = t(node.dataset.i18n);
  el("languageSelect").setAttribute("aria-label", t("language"));
  renderResult();
  renderStatus();
  if (activeScanId) txt("progressStage", t(currentStage || "starting"));
  try {
    localStorage.setItem("malguard-language", language);
  } catch {}
}
async function status() {
  el("statusButton").disabled = true;
  try {
    txt("updateStatus", t("checking"));
    lastStatus = await invoke("security_status");
    renderStatus();
  } catch {
    lastStatus = null;
    txt("updateStatus", t("missing"));
    txt("updateFacts", "");
  } finally {
    el("statusButton").disabled = false;
  }
}
function validate(data) {
  const r = data?.report,
    f = data?.file_inspection;
  return (
    r &&
    ["SAFE", "SUSPICIOUS", "MALICIOUS", "INVALID", "INCONCLUSIVE"].includes(
      r.verdict,
    ) &&
    [r.risk_score, r.coverage_score, r.confidence].every(
      (n) => typeof n === "number" && Number.isFinite(n) && n >= 0 && n <= 100,
    ) &&
    Array.isArray(r.artifacts) &&
    r.artifacts.length &&
    Array.isArray(r.evidence) &&
    r.artifacts.every((a) => a.hashes && Array.isArray(a.coverage)) &&
    typeof data.summary_fa === "string" &&
    typeof data.summary_en === "string" &&
    f &&
    typeof f.filename === "string" &&
    typeof f.label_en === "string" &&
    typeof f.label_fa === "string" &&
    typeof f.note_en === "string" &&
    typeof f.note_fa === "string" &&
    [
      "supported",
      "unsupported",
      "mismatch",
      "malformed",
      "empty",
      "unavailable",
    ].includes(f.scope_state) &&
    Number.isSafeInteger(f.file_size) &&
    f.file_size >= 0 &&
    Array.isArray(f.supported_formats) &&
    data.updates &&
    !(
      r.verdict === "SAFE" &&
      (f.scope_state !== "supported" ||
        data.updates.available !== true ||
        data.updates.fresh !== true ||
        data.updates.signature_verified !== true)
    )
  );
}
const progressReady = Promise.resolve().then(() =>
  window.__TAURI__.event.listen("scan-progress", (event) => {
    const p = event.payload;
    if (activeScanId && p?.scanId === activeScanId && stages.has(p.stage)) {
      currentStage = p.stage;
      txt("progressStage", t(p.stage));
    }
  }),
);
progressReady.catch(() => {});
el("languageSelect").addEventListener("change", (event) =>
  setLanguage(event.target.value),
);
el("statusButton").addEventListener("click", status);
el("detailsButton").addEventListener("click", () => {
  flip(true);
  el("backButton").focus({ preventScroll: true });
});
el("backButton").addEventListener("click", () => {
  flip(false);
  el("detailsButton").focus({ preventScroll: true });
});
el("saveButton").addEventListener("click", async () => {
  try {
    if (await invoke("save_report")) scanMessage("saved");
  } catch (error) {
    txt("scanStatus", String(error));
  }
});
el("updateButton").addEventListener("click", async () => {
  el("updateButton").disabled = true;
  try {
    await invoke("refresh_security");
    txt("updateStatus", t("started"));
  } catch (error) {
    txt("updateStatus", String(error));
  } finally {
    el("updateButton").disabled = false;
  }
});
el("chooseButton").addEventListener("click", async () => {
  el("chooseButton").disabled = true;
  try {
    const path = await invoke("choose_file");
    if (path) {
      el("filePath").removeAttribute("data-i18n");
      txt("filePath", path);
      el("scanButton").disabled = false;
      lastResult = null;
      phase("ready");
      flip(false);
      txt("scanStatus", "");
    }
  } catch (error) {
    txt("scanStatus", String(error));
  } finally {
    el("chooseButton").disabled = false;
  }
});
el("scanButton").addEventListener("click", async () => {
  for (const id of [
    "scanButton",
    "chooseButton",
    "languageSelect",
    "updateButton",
    "statusButton",
  ])
    el(id).disabled = true;
  lastResult = null;
  activeScanId = crypto.randomUUID();
  currentStage = null;
  phase("scanning");
  flip(false);
  txt("progressStage", t("starting"));
  scanMessage("scanning");
  try {
    await progressReady;
    const data = await invoke("scan_selected", { scanId: activeScanId });
    if (!validate(data)) throw new Error(t("invalidReport"));
    activeScanId = null;
    lastResult = data;
    completedAt = new Date().toISOString();
    renderResult();
    phase("complete");
    scanMessage("done");
  } catch (error) {
    activeScanId = null;
    phase("ready");
    txt("scanStatus", t("failed") + " " + String(error));
  } finally {
    for (const id of [
      "scanButton",
      "chooseButton",
      "languageSelect",
      "updateButton",
      "statusButton",
    ])
      el(id).disabled = false;
  }
});
// A standalone, local PNG. Text is drawn as text, never interpreted as markup.
function cardCanvas() {
  const canvas = document.createElement("canvas");
  canvas.width = 1200;
  canvas.height = 2600;
  const ctx = canvas.getContext("2d"),
    rtl = language === "fa",
    margin = 85,
    width = 1030;
  let y = 84;
  ctx.fillStyle = "#f0f1e9";
  ctx.fillRect(0, 0, 1200, 2600);
  const wash = ctx.createRadialGradient(1080, 100, 0, 1080, 100, 630);
  wash.addColorStop(0, "#f5e4b2");
  wash.addColorStop(1, "#f0f1e900");
  ctx.fillStyle = wash;
  ctx.fillRect(0, 0, 1200, 850);
  function text(
    value,
    font = 24,
    color = "#203442",
    maxLines = 6,
    forceLtr = false,
    x = margin,
    w = width,
  ) {
    ctx.font = `${font}px "Segoe UI",Tahoma,Arial,sans-serif`;
    ctx.direction = rtl && !forceLtr ? "rtl" : "ltr";
    ctx.textAlign = rtl && !forceLtr ? "right" : "left";
    ctx.fillStyle = color;
    const lines = [];
    for (const paragraph of String(value).split("\n")) {
      let line = "";
      for (const word of paragraph.split(/\s+/)) {
        const candidate = line ? line + " " + word : word;
        if (ctx.measureText(candidate).width > w && line) {
          lines.push(line);
          line = word;
        } else line = candidate;
      }
      lines.push(line);
    }
    const shown = lines.slice(0, maxLines);
    if (lines.length > maxLines) shown[maxLines - 1] += " …";
    for (const part of shown) {
      ctx.fillText(part, rtl && !forceLtr ? x + w : x, y, w);
      y += font * 1.5;
    }
    y += 8;
  }
  text("MALGUARD  /  GTA GUARD", 24, "#64736f", 1, true, margin, 850);
  ctx.beginPath();
  ctx.fillStyle = "#e9d99f";
  ctx.arc(1070, 92, 36, 0, 2 * Math.PI);
  ctx.fill();
  ctx.strokeStyle = "#aa914e";
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(1070, 92, 42, 0, 2 * Math.PI);
  ctx.stroke();
  ctx.font = "32px Arial";
  ctx.direction = "ltr";
  ctx.textAlign = "center";
  ctx.fillStyle = "#65501d";
  ctx.fillText("M", 1070, 103);
  y += 25;
  text(t("cardKicker"), 18, "#6f796f");
  text(headline(), 42, "#203442", 3);
  text(lastResult.file_inspection.filename, 24, "#64736f", 2);
  const risk = riskValue(),
    unknown = risk === null,
    cx = 600,
    cy = y + 140,
    rad = 120;
  ctx.lineWidth = 13;
  ctx.lineCap = "round";
  for (const [a, b, color] of unknown
    ? [[Math.PI, 2 * Math.PI, "#73818a"]]
    : [
        [Math.PI, 1.3 * Math.PI, "#3cb98f"],
        [1.32 * Math.PI, 1.65 * Math.PI, "#ddb64c"],
        [1.67 * Math.PI, 2 * Math.PI, "#e17672"],
      ]) {
    ctx.beginPath();
    ctx.strokeStyle = color;
    ctx.arc(cx, cy, rad, a, b);
    ctx.stroke();
  }
  ctx.font = "16px Arial";
  ctx.textAlign = "center";
  ctx.direction = "ltr";
  ctx.fillStyle = "#64736f";
  for (const [label, x, yy] of [
    ["0", cx - rad - 25, cy + 5],
    ["50", cx, cy - rad - 20],
    ["100", cx + rad + 32, cy + 5],
  ])
    ctx.fillText(label, x, yy);
  if (!unknown) {
    const a = Math.PI + (risk / 100) * Math.PI;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.lineTo(cx + 95 * Math.cos(a), cy + 95 * Math.sin(a));
    ctx.strokeStyle = "#203442";
    ctx.lineWidth = 5;
    ctx.stroke();
  }
  ctx.fillStyle = "#203442";
  ctx.beginPath();
  ctx.arc(cx, cy, 7, 0, 2 * Math.PI);
  ctx.fill();
  y = cy + 50;
  text(
    t("risk") +
      ": " +
      (unknown ? t("unknown") : number(risk) + " / " + number(100)),
    26,
    "#203442",
    2,
  );
  text(t(unknown ? "unknownNote" : "riskNote"), 18, "#64736f", 2);
  text(advice(), 22, "#203442", 3);
  y += 12;
  ctx.strokeStyle = "#bac3b5";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(margin, y);
  ctx.lineTo(1115, y);
  ctx.stroke();
  y += 35;
  const rows = factRows();
  let pending = null;
  for (const [label, value, style] of rows) {
    if (style && style !== "code") {
      if (pending !== null) {
        y = pending + 16;
        pending = null;
      }
      text(label, 17, "#64736f", 1);
      text(value, style === "hash" ? 20 : 22, "#203442", 4, style === "hash");
      y += 10;
    } else {
      const column =
          pending === null ? (rtl ? 635 : margin) : rtl ? margin : 635,
        top = y;
      text(label, 17, "#64736f", 1, false, column, 480);
      text(value, 22, "#203442", 3, style === "code", column, 480);
      const bottom = y;
      if (pending === null) {
        pending = bottom;
        y = top;
      } else {
        y = Math.max(pending, bottom) + 18;
        pending = null;
      }
    }
  }
  if (pending !== null) y = pending + 18;
  const preview = lastResult.file_inspection.preview;
  if (preview && y < 1900) {
    text(t("preview"), 17, "#64736f", 1);
    text(preview, 20, "#34443d", 4, !/[\u0600-\u06ff]/u.test(preview));
    text(
      t("previewSample", {
        bytes: number(lastResult.file_inspection.preview_bytes),
      }),
      16,
      "#64736f",
      2,
    );
  }
  text(t("evidence"), 18, "#64736f", 1);
  for (const line of evidenceLines().slice(0, 3)) {
    text(line, 20, "#203442", 2);
    if (y > 2210) break;
  }
  const root = reportRoot(lastResult.report);
  text(
    root.coverage
      .map((s) => s.stage + " · " + t("stage_" + s.state))
      .join("  /  "),
    16,
    "#64736f",
    3,
  );
  y = Math.min(y + 22, 2350);
  text(t("cardDisclaimer"), 18, "#64736f", 4);
  text(build + " · " + date(completedAt), 16, "#64736f", 2, true);
  const height = Math.min(2600, Math.ceil(y + 55));
  ctx.strokeStyle = "#a6ab91";
  ctx.lineWidth = 2;
  ctx.strokeRect(28, 28, 1144, height - 56);
  ctx.strokeStyle = "#c6c9b6";
  ctx.strokeRect(38, 38, 1124, height - 76);
  const output = document.createElement("canvas");
  output.width = 1200;
  output.height = height;
  output.getContext("2d").drawImage(canvas, 0, 0);
  return output;
}
el("downloadCard").addEventListener("click", async () => {
  el("downloadCard").disabled = true;
  try {
    await document.fonts.ready;
    const canvas = cardCanvas(),
      blob = await new Promise((resolve) =>
        canvas.toBlob(resolve, "image/png"),
      );
    if (!blob) throw new Error("PNG export unavailable");
    const bytes = Array.from(new Uint8Array(await blob.arrayBuffer()));
    if (await invoke("save_card", { bytes })) scanMessage("cardSaved");
  } catch (error) {
    txt("scanStatus", String(error));
  } finally {
    el("downloadCard").disabled = false;
  }
});
setLanguage(language);
status();
invoke("release_info")
  .then((data) => {
    if (typeof data.build === "string" && data.build.length <= 100) {
      build = data.build;
      txt("buildCode", build);
      if (lastResult) txt("cardBuild", build);
    }
  })
  .catch(() => {});
