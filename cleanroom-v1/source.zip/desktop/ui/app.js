'use strict';
const invoke=(name)=>window.__TAURI__.core.invoke(name);
const el=(id)=>document.getElementById(id);
async function status(){
 try{
  const data=await invoke('security_status');
  el('updateStatus').textContent=data.fresh
   ?'اطلاعات تهدید به‌روز است · '+data.record_count+' هش تأییدشده · '+data.version
   :'اطلاعات آنلاین هنوز آماده یا به‌روز نیست. به‌روزرسانی کنید؛ نتیجهٔ سالم تا تأیید اطلاعات جدید صادر نمی‌شود.';
 }catch(error){el('updateStatus').textContent=String(error);}
}
el('statusButton').addEventListener('click',status);
el('updateButton').addEventListener('click',async()=>{
 try{await invoke('refresh_security');el('updateStatus').textContent='دریافت اطلاعات آغاز شد. پس از چند لحظه «بررسی وضعیت» را بزنید.';}
 catch(error){el('updateStatus').textContent=String(error);}
});
el('chooseButton').addEventListener('click',async()=>{
 try{const path=await invoke('choose_file');if(path){el('filePath').textContent=path;el('scanButton').disabled=false;}}
 catch(error){el('scanStatus').textContent=String(error);}
});
el('scanButton').addEventListener('click',async()=>{
 el('scanButton').disabled=true;el('chooseButton').disabled=true;
 el('result').hidden=true;el('scanStatus').textContent='در حال بررسی ایستا؛ فایل اجرا نمی‌شود…';
 try{
  const data=await invoke('scan_selected');const report=data.report;
  const labels={SAFE:'شواهد مخرب پیدا نشد',SUSPICIOUS:'مشکوک',MALICIOUS:'مخرب',INVALID:'ساختار نامعتبر',INCONCLUSIVE:'نتیجهٔ نامشخص'};
  if(!Object.hasOwn(labels,report.verdict)||typeof data.summary_fa!=='string')throw new Error('گزارش معتبر نیست');
  el('verdict').textContent=labels[report.verdict];el('verdict').dataset.verdict=report.verdict;
  el('metrics').textContent='ریسک: '+report.risk_score+' · پوشش تحلیل: '+report.coverage_score+'٪ · اطمینان: '+report.confidence+'٪';
  el('summary').textContent=data.summary_fa;el('result').hidden=false;
  el('scanStatus').textContent='بررسی تمام شد.';
 }catch(error){el('scanStatus').textContent=String(error);}
 finally{el('scanButton').disabled=false;el('chooseButton').disabled=false;}
});
status();
