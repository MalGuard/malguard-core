'use strict';
const invoke=(name)=>window.__TAURI__.core.invoke(name);
const el=(id)=>document.getElementById(id);
const catalogs={
 en:{version:'Desktop 1.2 · Windows',language:'Language',eyebrow:'GTA V mod file protection',title:'Inspect before you install.',intro:'Static analysis runs locally. Signed threat intelligence updates online; your files are never uploaded or executed.',intelligence:'Online threat intelligence',update:'Get signed update',status:'Check status',schedule:'Automatic updates run daily at 03:00 when Windows is running. Manual updates require administrator approval.',scanHeading:'Scan a mod file or package',noFile:'No file selected.',choose:'Choose file',scan:'Start scan',save:'Save JSON report',footer:'SAFE means no evidence of malicious behavior was found by completed analyses; it is not a safety guarantee. Stale data or incomplete required analysis blocks SAFE.',checking:'Checking updates…',fresh:'Threat data is up to date',hashes:'verified hashes',stale:'Online intelligence is missing or stale. Update it; SAFE remains blocked until fresh data is authenticated.',saved:'Report saved to a new file.',started:'Update requested. Check status after a few moments.',scanning:'Static analysis in progress; the file is never executed…',done:'Analysis complete.',metrics:'Risk: {risk} · Coverage: {coverage}% · Confidence: {confidence}%',invalidReport:'Invalid engine report',SAFE:'No evidence of malicious behavior',SUSPICIOUS:'Suspicious',MALICIOUS:'Malicious',INVALID:'Invalid structure',INCONCLUSIVE:'Inconclusive'},
 fa:{version:'نسخهٔ گرافیکی ۱.۲ · Windows',language:'زبان',eyebrow:'حفاظت از فایل‌های ماد GTA V',title:'قبل از نصب ماد، بررسی کنید.',intro:'تحلیل ایستا روی دستگاه شما انجام می‌شود. اطلاعات تهدید امضاشده آنلاین به‌روز می‌شود؛ فایل شما آپلود یا اجرا نمی‌شود.',intelligence:'اطلاعات آنلاین تهدید',update:'دریافت به‌روزرسانی امضاشده',status:'بررسی وضعیت',schedule:'دریافت خودکار هر روز ساعت ۳، وقتی ویندوز روشن باشد. به‌روزرسانی دستی اجازهٔ مدیر سیستم می‌خواهد.',scanHeading:'بررسی فایل یا بستهٔ ماد',noFile:'فایلی انتخاب نشده است.',choose:'انتخاب فایل',scan:'شروع بررسی',save:'ذخیرهٔ گزارش JSON',footer:'نتیجهٔ SAFE یعنی در تحلیل‌های تکمیل‌شده شواهد مخرب پیدا نشده است؛ تضمین ایمنی نیست. اطلاعات قدیمی یا تحلیل ناقص، حکم سالم صادر نمی‌کند.',checking:'در حال بررسی به‌روزرسانی…',fresh:'اطلاعات تهدید به‌روز است',hashes:'هش تأییدشده',stale:'اطلاعات آنلاین آماده یا به‌روز نیست. به‌روزرسانی کنید؛ نتیجهٔ سالم تا تأیید اطلاعات جدید صادر نمی‌شود.',saved:'گزارش در فایل جدید ذخیره شد.',started:'دریافت درخواست شد. پس از چند لحظه وضعیت را بررسی کنید.',scanning:'در حال بررسی ایستا؛ فایل اجرا نمی‌شود…',done:'بررسی تمام شد.',metrics:'ریسک: {risk} · پوشش: {coverage}٪ · اطمینان: {confidence}٪',invalidReport:'گزارش موتور معتبر نیست',SAFE:'شواهد مخرب پیدا نشد',SUSPICIOUS:'مشکوک',MALICIOUS:'مخرب',INVALID:'ساختار نامعتبر',INCONCLUSIVE:'نتیجهٔ نامشخص'}
};
let language='en';
try{const saved=localStorage.getItem('malguard-language');if(Object.hasOwn(catalogs,saved))language=saved;}catch{}
let lastResult=null;
let lastStatus=null;
function t(key,values={}){let text=catalogs[language][key]||catalogs.en[key]||key;for(const [name,value] of Object.entries(values))text=text.replaceAll('{'+name+'}',String(value));return text;}
function renderResult(){
 if(!lastResult)return;
 const report=lastResult.report;
 el('verdict').textContent=t(report.verdict);el('verdict').dataset.verdict=report.verdict;
 el('metrics').textContent=t('metrics',{risk:report.risk_score,coverage:report.coverage_score,confidence:report.confidence});
 el('summary').textContent=language==='fa'?lastResult.summary_fa:lastResult.summary_en;
 el('summary').lang=language;el('summary').dir=language==='fa'?'rtl':'ltr';
}
function renderStatus(){if(lastStatus)el('updateStatus').textContent=lastStatus.fresh?t('fresh')+' · '+lastStatus.record_count+' '+t('hashes')+' · '+lastStatus.version:t('stale');}
function setLanguage(value){
 language=Object.hasOwn(catalogs,value)?value:'en';
 document.documentElement.lang=language;document.documentElement.dir=language==='fa'?'rtl':'ltr';
 el('languageSelect').value=language;
 for(const node of document.querySelectorAll('[data-i18n]'))node.textContent=t(node.dataset.i18n);
 el('languageSelect').setAttribute('aria-label',t('language'));
 renderResult();renderStatus();
 try{localStorage.setItem('malguard-language',language);}catch{}
}
async function status(){
 try{el('updateStatus').textContent=t('checking');lastStatus=await invoke('security_status');renderStatus();}
 catch(error){el('updateStatus').textContent=String(error);}
}
el('languageSelect').addEventListener('change',event=>setLanguage(event.target.value));
el('statusButton').addEventListener('click',status);
el('saveButton').addEventListener('click',async()=>{
 try{if(await invoke('save_report'))el('scanStatus').textContent=t('saved');}
 catch(error){el('scanStatus').textContent=String(error);}
});
el('updateButton').addEventListener('click',async()=>{
 try{await invoke('refresh_security');el('updateStatus').textContent=t('started');}
 catch(error){el('updateStatus').textContent=String(error);}
});
el('chooseButton').addEventListener('click',async()=>{
 try{const path=await invoke('choose_file');if(path){el('filePath').removeAttribute('data-i18n');el('filePath').textContent=path;el('scanButton').disabled=false;el('result').hidden=true;el('scanStatus').textContent='';}}
 catch(error){el('scanStatus').textContent=String(error);}
});
el('scanButton').addEventListener('click',async()=>{
 el('scanButton').disabled=true;el('chooseButton').disabled=true;el('languageSelect').disabled=true;
 el('result').hidden=true;el('scanStatus').textContent=t('scanning');
 try{
  const data=await invoke('scan_selected');
  if(!data||!data.report||!['SAFE','SUSPICIOUS','MALICIOUS','INVALID','INCONCLUSIVE'].includes(data.report.verdict)||typeof data.summary_fa!=='string'||typeof data.summary_en!=='string')throw new Error(t('invalidReport'));
  lastResult=data;renderResult();el('result').hidden=false;el('scanStatus').textContent=t('done');
 }catch(error){el('scanStatus').textContent=String(error);}
 finally{el('scanButton').disabled=false;el('chooseButton').disabled=false;el('languageSelect').disabled=false;}
});
setLanguage(language);status();
invoke('release_info').then(data=>{if(typeof data.build==='string'&&data.build.length<=100)el('buildCode').textContent=data.build;}).catch(()=>{});
