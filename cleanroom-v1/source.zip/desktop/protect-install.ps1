param([Parameter(Mandatory=$true)][string]$Directory)
$ErrorActionPreference='Stop'
$registry=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine,[Microsoft.Win32.RegistryView]::Registry64)
try {
  $key=$registry.OpenSubKey('SOFTWARE\Microsoft\Windows\CurrentVersion')
  try {$programFiles=$key.GetValue('ProgramFilesDir')} finally {$key.Dispose()}
} finally {$registry.Dispose()}
$expected=Join-Path $programFiles 'MalGuard'
$actual=[IO.Path]::GetFullPath($Directory).TrimEnd('\')
if ($actual -ne $expected) {throw 'Privileged updater requires the fixed Program Files installation'}
$root=Get-Item -LiteralPath $actual -Force
if (-not $root.PSIsContainer -or ($root.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {throw 'Installation root is not ordinary'}
$entries=New-Object 'Collections.Generic.List[IO.FileSystemInfo]'
$pending=New-Object 'Collections.Generic.Stack[IO.DirectoryInfo]'
$entries.Add($root)
$pending.Push($root)
while ($pending.Count -gt 0) {
  $current=$pending.Pop()
  Get-ChildItem -LiteralPath $current.FullName -Force | ForEach-Object {
    if ($entries.Count -ge 10000 -or $_.FullName.Substring($actual.Length).Split('\').Length -gt 32) {throw 'Installation inspection budget exceeded'}
    if (($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {throw 'Installation reparse points are forbidden'}
    $entries.Add($_)
    if ($_.PSIsContainer) {$pending.Push($_)}
  }
}
foreach ($entry in $entries) {
  if ($entry.PSIsContainer) {
    $acl=New-Object Security.AccessControl.DirectorySecurity
    $acl.SetSecurityDescriptorSddlForm('O:BAG:BAD:P(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)(A;OICI;GRGX;;;BU)')
  } else {
    $acl=New-Object Security.AccessControl.FileSecurity
    $acl.SetSecurityDescriptorSddlForm('O:BAG:BAD:P(A;;FA;;;SY)(A;;FA;;;BA)(A;;GRGX;;;BU)')
  }
  Set-Acl -LiteralPath $entry.FullName -AclObject $acl
}
Write-Output 'Installed updater code is writable only by administrators and SYSTEM'
