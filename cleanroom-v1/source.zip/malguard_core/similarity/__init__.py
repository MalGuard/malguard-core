"""Deterministic advisory similarity; no identity or verdict overrides.

Named-import imphash follows the conventional ordered ``module.function``
representation. Ordinals remain numeric rather than guessing an export name.
The separate semantic hash removes order, duplicates and known Win32 A/W
variants. Neither hash identifies a safe release.
"""

from dataclasses import dataclass
from collections.abc import Iterable, Mapping
import hashlib
import json
import re
from uuid import UUID


_AW_APIS = frozenset({
    "createfile", "createprocess", "createremotethread", "getmodulehandle",
    "loadlibrary", "loadlibraryex", "messagebox", "openservice",
    "createservice", "regopenkey", "regopenkeyex", "regsetvalue",
    "regsetvalueex", "regqueryvalueex", "regcreatekeyex", "regdeletekey",
    "getwindowtext", "setwindowshookex", "findwindow", "getusername",
    "getcomputername", "getenvironmentvariable", "shellexecute",
    "shellexecuteex", "internetopen", "internetopenurl", "internetconnect",
    "httpopenrequest", "httpsendrequest", "getfileattributes",
    "gettemppath", "gettempfilename", "movefile", "copyfile", "deletefile",
    "getprivateprofilestring", "writeprivateprofilestring",
})
_MAX_REFERENCES = 100_000


def normalize_api(name: str) -> str:
    """Normalize only recognized ANSI/Unicode pairs, never arbitrary symbols."""
    if not isinstance(name, str) or len(name) > 512:
        raise ValueError("invalid import symbol")
    value = name.strip().casefold()
    if value.endswith(("a", "w")) and value[:-1] in _AW_APIS:
        value = value[:-1]
    return value


def _import_parts(item: str | Mapping[str, object]) -> tuple[str, str]:
    if isinstance(item, str):
        if len(item) > 1024 or not item:
            raise ValueError("invalid import")
        if "!" in item:
            module, symbol = item.split("!", 1)
        elif "." in item:
            module, symbol = item.rsplit(".", 1)
        else:
            module, symbol = "", item
    elif isinstance(item, Mapping):
        module_value = item.get("dll", item.get("module", ""))
        symbol_value = item.get("name", item.get("function"))
        if symbol_value is None:
            ordinal = item.get("ordinal")
            if isinstance(ordinal, bool) or not isinstance(ordinal, int) or not 0 <= ordinal <= 65535:
                raise ValueError("invalid import ordinal")
            symbol_value = f"#{ordinal}"
        if not isinstance(module_value, str) or not isinstance(symbol_value, str):
            raise ValueError("invalid import fields")
        module, symbol = module_value, symbol_value
        if len(module) > 512 or len(symbol) > 512:
            raise ValueError("import field too long")
    else:
        raise ValueError("invalid import record")
    module = module.replace("\\", "/").rsplit("/", 1)[-1].casefold()
    module = re.sub(r"\.(dll|sys|ocx)$", "", module)
    return module, symbol.casefold()


def imphash(imports: Iterable[str | Mapping[str, object]]) -> str:
    parts: list[str] = []
    for index, item in enumerate(imports):
        if index >= _MAX_REFERENCES:
            raise ValueError("import count exceeds similarity limit")
        module, symbol = _import_parts(item)
        parts.append(f"{module}.{symbol}")
    return hashlib.md5(",".join(parts).encode("utf-8"), usedforsecurity=False).hexdigest()


def semantic_import_hash(imports: Iterable[str | Mapping[str, object]]) -> str:
    values: set[str] = set()
    for index, item in enumerate(imports):
        if index >= _MAX_REFERENCES:
            raise ValueError("import count exceeds similarity limit")
        module, symbol = _import_parts(item)
        values.add(f"{module}.{normalize_api(symbol)}")
    return hashlib.sha256("\n".join(sorted(values)).encode("utf-8")).hexdigest()


def dotnet_structural_hash(assembly_refs: Iterable[str], type_refs: Iterable[str]) -> str:
    """Canonical hash of actual parsed AssemblyRef/TypeRef records."""
    groups: list[list[str]] = []
    count = 0
    for records in (assembly_refs, type_refs):
        values: set[str] = set()
        for item in records:
            count += 1
            if count > _MAX_REFERENCES or not isinstance(item, str) or len(item) > 2048:
                raise ValueError("invalid .NET reference")
            values.add(item)
        groups.append(sorted(values))
    canonical = json.dumps(groups, ensure_ascii=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("ascii")).hexdigest()


def normalize_mvid(value: str) -> str:
    if not isinstance(value, str) or len(value) > 64:
        raise ValueError("invalid MVID")
    return str(UUID(value))


@dataclass(frozen=True, slots=True)
class SimilarityProfile:
    true_type: str
    architecture: str
    size: int
    capabilities: tuple[str, ...]
    imphash: str = ""
    dotnet_hash: str = ""
    mvid: str = ""
    signer_sha256: str = ""

    def __post_init__(self) -> None:
        if (not isinstance(self.true_type, str) or not self.true_type or len(self.true_type) > 64
                or not isinstance(self.architecture, str) or len(self.architecture) > 32):
            raise ValueError("invalid profile type")
        if isinstance(self.size, bool) or not isinstance(self.size, int) or not 0 <= self.size <= (1 << 63) - 1:
            raise ValueError("invalid profile size")
        if (not isinstance(self.capabilities, (list, tuple)) or len(self.capabilities) > 4096
                or any(not isinstance(c, str) or len(c) > 256 for c in self.capabilities)):
            raise ValueError("invalid profile capabilities")
        object.__setattr__(self, "capabilities", tuple(sorted(set(self.capabilities))))
        for name, length in (("imphash", 32), ("dotnet_hash", 64), ("signer_sha256", 64)):
            value = getattr(self, name)
            if not isinstance(value, str) or (value and (len(value) != length or re.fullmatch("[0-9a-fA-F]+", value) is None)):
                raise ValueError(f"invalid {name}")
            object.__setattr__(self, name, value.lower())
        if self.mvid:
            object.__setattr__(self, "mvid", normalize_mvid(self.mvid))


@dataclass(frozen=True, slots=True)
class SimilarityMatch:
    signals: tuple[str, ...]
    capability_overlap: float
    size_similarity: float
    confidence: float


def compare_profiles(candidate: SimilarityProfile, reference: SimilarityProfile) -> SimilarityMatch | None:
    """Require type, architecture, size and capabilities before advisory matching."""
    if candidate.true_type != reference.true_type or candidate.architecture != reference.architecture:
        return None
    if not candidate.architecture or candidate.architecture.casefold() in {"unknown", "none"}:
        return None
    largest = max(candidate.size, reference.size)
    size_similarity = min(candidate.size, reference.size) / largest if largest else 0.0
    if size_similarity < 0.8:
        return None
    a, b = set(candidate.capabilities), set(reference.capabilities)
    union = a | b
    overlap = len(a & b) / len(union) if union else 0.0
    if overlap < 0.65:
        return None
    empty = {
        "imphash": hashlib.md5(b"", usedforsecurity=False).hexdigest(),
        "dotnet_hash": dotnet_structural_hash((), ()),
        "mvid": str(UUID(int=0)), "signer_sha256": "0" * 64,
    }
    signals = tuple(name for name in ("imphash", "dotnet_hash", "mvid", "signer_sha256")
                    if getattr(candidate, name) and getattr(candidate, name) != empty[name]
                    and getattr(candidate, name) == getattr(reference, name))
    if not signals:
        return None
    return SimilarityMatch(signals, round(overlap, 6), round(size_similarity, 6), 0.5)


__all__ = [
    "SimilarityMatch", "SimilarityProfile", "compare_profiles", "dotnet_structural_hash",
    "imphash", "normalize_api", "normalize_mvid", "semantic_import_hash",
]
