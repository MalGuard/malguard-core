"""Deterministic Persian text and secret-redacted machine reports."""

import dataclasses
import json
import re
from enum import Enum
from collections.abc import Mapping

from malguard_core.model import Evidence, Report, Verdict
from malguard_core.correlation import build_graph
from malguard_core.scoring import assess

_WEBHOOK = re.compile(r"(https?://(?:[\w.-]*discord(?:app)?\.com)/api/webhooks/)[^\s\"'<>]+", re.I)
_QUOTED_SECRET = re.compile(r"(?i)([\"']?(?:token|password|secret|api[_-]?key|authorization)[\"']?\s*[=:]\s*)([\"'])((?:\\.|(?!\2)[^\\\r\n])*)(\2)")
_TOKEN = re.compile(r"(?i)([\"']?(?:token|password|secret|api[_-]?key|authorization)[\"']?\s*[=:]\s*[\"']?(?:(?:Bearer|Basic)\s+)?)[^\s\"'&;,<>]{8,}")
_AUTH_SCHEME = re.compile(r"(?i)(\b(?:Bearer|Basic)\s+)[A-Za-z0-9_./+=-]{8,}")
_QUERY = re.compile(r"(?i)([?&](?:token|key|secret|password|auth)=)[^\s&#\"']+")
_DISCORD_TOKEN = re.compile(r"\b(?:mfa\.[A-Za-z0-9_-]{40,}|[A-Za-z0-9_-]{24}\.[A-Za-z0-9_-]{6}\.[A-Za-z0-9_-]{27,})\b")


def redact(value: str) -> str:
    value = "".join(f"\\u{ord(char):04x}" if 0xD800 <= ord(char) <= 0xDFFF else char for char in value)
    value = _WEBHOOK.sub(r"\1[REDACTED]", value)
    value = _QUOTED_SECRET.sub(r"\1\2[REDACTED]\4", value)
    value = _TOKEN.sub(r"\1[REDACTED]", value)
    value = _AUTH_SCHEME.sub(r"\1[REDACTED]", value)
    value = _QUERY.sub(r"\1[REDACTED]", value)
    return _DISCORD_TOKEN.sub("[REDACTED]", value)


def _primitive(value):
    if isinstance(value, Enum):
        return value.value
    if dataclasses.is_dataclass(value) and not isinstance(value, type):
        output = {field.name: _primitive(getattr(value, field.name)) for field in dataclasses.fields(value)}
        if isinstance(value, Evidence):
            output["effective_weight"] = round(value.effective_weight, 6)
        return output
    if isinstance(value, Mapping):
        return {key: _primitive(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_primitive(item) for item in value]
    if isinstance(value, str):
        return redact(value)
    return value


def to_dict(report: Report) -> dict:
    output = _primitive(report)
    output.update(hashes=_primitive(report.hashes), true_file_type=report.true_file_type,
                  claimed_file_type=report.claimed_file_type, structure_status=report.structure_status.value)
    output["clean_verdict_meaning"] = "No evidence of malicious behavior was found by the completed static analyses."
    output["evidence_graph"] = _primitive(build_graph(report.evidence))
    output["family_scores"] = _primitive(assess(report.evidence).families)
    output["incomplete_stages"] = [dict(artifact_id=item.artifact_id, **_primitive(entry))
                                    for item in report.artifacts for entry in item.coverage
                                    if entry.applicable and entry.state.value != "COMPLETE"]
    return output


def to_json(report: Report, *, indent: int | None = 2) -> str:
    return json.dumps(to_dict(report), ensure_ascii=False, sort_keys=True, indent=indent, allow_nan=False)


def _display(value: str) -> str:
    value = redact(value)
    return "".join(char if (char >= " " and char not in "\u202a\u202b\u202c\u202d\u202e\u2066\u2067\u2068\u2069") else f"\\u{ord(char):04x}" for char in value)


def to_text(report: Report, language: str = "fa") -> str:
    if language == "en":
        return _to_text_en(report)
    if language != "fa":
        raise ValueError("Unsupported report language")
    labels = {Verdict.SAFE: "بدون شواهد مخرب", Verdict.MALICIOUS: "مخرب", Verdict.SUSPICIOUS: "مشکوک", Verdict.INVALID: "ساختار نامعتبر", Verdict.INCONCLUSIVE: "نتیجه نامشخص"}
    lines = [f"MalGuard / GTA Guard — {labels[report.verdict]} ({report.verdict.value})",
             f"فایل: {_display(report.root_artifact.logical_path)}",
             f"نوع واقعی: {report.true_file_type} | نوع اعلام‌شده: {report.claimed_file_type}",
             f"ریسک: {report.risk_score}/100 | اطمینان: {report.confidence:.2f}% | پوشش: {report.coverage_score:.2f}%",
             f"SHA256: {report.hashes.sha256 or 'محاسبه نشد'}"]
    if report.verdict == Verdict.SAFE:
        lines.append("در تحلیل‌های ایستای تکمیل‌شده، شواهدی از رفتار مخرب پیدا نشد. این نتیجه تضمین ایمنی نیست.")
    if report.verdict == Verdict.INVALID:
        lines.append("ساختار نامعتبر به معنی تشخیص بدافزار نیست؛ قالب فایل با ساختار لازم سازگار نیست یا ساختار آن خراب است.")
        if report.true_file_type == "TEXT" and report.claimed_file_type in {".asi", ".dll", ".exe"}:
            lines.append("این فایل متن ساده است؛ تغییر پسوند به ASI، DLL یا EXE آن را به افزونه یا برنامهٔ اجرایی ویندوز تبدیل نمی‌کند.")
    if report.classification_tags:
        lines.append("دسته‌بندی: " + ", ".join(report.classification_tags))
    if report.residual_evidence and report.verdict == Verdict.INVALID:
        lines.append("ساختار نامعتبر است؛ شواهد باقی‌مانده در گزارش حفظ شده‌اند (INVALID_WITH_RESIDUAL_EVIDENCE).")
    for item in report.evidence:
        lines.append(f"[{item.severity.value}/{item.domain.value}/{item.family}] {_display(item.description_fa)} — {_display(item.location.artifact_id)}")
    for artifact in report.artifacts:
        for entry in artifact.coverage:
            if entry.applicable and entry.state.value != "COMPLETE":
                reasons = {
                    "ITERATION_BUDGET_EXHAUSTED": "بودجهٔ قابل بازتولید تحلیل تمام شد.",
                    "WALLCLOCK_TIMEOUT": "مهلت زمانی حفاظتی تحلیل تمام شد.",
                    "MALFORMED_INPUT": "ساختار ورودی خراب است.",
                    "PARSER_DISAGREEMENT": "تفسیر ابزارهای تجزیه با هم اختلاف دارد.",
                    "PARSER_UNAVAILABLE": "ابزار لازم برای این تحلیل در دسترس نیست.",
                    "WORKER_FAILURE": "پردازش ایزولهٔ تحلیل شکست خورد.",
                    "PROTOCOL_VIOLATION": "پاسخ پردازش تحلیل شرایط امنیتی را رعایت نکرد.",
                    "ENCRYPTED_MEMBER": "یک عضو آرشیو رمزگذاری شده و قابل خواندن نیست.",
                    "UNSUPPORTED_FORMAT": "این قالب در تحلیل ساختاری پشتیبانی نمی‌شود.",
                    "IO_ERROR": "خواندن ایمن ورودی ممکن نشد.",
                    "INTEGRITY_FAILURE": "اعتبار داده یا قواعد امنیتی تأیید نشد.",
                    "CHANGED_DURING_SCAN": "فایل هنگام دریافت تغییر کرد.",
                }
                reason = reasons.get(entry.error_code.value if entry.error_code else "", "این مرحله کامل نشده است؛ دلیل دقیق در خروجی JSON آمده است.")
                lines.append(f"تحلیل ناقص {_display(artifact.logical_path)} {entry.stage}: {entry.state.value}; {reason}")
    if report.limitations:
        lines.append("محدودیت‌های تحلیل:")
        translations = set()
        for limitation in report.limitations:
            lower = limitation.lower()
            if "corpus" in lower or "acceptance targets" in lower:
                translated = "هدف‌های دقت و نرخ هشدار اشتباه با مجموعهٔ واقعی برچسب‌خورده هنوز اندازه‌گیری نشده‌اند."
            elif "authenticode" in lower or "certificate" in lower or "ocsp" in lower or "cms" in lower:
                translated = "امضای دیجیتال فقط در حد بررسی آفلاین تحلیل می‌شود؛ اعتماد سیستم‌عامل، زمان و ابطال آنلاین گواهی تأیید نشده‌اند."
            elif "native" in lower or "control flow" in lower or "indirect" in lower:
                translated = "تحلیل ایستا همهٔ جریان‌های اجرا، فراخوانی‌های غیرمستقیم و رشته‌های ساخته‌شده در زمان اجرا را مشخص نمی‌کند."
            elif "source" in lower or "lexical" in lower or "alias" in lower:
                translated = "تحلیل منبع زنجیره‌های قابل مشاهده را بررسی می‌کند؛ نام‌های مستعار و رفتار پویای پیچیده ممکن است پنهان بمانند."
            elif "budget" in lower or "limit" in lower or "timeout" in lower:
                translated = "بعضی تحلیل‌ها به محدودیت منابع یا زمان رسیدند؛ شواهد قبلی حفظ شده و جزئیات در JSON آمده است."
            elif "rar" in lower or "compression" in lower or "bytecode" in lower:
                translated = "برای بعضی قالب‌ها یا روش‌های فشرده‌سازی، تحلیل کامل و ایمن در دسترس نیست."
            elif "static" in lower or "guarantee" in lower:
                translated = "نتیجهٔ تحلیل ایستا تضمین ایمنی نیست؛ محموله‌های رمزگذاری‌شده و رفتار زمان اجرا ممکن است دیده نشوند."
            else:
                translated = "محدودیت فنی یک مرحله در گزارش JSON ثبت شده است؛ نتیجه با همان محدودیت محاسبه شده است."
            translations.add(translated)
        lines.extend(f"- {item}" for item in sorted(translations))
    lines.append(f"نسخه موتور: {report.engine_version} | قواعد: {report.ruleset_version} | داده اعتبار: {report.reputation_bundle_version}")
    return "\n".join(lines)


def _to_text_en(report: Report) -> str:
    lines = [f"MalGuard / GTA Guard — {report.verdict.value}",
             f"File: {_display(report.root_artifact.logical_path)}",
             f"Detected type: {report.true_file_type} | Declared type: {report.claimed_file_type}",
             f"Risk: {report.risk_score}/100 | Confidence: {report.confidence:.2f}% | Coverage: {report.coverage_score:.2f}%",
             f"SHA256: {report.hashes.sha256 or 'Not computed'}"]
    if report.verdict == Verdict.SAFE:
        lines.append("No evidence of malicious behavior was found by the completed static analyses. This is not a guarantee of safety.")
    if report.verdict == Verdict.INVALID:
        lines.append("INVALID describes a missing or malformed expected file structure; it does not by itself mean malware.")
        if report.true_file_type == "TEXT" and report.claimed_file_type in {".asi", ".dll", ".exe"}:
            lines.append("This file is plain text. Renaming it to ASI, DLL or EXE does not make it a Windows executable or GTA plugin.")
    if report.classification_tags:
        lines.append("Categories: " + ", ".join(report.classification_tags))
    if report.residual_evidence and report.verdict == Verdict.INVALID:
        lines.append("Collected evidence was retained (INVALID_WITH_RESIDUAL_EVIDENCE).")
    for item in report.evidence:
        lines.append(f"[{item.severity.value}/{item.domain.value}/{item.family}] {_display(item.description_en)} — {_display(item.location.artifact_id)}")
    for artifact in report.artifacts:
        for entry in artifact.coverage:
            if entry.applicable and entry.state.value != "COMPLETE":
                code = entry.error_code.value if entry.error_code else "INCOMPLETE"
                lines.append(f"Incomplete analysis: {_display(artifact.logical_path)} {entry.stage}: {entry.state.value}; {code}; {_display(entry.reason)}")
    if report.limitations:
        lines.append("Analysis limitations:")
        lines.extend(f"- {_display(item)}" for item in report.limitations)
    lines.append(f"Engine: {report.engine_version} | Rules: {report.ruleset_version} | Reputation: {report.reputation_bundle_version}")
    return "\n".join(lines)
