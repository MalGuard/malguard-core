rule MG_Credential_Collection_Chain {
  meta:
    author = "MalGuard clean-room engineering"
    description = "Credential store plus decryption and bulk collection capability"
    description_fa = "مسیر مخزن اعتبارنامه همراه با قابلیت رمزگشایی و جمع‌آوری"
    severity = "CRITICAL"
    domain = "HARM"
    family = "CREDENTIAL_ACCESS"
    reference = "https://attack.mitre.org/techniques/T1555/003/"
    false_positive_notes = "Browser maintenance tools may match; a path alone is insufficient."
  strings:
    $store1 = "Login Data" ascii wide nocase
    $store2 = "Local State" ascii wide nocase
    $store3 = "key4.db" ascii wide nocase
    $decrypt1 = "CryptUnprotectData" ascii wide nocase
    $decrypt2 = "ProtectedData.Unprotect" ascii wide nocase
    $query1 = "password_value" ascii wide nocase
    $query2 = "encrypted_value" ascii wide nocase
  condition:
    any of ($store*) and any of ($decrypt*) and any of ($query*)
}

rule MG_Credential_Exfiltration_Chain {
  meta:
    author = "MalGuard clean-room engineering"
    description = "Credential collection outputs plus an outbound upload operation"
    description_fa = "خروجی جمع‌آوری اعتبارنامه همراه با عملیات ارسال بیرونی"
    severity = "CRITICAL"
    domain = "HARM"
    family = "EXFILTRATION"
    reference = "https://attack.mitre.org/techniques/T1041/"
    false_positive_notes = "Backup/sync software may match; HTTP or a shared domain alone never qualifies."
  strings:
    $credential1 = "password_value" ascii wide nocase
    $credential2 = "encrypted_value" ascii wide nocase
    $credential3 = "discord token" ascii wide nocase
    $upload1 = "UploadData" ascii wide nocase
    $upload2 = "UploadString" ascii wide nocase
    $upload3 = "PostAsync" ascii wide nocase
    $upload4 = "HttpSendRequest" ascii wide nocase
    $collect1 = "CryptUnprotectData" ascii wide nocase
    $collect2 = "ProtectedData.Unprotect" ascii wide nocase
    $collect3 = "Login Data" ascii wide nocase
  condition:
    any of ($credential*) and any of ($upload*) and any of ($collect*)
}

rule MG_Managed_Memory_Loader {
  meta:
    author = "MalGuard clean-room engineering"
    description = "Decode plus memory assembly loading and reflective invocation"
    description_fa = "رمزگشایی همراه با بارگذاری اسمبلی در حافظه و فراخوانی بازتابی"
    severity = "HIGH"
    domain = "HARM"
    family = "LOADER_IN_MEMORY_EXECUTION"
    reference = "https://attack.mitre.org/techniques/T1620/"
    false_positive_notes = "Plugin frameworks can load assemblies; loading alone does not qualify."
  strings:
    $load1 = "Assembly.Load" ascii wide nocase
    $load2 = "System.Reflection.Assembly" ascii wide nocase
    $decode1 = "FromBase64String" ascii wide nocase
    $decode2 = "GetManifestResourceStream" ascii wide nocase
    $invoke1 = "Invoke" ascii wide
    $invoke2 = "CreateDelegate" ascii wide
  condition:
    any of ($load*) and any of ($decode*) and any of ($invoke*)
}

rule MG_Lua_Remote_Dynamic_Execution {
  meta:
    author = "MalGuard clean-room engineering"
    description = "Lua remote retrieval combined with dynamic source execution"
    description_fa = "دریافت کد از شبکه همراه با اجرای پویای کد Lua"
    severity = "HIGH"
    domain = "HARM"
    family = "REMOTE_CODE_EXECUTION"
    reference = "https://attack.mitre.org/techniques/T1059/"
    false_positive_notes = "Developer update systems can match; HTTP-only mods do not qualify."
  strings:
    $http1 = "PerformHttpRequest" ascii wide nocase
    $http2 = "http.request" ascii wide nocase
    $http3 = "https.request" ascii wide nocase
    $exec1 = "loadstring(" ascii wide nocase
    $exec2 = /load\s*\(\s*(body|response|data)/ ascii wide nocase
  condition:
    any of ($http*) and any of ($exec*)
}

rule MG_PowerShell_Remote_Execution {
  meta:
    author = "MalGuard clean-room engineering"
    description = "PowerShell download combined with expression execution"
    description_fa = "دانلود PowerShell همراه با اجرای عبارت دریافتی"
    severity = "HIGH"
    domain = "HARM"
    family = "REMOTE_CODE_EXECUTION"
    reference = "https://attack.mitre.org/techniques/T1059/001/"
    false_positive_notes = "Administrative bootstrap scripts can match; downloads alone do not qualify."
  strings:
    $download1 = "DownloadString" ascii wide nocase
    $download2 = "Invoke-WebRequest" ascii wide nocase
    $download3 = "Invoke-RestMethod" ascii wide nocase
    $exec1 = "Invoke-Expression" ascii wide nocase
    $exec2 = /\biex\b/ ascii wide nocase
  condition:
    any of ($download*) and any of ($exec*)
}

rule MG_Mod_Menu_Security_Disabling {
  meta:
    author = "MalGuard clean-room engineering"
    description = "Mod-menu presentation coupled to explicit Defender disabling commands"
    description_fa = "معرفی ماد منو همراه با فرمان صریح غیرفعال‌کردن Defender"
    severity = "HIGH"
    domain = "HARM"
    family = "SECURITY_TAMPERING"
    reference = "https://attack.mitre.org/techniques/T1562/001/"
    false_positive_notes = "Quoted documentation may match; the rule is behavioral suspicion, not family attribution."
  strings:
    $mod1 = "mod menu" ascii wide nocase
    $mod2 = "GTA5" ascii wide nocase
    $disable1 = "DisableRealtimeMonitoring" ascii wide nocase
    $disable2 = "DisableAntiSpyware" ascii wide nocase
    $command1 = "Set-MpPreference" ascii wide nocase
    $command2 = "reg add" ascii wide nocase
  condition:
    any of ($mod*) and any of ($disable*) and any of ($command*)
}

rule MG_Protector_Opacity {
  meta:
    author = "MalGuard clean-room engineering"
    description = "Packer or protector marker requiring coverage review"
    description_fa = "نشانهٔ بسته‌بند یا محافظ؛ کامل‌بودن تحلیل باید بررسی شود"
    severity = "MEDIUM"
    domain = "OPACITY"
    family = "PACKING"
    reference = "https://attack.mitre.org/techniques/T1027/002/"
    false_positive_notes = "Legitimate protected mod releases may match; opacity never proves maliciousness."
  strings:
    $upx = "UPX!" ascii
    $mpress = "MPRESS" ascii
    $vmp = "VMProtect" ascii wide
    $themida = "Themida" ascii wide
    $winlicense = "WinLicense" ascii wide
  condition:
    any of them
}

rule MG_Managed_Obfuscator_Opacity {
  meta:
    author = "MalGuard clean-room engineering"
    description = "Managed obfuscator metadata marker requiring coverage review"
    description_fa = "نشانهٔ مبهم‌ساز دات‌نت؛ کامل‌بودن تحلیل باید بررسی شود"
    severity = "MEDIUM"
    domain = "OPACITY"
    family = "OBFUSCATION"
    reference = "https://attack.mitre.org/techniques/T1027/"
    false_positive_notes = "Commercial and open source protection is legitimate and provides no malicious override."
  strings:
    $confuser = "ConfuserEx" ascii wide
    $reactor = ".NET Reactor" ascii wide
    $smart = "SmartAssembly" ascii wide
    $dotfuscator = "Dotfuscator" ascii wide
    $eaz = "Eazfuscator.NET" ascii wide
  condition:
    any of them
}

rule MG_Embedded_Executable_Context {
  meta:
    author = "MalGuard clean-room engineering"
    description = "Embedded executable markers with decoding/loading context"
    description_fa = "نشانهٔ فایل اجرایی جاسازی‌شده همراه با زمینهٔ رمزگشایی یا بارگذاری"
    severity = "MEDIUM"
    domain = "OPACITY"
    family = "ENCRYPTION"
    reference = "https://attack.mitre.org/techniques/T1027/009/"
    false_positive_notes = "Installers and resource libraries contain executables; a structured child scan remains necessary."
  strings:
    $mz = { 4D 5A }
    $pe = { 50 45 00 00 }
    $decode1 = "FromBase64String" ascii wide
    $decode2 = "VirtualAlloc" ascii wide
    $decode3 = "Assembly.Load" ascii wide
  condition:
    $mz and $pe and any of ($decode*) and for any i in (1..#mz): (@mz[i] > 0)
}
