"""Locally generated build trust anchor; no private signing key is shipped."""

PUBLIC_KEYS = {"malguard-build-2026-10": bytes.fromhex("f9a4353c08cb92b3f0f3adb5dce2592ec8792537c1fffbe1978a38b6803790ea")}
PINNED_MANIFEST_SHA256 = "876f4fe177248585abdf41bdf264187497d17fce97bafdfbf93f962227301825"

PUBLIC_KEYS["malguard-online-2026-10"] = bytes.fromhex("d0a59017fb757835c2f46afe082034ccfb0448bcb121d077b4f52d2dd46972c6")
