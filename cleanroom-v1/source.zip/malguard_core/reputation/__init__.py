"""Exact reputation is authenticated and precedes every risky parser."""

from __future__ import annotations

import re
import hashlib
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from urllib.parse import urlsplit
from collections.abc import Mapping

from malguard_core.integrity import BundleError, BundleVerifier, VerifiedBundle
from malguard_core.integrity.bundle import strict_json
from malguard_core.model import EvidenceDomain, EvidenceLocation, Hashes, Severity, StageResult, make_evidence
from malguard_core.similarity import SimilarityProfile, compare_profiles


def _records(bundle: VerifiedBundle, name: str) -> list[dict]:
    parsed = strict_json(bundle.payloads[name])
    if not isinstance(parsed, dict) or set(parsed) != {"records"} or not isinstance(parsed["records"], list) or len(parsed["records"]) > 50_000:
        raise BundleError("Security record schema invalid")
    records = parsed["records"]
    if any(not isinstance(record, dict) for record in records):
        raise BundleError("Security record must be an object")
    return records


def _text(record: dict, name: str, *, optional: bool = False, maximum: int = 2048) -> str:
    value = record.get(name, "")
    if not isinstance(value, str) or len(value) > maximum or (not optional and not value):
        raise BundleError("Invalid security record field")
    return value


_SHARED_HOSTS = frozenset({"github.com", "raw.githubusercontent.com", "discord.com", "discordapp.com", "discord.gg", "telegram.org", "t.me", "pastebin.com", "paste.ee", "mediafire.com", "mega.nz", "drive.google.com", "dropbox.com", "cloudfront.net", "amazonaws.com", "storage.googleapis.com", "azureedge.net"})
_URL = re.compile(r"https?://[^\s\"'<>]{1,4096}", re.IGNORECASE)


def _host(value: str) -> str:
    value = value.lower().rstrip(".")
    if not value or len(value) > 253 or not re.fullmatch(r"[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?", value) or any(not label or len(label) > 63 for label in value.split(".")):
        raise BundleError("IOC host invalid")
    return value


def _url(value: str) -> tuple[str, str]:
    parsed = urlsplit(value)
    if parsed.scheme.lower() not in {"http", "https"} or not parsed.hostname or parsed.username or parsed.password or parsed.fragment:
        raise BundleError("IOC URL invalid")
    try:
        _ = parsed.port
    except ValueError as error:
        raise BundleError("IOC URL port invalid") from error
    return _host(parsed.hostname), parsed.path


@dataclass(frozen=True, slots=True)
class IOCRecord:
    kind: str
    value: str
    host: str
    path: str
    reference: str
    description_en: str
    description_fa: str
    severity: Severity
    confidence: float


def _ioc(record: dict) -> IOCRecord:
    fields = {"kind", "value", "reference", "reviewed_by", "description_en", "description_fa", "severity", "confidence"}
    if set(record) != fields:
        raise BundleError("IOC record schema invalid")
    kind = _text(record, "kind")
    if kind not in {"domain", "url", "domain_path"}:
        raise BundleError("IOC kind invalid")
    value = _text(record, "value", maximum=4096)
    _text(record, "reviewed_by")
    reference = _text(record, "reference")
    en, fa = _text(record, "description_en"), _text(record, "description_fa")
    severity = _text(record, "severity")
    if severity not in {"INFO", "LOW", "MEDIUM", "HIGH"}:
        raise BundleError("IOC severity invalid")
    confidence = record["confidence"]
    if type(confidence) not in {float, int} or not 0.75 <= confidence <= 1:
        raise BundleError("IOC confidence invalid")
    host, path = (_host(value), "") if kind == "domain" else _url(value)
    if kind != "domain" and (len(path) < 3 or path == "/" or "*" in value):
        raise BundleError("Stronger IOC requires a reviewed specific exact path")
    return IOCRecord(kind, value, host, path, reference, en, fa, Severity.INFO if kind == "domain" else Severity(severity), float(confidence))


class ReputationStore:
    """Immutable record indexes built only from a verified signed byte snapshot."""

    def __init__(self, bundle: VerifiedBundle) -> None:
        if not isinstance(bundle, VerifiedBundle):
            raise BundleError("Unsigned local reputation data is not accepted")
        self.bundle_version = bundle.version
        self.ruleset_version = bundle.ruleset_version
        self.bundle = bundle
        blocked: dict[str, Mapping] = {}
        allowed: dict[str, Mapping] = {}
        similarity = []
        for name, target in (("blocklist.json", blocked), ("allowlist.json", allowed)):
            for record in _records(bundle, name):
                digest = _text(record, "sha256", maximum=64)
                if not re.fullmatch("[0-9a-f]{64}", digest) or digest in target:
                    raise BundleError("Invalid or duplicate exact hash")
                _text(record, "reference")
                _text(record, "reviewed_by")
                if name == "allowlist.json":
                    for field in ("component", "version", "official_provenance", "expected_type"):
                        _text(record, field)
                    if not record["official_provenance"].startswith("https://"):
                        raise BundleError("Allowlist requires official HTTPS provenance")
                    if "size" in record and (type(record["size"]) is not int or not 0 <= record["size"] < 2**63):
                        raise BundleError("Invalid allowlist size")
                else:
                    _text(record, "description_en")
                    _text(record, "description_fa")
                    if "similarity" in record:
                        profile = record["similarity"]
                        required = {"true_type", "architecture", "size", "capabilities"}
                        optional = {"imphash", "dotnet_hash", "mvid", "signer_sha256"}
                        if not isinstance(profile, dict) or not required <= profile.keys() or not set(profile) <= required | optional or not set(profile) & optional:
                            raise BundleError("Similarity profile schema invalid")
                        try:
                            normalized = SimilarityProfile(**profile)
                        except (TypeError, ValueError) as error:
                            raise BundleError("Similarity profile contents invalid") from error
                        similarity.append((normalized, record["reference"]))
                target[digest] = MappingProxyType(dict(record))
        if blocked.keys() & allowed.keys():
            raise BundleError("Conflicting allowlist/blocklist identity")
        self._blocked = MappingProxyType(blocked)
        self._allowed = MappingProxyType(allowed)
        self._similarity = tuple(similarity)
        self.iocs = tuple(_ioc(item) for item in _records(bundle, "iocs.json"))
        domains: dict[str, IOCRecord] = {}
        urls: dict[str, IOCRecord] = {}
        domain_paths: dict[tuple[str, str], IOCRecord] = {}
        for ioc_record in self.iocs:
            if ioc_record.kind == "domain":
                if ioc_record.host in domains:
                    raise BundleError("Duplicate IOC identity")
                domains[ioc_record.host] = ioc_record
            elif ioc_record.kind == "domain_path":
                path_key = (ioc_record.host, ioc_record.path)
                if path_key in domain_paths:
                    raise BundleError("Duplicate IOC identity")
                domain_paths[path_key] = ioc_record
            else:
                if ioc_record.value in urls:
                    raise BundleError("Duplicate IOC identity")
                urls[ioc_record.value] = ioc_record
        self._ioc_domains, self._ioc_urls, self._ioc_domain_paths = domains, urls, domain_paths
        revoked = _records(bundle, "revoked_signers.json")
        revocations = set()
        for record in revoked:
            digest = _text(record, "certificate_sha256", maximum=64)
            if not re.fullmatch("[0-9a-f]{64}", digest):
                raise BundleError("Invalid certificate digest")
            _text(record, "reference")
            revocations.add(digest)
        self.revoked_signers = frozenset(revocations)

    @property
    def version(self) -> str:
        return self.bundle_version

    def analyze(
        self, hashes: Hashes, artifact_id: str, logical_path: str = "", true_type: str = "", file_size: int | None = None,
    ) -> StageResult:
        evidence = []
        blocked = self._blocked.get(hashes.sha256)
        allowed = self._allowed.get(hashes.sha256)
        verified_allowlist = False
        if blocked:
            evidence.append(make_evidence(
                "reputation.exact_blocklist", "S1", EvidenceDomain.REPUTATION, "EXACT_BLOCKLIST", "exact_hash",
                Severity.CRITICAL, EvidenceLocation(artifact_id), blocked["description_en"], blocked["description_fa"],
                attributes=(("hard_malicious_override", True), ("reference", blocked["reference"])),
            ))
        if allowed:
            verified_allowlist = allowed["expected_type"] == true_type and ("size" not in allowed or allowed["size"] == file_size)
            evidence.append(make_evidence(
                "reputation.exact_allowlist", "S1", EvidenceDomain.REPUTATION, "VERIFIED_COMPONENT", "exact_hash",
                Severity.INFO, EvidenceLocation(artifact_id), "Exact reviewed component hash; harmful evidence still takes precedence.",
                "هش دقیق نسخهٔ بازبینی‌شده تطبیق دارد؛ شواهد رفتار مخرب همچنان اولویت دارند.",
                attributes=(("verified_allowlist", verified_allowlist), ("component", allowed["component"]), ("version", allowed["version"])),
            ))
        return StageResult("S1", evidence=tuple(evidence), facts={"hard_malicious_override": bool(blocked), "verified_allowlist": verified_allowlist, "bundle_version": self.bundle_version})

    check = analyze

    def analyze_similarity(self, profile: SimilarityProfile, artifact_id: str, ledger=None) -> StageResult:
        """No similarity signal is a hard override or a safety identity."""
        if not isinstance(profile, SimilarityProfile):
            raise TypeError("SimilarityProfile required")
        evidence = []
        for reference_profile, reference in self._similarity:
            if ledger is not None:
                ledger.consume("parser_iterations", 1 + len(profile.capabilities) + len(reference_profile.capabilities))
            match = compare_profiles(profile, reference_profile)
            if match is None:
                continue
            if ledger is not None:
                ledger.consume("evidence")
            evidence.append(make_evidence(
                "reputation.corroborated_similarity", "S1", EvidenceDomain.REPUTATION, "SIMILARITY", "corroborated_profile",
                Severity.MEDIUM, EvidenceLocation(artifact_id),
                "An advisory structural identity matches a reviewed record with matching type, architecture, similar size and capabilities; it cannot override a verdict.",
                "شباهت ساختاری با رکورد بازبینی‌شده همراه با نوع، معماری، اندازه و قابلیت‌های مشابه دیده شد؛ این قرینه حکم را به‌تنهایی تغییر نمی‌دهد.",
                confidence=match.confidence, reliability=0.50,
                attributes=(("signals", ",".join(match.signals)), ("capability_overlap", match.capability_overlap), ("size_similarity", match.size_similarity), ("reference", reference)),
            ))
        return StageResult("S1", evidence=tuple({item.id: item for item in evidence}.values()), facts={"similarity_matches": len(evidence), "hard_malicious_override": False})

    def analyze_iocs(self, strings: tuple, artifact_id: str, ledger=None) -> StageResult:
        """Lookup reviewed exact identities; reports never contain matched secrets."""
        found: dict[tuple[str, str], tuple[IOCRecord, int | None]] = {}
        for item in strings:
            if ledger is not None:
                ledger.consume("parser_iterations")
            text = getattr(item, "text", item if isinstance(item, str) else "")
            if not isinstance(text, str) or len(text) > 65536:
                continue
            offset = getattr(item, "offset", None)
            domain_record = self._ioc_domains.get(text.strip().lower().rstrip("."))
            if domain_record is not None:
                found.setdefault((domain_record.kind, domain_record.value), (domain_record, offset))
            for match in _URL.finditer(text):
                if ledger is not None:
                    ledger.consume("parser_iterations")
                candidate = match.group().rstrip(".,;)")
                try:
                    host, path = _url(candidate)
                except (ValueError, BundleError):
                    continue
                records = (self._ioc_urls.get(candidate), self._ioc_domain_paths.get((host, path)), self._ioc_domains.get(host))
                for record in records:
                    if record is not None:
                        found.setdefault((record.kind, record.value), (record, offset))
        evidence = []
        for identity, (record, offset) in sorted(found.items()):
            if ledger is not None:
                ledger.consume("evidence")
            # A shared hostname gets no risk even when its record was signed.
            shared = any(record.host == host or record.host.endswith("." + host) for host in _SHARED_HOSTS)
            severity = Severity.INFO if record.kind == "domain" and shared else record.severity
            evidence.append(make_evidence(
                "reputation.reviewed_ioc", "S1", EvidenceDomain.REPUTATION, "VERIFIED_IOC", record.kind,
                severity, EvidenceLocation(artifact_id, offset=offset), record.description_en, record.description_fa,
                confidence=record.confidence, reliability=0.70,
                attributes=(("identity_sha256", hashlib.sha256((identity[0] + "\0" + identity[1]).encode()).hexdigest()), ("host", record.host), ("reference", record.reference), ("shared_infrastructure", shared)),
            ))
        return StageResult("S1", evidence=tuple(evidence), facts={"ioc_matches": len(evidence), "hard_malicious_override": False})


def load_default_bundle() -> VerifiedBundle:
    from .trust import PUBLIC_KEYS, PINNED_MANIFEST_SHA256
    bundle = BundleVerifier(PUBLIC_KEYS).verify(Path(__file__).parent / "data", commit=False)
    if bundle.manifest_sha256 != PINNED_MANIFEST_SHA256:
        raise BundleError("Packaged bundle differs from the engine's pinned manifest")
    return bundle


def load_default_store() -> ReputationStore:
    return ReputationStore(load_default_bundle())


__all__ = ["ReputationStore", "load_default_store", "load_default_bundle"]
