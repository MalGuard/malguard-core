"""The sole producer of security verdicts, in mandatory precedence order."""

from dataclasses import dataclass
from collections.abc import Iterable
from malguard_core.model import Artifact, ArtifactStatus, Evidence, EvidenceDomain, CoverageState, ErrorCode, Severity, Verdict
from malguard_core.scoring import RiskAssessment


@dataclass(frozen=True, slots=True)
class VerdictDecision:
    verdict: Verdict
    confidence: float
    residual_evidence: bool


class VerdictEngine:
    def decide(self, artifact: Artifact, assessment: RiskAssessment, coverage: float,
               evidence: Iterable[Evidence], *, hard_block: bool = False,
               allowlisted: bool = False, unreadable_child: bool = False) -> VerdictDecision:
        evidence = tuple(evidence)
        harm = tuple(item for item in assessment.families if item.domain == EvidenceDomain.HARM)
        decisive = tuple(item for item in harm if item.score >= 16 and item.decisive_confidence >= .75)
        decisive_total = sum(sorted((item.score for item in decisive), reverse=True)[:3])
        opacity = tuple(item for item in assessment.families if item.domain == EvidenceDomain.OPACITY)
        disagreement = any(item.error_code == ErrorCode.PARSER_DISAGREEMENT for item in artifact.coverage) or any(item.kind == "PARSER_DISAGREEMENT" for item in evidence)
        incomplete = any(entry.applicable and (entry.state != CoverageState.COMPLETE or entry.error_code is not None) for entry in artifact.coverage)
        executable_mismatch = any(item.domain == EvidenceDomain.STRUCTURE and item.kind in {
            "EXECUTABLE_MISMATCH", "EXE_MASQUERADE", "PE_EXECUTABLE_MISMATCH",
            "exe_as_dll", "executable_disguise", "bidi_filename", "double_extension",
        } for item in evidence)
        residual = any(item.effective_weight > 0 for item in evidence)
        # Authenticated adverse reputation is a separate verdict gate. It is
        # never fabricated into an independent behavioral HARM family, and
        # shared hostnames or similarity alone cannot trigger this gate.
        adverse_reputation = any(
            item.domain == EvidenceDomain.REPUTATION and not item.mitigating
            and item.severity in (Severity.HIGH, Severity.CRITICAL) and item.confidence >= .75
            and ((item.stage == "S2" and item.rule_id == "AUTH.REVOKED_SIGNER"
                  and item.family == "SIGNER_REVOCATION" and item.kind == "revoked_signer"
                  and item.reliability >= .9)
                 or (item.stage == "S1" and item.rule_id == "reputation.reviewed_ioc"
                     and item.family == "VERIFIED_IOC" and item.kind in {"url", "domain_path"}
                     and item.reliability >= .6))
            for item in evidence
        )
        confidence = max(0.0, min(100.0, coverage - (10 if disagreement else 0) - min(15.0, assessment.opacity_total * .5)))
        if hard_block:
            return VerdictDecision(Verdict.MALICIOUS, 100.0, residual)
        if len({item.family for item in decisive}) >= 2 and decisive_total >= 48:
            return VerdictDecision(Verdict.MALICIOUS, round(100 * min(item.decisive_confidence for item in decisive), 2), residual)
        if (assessment.risk >= 25 or any(item.score >= 16 for item in harm)
                or executable_mismatch or adverse_reputation
                or (not allowlisted and any(item.score >= 16 for item in opacity))):
            return VerdictDecision(Verdict.SUSPICIOUS, round(max(confidence, 65.0), 2), residual)
        if artifact.structure_status == ArtifactStatus.MALFORMED:
            return VerdictDecision(Verdict.INVALID, round(confidence, 2), residual)
        if (artifact.structure_status in (ArtifactStatus.BLOCKED, ArtifactStatus.UNKNOWN)
                or incomplete or disagreement or unreadable_child):
            return VerdictDecision(Verdict.INCONCLUSIVE, round(confidence, 2), residual)
        unresolved_opacity = bool(opacity) and not allowlisted
        if (assessment.risk <= 14 and not any(item.score >= 10 for item in harm)
                and coverage >= 92 and confidence >= 85 and not unresolved_opacity):
            return VerdictDecision(Verdict.SAFE, round(confidence, 2), residual)
        return VerdictDecision(Verdict.INCONCLUSIVE, round(confidence, 2), residual)


VERDICT_PRECEDENCE = {
    Verdict.SAFE: 0, Verdict.INCONCLUSIVE: 1, Verdict.INVALID: 2,
    Verdict.SUSPICIOUS: 3, Verdict.MALICIOUS: 4,
}
