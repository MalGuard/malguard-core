"""Explicit applicable-stage coverage accounting."""

from collections.abc import Iterable
from malguard_core.model import CoverageEntry, CoverageState

STAGE_WEIGHTS = {"S0": 3, "S1": 1, "S2": 2, "S3": 3, "S4": 3, "S5": 3, "S6": 3, "S7": 2}
MULTIPLIERS = {
    CoverageState.COMPLETE: 1.0, CoverageState.PARTIAL: 0.6,
    CoverageState.SKIPPED_LIMIT: 0.25, CoverageState.TIMEOUT: 0.1,
    CoverageState.FAILED: 0.0, CoverageState.UNAVAILABLE: 0.0,
    CoverageState.BLOCKED: 0.0,
}


def coverage_score(entries: Iterable[CoverageEntry]) -> float:
    stages: dict[str, CoverageEntry] = {}
    for entry in entries:
        if not entry.applicable:
            continue
        previous = stages.get(entry.stage)
        if previous is None or MULTIPLIERS[entry.state] < MULTIPLIERS[previous.state]:
            stages[entry.stage] = entry
    entries = tuple(stages.values())
    denominator = sum(STAGE_WEIGHTS.get(entry.stage, 0) for entry in entries)
    if not denominator:
        return 0.0
    numerator = sum(STAGE_WEIGHTS.get(entry.stage, 0) * MULTIPLIERS[entry.state] for entry in entries)
    return round(100.0 * numerator / denominator, 2)
