"""Evidence graph and artifact-local semantic correlation.

Analyzers emit relationship evidence; this graph never invents a missing sink or
combines two unrelated archive members into a malicious behavior chain.
"""

from dataclasses import dataclass
from collections.abc import Iterable
from malguard_core.model import Evidence, EvidenceDomain


@dataclass(frozen=True, slots=True)
class EvidenceEdge:
    source_id: str
    target_id: str
    relation: str


@dataclass(frozen=True, slots=True)
class EvidenceGraph:
    nodes: tuple[Evidence, ...]
    edges: tuple[EvidenceEdge, ...]


def build_graph(evidence: Iterable[Evidence]) -> EvidenceGraph:
    nodes = tuple(sorted({item.id: item for item in evidence}.values(), key=lambda item: item.id))
    groups: dict[tuple[str, str], list[Evidence]] = {}
    for item in nodes:
        groups.setdefault((item.location.artifact_id, item.family), []).append(item)
    edges = []
    for key in sorted(groups):
        items = groups[key]
        # Star links bound graph size, preventing quadratic evidence expansion.
        for item in items[1:]:
            edges.append(EvidenceEdge(items[0].id, item.id, "SAME_BEHAVIOR_FAMILY"))
    for artifact in sorted({item.location.artifact_id for item in nodes}):
        local = [item for item in nodes if item.location.artifact_id == artifact and item.domain == EvidenceDomain.HARM]
        credentials = next((item for item in local if item.family == "CREDENTIAL_ACCESS" and item.confidence >= .75), None)
        exfil = next((item for item in local if item.family == "EXFILTRATION" and item.confidence >= .75), None)
        if credentials and exfil:
            edges.append(EvidenceEdge(credentials.id, exfil.id, "CREDENTIAL_COLLECTION_WITH_EXFILTRATION"))
    return EvidenceGraph(nodes, tuple(sorted(edges, key=lambda edge: (edge.source_id, edge.target_id, edge.relation))))
