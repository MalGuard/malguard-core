"""Validated, deterministic data shared by the analysis and verdict layers."""

from dataclasses import dataclass, field
from enum import StrEnum
from hashlib import sha256
import json
from math import isfinite
from typing import Any


class Verdict(StrEnum):
    SAFE = "SAFE"
    SUSPICIOUS = "SUSPICIOUS"
    MALICIOUS = "MALICIOUS"
    INVALID = "INVALID"
    INCONCLUSIVE = "INCONCLUSIVE"


class ArtifactStatus(StrEnum):
    VALID = "VALID"
    MALFORMED = "MALFORMED"
    UNKNOWN = "UNKNOWN"
    BLOCKED = "BLOCKED"


class EvidenceDomain(StrEnum):
    HARM = "HARM"
    OPACITY = "OPACITY"
    CONTEXT = "CONTEXT"
    STRUCTURE = "STRUCTURE"
    REPUTATION = "REPUTATION"


class Severity(StrEnum):
    INFO = "INFO"
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"

    @property
    def base_weight(self) -> int:
        return {"INFO": 0, "LOW": 4, "MEDIUM": 10, "HIGH": 18, "CRITICAL": 28}[self.value]


class CoverageState(StrEnum):
    COMPLETE = "COMPLETE"
    PARTIAL = "PARTIAL"
    SKIPPED_LIMIT = "SKIPPED_LIMIT"
    TIMEOUT = "TIMEOUT"
    FAILED = "FAILED"
    UNAVAILABLE = "UNAVAILABLE"
    BLOCKED = "BLOCKED"


class ErrorCode(StrEnum):
    ITERATION_BUDGET_EXHAUSTED = "ITERATION_BUDGET_EXHAUSTED"
    WALLCLOCK_TIMEOUT = "WALLCLOCK_TIMEOUT"
    MALFORMED_INPUT = "MALFORMED_INPUT"
    PARSER_DISAGREEMENT = "PARSER_DISAGREEMENT"
    PARSER_UNAVAILABLE = "PARSER_UNAVAILABLE"
    WORKER_FAILURE = "WORKER_FAILURE"
    PROTOCOL_VIOLATION = "PROTOCOL_VIOLATION"
    ENCRYPTED_MEMBER = "ENCRYPTED_MEMBER"
    UNSUPPORTED_FORMAT = "UNSUPPORTED_FORMAT"
    IO_ERROR = "IO_ERROR"
    INTEGRITY_FAILURE = "INTEGRITY_FAILURE"
    CHANGED_DURING_SCAN = "CHANGED_DURING_SCAN"


Primitive = str | int | float | bool | None


def _bounded_string(value: str, name: str, maximum: int, empty: bool = True) -> None:
    if not isinstance(value, str) or len(value) > maximum or (not empty and not value):
        raise ValueError(f"invalid {name}")


def _unit_interval(value: float, name: str) -> None:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(value) or not 0 <= value <= 1:
        raise ValueError(f"{name} must be a finite value in [0, 1]")


def _json_copy(value: Any, depth: int = 0, counter: list[int] | None = None) -> Any:
    """Copy only bounded JSON primitives; never accept arbitrary objects."""
    if counter is None:
        counter = [0]
    counter[0] += 1
    if depth > 20 or counter[0] > 200_000:
        raise ValueError("facts exceed nesting or item limit")
    if value is None or isinstance(value, (bool, int)):
        if isinstance(value, int) and not -(2**63) <= value <= 2**63 - 1:
            raise ValueError("facts integer exceeds signed 64-bit range")
        return value
    if isinstance(value, float):
        if not isfinite(value):
            raise ValueError("facts require finite numbers")
        return value
    if isinstance(value, str):
        _bounded_string(value, "fact string", 128 * 1024 * 1024)
        return value
    if isinstance(value, (tuple, list)):
        return [_json_copy(item, depth + 1, counter) for item in value]
    if isinstance(value, dict):
        result = {}
        if any(not isinstance(key, str) for key in value):
            raise ValueError("facts keys must be strings")
        for key in sorted(value):
            _bounded_string(key, "fact key", 256, empty=False)
            if key.casefold() in {"verdict", "final_verdict"}:
                raise ValueError("analyzer facts cannot contain a verdict")
            result[key] = _json_copy(value[key], depth + 1, counter)
        return result
    raise ValueError("facts require JSON primitives")


@dataclass(frozen=True, slots=True)
class EvidenceLocation:
    artifact_id: str
    offset: int | None = None
    length: int | None = None
    member: str | None = None
    detail: str | None = None

    def __post_init__(self) -> None:
        _bounded_string(self.artifact_id, "artifact ID", 256, empty=False)
        for name in ("offset", "length"):
            value = getattr(self, name)
            if value is not None and (isinstance(value, bool) or not isinstance(value, int) or not 0 <= value <= 2**63 - 1):
                raise ValueError(f"invalid evidence {name}")
        if self.offset is not None and self.length is not None and self.length > 2**63 - 1 - self.offset:
            raise ValueError("evidence location overflow")
        for name in ("member", "detail"):
            value = getattr(self, name)
            if value is not None:
                _bounded_string(value, name, 8192)


@dataclass(frozen=True, slots=True)
class Evidence:
    id: str
    rule_id: str
    stage: str
    domain: EvidenceDomain
    family: str
    kind: str
    severity: Severity
    base_weight: int
    confidence: float
    reliability: float
    location: EvidenceLocation
    description_fa: str
    description_en: str
    mitigating: bool = False
    attributes: tuple[tuple[str, Primitive], ...] = ()

    def __post_init__(self) -> None:
        for name, maximum in (("id", 64), ("rule_id", 128), ("stage", 64), ("family", 128), ("kind", 128)):
            _bounded_string(getattr(self, name), name, maximum, empty=False)
        if len(self.id) != 64 or any(c not in "0123456789abcdef" for c in self.id):
            raise ValueError("evidence ID must be a SHA256 digest")
        if not isinstance(self.domain, EvidenceDomain) or not isinstance(self.severity, Severity):
            raise ValueError("invalid evidence enum")
        if self.base_weight != self.severity.base_weight or isinstance(self.base_weight, bool):
            raise ValueError("evidence weight must match severity")
        _unit_interval(self.confidence, "confidence")
        _unit_interval(self.reliability, "reliability")
        if not isinstance(self.location, EvidenceLocation) or not isinstance(self.mitigating, bool):
            raise ValueError("invalid evidence location or mitigation")
        _bounded_string(self.description_fa, "Persian description", 8192)
        _bounded_string(self.description_en, "English description", 8192)
        if len(self.attributes) > 128:
            raise ValueError("too many evidence attributes")
        checked: list[tuple[str, Primitive]] = []
        for key, value in self.attributes:
            _bounded_string(key, "attribute key", 128, empty=False)
            if not isinstance(value, (str, int, float, bool, type(None))):
                raise ValueError("attribute values must be primitives")
            if isinstance(value, str):
                _bounded_string(value, "attribute string", 8192)
            if isinstance(value, float) and not isfinite(value):
                raise ValueError("attribute number must be finite")
            if isinstance(value, int) and not -(2**63) <= value <= 2**63 - 1:
                raise ValueError("attribute integer out of range")
            checked.append((key, value))
        if len({key for key, _ in checked}) != len(checked):
            raise ValueError("duplicate evidence attributes")
        object.__setattr__(self, "attributes", tuple(sorted(checked)))

    @property
    def effective_weight(self) -> float:
        return self.base_weight * self.confidence * self.reliability


def make_evidence(
    rule_id: str, stage: str, domain: EvidenceDomain, family: str, kind: str,
    severity: Severity, location: EvidenceLocation, description_en: str,
    description_fa: str, confidence: float = 1.0, reliability: float = 1.0,
    mitigating: bool = False, attributes: tuple[tuple[str, Primitive], ...] = (),
) -> Evidence:
    _unit_interval(confidence, "confidence")
    _unit_interval(reliability, "reliability")
    confidence, reliability = float(confidence), float(reliability)
    attributes = tuple(sorted(attributes))
    payload = {
        "rule_id": rule_id, "stage": stage, "domain": domain.value,
        "family": family, "kind": kind, "severity": severity.value,
        "confidence": confidence, "reliability": reliability,
        "location": [location.artifact_id, location.offset, location.length, location.member, location.detail],
        "description_en": description_en, "description_fa": description_fa,
        "mitigating": mitigating, "attributes": attributes,
    }
    identity = sha256(json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False).encode("ascii")).hexdigest()
    return Evidence(identity, rule_id, stage, domain, family, kind, severity,
                    severity.base_weight, confidence, reliability, location,
                    description_fa, description_en, mitigating, attributes)


@dataclass(frozen=True, slots=True)
class CoverageEntry:
    stage: str
    state: CoverageState
    reason: str = ""
    error_code: ErrorCode | None = None
    applicable: bool = True

    def __post_init__(self) -> None:
        _bounded_string(self.stage, "stage", 64, empty=False)
        _bounded_string(self.reason, "coverage reason", 8192)
        if not isinstance(self.state, CoverageState) or not isinstance(self.applicable, bool):
            raise ValueError("invalid coverage state")
        if self.error_code is not None and not isinstance(self.error_code, ErrorCode):
            raise ValueError("invalid coverage error code")


@dataclass(frozen=True, slots=True)
class Hashes:
    sha256: str = ""
    sha1: str = ""
    md5: str = ""

    def __post_init__(self) -> None:
        for name, length in (("sha256", 64), ("sha1", 40), ("md5", 32)):
            value = getattr(self, name)
            if not isinstance(value, str) or (value and (len(value) != length or any(c not in "0123456789abcdef" for c in value))):
                raise ValueError(f"invalid {name}")


@dataclass(frozen=True, slots=True)
class StageResult:
    stage: str
    state: CoverageState = CoverageState.COMPLETE
    evidence: tuple[Evidence, ...] = ()
    facts: dict[str, Any] = field(default_factory=dict)
    errors: tuple[ErrorCode, ...] = ()
    limitations: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        _bounded_string(self.stage, "stage", 64, empty=False)
        if not isinstance(self.state, CoverageState):
            raise ValueError("invalid stage state")
        if len(self.evidence) > 20_000 or any(not isinstance(item, Evidence) for item in self.evidence):
            raise ValueError("invalid stage evidence")
        if any(not isinstance(item, ErrorCode) for item in self.errors):
            raise ValueError("invalid stage errors")
        for item in self.limitations:
            _bounded_string(item, "limitation", 8192)
        object.__setattr__(self, "evidence", tuple(sorted(self.evidence, key=lambda item: item.id)))
        object.__setattr__(self, "errors", tuple(sorted(set(self.errors), key=lambda item: item.value)))
        object.__setattr__(self, "limitations", tuple(sorted(set(self.limitations))))
        object.__setattr__(self, "facts", _json_copy(self.facts))


@dataclass(frozen=True, slots=True)
class Artifact:
    artifact_id: str
    logical_path: str
    declared_type: str
    true_type: str
    type_confidence: float
    file_size: int
    hashes: Hashes
    structure_status: ArtifactStatus
    parent_artifact_id: str | None = None
    archive_depth: int = 0
    evidence: tuple[Evidence, ...] = ()
    coverage: tuple[CoverageEntry, ...] = ()
    child_artifact_ids: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        _bounded_string(self.artifact_id, "artifact ID", 256, empty=False)
        _bounded_string(self.logical_path, "logical path", 8192)
        _bounded_string(self.declared_type, "declared type", 64)
        _bounded_string(self.true_type, "true type", 128)
        _unit_interval(self.type_confidence, "type confidence")
        if isinstance(self.file_size, bool) or not isinstance(self.file_size, int) or not 0 <= self.file_size <= 2**63 - 1:
            raise ValueError("invalid artifact size")
        if isinstance(self.archive_depth, bool) or not isinstance(self.archive_depth, int) or not 0 <= self.archive_depth <= 1024:
            raise ValueError("invalid archive depth")
        if not isinstance(self.hashes, Hashes) or not isinstance(self.structure_status, ArtifactStatus):
            raise ValueError("invalid artifact metadata")
        if self.parent_artifact_id is not None:
            _bounded_string(self.parent_artifact_id, "parent ID", 256, empty=False)
        if any(not isinstance(item, Evidence) for item in self.evidence) or any(not isinstance(item, CoverageEntry) for item in self.coverage):
            raise ValueError("invalid artifact evidence or coverage")
        object.__setattr__(self, "evidence", tuple(sorted(self.evidence, key=lambda item: item.id)))
        object.__setattr__(self, "coverage", tuple(sorted(self.coverage, key=lambda item: item.stage)))
        object.__setattr__(self, "child_artifact_ids", tuple(sorted(set(self.child_artifact_ids))))


@dataclass(frozen=True, slots=True)
class Report:
    verdict: Verdict
    risk_score: int
    confidence: float
    coverage_score: float
    root_artifact_id: str
    artifacts: tuple[Artifact, ...]
    evidence: tuple[Evidence, ...]
    classification_tags: tuple[str, ...]
    limitations: tuple[str, ...]
    residual_evidence: bool
    engine_version: str
    ruleset_version: str
    reputation_bundle_version: str
    schema_version: str

    def __post_init__(self) -> None:
        if not isinstance(self.verdict, Verdict):
            raise ValueError("invalid report verdict")
        for name in ("risk_score", "confidence", "coverage_score"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(value) or not 0 <= value <= 100:
                raise ValueError(f"invalid report {name}")
        if len({item.artifact_id for item in self.artifacts}) != len(self.artifacts):
            raise ValueError("duplicate artifact IDs")
        if not any(item.artifact_id == self.root_artifact_id for item in self.artifacts):
            raise ValueError("root artifact missing")
        for name in ("engine_version", "ruleset_version", "reputation_bundle_version", "schema_version"):
            _bounded_string(getattr(self, name), name, 128)
        object.__setattr__(self, "artifacts", tuple(sorted(self.artifacts, key=lambda item: item.artifact_id)))
        object.__setattr__(self, "evidence", tuple(sorted(self.evidence, key=lambda item: item.id)))
        object.__setattr__(self, "classification_tags", tuple(sorted(set(self.classification_tags))))
        object.__setattr__(self, "limitations", tuple(sorted(set(self.limitations))))

    @property
    def root_artifact(self) -> Artifact:
        return next(item for item in self.artifacts if item.artifact_id == self.root_artifact_id)

    @property
    def hashes(self) -> Hashes:
        return self.root_artifact.hashes

    @property
    def true_file_type(self) -> str:
        return self.root_artifact.true_type

    @property
    def claimed_file_type(self) -> str:
        return self.root_artifact.declared_type

    @property
    def structure_status(self) -> ArtifactStatus:
        return self.root_artifact.structure_status

    def to_json(self) -> str:
        from malguard_core.reporting import to_json
        return to_json(self)

    def to_text(self, language: str = "fa") -> str:
        from malguard_core.reporting import to_text
        return to_text(self, language=language)
