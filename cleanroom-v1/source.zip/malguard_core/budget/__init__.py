"""Shared deterministic work accounting for every artifact and parser."""

from dataclasses import dataclass
from threading import RLock
from types import MappingProxyType
from collections.abc import Mapping
from typing import Any

from malguard_core.settings import DEFAULT_BUDGETS


class BudgetExceeded(RuntimeError):
    """A deterministic work limit, distinct from a wall-clock timeout."""

    def __init__(self, dimension: str, requested: int, remaining: int) -> None:
        self.dimension = dimension
        self.resource = dimension
        self.requested = requested
        self.remaining = remaining
        self.partial_results: tuple[Any, ...] = ()
        from malguard_core.model import ErrorCode
        self.error_code = ErrorCode.ITERATION_BUDGET_EXHAUSTED
        super().__init__(f"budget {dimension} exhausted: requested {requested}, remaining {remaining}")


@dataclass(frozen=True, slots=True)
class BudgetSnapshot:
    limits: tuple[tuple[str, int], ...]
    consumed: tuple[tuple[str, int], ...]
    exhausted: tuple[str, ...]


class BudgetLedger:
    """One ledger per root; no child may replenish or reset limits."""

    def __init__(self, limits: Mapping[str, int] | None = None) -> None:
        values = dict(DEFAULT_BUDGETS)
        if limits is not None:
            for key, value in limits.items():
                if key not in values:
                    raise ValueError(f"unknown budget: {key}")
                if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                    raise ValueError(f"invalid budget: {key}")
                values[key] = value
        self._limits = MappingProxyType(values)
        self._used = dict.fromkeys(values, 0)
        self._exhausted: set[str] = set()
        self._lock = RLock()

    @property
    def limits(self) -> Mapping[str, int]:
        return self._limits

    @property
    def exhausted(self) -> tuple[str, ...]:
        with self._lock:
            return tuple(sorted(self._exhausted))

    def remaining(self, dimension: str) -> int:
        with self._lock:
            return self._limits[dimension] - self._used[dimension]

    def consumed(self, dimension: str) -> int:
        with self._lock:
            return self._used[dimension]

    def consume(self, dimension: str, amount: int = 1) -> None:
        self.consume_many({dimension: amount})

    def consume_many(self, requests: Mapping[str, int]) -> None:
        """Reserve all dimensions atomically, in stable sorted order."""
        with self._lock:
            ordered = sorted(requests.items())
            for name, amount in ordered:
                if name not in self._limits:
                    raise ValueError(f"unknown budget: {name}")
                if isinstance(amount, bool) or not isinstance(amount, int) or amount < 0:
                    raise ValueError("budget consumption must be a nonnegative integer")
                remaining = self._limits[name] - self._used[name]
                if amount > remaining:
                    self._exhausted.add(name)
                    raise BudgetExceeded(name, amount, remaining)
            for name, amount in ordered:
                self._used[name] += amount

    def snapshot(self) -> BudgetSnapshot:
        with self._lock:
            return BudgetSnapshot(
                tuple(sorted(self._limits.items())),
                tuple(sorted(self._used.items())),
                tuple(sorted(self._exhausted)),
            )

    def usage(self) -> dict[str, int]:
        with self._lock:
            return dict(sorted(self._used.items()))
