"""Bounded YARA-X facts and signed, compile-before-accept rule updates."""

from __future__ import annotations

from functools import lru_cache
from dataclasses import replace
from pathlib import Path
import re

from malguard_core.budget import BudgetExceeded, BudgetLedger
from malguard_core.integrity import BundleError, BundleVerifier, VerifiedBundle, bundle_snapshot
from malguard_core.model import CoverageState, ErrorCode, EvidenceDomain, EvidenceLocation, Severity, StageResult, make_evidence


_REQUIRED_META = {"author", "description", "severity", "reference", "false_positive_notes", "domain", "family"}
_HARM = {"PROCESS_INJECTION", "CREDENTIAL_ACCESS", "EXFILTRATION", "PERSISTENCE", "LOADER_IN_MEMORY_EXECUTION", "KEYLOGGING", "REMOTE_CODE_EXECUTION", "SECURITY_TAMPERING", "DESTRUCTIVE_BEHAVIOR"}
_OPACITY = {"PACKING", "OBFUSCATION", "ANTI_DEBUG_VM", "ENCRYPTION", "STRING_ENCRYPTION", "DYNAMIC_API_RESOLUTION", "PARSER_EVASION", "METADATA_JUNK", "ANTI_TAMPER"}


def _documentation_source(data: bytes, logical_path: str, ledger: BudgetLedger):
    """Only complete plain source can prove that a raw token is inert text.

    Malformed/binary/limited source, interpolation and dynamic API resolution
    keep raw evidence. No raw PE signal depends on successful source parsing.
    """
    extension = Path(logical_path).suffix.casefold()
    if extension not in {".cs", ".vb", ".lua", ".ps1", ".psm1", ".vbs", ".bat", ".cmd", ".ini", ".cfg", ".xml"} or len(data) > 2 * 1024 * 1024 or data.startswith((b"MZ", b"\x1bLua", b"\x1bLJ")):
        return None
    try:
        if data.startswith((b"\xff\xfe", b"\xfe\xff")):
            text = data.decode("utf-16")
        elif len(data) >= 8 and data[1::2].count(0) > len(data) // 4:
            text = data.decode("utf-16-le")
        else:
            text = data.decode("utf-8-sig")
    except UnicodeError:
        return None
    if any(ord(char) < 32 and char not in "\r\n\t" for char in text):
        return None
    from malguard_core.scripts import lex_source
    lexical = lex_source(text, extension, ledger)
    if lexical.malformed or lexical.unsupported_dynamic:
        return None
    # Do not call literal targets inert when reflection or another dynamic sink
    # can turn them into behavior. Aliases remain a documented static limit.
    active_call = re.search(r"\b(?:loadstring|load|Execute|ExecuteGlobal|GetMethod|GetProcAddress|Invoke|CreateDelegate|eval)\s*\(|\b_G\s*\[", lexical.code, re.IGNORECASE)
    active_command = extension in {".ps1", ".psm1", ".vbs", ".bat", ".cmd"} and re.search(r"(?:^|[;|&{}=])\s*(?:iex|Invoke-Expression|Execute|ExecuteGlobal)\b", lexical.code, re.IGNORECASE | re.MULTILINE)
    if active_command:
        return None
    if active_call:
        # A fully bound constant Lua body has a separate lexical view. Include
        # its actual calls while leaving unrelated documentation literals inert.
        # Unknown, nested, reflective or computed sinks retain raw evidence.
        calls = tuple(re.finditer(r"\b(?:loadstring|load|Execute|ExecuteGlobal|GetMethod|GetProcAddress|Invoke|CreateDelegate|eval)\s*\(|\b_G\s*\[", lexical.code, re.IGNORECASE))
        if extension != ".lua" or any(not re.match(r"(?:loadstring|load)\s*\(", match.group()) for match in calls):
            return None
        from malguard_core.scripts.flow import execution_sources
        sources = execution_sources(lexical.text, lexical.code, extension, ledger=ledger)
        if len(sources) != len(calls):
            return None
        code_parts = [lexical.code]
        for body, _decoded in sources:
            body_lexical = lex_source(body, extension, ledger)
            if body_lexical.malformed or body_lexical.unsupported_dynamic or re.search(
                r"\b(?:loadstring|load|Execute|ExecuteGlobal|GetMethod|GetProcAddress|Invoke|CreateDelegate|eval)\s*\(|\b_G\s*\[",
                body_lexical.code, re.IGNORECASE,
            ):
                return None
            code_parts.append(body_lexical.code)
        lexical = replace(lexical, code="\n".join(code_parts))
    return lexical, text


def _inert_rule(rule, context) -> bool:
    if context is None:
        return False
    lexical, text = context
    groups = {
        "MG_Credential_Collection_Chain": "$decrypt",
        "MG_Credential_Exfiltration_Chain": "$upload",
        "MG_Managed_Memory_Loader": "$load",
        "MG_Lua_Remote_Dynamic_Execution": "$exec",
        "MG_PowerShell_Remote_Execution": "$exec",
        "MG_Mod_Menu_Security_Disabling": "$command",
    }
    group = groups.get(rule.identifier)
    if group is None:
        return False
    api_tokens = [pattern for pattern in rule.patterns if pattern.identifier.startswith(group) and pattern.matches]
    if not api_tokens:
        return False
    # Match offsets use input bytes, while the lexer uses character offsets.
    # Unicode decoding makes direct offset mapping ambiguous; conservatively
    # recognize only ASCII tokens by visible source occurrences instead.
    names = {
        "$decrypt1": "CryptUnprotectData", "$decrypt2": "ProtectedData.Unprotect",
        "$upload1": "UploadData", "$upload2": "UploadString", "$upload3": "PostAsync", "$upload4": "HttpSendRequest",
        "$load1": "Assembly.Load", "$load2": "System.Reflection.Assembly",
        "$exec1": "loadstring" if rule.identifier == "MG_Lua_Remote_Dynamic_Execution" else "Invoke-Expression",
        "$exec2": "load" if rule.identifier == "MG_Lua_Remote_Dynamic_Execution" else "iex",
        "$command1": "Set-MpPreference", "$command2": "reg add",
    }
    for pattern in api_tokens:
        token = names.get(pattern.identifier)
        if token is None or re.search(re.escape(token), lexical.code, re.IGNORECASE):
            return False
        if not re.search(re.escape(token), text, re.IGNORECASE):
            return False
    return True


def compile_bundle(bundle: VerifiedBundle):
    """Compilation rejects invalid metadata before an update can become active."""
    import yara_x
    sources = [data.decode("utf-8") for name, data in sorted(bundle.payloads.items()) if name.startswith("rules/") and name.endswith(".yar")]
    if not sources:
        raise BundleError("Signed bundle has no rules")
    source = "\n".join(sources)
    if len(source.encode("utf-8")) > 4 * 1024 * 1024:
        raise BundleError("Rule source limit")
    rules = yara_x.compile(source)
    count = 0
    for rule in rules:
        count += 1
        meta = dict(rule.metadata)
        if len(meta) != len(rule.metadata) or not _REQUIRED_META <= meta.keys():
            raise BundleError("Rule metadata missing or duplicated")
        if any(not isinstance(meta[key], str) or not 1 <= len(meta[key]) <= 2048 for key in _REQUIRED_META):
            raise BundleError("Rule metadata is not bounded text")
        if meta["severity"] not in Severity.__members__:
            raise BundleError("Rule severity invalid")
        if meta["domain"] not in {"HARM", "OPACITY", "CONTEXT", "STRUCTURE"}:
            raise BundleError("Rule domain invalid")
        if meta["domain"] == "HARM" and meta["family"] not in _HARM:
            raise BundleError("Rule HARM family invalid")
        if meta["domain"] == "OPACITY" and meta["family"] not in _OPACITY:
            raise BundleError("Rule OPACITY family invalid")
    if not 1 <= count <= 128:
        raise BundleError("Rule count invalid")
    return rules


@lru_cache(maxsize=1)
def _builtin_rules():
    from malguard_core.reputation import load_default_bundle
    return compile_bundle(load_default_bundle())


class RulesManager:
    """An invalid update cannot displace the last successfully compiled bundle."""

    def __init__(self, bundle: VerifiedBundle, verifier: BundleVerifier) -> None:
        self.active_bundle = bundle
        self.active_rules = compile_bundle(bundle)
        self.verifier = verifier
        self.last_error: str | None = None

    def update(self, directory: Path) -> bool:
        try:
            candidate = self.verifier.verify(directory, commit=False)
            compiled = compile_bundle(candidate)
            if self.verifier.state is None:
                raise BundleError("External updates require protected epoch state")
            self.verifier.state.accept(candidate.epoch, candidate.manifest_sha256)
        except Exception as error:
            self.last_error = type(error).__name__
            return False
        self.active_bundle = candidate
        self.active_rules = compiled
        self.last_error = None
        return True

    def worker_snapshot(self) -> dict:
        return bundle_snapshot(self.active_bundle)


def analyze(data: bytes, artifact_id: str, logical_path: str, ledger: BudgetLedger, rules_source=None) -> StageResult:
    """Scan a bounded byte snapshot; workers return evidence, never verdicts."""
    evidence = []
    try:
        import yara_x
        ledger.consume("yara_bytes", len(data))
        if rules_source is None:
            rules = _builtin_rules()
        else:
            from malguard_core.reputation.trust import PUBLIC_KEYS
            bundle = BundleVerifier(PUBLIC_KEYS).verify_snapshot(rules_source)
            rules = compile_bundle(bundle)
        scanner = yara_x.Scanner(rules)
        scanner.set_timeout(10)
        scanner.max_matches_per_pattern(64)
        result = scanner.scan(data)
        matched = sorted(result.matching_rules, key=lambda item: item.identifier)
        for rule in matched:
            ledger.consume("parser_iterations")
            ledger.consume("evidence")
            meta = dict(rule.metadata)
            matches = sorted((match.offset, match.length) for pattern in rule.patterns for match in pattern.matches)
            offset, length = matches[0] if matches else (None, None)
            evidence.append(make_evidence(
                f"yara.{rule.identifier}", "S7", EvidenceDomain(meta["domain"]), meta["family"], "yara_match",
                Severity(meta["severity"]), EvidenceLocation(artifact_id, offset, length), meta["description"],
                meta.get("description_fa", "الگوی ایستای قاعده تطبیق دارد و نیازمند بررسی است."),
                confidence=0.95 if meta["domain"] == "HARM" else 0.80, reliability=0.95,
                attributes=(("reference", meta["reference"]), ("false_positive_notes", meta["false_positive_notes"])),
            ))
        # Collect raw evidence first. Lexer failure or budget exhaustion cannot
        # erase the higher-confidence evidence already emitted by YARA.
        context = _documentation_source(data, logical_path, ledger) if any(item.domain == EvidenceDomain.HARM for item in evidence) else None
        for index, rule in enumerate(matched):
            if evidence[index].domain == EvidenceDomain.HARM and _inert_rule(rule, context):
                previous = evidence[index]
                evidence[index] = make_evidence(
                    previous.rule_id, "S7", EvidenceDomain.CONTEXT, "SOURCE_DOCUMENTATION", "inert_source_token",
                    Severity.INFO, previous.location,
                    "Raw rule tokens occur only in comments, data operands, literals or declarations; a completed source lexer found no corresponding executable token or dynamic invocation sink.",
                    "نشانه‌های خام فقط در توضیحات، داده، رشته یا تعریف متد هستند؛ تحلیل واژگانی کامل، نشانهٔ اجرایی متناظر یا فراخوانی پویا پیدا نکرد.",
                    confidence=1.0, reliability=0.95, attributes=previous.attributes,
                )
        return StageResult("S7", evidence=tuple(evidence), facts={"matched_rules": [rule.identifier for rule in result.matching_rules]})
    except BudgetExceeded:
        return StageResult("S7", CoverageState.SKIPPED_LIMIT, tuple(evidence), errors=(ErrorCode.ITERATION_BUDGET_EXHAUSTED,), limitations=("YARA work-unit budget exhausted.",))
    except ImportError:
        return StageResult("S7", CoverageState.UNAVAILABLE, tuple(evidence), errors=(ErrorCode.PARSER_UNAVAILABLE,), limitations=("YARA-X unavailable; rule coverage is incomplete.",))
    except Exception as error:
        timeout = type(error).__name__ == "TimeoutError"
        return StageResult("S7", CoverageState.TIMEOUT if timeout else CoverageState.FAILED, tuple(evidence), errors=(ErrorCode.WALLCLOCK_TIMEOUT if timeout else ErrorCode.INTEGRITY_FAILURE,), limitations=(f"YARA analysis failed: {type(error).__name__}.",))


__all__ = ["analyze", "compile_bundle", "RulesManager"]
