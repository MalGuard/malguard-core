"""MalGuard clean-room offline static analysis library."""

from .api import Scanner, scan_file
from .model import Report, Verdict
from .settings import ScanSettings

from .version import ENGINE_VERSION, SCHEMA_VERSION

__all__ = ["scan_file", "Scanner", "ScanSettings", "Report", "Verdict", "ENGINE_VERSION", "SCHEMA_VERSION"]
