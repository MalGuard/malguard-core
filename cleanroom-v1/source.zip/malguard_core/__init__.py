"""MalGuard clean-room offline static analysis library."""

from .api import Scanner, scan_file
from .model import Report, Verdict
from .settings import ScanSettings

ENGINE_VERSION = "1.0.0"
SCHEMA_VERSION = "1"

__all__ = ["scan_file", "Scanner", "ScanSettings", "Report", "Verdict", "ENGINE_VERSION", "SCHEMA_VERSION"]
