"""Streaming ASCII and UTF-16LE extraction with bounded retained strings."""

from dataclasses import dataclass

from malguard_core.budget import BudgetExceeded, BudgetLedger
from malguard_core.intake import BoundedByteSource


@dataclass(frozen=True, slots=True)
class ExtractedString:
    text: str
    offset: int
    encoding: str
    decoded: bool = False

    def __post_init__(self) -> None:
        if not isinstance(self.text, str) or isinstance(self.offset, bool) or not isinstance(self.offset, int) or self.offset < 0:
            raise ValueError("invalid extracted string")
        if not isinstance(self.encoding, str) or len(self.encoding) > 64 or not isinstance(self.decoded, bool):
            raise ValueError("invalid string encoding")


def extract_strings(source: BoundedByteSource, ledger: BudgetLedger, max_length: int = 4096, min_length: int = 4) -> tuple[ExtractedString, ...]:
    if not 1 <= min_length <= max_length <= 65536:
        raise ValueError("invalid string extraction lengths")
    result: list[ExtractedString] = []
    seen: set[tuple[int, str, str]] = set()
    buffers: list[list[str]] = [[], [], []]
    starts = [0, 0, 0]
    encodings = ["ascii", "utf-16le", "utf-16le"]

    def emit(stream: int) -> None:
        text = "".join(buffers[stream])
        if len(text) >= min_length:
            key = (starts[stream], encodings[stream], text)
            if key not in seen:
                byte_length = len(text) * (1 if stream == 0 else 2)
                try:
                    ledger.consume_many({"strings": 1, "string_bytes": byte_length})
                except BudgetExceeded as exc:
                    exc.partial_results = tuple(sorted(result, key=lambda item: (item.offset, item.encoding, item.text)))
                    raise
                seen.add(key)
                result.append(ExtractedString(text, starts[stream], encodings[stream]))

    def append(stream: int, char: str, position: int) -> None:
        if not buffers[stream]:
            starts[stream] = position
        buffers[stream].append(char)
        if len(buffers[stream]) >= max_length:
            emit(stream)
            overlap = min(64, max_length // 4)
            buffers[stream] = buffers[stream][-overlap:] if overlap else []
            starts[stream] = position - (overlap - 1) * (1 if stream == 0 else 2)

    previous = None
    position = 0
    try:
        for chunk in source.iter_chunks():
            ledger.consume("parser_iterations", len(chunk))
            for byte in chunk:
                if 32 <= byte <= 126 or byte == 9:
                    append(0, chr(byte), position)
                else:
                    emit(0)
                    buffers[0] = []
                if previous is not None:
                    pair_position = position - 1
                    stream = 1 + pair_position % 2
                    if byte == 0 and (32 <= previous <= 126 or previous == 9):
                        append(stream, chr(previous), pair_position)
                    else:
                        emit(stream)
                        buffers[stream] = []
                previous = byte
                position += 1
        for stream in range(3):
            emit(stream)
    except BudgetExceeded as exc:
        if not exc.partial_results:
            exc.partial_results = tuple(sorted(result, key=lambda item: (item.offset, item.encoding, item.text)))
        raise
    return tuple(sorted(result, key=lambda item: (item.offset, item.encoding, item.text)))
