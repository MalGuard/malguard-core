"""Conservative GTA context derived from explicit source relationships.

An isolated game name in native strings is never proof of an exclusive target.
This small recognizer deliberately accepts only local, visible PID/handle flows.
"""

from __future__ import annotations

import re
from bisect import bisect_right
from itertools import islice
from dataclasses import dataclass


_PROCESS_CALL = re.compile(
    r"(?:Process\s*\.\s*)?GetProcessesByName\s*\(\s*[\"']([^\"'\r\n]{1,128})[\"']\s*\)",
    re.IGNORECASE,
)
_EXE_NAME = re.compile(r"(?<![\w.])([a-z0-9_.-]{1,96}\.exe)(?![\w.])", re.IGNORECASE)
_ASSIGN = re.compile(
    r"\b(?:var\s+|[A-Za-z_][\w<>.]*\s+)?([A-Za-z_]\w*)\s*=\s*"
    r"(?:Process\s*\.\s*)?GetProcessesByName\s*\(\s*[\"']GTA5(?:\.exe)?[\"']\s*\)",
    re.IGNORECASE,
)


@dataclass(frozen=True, slots=True)
class TargetContext:
    targets: tuple[str, ...]
    gta_only: bool
    source_linked: bool
    classification_tags: tuple[str, ...]


def identify_target_context(source: str, remote_memory: bool, code: str | None = None,
                            case_insensitive_variables: bool = False) -> TargetContext:
    """Recognize a GTA process variable flowing into OpenProcess and its handle.

    Arbitrary binary strings, absence of another target, and ScriptHookV branding
    do not establish this relationship. A second process name cancels exclusivity.
    """
    targets = {value.lower().removesuffix(".exe") for value in _PROCESS_CALL.findall(source)}
    targets.update(value.lower().removesuffix(".exe") for value in _EXE_NAME.findall(source))
    source_linked = False
    linked_handles = set()
    linked_open_offsets = set()
    visible = code if code is not None else source
    assignments = tuple(islice(_ASSIGN.finditer(source), 65))
    openings = tuple(islice(re.finditer(r"\bOpenProcess\s*\(", visible, re.IGNORECASE), 65))
    braces = tuple(islice(re.finditer(r"[{}]", visible), 4097))
    # This recognizer proves a narrow visible relationship, rather than trying
    # to resolve arbitrary language scopes or an unbounded number of bindings.
    ambiguous_scope = (len(assignments) > 64 or len(openings) > 64 or len(braces) > 4096
                       or bool(re.search(r"\b(?:Sub|Function)\b", visible, re.IGNORECASE)))
    scope_offsets = [-1]
    scope_paths: list[tuple[int, ...]] = [()]
    stack: list[int] = []
    if not ambiguous_scope:
        for brace in braces:
            if brace.group() == "{":
                stack.append(brace.start())
                if len(stack) > 64:
                    ambiguous_scope = True
                    break
            elif stack:
                stack.pop()
            else:
                ambiguous_scope = True
                break
            scope_offsets.append(brace.start())
            scope_paths.append(tuple(stack))
        ambiguous_scope = ambiguous_scope or bool(stack)

    def scope_at(position: int) -> tuple[int, ...]:
        return scope_paths[bisect_right(scope_offsets, position) - 1]

    handle_scopes: dict[str, tuple[int, ...]] = {}
    def variable_pattern(value: str) -> str:
        escaped = re.escape(value)
        return escaped if case_insensitive_variables else f"(?-i:{escaped})"

    def canonical_variable(value: str) -> str:
        return value.casefold() if case_insensitive_variables else value

    # A process object or array can be mutated by a callee without an assignment
    # to its local name. Bare references outside the binding and PID projection,
    # or receiver method calls, therefore cannot support an exclusive target.
    # Collect them once instead of scanning the whole source for every binding.
    escaped_targets = set()
    if remote_memory and targets == {"gta5"} and not ambiguous_scope:
        process_variables = {canonical_variable(match.group(1)) for match in assignments}
        for occurrence in re.finditer(r"\b([A-Za-z_]\w*)\b", visible):
            value = canonical_variable(occurrence.group(1))
            if value not in process_variables:
                continue
            tail = visible[occurrence.end():occurrence.end() + 96]
            if (not re.match(r"\s*(?:\.|\[|=(?!=))", tail)
                    or re.match(r"\s*\.\s*[A-Za-z_]\w*\s*\(", tail)):
                escaped_targets.add(value)

    def unmodified_variable(value: str, visible: str) -> bool:
        variable = variable_pattern(value)
        member = r"(?:\s*\[[^\]\r\n]{0,64}\]|\s*\.\s*[A-Za-z_]\w*)*"
        writes = re.findall(
            rf"\b{variable}{member}\s*(?:=(?!=)|[+*/%&|^-]=|<<=|>>=|\+\+|--)",
            visible, re.IGNORECASE,
        )
        prefixed = re.search(rf"(?:\+\+|--)\s*\b{variable}\b", visible, re.IGNORECASE)
        by_reference = re.search(rf"\b(?:ref|out)\s+{variable}\b", visible, re.IGNORECASE)
        alias = re.search(rf"\b[A-Za-z_]\w*\s*=\s*{variable}\s*[;\r\n]", visible, re.IGNORECASE)
        return len(writes) == 1 and not prefixed and not by_reference and not alias
    if remote_memory and targets == {"gta5"} and not ambiguous_scope:
        for match in assignments:
            if code is not None and not re.search(r"\bGetProcessesByName\s*\(", code[match.start():match.end()], re.IGNORECASE):
                continue
            variable = variable_pattern(match.group(1))
            if (canonical_variable(match.group(1)) in escaped_targets
                    or not unmodified_variable(match.group(1), visible)):
                continue
            pid = rf"{variable}\s*(?:\[\s*0\s*\])?\s*\.\s*Id"
            open_call = re.compile(
                rf"\b([A-Za-z_]\w*)\s*=\s*OpenProcess\s*\([^;\r\n]{{0,256}}\b{pid}\s*\)",
                re.IGNORECASE,
            )
            for handle_match in open_call.finditer(source):
                if handle_match.start() < match.end():
                    continue
                if scope_at(match.start()) != scope_at(handle_match.start()):
                    continue
                if code is not None and not re.search(r"\bOpenProcess\s*\(", code[handle_match.start():handle_match.end()], re.IGNORECASE):
                    continue
                handle = variable_pattern(handle_match.group(1))
                if not unmodified_variable(handle_match.group(1), visible):
                    continue
                use = re.compile(
                    rf"\b(?:ReadProcessMemory|WriteProcessMemory)\s*\(\s*{handle}\s*[,)]",
                    re.IGNORECASE,
                )
                uses = tuple(use.finditer(visible))
                if uses and all(item.start() >= handle_match.end()
                                and scope_at(item.start()) == scope_at(handle_match.start()) for item in uses):
                    canonical = canonical_variable(handle_match.group(1))
                    linked_handles.add(canonical)
                    handle_scopes[canonical] = scope_at(handle_match.start())
                    opening = re.search(r"\bOpenProcess\s*\(", source[handle_match.start():handle_match.end()], re.IGNORECASE)
                    if opening:
                        linked_open_offsets.add(handle_match.start() + opening.start())
    visible_code = code if code is not None else source
    open_offsets = {match.start() for match in re.finditer(r"\bOpenProcess\s*\(", visible_code, re.IGNORECASE)}
    scoped_apis = "ReadProcessMemory|WriteProcessMemory|VirtualAllocEx|VirtualProtectEx|CreateRemoteThread|CreateRemoteThreadEx"
    memory_handles = {canonical_variable(match.group(1)) for match in re.finditer(
        rf"\b(?:{scoped_apis})\s*\(\s*([A-Za-z_]\w*)\s*[,)]",
        visible_code, re.IGNORECASE,
    )}
    memory_calls = list(re.finditer(rf"\b(?:{scoped_apis})\s*\(", visible_code, re.IGNORECASE))
    every_handle_visible = all(re.match(r"\s*[A-Za-z_]\w*\s*[,)]", visible_code[match.end():]) for match in memory_calls)
    every_scope_linked = all(
        handle_scopes.get(canonical_variable(match.group(1))) == scope_at(match.start())
        for match in re.finditer(rf"\b(?:{scoped_apis})\s*\(\s*([A-Za-z_]\w*)\s*[,)]", visible_code, re.IGNORECASE)
    ) if not ambiguous_scope else False
    unresolved_handle_apis = bool(re.search(r"\b(?:QueueUserAPC|NtQueueApcThread|NtMapViewOfSection|NtCreateThreadEx|RtlCreateUserThread)\s*\(", visible_code, re.IGNORECASE))
    source_linked = (bool(linked_handles) and open_offsets == linked_open_offsets and every_handle_visible and every_scope_linked
                     and memory_handles.issubset(linked_handles) and not unresolved_handle_apis)
    gta_only = source_linked and targets == {"gta5"}
    return TargetContext(
        tuple(sorted(targets)), gta_only, source_linked,
        ("HACKTOOL_PUA",) if gta_only and remote_memory else (),
    )


def is_in_process_mod(imports: set[str], text: str, is_dll: bool) -> bool:
    """A DLL with ScriptHookV APIs supplies context, never a trust override."""
    hook_apis = {"scriptregister", "nativeinit", "nativepush64", "nativecall"}
    return is_dll and (bool(hook_apis.intersection(imports)) or "scripthookv" in text.lower())


__all__ = ["TargetContext", "identify_target_context", "is_in_process_mod"]
