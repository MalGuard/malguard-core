"""Static, multi-signal native capability analysis.

No disassembly or dynamic tracing is implied. Raw API spellings are weaker than
validated import facts, and individual dangerous APIs produce no harmful finding.
"""

from __future__ import annotations

import re
from collections.abc import Iterable
from typing import Any

from malguard_core.budget import BudgetExceeded, BudgetLedger
from malguard_core.gta_context import identify_target_context, is_in_process_mod
from malguard_core.model import (
    CoverageState, EvidenceDomain, EvidenceLocation, Severity, StageResult, make_evidence,
)


_API_GROUPS = {
    "open_process": {"openprocess", "ntopenprocess"},
    "remote_allocate": {"virtualallocex", "ntallocatevirtualmemory"},
    "remote_write": {"writeprocessmemory", "ntwritevirtualmemory"},
    "remote_execute": {"createremotethread", "createremotethreadex", "ntcreatethreadex", "queueuserapc", "ntqueueapcthread", "rtlcreateuserthread"},
    "remote_map": {"ntmapviewofsection", "zwmapviewofsection"},
    "memory_read": {"readprocessmemory", "ntreadvirtualmemory"},
    "keyboard": {"getasynckeystate", "getkeystate", "setwindowshookex"},
    "file_read": {"readfile", "fread", "sqlite3_prepare_v2", "sqlite3_exec"},
    "file_write": {"writefile", "fwrite", "fprintf"},
    "credential_decrypt": {"cryptunprotectdata", "bcryptdecrypt", "ncryptdecrypt"},
    "network_send": {"httpsendrequest", "winhttpsendrequest", "internetwritefile", "winhttpwritedata", "send", "wsasend", "smtp_send", "curl_easy_perform"},
    "network_open": {"internetopen", "winhttpopen", "internetopenurl", "connect", "urlmon", "urldownloadtofile"},
    "registry_write": {"regsetvalueex", "regcreatekeyex"},
    "service_create": {"createservice", "startservice"},
    "process_launch": {"createprocess", "shellexecute", "winexec"},
    "dynamic_api": {"getprocaddress", "ldrgetprocedureaddress"},
    "module_load": {"loadlibrary", "ldrloaddll"},
    "anti_debug": {"isdebuggerpresent", "checkremotedebuggerpresent", "ntqueryinformationprocess", "outputdebugstring"},
    "capture": {"bitblt", "stretchblt", "getdibits", "printwindow"},
    "clipboard": {"openclipboard", "getclipboarddata"},
    "delete": {"deletefile", "remove", "shfileoperation"},
    "local_allocate": {"virtualalloc", "virtualprotect"},
}
_KNOWN_APIS = set().union(*_API_GROUPS.values()) | {"scriptregister", "nativeinit", "nativepush64", "nativecall"}
_BROWSER = re.compile(r"(?:login\s+data|local\s+state|logins\.json|key4\.db|cookies|web\s+data)", re.IGNORECASE)
_CREDENTIAL_SELECT = re.compile(r"(?:password_value|encrypted_value|username_value|decrypt(?:ed)?_token|discord.{0,32}token|wallet\.dat|[\\/]leveldb\b)", re.IGNORECASE)
_URL = re.compile(r"\bhttps?://[^\s\"'<>]{3,256}", re.IGNORECASE)
_EXEC_TARGET = re.compile(r"\b(?:chrome|msedge|firefox|explorer|lsass|svchost|securityhealthservice|msmpeng)\.exe\b", re.IGNORECASE)


def normalize_api(value: str) -> str:
    """Normalize DLL decoration and A/W variants without merging unrelated APIs."""
    name = value.rsplit("!", 1)[-1].rsplit("::", 1)[-1].split("@", 1)[0].strip("_ ").lower()
    if name not in _KNOWN_APIS and name[-1:] in {"a", "w"} and name[:-1] in _KNOWN_APIS:
        name = name[:-1]
    return name


def _text_of(strings: Iterable[Any]) -> tuple[str, int | None, bool]:
    items = []
    first_offset = None
    decoded = False
    for item in strings:
        value = item if isinstance(item, str) else getattr(item, "text", "")
        if isinstance(value, str):
            items.append(value)
        if first_offset is None:
            first_offset = getattr(item, "offset", None)
        decoded = decoded or bool(getattr(item, "decoded", False))
    return "\n".join(items), first_offset, decoded


def _analyze_once(data: bytes, artifact_id: str, logical_path: str, ledger: BudgetLedger,
            strings: tuple, pe_facts: dict | None = None) -> StageResult:
    """Emit capability evidence while preserving raw analysis after PE failure."""
    evidence = []
    facts: dict[str, Any] = {"capabilities": [], "classification_tags": [], "gta_only": False}
    pe_facts = pe_facts or {}
    location = EvidenceLocation(artifact_id, detail="Static capability combinations")
    try:
        ledger.consume("parser_iterations", max(1, len(data) // 256))
        text, offset, decoded = _text_of(strings)
        if not text and data:
            text = data.decode("latin-1", errors="replace")
        imports = {
            normalize_api(value) for value in pe_facts.get("imports", [])
            if isinstance(value, str)
        }
        raw_names = {normalize_api(match.group(0)) for match in re.finditer(r"\b[A-Za-z_][A-Za-z_0-9@]{2,80}\b", text)}
        raw_apis = raw_names.intersection(_KNOWN_APIS)
        apis = imports | raw_apis
        capabilities = {key for key, group in _API_GROUPS.items() if apis.intersection(group)}
        facts["capabilities"] = sorted(capabilities)
        facts["raw_capabilities"] = sorted({key for key, group in _API_GROUPS.items() if raw_apis.intersection(group)})
        facts["validated_capabilities"] = sorted({key for key, group in _API_GROUPS.items() if imports.intersection(group)})
        # Native strings can contain forged source snippets. They establish target
        # names, but cannot prove an exclusive PID/handle flow in machine code.
        target_context = identify_target_context(text, False)
        facts.update(gta_only=target_context.gta_only, target_processes=list(target_context.targets), classification_tags=list(target_context.classification_tags))
        location = EvidenceLocation(artifact_id, offset=offset, detail="Imports and bounded extracted strings")

        def emit(rule: str, domain: EvidenceDomain, family: str, severity: Severity,
                 en: str, fa: str, confidence: float = .9, involved: set[str] | None = None,
                 mitigating: bool = False) -> None:
            reliability = .60 if decoded else .70
            if involved and all(imports.intersection(_API_GROUPS.get(key, set())) for key in involved):
                reliability = 1.0
            ledger.consume("evidence")
            evidence.append(make_evidence(
                rule, "S3", domain, family, "CAPABILITY_COMBINATION", severity, location,
                en, fa, confidence=confidence, reliability=reliability,
                mitigating=mitigating, attributes=(("validated_imports", reliability == 1.0),),
            ))

        if is_in_process_mod(imports | raw_apis, text, bool(pe_facts.get("is_dll"))):
            emit("native.gta.in_process_mod", EvidenceDomain.CONTEXT, "GAME_PROCESS_MODIFICATION", Severity.INFO,
                 "ScriptHookV-related DLL context is present; in-process hooks and protection changes are dual-use.",
                 "زمینهٔ افزونهٔ داخل فرایند GTA دیده شد؛ هوک و تغییر حفاظت حافظه به‌تنهایی رفتار مخرب نیست.", 1.0)
        injection = {"open_process", "remote_write", "remote_execute"}.issubset(capabilities) and bool(capabilities.intersection({"remote_allocate", "remote_map"}))
        if injection:
            emit("native.injection.chain", EvidenceDomain.HARM, "PROCESS_INJECTION", Severity.CRITICAL,
                 "Remote-process allocation or mapping, memory writing, and remote execution capabilities occur together.",
                 "قابلیت تخصیص یا نگاشت حافظه، نوشتن در فرایند دیگر و اجرای کد از راه دور هم‌زمان دیده شد.",
                 .96, {"open_process", "remote_write", "remote_execute"})
            if _EXEC_TARGET.search(text):
                emit("native.injection.non_game_target", EvidenceDomain.HARM, "PROCESS_INJECTION", Severity.HIGH,
                     "The injection capability chain also names a browser, system, or security process.",
                     "زنجیرهٔ تزریق همراه با نام مرورگر یا فرایند سیستم یا امنیتی دیده شد.", .9)
        elif {"open_process", "remote_write"}.issubset(capabilities) and not target_context.gta_only:
            emit("native.remote_memory.unknown_scope", EvidenceDomain.HARM, "PROCESS_INJECTION", Severity.HIGH,
                 "Cross-process memory writing is present without a proven exclusive GTA target.",
                 "نوشتن حافظهٔ فرایند دیگر دیده شد و محدود بودن هدف به GTA اثبات نشد.", .95, {"open_process", "remote_write"})
        if target_context.gta_only:
            emit("native.gta.external_trainer", EvidenceDomain.CONTEXT, "GAME_PROCESS_MODIFICATION", Severity.INFO,
                 "A visible process-variable and handle relationship scopes memory access to GTA5 only.",
                 "رابطهٔ متغیر هدف و دستگیره نشان می‌دهد دسترسی حافظهٔ این بخش فقط به GTA5 مربوط است.", 1.0, mitigating=True)
        credential_target = bool(_BROWSER.search(text) and _CREDENTIAL_SELECT.search(text)) or bool(re.search(r"(?:wallet\.dat|discord.{0,24}leveldb|steam.{0,24}(?:ssfn|loginusers\.vdf))", text, re.IGNORECASE))
        credential_chain = credential_target and "file_read" in capabilities and "credential_decrypt" in capabilities
        if credential_chain:
            emit("native.credential.read_decrypt", EvidenceDomain.HARM, "CREDENTIAL_ACCESS", Severity.CRITICAL,
                 "Credential-store paths and credential fields occur with file reading and protected-data decryption capabilities.",
                 "مسیر و فیلدهای ذخیرهٔ اعتبارنامه همراه با خواندن فایل و رمزگشایی دادهٔ محافظت‌شده دیده شد.", .96, {"file_read", "credential_decrypt"})
            emit("native.credential.store_fields", EvidenceDomain.HARM, "CREDENTIAL_ACCESS", Severity.CRITICAL,
                 "Specific credential-store fields corroborate the read-and-decrypt capability chain.",
                 "فیلدهای مشخص ذخیرهٔ اعتبارنامه، زنجیرهٔ خواندن و رمزگشایی را تقویت می‌کنند.", .92)
        elif credential_target and ("file_read" in capabilities or "credential_decrypt" in capabilities):
            emit("native.credential.partial_chain", EvidenceDomain.HARM, "CREDENTIAL_ACCESS", Severity.HIGH,
                 "Credential-specific stores occur with reading or decryption, but data flow is not proven.",
                 "ذخیرهٔ مشخص اعتبارنامه همراه با خواندن یا رمزگشایی دیده شد؛ جریان داده اثبات نشد.", .86)
        upload_marker = bool(re.search(r"\b(?:POST|multipart/form-data|upload|send_credentials|exfiltrat\w*|smtp)\b", text, re.IGNORECASE))
        if credential_chain and "network_send" in capabilities and upload_marker:
            emit("native.exfil.credential_upload", EvidenceDomain.HARM, "EXFILTRATION", Severity.CRITICAL,
                 "Credential collection co-occurs with an outbound send capability and upload or mail protocol markers.",
                 "جمع‌آوری اعتبارنامه همراه با قابلیت ارسال و نشانگر بارگذاری یا پروتکل ایمیل دیده شد.", .95, {"network_send"})
            emit("native.exfil.protocol_sink", EvidenceDomain.HARM, "EXFILTRATION", Severity.CRITICAL,
                 "An upload protocol sink corroborates outbound transfer of collected sensitive data; static data flow remains limited.",
                 "نشانگر مقصد بارگذاری، انتقال دادهٔ حساس جمع‌شده را تقویت می‌کند؛ جریان دادهٔ ایستا همچنان محدود است.", .9)
        if "keyboard" in capabilities and capabilities.intersection({"file_write", "network_send"}):
            if re.search(r"(?:WH_KEYBOARD_LL|keylog|keystroke|VK_[A-Z0-9_]+)", text, re.IGNORECASE):
                emit("native.keylogging.capture_sink", EvidenceDomain.HARM, "KEYLOGGING", Severity.CRITICAL,
                     "Keyboard capture, keystroke-oriented markers, and a storage or network sink occur together.",
                     "ثبت کلیدهای صفحه‌کلید، نشانگرهای ثبت کلید و مقصد ذخیره یا ارسال هم‌زمان دیده شد.", .9)
        run_key = bool(re.search(r"(?:CurrentVersion[\\/]Run(?:Once)?\b|[\\/]Startup[\\/])", text, re.IGNORECASE))
        scheduled = bool(re.search(r"\bschtasks(?:\.exe)?\b.{0,100}/create|\bRegisterTaskDefinition\b", text, re.IGNORECASE))
        if (run_key and capabilities.intersection({"registry_write", "file_write"})) or (scheduled and "process_launch" in capabilities) or {"service_create", "file_write"}.issubset(capabilities):
            emit("native.persistence.install", EvidenceDomain.HARM, "PERSISTENCE", Severity.CRITICAL,
                 "An autorun, scheduled-task, or service persistence mechanism is paired with an installation capability.",
                 "سازوکار اجرای خودکار، وظیفهٔ زمان‌بندی‌شده یا سرویس همراه با قابلیت نصب دیده شد.", .93)
        if re.search(r"(?:Set-MpPreference.{0,100}-DisableRealtimeMonitoring\s+(?:\$true\b|1\b)|Add-MpPreference.{0,100}-Exclusion|\bsc\s+(?:stop|delete)\s+(?:WinDefend|WdNisSvc))", text, re.IGNORECASE):
            if capabilities.intersection({"registry_write", "process_launch"}):
                emit("native.security_tampering.command", EvidenceDomain.HARM, "SECURITY_TAMPERING", Severity.CRITICAL,
                     "Security-control disabling commands occur with a registry or process-launch capability.",
                     "دستورهای غیرفعال کردن کنترل امنیتی همراه با تغییر رجیستری یا اجرای فرایند دیده شد.", .95)
        if "capture" in capabilities:
            emit("native.screen_capture", EvidenceDomain.CONTEXT, "SCREEN_CAPTURE", Severity.INFO,
                 "Screen capture capability is present; capture alone does not establish harmful use.",
                 "قابلیت تصویربرداری صفحه دیده شد؛ این قابلیت به‌تنهایی رفتار مخرب را اثبات نمی‌کند.", .8)
            if "network_send" in capabilities and upload_marker and {"getdibits", "bitblt"}.issubset(apis):
                emit("native.exfil.screen_transfer", EvidenceDomain.HARM, "EXFILTRATION", Severity.HIGH,
                     "Screen-capture and pixel-extraction APIs co-occur with an outbound send capability and upload protocol markers.",
                     "API تصویربرداری و استخراج پیکسل همراه با قابلیت ارسال و نشانگر پروتکل بارگذاری دیده شد.", .95, {"capture", "network_send"})
        if "clipboard" in capabilities:
            emit("native.clipboard_access", EvidenceDomain.CONTEXT, "CLIPBOARD_ACCESS", Severity.INFO,
                 "Clipboard read capability is present; access alone does not establish theft.",
                 "قابلیت خواندن کلیپ‌بورد دیده شد؛ دسترسی به‌تنهایی سرقت را اثبات نمی‌کند.", .8)
            if "network_send" in capabilities and upload_marker and re.search(r"\b(?:clipboard|CF_UNICODETEXT|CF_TEXT)\b", text, re.IGNORECASE):
                emit("native.exfil.clipboard_transfer", EvidenceDomain.HARM, "EXFILTRATION", Severity.HIGH,
                     "Clipboard reading and clipboard-data markers co-occur with outbound upload capabilities.",
                     "خواندن کلیپ‌بورد و نشانگر دادهٔ آن همراه با قابلیت بارگذاری به بیرون دیده شد.", .94, {"clipboard", "network_send"})
        if "anti_debug" in capabilities and re.search(r"(?:debugger|vmware|virtualbox|qemu|sandbox|vbox)", text, re.IGNORECASE):
            emit("native.opacity.anti_analysis", EvidenceDomain.OPACITY, "ANTI_DEBUG_VM", Severity.MEDIUM,
                 "Anti-debug or virtual-environment checks reduce static-analysis confidence and are not harmful behavior by themselves.",
                 "بررسی دیباگر یا محیط مجازی اعتماد تحلیل را کاهش می‌دهد و به‌تنهایی رفتار مخرب نیست.", .85)
        if {"dynamic_api", "module_load"}.issubset(capabilities):
            emit("native.opacity.dynamic_api", EvidenceDomain.OPACITY, "DYNAMIC_API_RESOLUTION", Severity.LOW,
                 "Runtime API resolution is present; the resolved behavior may not be fully visible statically.",
                 "حل نام API در زمان اجرا دیده شد؛ رفتار مقصد ممکن است در تحلیل ایستا کامل دیده نشود.", .9)
        if re.search(r"(?:ror\s+\w+\s*,\s*(?:0x)?d\b|api[_ -]?hash|hash[_ -]?(?:api|export))", text, re.IGNORECASE) and "dynamic_api" in capabilities:
            emit("native.opacity.api_hash", EvidenceDomain.OPACITY, "DYNAMIC_API_RESOLUTION", Severity.MEDIUM,
                 "API hash markers co-occur with dynamic API resolution; this is an opacity heuristic.",
                 "نشانگر هش API همراه با حل نام پویا دیده شد؛ این یک قرینهٔ پوشیدگی است.", .7)
        if re.search(rb"\x4c\x8b\xd1\xb8[\s\S]{4,16}\x0f\x05\xc3", data):
            emit("native.opacity.direct_syscall", EvidenceDomain.OPACITY, "DYNAMIC_API_RESOLUTION", Severity.MEDIUM,
                 "A bounded raw-byte pattern resembles a Windows x64 syscall stub; static bytes do not establish execution.",
                 "الگوی بایت خام به واسط فراخوانی مستقیم سیستم x64 شبیه است؛ اجرای آن اثبات نشده است.", .65)
        if re.search(r"\bxor\s+[^\r\n]{0,80}\b(?:loop|jnz|for|while)\b|\b(?:for|while)\b[^\r\n]{0,120}\^\s*(?:0x[0-9a-f]+|\d+)", text, re.IGNORECASE):
            emit("native.opacity.xor_loop", EvidenceDomain.OPACITY, "STRING_ENCRYPTION", Severity.MEDIUM,
                 "A constant-XOR loop pattern may conceal strings or payload bytes.",
                 "الگوی حلقهٔ XOR ثابت ممکن است رشته یا بایت‌های محموله را پنهان کند.", .7)
        if re.search(r"\bmov\s+(?:byte|dword|qword)\s+ptr\s*\[\s*(?:rsp|esp)", text, re.IGNORECASE):
            emit("native.opacity.stack_strings", EvidenceDomain.OPACITY, "STRING_ENCRYPTION", Severity.LOW,
                 "Immediate stack-write patterns may construct strings at runtime.",
                 "نوشتن ثابت روی پشته ممکن است رشته‌ها را هنگام اجرا بازسازی کند.", .65)
        if {"local_allocate", "dynamic_api"}.issubset(capabilities) and data.count(b"\x90") >= 64 and (b"\xff\xe0" in data or b"\xff\xd0" in data):
            emit("native.opacity.shellcode_like", EvidenceDomain.OPACITY, "OBFUSCATION", Severity.MEDIUM,
                 "Executable-memory APIs co-occur with shellcode-like raw bytes; this remains a heuristic opacity finding.",
                 "API حافظهٔ اجرایی همراه با بایت‌های شبیه شل‌کد دیده شد؛ این قرینهٔ پوشیدگی است.", .65)
        if "delete" in capabilities and re.search(r"(?:vssadmin\s+delete\s+shadows|bcdedit.{0,60}recoveryenabled.{0,20}no|format\s+[a-z]:)", text, re.IGNORECASE):
            emit("native.destructive.recovery_delete", EvidenceDomain.HARM, "DESTRUCTIVE_BEHAVIOR", Severity.CRITICAL,
                 "Deletion capabilities co-occur with commands that remove recovery data or format a volume.",
                 "قابلیت حذف همراه با دستور حذف دادهٔ بازیابی یا قالب‌بندی حجم دیده شد.", .9)
        facts["unresolved_loader"] = injection and not target_context.gta_only
        facts["gta_mitigation_families"] = ["PROCESS_INJECTION"] if target_context.gta_only and not _EXEC_TARGET.search(text) else []
        return StageResult("S3", evidence=tuple(evidence), facts=facts, limitations=(
            "Native capability correlation does not prove control flow; encrypted code, indirect calls, and complex stack strings may remain unseen.",
        ))
    except BudgetExceeded as exc:
        return StageResult("S3", CoverageState.SKIPPED_LIMIT, tuple(evidence), facts,
                           errors=(exc.error_code,), limitations=(f"Native capability work budget exhausted: {exc.resource}.",))


def analyze(data: bytes, artifact_id: str, logical_path: str, ledger: BudgetLedger,
            strings: tuple, pe_facts: dict | None = None) -> StageResult:
    """Keep original provenance when unrelated decoded material is added."""
    raw = tuple(item for item in strings if not getattr(item, "decoded", False))
    baseline = _analyze_once(data, artifact_id, logical_path, ledger, raw, pe_facts)
    if len(raw) == len(strings):
        return baseline
    enriched = _analyze_once(data, artifact_id, logical_path, ledger, strings, pe_facts)
    evidence = {item.id: item for item in (*baseline.evidence, *enriched.evidence)}
    state = enriched.state if baseline.state == CoverageState.COMPLETE else baseline.state
    return StageResult("S3", state, tuple(evidence.values()), {**baseline.facts, **enriched.facts},
                       (*baseline.errors, *enriched.errors), (*baseline.limitations, *enriched.limitations))


__all__ = ["analyze", "normalize_api"]
