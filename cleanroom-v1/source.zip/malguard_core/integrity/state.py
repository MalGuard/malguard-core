"""Rollback state kept outside scanned artifacts and ordinary user settings."""

from __future__ import annotations

import json
import os
import re
import stat
import sys
import tempfile
from contextlib import contextmanager
from pathlib import Path


class EpochStateError(ValueError):
    """Rollback, state corruption, or insufficient filesystem protection."""


def _windows_sddl(path: Path) -> str:
    if sys.platform != "win32":
        raise EpochStateError("Windows state ACL inspection requires Windows")
    import ctypes
    from ctypes import wintypes

    advapi = ctypes.WinDLL("advapi32", use_last_error=True)
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    get_security = advapi.GetFileSecurityW
    get_security.argtypes = (wintypes.LPCWSTR, wintypes.DWORD, wintypes.LPVOID, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD))
    get_security.restype = wintypes.BOOL
    required = wintypes.DWORD()
    get_security(str(path), 5, None, 0, ctypes.byref(required))
    if not 1 <= required.value <= 1024 * 1024:
        raise EpochStateError("Cannot inspect protected Windows state ACL")
    buffer = ctypes.create_string_buffer(required.value)
    if not get_security(str(path), 5, buffer, required.value, ctypes.byref(required)):
        raise EpochStateError("Cannot read protected Windows state ACL")
    convert = advapi.ConvertSecurityDescriptorToStringSecurityDescriptorW
    convert.argtypes = (wintypes.LPVOID, wintypes.DWORD, wintypes.DWORD, ctypes.POINTER(wintypes.LPWSTR), ctypes.POINTER(wintypes.DWORD))
    convert.restype = wintypes.BOOL
    text = wintypes.LPWSTR()
    if not convert(buffer, 1, 5, ctypes.byref(text), None):
        raise EpochStateError("Cannot decode protected Windows state ACL")
    try:
        return text.value or ""
    finally:
        kernel.LocalFree.argtypes = (wintypes.HLOCAL,)
        kernel.LocalFree.restype = wintypes.HLOCAL
        kernel.LocalFree(text)


def _windows_create_directory(path: Path) -> None:
    if sys.platform != "win32":
        raise EpochStateError("Windows state ACL creation requires Windows")
    import ctypes
    from ctypes import wintypes

    class SecurityAttributes(ctypes.Structure):
        _fields_ = [("length", wintypes.DWORD), ("descriptor", wintypes.LPVOID), ("inherit", wintypes.BOOL)]

    advapi = ctypes.WinDLL("advapi32", use_last_error=True)
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    descriptor = wintypes.LPVOID()
    convert = advapi.ConvertStringSecurityDescriptorToSecurityDescriptorW
    convert.argtypes = (wintypes.LPCWSTR, wintypes.DWORD, ctypes.POINTER(wintypes.LPVOID), ctypes.POINTER(wintypes.DWORD))
    convert.restype = wintypes.BOOL
    # Normal user accounts cannot replace this state or add their own trust data.
    sddl = "O:BAG:BAD:P(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)"
    if not convert(sddl, 1, ctypes.byref(descriptor), None):
        raise EpochStateError("Cannot construct protected state ACL")
    try:
        attributes = SecurityAttributes(ctypes.sizeof(SecurityAttributes), descriptor, False)
        kernel.CreateDirectoryW.argtypes = (wintypes.LPCWSTR, ctypes.POINTER(SecurityAttributes))
        kernel.CreateDirectoryW.restype = wintypes.BOOL
        if not kernel.CreateDirectoryW(str(path), ctypes.byref(attributes)):
            raise EpochStateError("Administrator updater required to create protected state")
    finally:
        kernel.LocalFree.argtypes = (wintypes.HLOCAL,)
        kernel.LocalFree.restype = wintypes.HLOCAL
        kernel.LocalFree(descriptor)


def _windows_protect_file(path: Path) -> None:
    if sys.platform != "win32":
        raise EpochStateError("Windows file ACL creation requires Windows")
    import ctypes
    from ctypes import wintypes

    advapi = ctypes.WinDLL("advapi32", use_last_error=True)
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    descriptor = wintypes.LPVOID()
    convert = advapi.ConvertStringSecurityDescriptorToSecurityDescriptorW
    convert.argtypes = (wintypes.LPCWSTR, wintypes.DWORD, ctypes.POINTER(wintypes.LPVOID), ctypes.POINTER(wintypes.DWORD))
    convert.restype = wintypes.BOOL
    if not convert("O:BAD:P(A;;FA;;;SY)(A;;FA;;;BA)", 1, ctypes.byref(descriptor), None):
        raise EpochStateError("Cannot construct protected file ACL")
    try:
        advapi.SetFileSecurityW.argtypes = (wintypes.LPCWSTR, wintypes.DWORD, wintypes.LPVOID)
        advapi.SetFileSecurityW.restype = wintypes.BOOL
        if not advapi.SetFileSecurityW(str(path), 0x80000005, descriptor):
            raise EpochStateError("Administrator updater required to protect state file")
    finally:
        kernel.LocalFree.argtypes = (wintypes.HLOCAL,)
        kernel.LocalFree.restype = wintypes.HLOCAL
        kernel.LocalFree(descriptor)


def default_state_directory() -> Path:
    if sys.platform == "win32":
        import ctypes
        from ctypes import wintypes

        buffer = ctypes.create_unicode_buffer(32768)
        shell = ctypes.WinDLL("shell32", use_last_error=True)
        shell.SHGetFolderPathW.argtypes = (wintypes.HWND, ctypes.c_int, wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR)
        shell.SHGetFolderPathW.restype = ctypes.c_long
        if shell.SHGetFolderPathW(None, 0x23, None, 0, buffer) != 0:
            raise EpochStateError("Windows ProgramData unavailable")
        return Path(buffer.value) / "MalGuardSecurityState"
    return Path.home() / ".local" / "state" / "malguard-security"


class ProtectedEpochState:
    """Locked atomic monotonic state; Windows writes require administrator access."""

    def __init__(self, directory: Path | None = None) -> None:
        self.directory = Path(directory) if directory is not None else default_state_directory()

    def _prepare(self) -> None:
        if not self.directory.exists():
            if os.name == "nt":
                _windows_create_directory(self.directory)
            else:
                self.directory.parent.mkdir(parents=True, exist_ok=True)
                self.directory.mkdir(mode=0o700)
        self._validate(self.directory, directory=True)

    @staticmethod
    def _validate(path: Path, *, directory: bool = False) -> None:
        info = path.lstat()
        expected = stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode)
        if not expected or stat.S_ISLNK(info.st_mode):
            raise EpochStateError("Protected state is not ordinary")
        if sys.platform == "win32":
            sddl = _windows_sddl(path)
            if not (sddl.startswith("O:BA") or sddl.startswith("O:SY")) or "D:P" not in sddl:
                raise EpochStateError("Windows state owner/DACL is not protected")
            aces = re.findall(r"\(([^()]*)\)", sddl)
            if not aces or any(ace.split(";")[-1] not in {"BA", "SY"} for ace in aces):
                raise EpochStateError("Windows state grants access outside administrators/system")
        elif info.st_uid != os.getuid() or stat.S_IMODE(info.st_mode) & 0o077:
            raise EpochStateError("State must be owner-only")

    @contextmanager
    def _locked(self):
        self._prepare()
        path = self.directory / "state.lock"
        flags = os.O_RDWR | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0)
        try:
            descriptor = os.open(path, flags | os.O_EXCL, 0o600)
            try:
                if os.name == "nt":
                    _windows_protect_file(path)
            except BaseException:
                os.close(descriptor)
                raise
        except FileExistsError:
            descriptor = os.open(path, os.O_RDWR | getattr(os, "O_NOFOLLOW", 0))
        try:
            self._validate(path)
            if sys.platform == "win32":
                import msvcrt
                if os.fstat(descriptor).st_size == 0:
                    os.write(descriptor, b"0")
                os.lseek(descriptor, 0, os.SEEK_SET)
                msvcrt.locking(descriptor, msvcrt.LK_LOCK, 1)
            else:
                import fcntl
                fcntl.flock(descriptor, fcntl.LOCK_EX)
            yield
        finally:
            os.close(descriptor)

    def _read(self) -> tuple[int, str]:
        path = self.directory / "epoch.json"
        if not path.exists():
            return 0, ""
        self._validate(path)
        from .bundle import strict_json
        with path.open("rb") as stream:
            data = stream.read(4097)
        if len(data) > 4096:
            raise EpochStateError("State is too large")
        record = strict_json(data)
        if not isinstance(record, dict) or set(record) != {"epoch", "manifest_sha256"}:
            raise EpochStateError("State schema invalid")
        epoch, digest = record["epoch"], record["manifest_sha256"]
        if type(epoch) is not int or not 1 <= epoch < 2**63 or not isinstance(digest, str) or not re.fullmatch("[0-9a-f]{64}", digest):
            raise EpochStateError("State contents invalid")
        return epoch, digest

    def _check(self, epoch: int, digest: str) -> None:
        previous, previous_digest = self._read()
        if epoch < previous or (epoch == previous and digest != previous_digest):
            raise EpochStateError("Security bundle rollback or epoch reuse")

    def check(self, epoch: int, digest: str) -> None:
        with self._locked():
            self._check(epoch, digest)

    def accept(self, epoch: int, digest: str) -> None:
        if type(epoch) is not int or not 1 <= epoch < 2**63 or not re.fullmatch("[0-9a-f]{64}", digest):
            raise EpochStateError("Invalid accepted epoch/digest")
        with self._locked():
            self._check(epoch, digest)
            descriptor, name = tempfile.mkstemp(prefix=".epoch-", dir=self.directory)
            try:
                with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
                    if os.name == "nt":
                        _windows_protect_file(Path(name))
                    json.dump({"epoch": epoch, "manifest_sha256": digest}, stream, sort_keys=True)
                    stream.flush()
                    os.fsync(stream.fileno())
                self._validate(Path(name))
                os.replace(name, self.directory / "epoch.json")
            finally:
                if os.path.exists(name):
                    os.unlink(name)
