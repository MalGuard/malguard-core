"""Verify bounded versioned bundles before their contents influence analysis."""

from __future__ import annotations

import hashlib
import base64
import binascii
import json
import os
import re
import stat
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path, PurePosixPath
from types import MappingProxyType
from typing import TYPE_CHECKING

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from packaging.version import InvalidVersion, Version

if TYPE_CHECKING:
    from collections.abc import Mapping
    from .state import ProtectedEpochState


class BundleError(ValueError):
    """A bundle is unsigned, ambiguous, tampered, incompatible, or rolled back."""


_VERIFIED_BUNDLE_SEAL = object()


def _pairs(pairs: list[tuple[str, object]]) -> dict[str, object]:
    result: dict[str, object] = {}
    for key, value in pairs:
        if key in result:
            raise BundleError("Duplicate JSON object key")
        result[key] = value
    return result


def _constant(value: str) -> object:
    raise BundleError("Nonfinite JSON number")


def strict_json(data: bytes) -> object:
    try:
        return json.loads(data.decode("utf-8"), object_pairs_hook=_pairs, parse_constant=_constant)
    except (UnicodeError, json.JSONDecodeError, RecursionError) as error:
        raise BundleError("Invalid bounded UTF-8 JSON") from error


@dataclass(frozen=True, slots=True)
class VerifiedBundle:
    """A signed, digest checked snapshot; payload bytes cannot change afterwards."""

    version: str
    epoch: int
    ruleset_version: str
    key_id: str
    manifest_sha256: str
    manifest_bytes: bytes
    signature: bytes
    payloads: Mapping[str, bytes]
    _seal: object = field(default=None, repr=False, compare=False)

    def __post_init__(self) -> None:
        if self._seal is not _VERIFIED_BUNDLE_SEAL:
            raise BundleError("VerifiedBundle can only be created by signature verification")
        object.__setattr__(self, "payloads", MappingProxyType(dict(self.payloads)))


class BundleVerifier:
    """Trust keys are explicitly provisioned by the engine/operator, never a sample."""

    def __init__(
        self,
        trusted_keys: Mapping[str, bytes],
        state: ProtectedEpochState | None = None,
        engine_version: str = "1.1.0",
    ) -> None:
        self._keys = MappingProxyType(dict(trusted_keys))
        self.state = state
        self.engine_version = Version(engine_version)

    @staticmethod
    def _read(path: Path, limit: int) -> bytes:
        try:
            info = path.lstat()
            if not stat.S_ISREG(info.st_mode) or info.st_size > limit:
                raise BundleError("Bundle payload is not an ordinary bounded file")
            # A racing replacement must not turn the prechecked regular file
            # into a blocking FIFO or followed link before authentication.
            flags = os.O_RDONLY | getattr(os, "O_BINARY", 0)
            flags |= getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0)
            descriptor = os.open(path, flags)
            try:
                opened = os.fstat(descriptor)
                if not stat.S_ISREG(opened.st_mode) or opened.st_size > limit:
                    raise BundleError("Opened bundle payload is not an ordinary bounded file")
                with os.fdopen(descriptor, "rb", closefd=False) as stream:
                    data = stream.read(limit + 1)
            finally:
                os.close(descriptor)
            if len(data) > limit:
                raise BundleError("Bundle payload exceeded read limit")
            return data
        except OSError as error:
            raise BundleError("Bundle payload unavailable") from error

    def verify(self, directory: Path, *, commit: bool = True) -> VerifiedBundle:
        directory = Path(directory)
        if not directory.is_dir() or directory.is_symlink():
            raise BundleError("Bundle directory is not ordinary")

        def read(name: str, limit: int) -> bytes:
            current = directory
            for part in PurePosixPath(name).parts:
                current /= part
                if current.is_symlink():
                    raise BundleError("Symlink in bundle path")
            return self._read(current, limit)

        return self._verify(read, commit=commit)

    def verify_snapshot(self, snapshot: dict, *, commit: bool = False) -> VerifiedBundle:
        """Reverify primitive JSON IPC; caller-provided keys are never accepted."""
        fields = {"schema_version", "manifest_b64", "signature_b64", "payloads"}
        if not isinstance(snapshot, dict) or set(snapshot) != fields or type(snapshot["schema_version"]) is not int or snapshot["schema_version"] != 1:
            raise BundleError("Signed snapshot schema invalid")
        payloads = snapshot["payloads"]
        if not isinstance(payloads, dict) or len(payloads) > 256:
            raise BundleError("Signed snapshot payload count invalid")
        encoded = {"manifest.json": snapshot["manifest_b64"], "manifest.sig": snapshot["signature_b64"], **payloads}
        if len(encoded) != len(payloads) + 2:
            raise BundleError("Signed snapshot reserved name collision")
        if any(not isinstance(name, str) or len(name) > 256 or not isinstance(value, str) for name, value in encoded.items()):
            raise BundleError("Signed snapshot text invalid")
        if sum(len(value) for value in encoded.values()) > 23 * 1024 * 1024:
            raise BundleError("Signed snapshot input limit")

        def read(name: str, limit: int) -> bytes:
            value = encoded.get(name)
            if value is None or len(value) > ((limit + 2) // 3) * 4:
                raise BundleError("Signed snapshot payload unavailable/oversized")
            try:
                data = base64.b64decode(value, validate=True)
            except (ValueError, binascii.Error) as error:
                raise BundleError("Signed snapshot base64 invalid") from error
            if len(data) > limit:
                raise BundleError("Signed snapshot decoded limit")
            return data

        bundle = self._verify(read, commit=False)
        if set(payloads) != set(bundle.payloads):
            raise BundleError("Unsigned extra snapshot payload")
        if commit and self.state is not None:
            self.state.accept(bundle.epoch, bundle.manifest_sha256)
        return bundle

    def _verify(self, read, *, commit: bool) -> VerifiedBundle:
        manifest_bytes = read("manifest.json", 128 * 1024)
        signature = read("manifest.sig", 64)
        manifest = strict_json(manifest_bytes)
        fields = {"bundle_version", "epoch", "minimum_engine_version", "ruleset_version", "created_at", "key_id", "files"}
        if not isinstance(manifest, dict) or set(manifest) != fields:
            raise BundleError("Manifest schema mismatch")
        for key in fields - {"epoch", "files"}:
            if not isinstance(manifest[key], str) or not 1 <= len(manifest[key]) <= 200:
                raise BundleError("Manifest field length/type invalid")
        epoch = manifest["epoch"]
        if type(epoch) is not int or not 1 <= epoch <= 2**63 - 1:
            raise BundleError("Invalid manifest epoch")
        try:
            if Version(manifest["minimum_engine_version"]) > self.engine_version:
                raise BundleError("Engine too old for bundle")
            timestamp = datetime.fromisoformat(manifest["created_at"].replace("Z", "+00:00"))
            if timestamp.utcoffset() is None:
                raise BundleError("Bundle timestamp must specify timezone")
        except (InvalidVersion, ValueError) as error:
            raise BundleError("Invalid version or timestamp") from error
        key_id = manifest["key_id"]
        public_key = self._keys.get(key_id)
        if public_key is None or len(signature) != 64:
            raise BundleError("Untrusted key or invalid signature length")
        try:
            Ed25519PublicKey.from_public_bytes(public_key).verify(signature, manifest_bytes)
        except (InvalidSignature, ValueError) as error:
            raise BundleError("Invalid bundle signature") from error

        files = manifest["files"]
        required = {"blocklist.json", "allowlist.json", "iocs.json", "revoked_signers.json"}
        if not isinstance(files, dict) or not required <= set(files) or len(files) > 256:
            raise BundleError("Invalid payload manifest")
        payloads: dict[str, bytes] = {}
        total = 0
        for name, digest in sorted(files.items()):
            if not isinstance(name, str) or not isinstance(digest, str) or not re.fullmatch("[0-9a-f]{64}", digest):
                raise BundleError("Invalid payload digest")
            path = PurePosixPath(name)
            permitted = name in required or (len(path.parts) == 2 and path.parts[0] == "rules" and path.suffix == ".yar")
            if not permitted or path.as_posix() != name or "\\" in name or ":" in name or any(part in {"..", ".", ""} for part in path.parts):
                raise BundleError("Unsafe bundle path")
            data = read(name, 4 * 1024 * 1024)
            total += len(data)
            if total > 16 * 1024 * 1024:
                raise BundleError("Bundle expansion limit")
            if hashlib.sha256(data).hexdigest() != digest:
                raise BundleError("Payload hash mismatch")
            if name.endswith(".json"):
                strict_json(data)
            payloads[name] = data
        result = VerifiedBundle(
            manifest["bundle_version"], epoch, manifest["ruleset_version"], key_id,
            hashlib.sha256(manifest_bytes).hexdigest(), manifest_bytes, signature,
            MappingProxyType(payloads), _VERIFIED_BUNDLE_SEAL,
        )
        if self.state is not None:
            self.state.check(result.epoch, result.manifest_sha256)
            if commit:
                self.state.accept(result.epoch, result.manifest_sha256)
        return result


def bundle_snapshot(bundle: VerifiedBundle) -> dict:
    """Serialize authenticated bytes into a bounded primitive worker request."""
    return {"schema_version": 1, "manifest_b64": base64.b64encode(bundle.manifest_bytes).decode("ascii"), "signature_b64": base64.b64encode(bundle.signature).decode("ascii"), "payloads": {name: base64.b64encode(data).decode("ascii") for name, data in sorted(bundle.payloads.items())}}
