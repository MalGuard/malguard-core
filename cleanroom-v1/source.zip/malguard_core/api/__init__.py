"""Public scan_file(path) API and bounded artifact pipeline."""

from .scanner import Scanner, scan_file

__all__ = ["Scanner", "scan_file"]
