"""S0 → reputation → raw → structure → graph → coverage → verdict.

The coordinator retains evidence at every failure boundary. Nested objects use
the same stages and the same root ledger. Only VerdictEngine chooses a verdict.
"""

import base64
from dataclasses import replace
import hashlib
import os
import threading
from collections.abc import Callable

from malguard_core.budget import BudgetExceeded, BudgetLedger
from malguard_core.coverage import coverage_score
from malguard_core.intake import (
    BoundedByteSource, IntakeError, analyze_filename, extension_of, identify, type_mismatch_evidence,
)
from malguard_core.intake.description import describe
from malguard_core.model import (
    Artifact, ArtifactStatus, CoverageEntry, CoverageState, ErrorCode, EvidenceDomain,
    EvidenceLocation, Hashes, Report, Severity, StageResult, Verdict, make_evidence,
)
from malguard_core.scoring import assess
from malguard_core.settings import ScanSettings
from malguard_core.verdict import VERDICT_PRECEDENCE, VerdictDecision, VerdictEngine
from malguard_core.workers import WorkerPool
from malguard_core.version import ENGINE_VERSION

_EXECUTABLE_EXTENSIONS = {".exe", ".dll", ".asi", ".scr", ".com"}
_UNSUPPORTED_EXECUTABLES = {".lnk", ".msi", ".sys", ".ocx"}
_COMMON_LIMITATIONS = (
    "Static analysis cannot guarantee safety or recover all encrypted payloads, indirect calls, runtime targets, or dynamic behavior.",
    "Corpus detection and false-positive acceptance targets have not been measured by synthetic tests.",
    "Offline Authenticode checks do not establish current OS trust-chain or online revocation status.",
)


def _artifact_id(parent_id: str | None, path: str, digest: str, ordinal: int = 0) -> str:
    material = f"{parent_id or 'ROOT'}\0{path}\0{digest}\0{ordinal}".encode("utf-8", "surrogatepass")
    return hashlib.sha256(material).hexdigest()


def _declared_type(path: str) -> str:
    return extension_of(path)[:64]


def _local_stage(stage: str, analyzer, *args, **kwargs) -> StageResult:
    try:
        return analyzer(*args, **kwargs)
    except BudgetExceeded as exc:
        return StageResult(stage, CoverageState.SKIPPED_LIMIT, errors=(exc.error_code,),
                           limitations=(f"Static analysis exhausted {exc.resource}; prior stages were retained.",))
    except Exception as exc:
        return StageResult(stage, CoverageState.FAILED, errors=(ErrorCode.WORKER_FAILURE,),
                           limitations=(f"Static analysis failed: {type(exc).__name__}; prior stages were retained.",))


def _stage_entry(result: StageResult) -> CoverageEntry:
    state = CoverageState.PARTIAL if result.errors and result.state == CoverageState.COMPLETE else result.state
    reason = "; ".join(result.limitations)[:8192] if state != CoverageState.COMPLETE else ""
    return CoverageEntry(result.stage, state, reason,
                         result.errors[0] if result.errors else None)


def _merge_stage(first: StageResult, second: StageResult) -> StageResult:
    rank = {CoverageState.COMPLETE: 7, CoverageState.PARTIAL: 6, CoverageState.SKIPPED_LIMIT: 5,
            CoverageState.TIMEOUT: 4, CoverageState.UNAVAILABLE: 3, CoverageState.BLOCKED: 2, CoverageState.FAILED: 1}
    state = min((first.state, second.state), key=rank.__getitem__)
    evidence = tuple({item.id: item for item in (*first.evidence, *second.evidence)}.values())
    return StageResult(first.stage, state, evidence, {**first.facts, **second.facts},
                       (*first.errors, *second.errors), (*first.limitations, *second.limitations))


class Scanner:
    """Reusable scanner. Concurrent calls serialize one isolated worker pool."""

    def __init__(self, settings: ScanSettings | None = None, reputation=None, rules_manager=None,
                 reputation_fresh: bool = True, progress: Callable[[str], None] | None = None):
        self.settings = settings or ScanSettings()
        self._reputation_error: str | None = None
        try:
            if reputation is None:
                from malguard_core.reputation import load_default_store
                reputation = load_default_store()
            else:
                from malguard_core.reputation import ReputationStore
                if not isinstance(reputation, ReputationStore):
                    raise ValueError("Reputation requires an authenticated ReputationStore.")
        except (ImportError, ValueError, OSError) as exc:
            self._reputation_error = type(exc).__name__
            reputation = None
        self.reputation = reputation
        if rules_manager is not None:
            from malguard_core.rules import RulesManager
            if not isinstance(rules_manager, RulesManager):
                raise ValueError("Rules require an authenticated RulesManager.")
        self.rules_manager = rules_manager
        self.reputation_fresh = reputation_fresh
        self._pool = WorkerPool(self.settings)
        self._verdict = VerdictEngine()
        self._lock = threading.RLock()
        self._progress = progress
        self.file_inspection: dict = {}

    def _notify(self, stage: str) -> None:
        # Observers receive fixed stage identifiers, never sample content. A
        # failed UI observer must not change analysis or its verdict.
        if self._progress is not None:
            try:
                self._progress(stage)
            except Exception:
                return  # Telemetry is advisory and cannot affect analysis.

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def close(self) -> None:
        self._pool.close()

    def _worker(self, stage: str, data: bytes, artifact_id: str, path: str,
                ledger: BudgetLedger, extra: dict | None = None) -> StageResult:
        if not self.settings.isolate_parsers:
            # Trusted configuration may restrict work, never silently remove a
            # required isolation boundary and grant a completed clean verdict.
            stage_id = {"pe": "S2", "dotnet": "S4", "archives": "S6", "yara": "S7"}[stage]
            return StageResult(stage_id, CoverageState.BLOCKED, errors=(ErrorCode.PARSER_UNAVAILABLE,),
                               limitations=("Required parser isolation was disabled by configuration.",))
        return self._pool.run(stage, data, artifact_id, path, ledger, extra)

    def scan_file(self, path: str | os.PathLike[str]) -> Report:
        with self._lock:
            self.file_inspection = {}
            self._notify("capture")
            ledger = BudgetLedger(self.settings.budget_limits)
            native_path = os.fspath(path)
            if not isinstance(native_path, str):
                raise TypeError("scan_file requires a text filesystem path")
            # Long paths are bounded before creating model or IPC objects.
            logical_path = native_path[:8192]
            if len(native_path) > 8192:
                return self._intake_failure(logical_path, ErrorCode.IO_ERROR, "Input path exceeds the model limit.")
            try:
                source = BoundedByteSource.from_path(native_path, ledger, self.settings.per_read_limit, self.settings.max_file_size)
            except (IntakeError, BudgetExceeded, OSError) as exc:
                code = getattr(exc, "error_code", ErrorCode.IO_ERROR)
                return self._intake_failure(logical_path, code, "The input could not be captured within safe intake limits.")
            artifacts: list[Artifact] = []
            decisions: dict[str, VerdictDecision] = {}
            classifications: set[str] = set()
            limitations: set[str] = set(_COMMON_LIMITATIONS)
            root = self._scan_source(source, logical_path, None, 0, 0, ledger,
                                     artifacts, decisions, classifications, limitations)
            self._notify("finalizing")
            # Parents inherit the strongest descendant decision. Families never
            # combine across unrelated archive children to manufacture MALICIOUS.
            strongest = max(decisions.values(), key=lambda decision: VERDICT_PRECEDENCE[decision.verdict])
            all_evidence = tuple({item.id: item for artifact in artifacts for item in artifact.evidence}.values())
            risk = max((assess(artifact.evidence).risk for artifact in artifacts), default=0)
            if any(item.stage == "S1" and item.rule_id == "reputation.exact_blocklist"
                   and item.domain == EvidenceDomain.REPUTATION
                   and dict(item.attributes).get("hard_malicious_override") is True for item in all_evidence):
                risk = 100
            coverage = min((coverage_score(artifact.coverage) for artifact in artifacts), default=0.0)
            confidence = strongest.confidence if strongest.verdict in {Verdict.MALICIOUS, Verdict.SUSPICIOUS} else min((decision.confidence for decision in decisions.values()), default=0.0)
            # A child incomplete stage is material to the package report even
            # when the root's archive directory was readable.
            return Report(strongest.verdict, risk, confidence, coverage, root.artifact_id,
                          tuple(artifacts), all_evidence, tuple(classifications), tuple(limitations),
                          any(decision.residual_evidence for decision in decisions.values()),
                          ENGINE_VERSION, self._ruleset_version(),
                          getattr(self.reputation, "bundle_version", "UNAVAILABLE"), "1")

    def _ruleset_version(self) -> str:
        return self.rules_manager.active_bundle.ruleset_version if self.rules_manager else "1.0.0"

    def _intake_failure(self, path: str, code: ErrorCode, reason: str) -> Report:
        self.file_inspection = describe({"true_type": "UNKNOWN", "type_confidence": 0,
                                         "structure_status": "BLOCKED"}, path, 0, False, size_known=False)
        artifact_id = _artifact_id(None, path, "")
        state = CoverageState.SKIPPED_LIMIT if code == ErrorCode.ITERATION_BUDGET_EXHAUSTED else CoverageState.BLOCKED
        artifact = Artifact(artifact_id, path, _declared_type(path), "UNKNOWN", 0.0, 0,
                            Hashes(), ArtifactStatus.BLOCKED, coverage=(CoverageEntry("S0", state, reason, code),))
        decision = self._verdict.decide(artifact, assess(()), coverage_score(artifact.coverage), ())
        return Report(decision.verdict, 0, decision.confidence, coverage_score(artifact.coverage), artifact_id,
                      (artifact,), (), (), (reason, *_COMMON_LIMITATIONS), False,
                      ENGINE_VERSION, self._ruleset_version(), getattr(self.reputation, "bundle_version", "UNAVAILABLE"), "1")

    def _scan_source(self, source: BoundedByteSource, path: str, parent_id: str | None,
                     depth: int, ordinal: int, ledger: BudgetLedger, artifacts: list[Artifact],
                     decisions: dict[str, VerdictDecision], classifications: set[str], limitations: set[str]) -> Artifact:
        evidence = []
        coverage: list[CoverageEntry] = []
        hashes = Hashes()
        data = b""
        intake_state = CoverageState.COMPLETE
        intake_errors: list[ErrorCode] = []
        if len(extension_of(path)) > 64:
            intake_state = CoverageState.PARTIAL
            intake_errors.append(ErrorCode.UNSUPPORTED_FORMAT)
            limitations.add("The declared extension exceeds the report schema limit; the full logical filename was retained.")
        try:
            hashes = source.hashes()
            data = source.read_all()
        except BudgetExceeded as exc:
            intake_state = CoverageState.SKIPPED_LIMIT
            intake_errors.append(exc.error_code)
            limitations.add(f"Input read work budget exhausted: {exc.resource}.")
        artifact_id = _artifact_id(parent_id, path, hashes.sha256, ordinal)
        evidence = list(analyze_filename(path, artifact_id))
        identity = identify(data, extension_of(path))
        status = identity["structure_status"]
        if not isinstance(status, ArtifactStatus):
            status = ArtifactStatus(status)
        snapshot_available = len(data) == source.size
        if intake_state != CoverageState.COMPLETE:
            status = ArtifactStatus.BLOCKED
        if parent_id is None:
            self.file_inspection = describe(identity, path, source.size, snapshot_available)
            if self.file_inspection["scope_state"] in {"unsupported", "empty"} and status == ArtifactStatus.VALID:
                # Raw checks can retain malicious evidence, but a standalone
                # text/media file cannot earn SAFE as a validated GTA mod.
                status = ArtifactStatus.UNKNOWN
            if self.file_inspection["scope_state"] in {"unsupported", "empty"} and intake_state == CoverageState.COMPLETE:
                intake_state = CoverageState.PARTIAL
                intake_errors.append(ErrorCode.UNSUPPORTED_FORMAT)
                limitations.add("Root content was identified, but its format is outside direct mod validation.")

        def progress(stage: str) -> None:
            if parent_id is None:
                self._notify(stage)

        def run_isolated(stage: str, extra: dict | None = None) -> StageResult:
            if snapshot_available:
                return self._worker(stage, data, artifact_id, path, ledger, extra)
            stage_id = {"pe": "S2", "dotnet": "S4", "archives": "S6", "yara": "S7"}[stage]
            return StageResult(stage_id, CoverageState.SKIPPED_LIMIT,
                               errors=(ErrorCode.ITERATION_BUDGET_EXHAUSTED,),
                               limitations=("A full bounded byte snapshot was unavailable; no substitute was parsed.",))
        evidence.extend(type_mismatch_evidence(identity, path, artifact_id))
        # S1 exact authenticated reputation must run before any deep parser and
        # still runs when raw capture analysis was incomplete after hashing.
        progress("reputation")
        if self.reputation is not None and hashes.sha256:
            reputation_result = self.reputation.analyze(hashes, artifact_id, path, identity["true_type"], source.size)
        else:
            reputation_result = StageResult("S1", CoverageState.UNAVAILABLE, errors=(ErrorCode.INTEGRITY_FAILURE,),
                                           limitations=("Authenticated reputation data is unavailable.",))
        if not self.reputation_fresh:
            reputation_result = replace(
                reputation_result,
                state=(CoverageState.PARTIAL if reputation_result.state == CoverageState.COMPLETE
                       else reputation_result.state),
                limitations=(*reputation_result.limitations,
                             "Online reputation is unavailable or stale; retained evidence still applies."),
            )
        coverage.append(_stage_entry(reputation_result))
        evidence.extend(reputation_result.evidence)
        try:
            ledger.consume("evidence", len(reputation_result.evidence))
        except BudgetExceeded as exc:
            coverage[-1] = CoverageEntry("S1", CoverageState.SKIPPED_LIMIT, "Reputation evidence budget exhausted.", exc.error_code)
        limitations.update(reputation_result.limitations)
        hard_block = bool(reputation_result.facts.get("hard_malicious_override", False))
        allowlisted = bool(reputation_result.facts.get("verified_allowlist", False))
        strings: tuple = ()
        if data:
            progress("strings")
            from malguard_core.strings import extract_strings
            from malguard_core.decoding import decode_strings, decode_artifact_bytes
            try:
                strings = extract_strings(source, ledger, self.settings.max_string_length, self.settings.min_string_length)
            except BudgetExceeded as exc:
                strings = getattr(exc, "partial_results", ())
                intake_state = CoverageState.SKIPPED_LIMIT
                intake_errors.append(exc.error_code)
                limitations.add(f"String extraction exhausted {exc.resource}; earlier strings were retained.")
            try:
                strings += decode_strings(strings, ledger, self.settings.decode_max_depth)
                xor_strings = decode_artifact_bytes(data, ledger)
                strings += xor_strings
                strings += decode_strings(xor_strings, ledger, self.settings.decode_max_depth)
            except BudgetExceeded as exc:
                strings += getattr(exc, "partial_results", ())
                intake_state = CoverageState.SKIPPED_LIMIT
                intake_errors.append(exc.error_code)
                limitations.add(f"Bounded decoding exhausted {exc.resource}; earlier candidates were retained.")
        intake_reason = ("File bytes captured; root format is outside direct mod validation."
                         if ErrorCode.UNSUPPORTED_FORMAT in intake_errors and snapshot_available
                         else "Raw intake or bounded decoding incomplete." if intake_errors else "")
        coverage.append(CoverageEntry("S0", intake_state, intake_reason,
                                      intake_errors[0] if intake_errors else None))
        script_applicable = bool(identity.get("is_script"))
        pe_applicable = bool(identity.get("is_pe") or extension_of(path) in _EXECUTABLE_EXTENSIONS)
        native_applicable = pe_applicable or (not script_applicable and not identity.get("is_archive"))
        native_result: StageResult | None = None
        if native_applicable:
            progress("native")
            from malguard_core.native import analyze as analyze_native
            native_result = (_local_stage("S3", analyze_native, data, artifact_id, path, ledger, strings)
                             if snapshot_available else StageResult("S3", CoverageState.SKIPPED_LIMIT,
                                                                    errors=(ErrorCode.ITERATION_BUDGET_EXHAUSTED,)))
            evidence.extend(native_result.evidence)
            limitations.update(native_result.limitations)
        if script_applicable:
            progress("script")
            from malguard_core.scripts import analyze as analyze_script
            script_result = _local_stage("S5", analyze_script, data, artifact_id, path, ledger, strings)
            evidence.extend(script_result.evidence)
            coverage.append(_stage_entry(script_result))
            classifications.update(script_result.facts.get("classification_tags", []))
            limitations.update(script_result.limitations)
        # YARA is raw-byte analysis and does not depend on valid PE metadata.
        if self.settings.enable_yara:
            progress("rules")
            rules_extra = {"rules_source": self.rules_manager.worker_snapshot()} if self.rules_manager else None
            rules_result = run_isolated("yara", rules_extra)
        else:
            rules_result = StageResult("S7", CoverageState.BLOCKED, errors=(ErrorCode.PARSER_UNAVAILABLE,),
                                       limitations=("Required raw rule analysis was disabled by configuration.",))
        evidence.extend(rules_result.evidence)
        coverage.append(_stage_entry(rules_result))
        limitations.update(rules_result.limitations)
        pe_result: StageResult | None = None
        if pe_applicable:
            progress("pe")
            pe_result = run_isolated("pe", {"revoked_signers": sorted(getattr(self.reputation, "revoked_signers", ()))})
            evidence.extend(pe_result.evidence)
            coverage.append(_stage_entry(pe_result))
            limitations.update(pe_result.limitations)
            if snapshot_available and pe_result.facts.get("structure_status") == "MALFORMED":
                status = ArtifactStatus.MALFORMED
            if pe_result.facts.get("parser_disagreement"):
                coverage[-1] = replace(coverage[-1], error_code=ErrorCode.PARSER_DISAGREEMENT)
            from malguard_core.native import analyze as analyze_native
            enriched = (_local_stage("S3", analyze_native, data, artifact_id, path, ledger, strings, pe_result.facts)
                        if snapshot_available else StageResult("S3", CoverageState.SKIPPED_LIMIT,
                                                               errors=(ErrorCode.ITERATION_BUDGET_EXHAUSTED,)))
            if native_result is not None:
                native_result = _merge_stage(native_result, enriched)
            else:
                native_result = enriched
            evidence.extend(enriched.evidence)
            classifications.update(native_result.facts.get("classification_tags", []))
            limitations.update(native_result.limitations)
        if native_result is not None:
            coverage.append(_stage_entry(native_result))
        dotnet_result: StageResult | None = None
        if (identity.get("is_dotnet") or (pe_result and pe_result.facts.get("is_dotnet"))
                or (native_applicable and b"BSJB" in data
                    and (not pe_result or pe_result.facts.get("structure_status") != "VALID"))):
            progress("dotnet")
            dotnet_result = run_isolated("dotnet", {"pe_facts": {key: value for key, value in pe_result.facts.items()
                                                                if key != "resources"} if pe_result else {}})
            evidence.extend(dotnet_result.evidence)
            coverage.append(_stage_entry(dotnet_result))
            limitations.update(dotnet_result.limitations)
            if dotnet_result.facts.get("structure_status") == "MALFORMED":
                status = ArtifactStatus.MALFORMED
            if dotnet_result.facts.get("parser_disagreement"):
                coverage[-1] = replace(coverage[-1], error_code=ErrorCode.PARSER_DISAGREEMENT)
        if self.reputation is not None:
            ioc_result = _local_stage("S1", self.reputation.analyze_iocs, strings, artifact_id, ledger)
            evidence.extend(ioc_result.evidence)
            limitations.update(ioc_result.limitations)
            if ioc_result.state != CoverageState.COMPLETE:
                coverage[0] = _stage_entry(_merge_stage(reputation_result, ioc_result))
            if pe_result and pe_result.facts.get("architecture"):
                from malguard_core.similarity import SimilarityProfile
                profile_capabilities = tuple(native_result.facts.get("capabilities", ())) if native_result else ()
                if dotnet_result:
                    profile_capabilities += tuple(sorted({call["name"] for method in dotnet_result.facts.get("methods", [])
                                                           for call in method.get("calls", []) if isinstance(call, dict) and isinstance(call.get("name"), str)}))
                signatures = pe_result.facts.get("authenticode", {}).get("signatures", [])
                valid_signer = next((signature.get("signer_sha256", "") for signature in signatures
                                     if signature.get("image_digest_valid") is True and signature.get("cms_signature_valid") is True), "")
                try:
                    profile = SimilarityProfile(identity["true_type"], pe_result.facts["architecture"], source.size,
                                                profile_capabilities, imphash=pe_result.facts.get("imphash", ""),
                                                dotnet_hash=dotnet_result.facts.get("structural_hash", "") if dotnet_result else "",
                                                mvid=dotnet_result.facts.get("mvid", "") if dotnet_result else "",
                                                signer_sha256=valid_signer)
                    similarity_result = _local_stage("S1", self.reputation.analyze_similarity, profile, artifact_id, ledger)
                    evidence.extend(similarity_result.evidence)
                    limitations.update(similarity_result.limitations)
                    if similarity_result.state != CoverageState.COMPLETE:
                        coverage[0] = _stage_entry(_merge_stage(reputation_result, similarity_result))
                    ledger.consume("evidence")
                    evidence.append(make_evidence("S1.STRUCTURAL_PROFILE", "S1", EvidenceDomain.CONTEXT,
                                                  "SIMILARITY_PROFILE", "profile", Severity.INFO, EvidenceLocation(artifact_id),
                                                  "Structural similarity identifiers are advisory and never a safety identity.",
                                                  "شناسه‌های شباهت ساختاری صرفاً قرینه‌اند و هویت ایمن محسوب نمی‌شوند.",
                                                  attributes=(("imphash", profile.imphash), ("dotnet_hash", profile.dotnet_hash),
                                                              ("mvid", profile.mvid), ("signer_sha256", profile.signer_sha256),
                                                              ("architecture", profile.architecture))))
                except (ValueError, BudgetExceeded) as exc:
                    coverage[0] = CoverageEntry("S1", CoverageState.PARTIAL, "A corroborated similarity profile could not be completed.",
                                                getattr(exc, "error_code", ErrorCode.PROTOCOL_VIOLATION))
                    limitations.add("Structural similarity was incomplete; exact reputation and collected evidence were retained.")
        children: list[dict] = []
        unreadable_child = False
        if identity.get("is_archive"):
            progress("archive")
            archive_result = run_isolated("archives", {"depth": depth, "max_depth": self.settings.max_depth,
                                                       "max_member_size": self.settings.max_file_size})
            evidence.extend(archive_result.evidence)
            coverage.append(_stage_entry(archive_result))
            limitations.update(archive_result.limitations)
            children = archive_result.facts.get("children", [])
            unreadable_child = bool(archive_result.facts.get("incomplete_children"))
            if archive_result.facts.get("malformed"):
                status = ArtifactStatus.MALFORMED
            if archive_result.facts.get("parser_disagreement"):
                coverage[-1] = replace(coverage[-1], error_code=ErrorCode.PARSER_DISAGREEMENT)
        elif pe_result or dotnet_result:
            # Resource PE children get the normal pipeline, rather than merely
            # counting the embedded header as a single weak indicator.
            resources = [resource for result in (pe_result, dotnet_result) if result
                         for resource in result.facts.get("resources", [])]
            if pe_result:
                resources += [{**record, "embedded_pe": True} for record in pe_result.facts.get("embedded_artifacts", [])
                              if record.get("type") == "pe"]
            resource_seen = set()
            for resource in resources:
                if resource.get("embedded_pe"):
                    identity_key = resource.get("offset", 0)
                    if identity_key in resource_seen:
                        continue
                    resource_seen.add(identity_key)
                    try:
                        ledger.consume("children")
                    except BudgetExceeded:
                        unreadable_child = True
                        continue
                    embedded_data = base64.b64decode(resource["data_b64"], validate=True)
                    embedded_identity = identify(embedded_data, "")
                    resource_extension = ".dll" if embedded_identity.get("is_dll") else ".exe"
                    children.append({"logical_path": f"{path}!resource/{resource.get('offset', 0)}{resource_extension}",
                                     "data_b64": resource["data_b64"], "readable": True,
                                     "encrypted": False, "reason": "Embedded PE resource."})
        if extension_of(path) in _UNSUPPORTED_EXECUTABLES:
            coverage.append(CoverageEntry("S2", CoverageState.UNAVAILABLE,
                                          "This executable container format has no validated structured analyzer.", ErrorCode.UNSUPPORTED_FORMAT))
            status = ArtifactStatus.UNKNOWN
        if identity["true_type"] in {"LUA_BYTECODE", "LUAJIT_BYTECODE"} and not script_applicable:
            coverage.append(CoverageEntry("S5", CoverageState.UNAVAILABLE,
                                          "Lua bytecode is recognized but not statically decompiled.", ErrorCode.UNSUPPORTED_FORMAT))
        child_ids = []
        for child_ordinal, child in enumerate(children):
            child_path = child.get("logical_path", path + "!unreadable")[:8192]
            if not child.get("readable") or child.get("encrypted") or depth >= self.settings.max_depth:
                child_id = _artifact_id(artifact_id, child_path, "", child_ordinal)
                child_code = ErrorCode.ENCRYPTED_MEMBER if child.get("encrypted") else ErrorCode.ITERATION_BUDGET_EXHAUSTED if depth >= self.settings.max_depth else ErrorCode.UNSUPPORTED_FORMAT
                child_artifact = Artifact(child_id, child_path, _declared_type(child_path), "UNREADABLE", 0.0,
                                          int(child.get("declared_size", 0)), Hashes(), ArtifactStatus.BLOCKED,
                                          artifact_id, depth + 1, coverage=(CoverageEntry("S0", CoverageState.BLOCKED,
                                                                                    child.get("reason", "Unreadable child."), child_code),))
                artifacts.append(child_artifact)
                decisions[child_id] = self._verdict.decide(child_artifact, assess(()), 0.0, ())
                unreadable_child = True
                child_ids.append(child_id)
                continue
            try:
                child_data = base64.b64decode(child["data_b64"], validate=True)
                if len(child_data) > self.settings.max_file_size:
                    raise BudgetExceeded("file_bytes", len(child_data), self.settings.max_file_size)
                child_source = BoundedByteSource.from_bytes(child_data, ledger, self.settings.per_read_limit)
                child_artifact = self._scan_source(child_source, child_path, artifact_id, depth + 1,
                                                   child_ordinal, ledger, artifacts, decisions, classifications, limitations)
                child_ids.append(child_artifact.artifact_id)
            except (BudgetExceeded, ValueError):
                unreadable_child = True
                limitations.add("A child artifact could not pass bounded intake; completed parent evidence was retained.")
        progress("context")
        final_evidence = tuple({item.id: item for item in evidence}.values())
        # Root-only generated filename evidence is also debited. Stage analyzers
        # debit their own emissions, including retries that were actually run.
        try:
            ledger.consume("evidence", len(analyze_filename(path, artifact_id)) + len(type_mismatch_evidence(identity, path, artifact_id)))
        except BudgetExceeded as exc:
            coverage[coverage.index(next(entry for entry in coverage if entry.stage == "S0"))] = CoverageEntry("S0", CoverageState.SKIPPED_LIMIT, "Evidence budget exhausted.", exc.error_code)
        artifact = Artifact(artifact_id, path, _declared_type(path), identity["true_type"], identity["type_confidence"],
                            source.size, hashes, status, parent_id, depth, final_evidence, tuple(coverage), tuple(child_ids))
        if parent_id is None:
            self.file_inspection = describe({**identity, "structure_status": status.value},
                                            path, source.size, snapshot_available)
        artifacts.append(artifact)
        assessment = assess(final_evidence)
        decisions[artifact_id] = self._verdict.decide(artifact, assessment, coverage_score(coverage), final_evidence,
                                                     hard_block=hard_block, allowlisted=allowlisted, unreadable_child=unreadable_child)
        return artifact


def scan_file(path: str | os.PathLike[str]) -> Report:
    with Scanner() as scanner:
        return scanner.scan_file(path)
