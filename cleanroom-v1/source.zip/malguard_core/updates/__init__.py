"""Authenticated metadata-only online updates, independent of scanned bytes."""

from __future__ import annotations

import os
import re
import stat
import sys
import tempfile
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from urllib.request import HTTPRedirectHandler, Request, build_opener

from malguard_core.integrity import BundleError, BundleVerifier, ProtectedEpochState
from malguard_core.integrity.bundle import VerifiedBundle, strict_json
from malguard_core.reputation import ReputationStore
from malguard_core.reputation.trust import PUBLIC_KEYS
from malguard_core.rules import compile_bundle

UPDATE_URL = "https://raw.githubusercontent.com/MalGuard/malguard-core/main/cleanroom-updates/latest.json"
MAX_UPDATE_BYTES = 23 * 1024 * 1024


class UpdateError(ValueError):
    """An update could not be authenticated or installed safely."""


def _object(data: bytes) -> dict:
    value = strict_json(data)
    if not isinstance(value, dict):
        raise UpdateError("Update JSON must be an object")
    return value


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise UpdateError("Update redirects are forbidden")


@dataclass(frozen=True, slots=True)
class UpdateStatus:
    available: bool
    fresh: bool
    version: str
    epoch: int
    record_count: int
    reason: str


def default_cache_directory() -> Path:
    if sys.platform == "win32":
        from malguard_core.integrity.state import default_state_directory
        return default_state_directory().parent / "MalGuardSecurityUpdates"
    return Path.home() / ".local" / "state" / "malguard-updates"


def _protect_directory(directory: Path) -> None:
    if sys.platform != "win32":
        directory.mkdir(mode=0o700, parents=True, exist_ok=True)
        return
    import ctypes
    from ctypes import wintypes

    # The administrator updater writes; ordinary desktop users may only read.
    advapi = ctypes.WinDLL("advapi32", use_last_error=True)
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    pointer = wintypes.LPVOID()
    convert = advapi.ConvertStringSecurityDescriptorToSecurityDescriptorW
    convert.argtypes = (wintypes.LPCWSTR, wintypes.DWORD,
                        ctypes.POINTER(wintypes.LPVOID), ctypes.POINTER(wintypes.DWORD))
    convert.restype = wintypes.BOOL
    sddl = "O:BAG:BAD:P(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)(A;OICI;GRGX;;;BU)"
    if not convert(sddl, 1, ctypes.byref(pointer), None):
        raise UpdateError("Cannot construct update ACL")
    try:
        class Attributes(ctypes.Structure):
            _fields_ = [("length", wintypes.DWORD), ("descriptor", wintypes.LPVOID),
                        ("inherit", wintypes.BOOL)]
        attrs = Attributes(ctypes.sizeof(Attributes), pointer, False)
        kernel.CreateDirectoryW.argtypes = (wintypes.LPCWSTR, ctypes.POINTER(Attributes))
        kernel.CreateDirectoryW.restype = wintypes.BOOL
        if not kernel.CreateDirectoryW(str(directory), ctypes.byref(attrs)):
            raise UpdateError("Administrator permission required for update cache")
    finally:
        kernel.LocalFree.argtypes = (wintypes.HLOCAL,)
        kernel.LocalFree.restype = wintypes.HLOCAL
        kernel.LocalFree(pointer)


def _validate_directory(directory: Path) -> None:
    info = directory.lstat()
    if not stat.S_ISDIR(info.st_mode) or directory.is_symlink():
        raise UpdateError("Update cache is not an ordinary directory")
    if sys.platform == "win32":
        from malguard_core.integrity.state import _windows_sddl
        sddl = _windows_sddl(directory)
        if not sddl.startswith(("O:BA", "O:SY")) or "D:P" not in sddl:
            raise UpdateError("Update cache owner or ACL is unprotected")
        aces = re.findall(r"\(([^()]*)\)", sddl)
        if not aces:
            raise UpdateError("Update cache ACL is empty")
        for ace in aces:
            fields = ace.split(";")
            if len(fields) != 6 or fields[0] != "A":
                raise UpdateError("Unsupported update cache ACL")
            if fields[5] in {"BA", "SY"}:
                continue
            if fields[5] != "BU" or fields[2] not in {"GRGX", "GR", "0x1200a9"}:
                raise UpdateError("Update cache permits untrusted writers")
    elif info.st_uid != os.getuid() or stat.S_IMODE(info.st_mode) & 0o077:
        raise UpdateError("Update cache is not owner-only")


def authenticate(data: bytes, *, state: ProtectedEpochState | None = None) -> VerifiedBundle:
    if len(data) > MAX_UPDATE_BYTES:
        raise UpdateError("Update exceeded deterministic byte limit")
    parsed = _object(data)
    bundle = BundleVerifier(PUBLIC_KEYS, state=state).verify_snapshot(parsed, commit=False)
    if bundle.key_id != "malguard-online-2026-10":
        raise UpdateError("Online update signer differs from provisioned key")
    ReputationStore(bundle)
    try:
        compile_bundle(bundle)
    except Exception as error:
        raise UpdateError("Ruleset compilation failed") from error
    return bundle


def status_for(bundle: VerifiedBundle, *, now: datetime | None = None) -> UpdateStatus:
    manifest = _object(bundle.manifest_bytes)
    created = datetime.fromisoformat(manifest["created_at"].replace("Z", "+00:00"))
    age = (now or datetime.now(UTC)) - created
    fresh = -timedelta(minutes=15) <= age <= timedelta(hours=48)
    records = _object(bundle.payloads["blocklist.json"])["records"]
    return UpdateStatus(True, fresh, bundle.version, bundle.epoch, len(records),
                        "" if fresh else "Signed reputation is older than 48 hours or future-dated")


def load_cached(directory: Path | None = None) -> tuple[VerifiedBundle | None, UpdateStatus]:
    directory = directory or default_cache_directory()
    try:
        _validate_directory(directory)
        data = BundleVerifier._read(directory / "latest.json", MAX_UPDATE_BYTES)
        bundle = authenticate(data)
        return bundle, status_for(bundle)
    except (OSError, ValueError, BundleError) as error:
        return None, UpdateStatus(False, False, "", 0, 0, type(error).__name__)


def download() -> bytes:
    request = Request(UPDATE_URL, headers={"Accept": "application/json",
                                          "Accept-Encoding": "identity",
                                          "User-Agent": "MalGuard/1.1.0"})
    with build_opener(_NoRedirect()).open(request, timeout=30) as response:
        if response.status != 200 or response.headers.get("Content-Encoding") not in (None, "identity"):
            raise UpdateError("Update transport response is unsupported")
        data = response.read(MAX_UPDATE_BYTES + 1)
    if len(data) > MAX_UPDATE_BYTES:
        raise UpdateError("Update exceeded deterministic byte limit")
    return data


@contextmanager
def _installation_lock(directory: Path):
    descriptor = os.open(directory / "update.lock", os.O_RDWR | os.O_CREAT |
                         getattr(os, "O_NOFOLLOW", 0), 0o600)
    try:
        info = os.fstat(descriptor)
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size > 1:
            raise UpdateError("Update lock is not ordinary")
        if sys.platform == "win32":
            import msvcrt
            if info.st_size == 0:
                os.write(descriptor, b"0")
            os.lseek(descriptor, 0, os.SEEK_SET)
            msvcrt.locking(descriptor, msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        yield
    finally:
        os.close(descriptor)


def install(data: bytes, directory: Path, state: ProtectedEpochState) -> UpdateStatus:
    if not directory.exists():
        _protect_directory(directory)
    _validate_directory(directory)
    with _installation_lock(directory):
        return _install_locked(data, directory, state)


def _install_locked(data: bytes, directory: Path, state: ProtectedEpochState) -> UpdateStatus:
    candidate = authenticate(data, state=state)
    previous, _ = load_cached(directory)
    if previous and (candidate.epoch < previous.epoch or
                     (candidate.epoch == previous.epoch and
                      candidate.manifest_sha256 != previous.manifest_sha256)):
        raise UpdateError("Update rollback or epoch collision")
    # Never let a refresh silently delete a previously authenticated block entry.
    if previous:
        old = {record["sha256"] for record in _object(previous.payloads["blocklist.json"])["records"]}
        new = {record["sha256"] for record in _object(candidate.payloads["blocklist.json"])["records"]}
        if not old <= new:
            raise UpdateError("Update removed an existing blocklist identity")
    # Protected monotonic state is checked above. Replace only authenticated data;
    # retained cache epoch also rejects rollback after a interrupted state write.
    name = None
    try:
        with tempfile.NamedTemporaryFile(dir=directory, delete=False, prefix="update-",
                                         suffix=".json") as stream:
            name = stream.name
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, directory / "latest.json")
        state.accept(candidate.epoch, candidate.manifest_sha256)
    finally:
        if name and Path(name).exists():
            Path(name).unlink()
    return status_for(candidate)


def refresh() -> UpdateStatus:
    try:
        return install(download(), default_cache_directory(), ProtectedEpochState())
    except (OSError, ValueError) as error:
        _, existing = load_cached()
        return UpdateStatus(existing.available, False, existing.version, existing.epoch,
                            existing.record_count, "Update failed: " + type(error).__name__)


def status_json(status: UpdateStatus) -> dict:
    return {field: getattr(status, field) for field in status.__dataclass_fields__}
