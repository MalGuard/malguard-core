"""Bounded, administrator-owned progress records for one desktop update job."""

from __future__ import annotations

import json
import os
import re
import stat
import sys
import tempfile
from pathlib import Path

from malguard_core.integrity import BundleVerifier
from malguard_core.updates import (UpdateError, _protect_directory, _validate_directory,
                                   default_cache_directory, load_cached, refresh, status_json)

STAGES = {"preparing", "downloading", "verifying", "comparing", "installing", "complete", "failed"}


def job_path(request_id: str, directory: Path) -> Path:
    if not re.fullmatch(r"[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}", request_id):
        raise UpdateError("Invalid update request identifier")
    return directory / ("refresh-" + request_id + ".json")


def _protect_record(path: Path) -> None:
    if sys.platform != "win32":
        path.chmod(0o600)
        return
    import ctypes
    from ctypes import wintypes
    advapi = ctypes.WinDLL("advapi32", use_last_error=True)
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    descriptor = wintypes.LPVOID()
    convert = advapi.ConvertStringSecurityDescriptorToSecurityDescriptorW
    convert.argtypes = (wintypes.LPCWSTR, wintypes.DWORD, ctypes.POINTER(wintypes.LPVOID),
                        ctypes.POINTER(wintypes.DWORD))
    convert.restype = wintypes.BOOL
    if not convert("O:BAD:P(A;;FA;;;SY)(A;;FA;;;BA)(A;;FR;;;BU)", 1,
                   ctypes.byref(descriptor), None):
        raise UpdateError("Cannot protect update progress")
    try:
        advapi.SetFileSecurityW.argtypes = (wintypes.LPCWSTR, wintypes.DWORD, wintypes.LPVOID)
        advapi.SetFileSecurityW.restype = wintypes.BOOL
        if not advapi.SetFileSecurityW(str(path), 0x80000005, descriptor):
            raise UpdateError("Administrator permission required for update progress")
    finally:
        kernel.LocalFree.argtypes = (wintypes.HLOCAL,)
        kernel.LocalFree.restype = wintypes.HLOCAL
        kernel.LocalFree(descriptor)


def _validate_record_sddl(sddl: str) -> None:
    aces = re.findall(r"\(([^()]*)\)", sddl)
    if not sddl.startswith(("O:BA", "O:SY")) or "D:P" not in sddl or not aces:
        raise UpdateError("Update progress is not protected")
    for ace in aces:
        fields = ace.split(";")
        # Windows maps generic read to FILE_GENERIC_READ and serializes it as
        # FR. All accepted spellings permit reading only, never file writes.
        if len(fields) != 6 or fields[0] != "A" or (fields[5] not in {"BA", "SY"} and
                (fields[5] != "BU" or fields[2] not in {"GR", "FR", "0x120089"})):
            raise UpdateError("Update progress permits untrusted writers")


def _validate_record(path: Path) -> None:
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size > 8192:
        raise UpdateError("Update progress is not an ordinary bounded file")
    if sys.platform == "win32":
        from malguard_core.integrity.state import _windows_sddl
        _validate_record_sddl(_windows_sddl(path))
    elif info.st_uid != os.getuid() or stat.S_IMODE(info.st_mode) & 0o077:
        raise UpdateError("Update progress is not owner-only")


def run_job(request_id: str) -> int:
    directory = default_cache_directory()
    path = job_path(request_id, directory)
    if not directory.exists():
        _protect_directory(directory)
    _validate_directory(directory)
    if path.exists() or path.is_symlink():
        raise UpdateError("Update identifier has already been used")
    # Retain only a bounded history; each UI request uses a fresh UUID.
    records = sorted(directory.glob("refresh-*.json"), key=lambda p: p.lstat().st_mtime)
    for old in records[:-31]:
        _validate_record(old)
        old.unlink()

    def progress(event: dict) -> None:
        value = {"requestId": request_id, **event}
        if value.get("stage") not in STAGES:
            raise UpdateError("Invalid update stage")
        data = json.dumps(value, ensure_ascii=False).encode()
        if len(data) > 8192:
            raise UpdateError("Update progress exceeded the limit")
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(dir=directory, prefix="refresh-writing-",
                                             suffix=".tmp", delete=False) as stream:
                temporary = Path(stream.name)
                _protect_record(temporary)
                stream.write(data)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
        finally:
            if temporary and temporary.exists():
                temporary.unlink()

    progress({"stage": "preparing"})
    result = refresh(progress=progress)
    complete = result.fresh and result.signature_verified and result.update_outcome != "failed"
    progress({"stage": "complete" if complete else "failed", "result": status_json(result)})
    return 0 if complete else 4


def read_job(request_id: str) -> dict:
    directory = default_cache_directory()
    path = job_path(request_id, directory)
    _validate_directory(directory)
    _validate_record(path)
    value = json.loads(BundleVerifier._read(path, 8192))
    if not isinstance(value, dict) or value.get("requestId") != request_id or value.get("stage") not in STAGES:
        raise UpdateError("Invalid update progress identity")
    if value["stage"] == "complete":
        result = value.get("result")
        _, actual = load_cached(directory)
        if not isinstance(result, dict) or not actual.fresh or not actual.signature_verified or (
                result.get("epoch"), result.get("record_count")) != (actual.epoch, actual.record_count):
            raise UpdateError("Completed update no longer matches authenticated cache")
    return value
