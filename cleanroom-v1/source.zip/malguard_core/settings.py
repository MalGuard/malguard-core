"""Deterministic, offline scan policy and shared resource limits."""

from dataclasses import dataclass, field
from types import MappingProxyType
from collections.abc import Mapping


DEFAULT_BUDGETS: Mapping[str, int] = MappingProxyType({
    "file_bytes": 512 * 1024 * 1024,
    "read_bytes": 1024 * 1024 * 1024,
    "archive_entries": 4096,
    "decompressed_bytes": 256 * 1024 * 1024,
    "parser_iterations": 256 * 1024 * 1024,
    "metadata_rows": 100_000,
    "resource_entries": 4096,
    "decoded_candidates": 2048,
    "decoded_bytes": 16 * 1024 * 1024,
    "strings": 50_000,
    "string_bytes": 8 * 1024 * 1024,
    "children": 4096,
    "evidence": 20_000,
    "yara_bytes": 256 * 1024 * 1024,
})


@dataclass(frozen=True, slots=True)
class ScanSettings:
    """Limits are per root scan; children share its budget ledger."""

    max_file_size: int = 64 * 1024 * 1024
    per_read_limit: int = 1024 * 1024
    max_depth: int = 4
    max_string_length: int = 4096
    min_string_length: int = 4
    decode_max_depth: int = 2
    max_decode_candidate_length: int = 64 * 1024
    worker_timeout: float = 15.0
    worker_memory_mb: int = 512
    worker_cpu_seconds: int = 10
    worker_recycle_count: int = 32
    worker_recycle_bytes: int = 128 * 1024 * 1024
    enable_yara: bool = True
    isolate_parsers: bool = True
    network_enabled: bool = False
    budget_limits: Mapping[str, int] = field(default_factory=lambda: DEFAULT_BUDGETS)

    def __post_init__(self) -> None:
        integer_fields = (
            "max_file_size", "per_read_limit", "max_depth",
            "max_string_length", "min_string_length", "decode_max_depth",
            "max_decode_candidate_length", "worker_memory_mb",
            "worker_cpu_seconds", "worker_recycle_count", "worker_recycle_bytes",
        )
        for name in integer_fields:
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError(f"{name} must be a nonnegative integer")
        if self.per_read_limit == 0 or self.max_string_length < self.min_string_length:
            raise ValueError("invalid read or string limits")
        if not 0 < self.worker_timeout <= 3600:
            raise ValueError("worker_timeout must be in (0, 3600]")
        limits = dict(DEFAULT_BUDGETS)
        for name, value in self.budget_limits.items():
            if name not in DEFAULT_BUDGETS:
                raise ValueError(f"unknown budget: {name}")
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError(f"invalid budget: {name}")
            limits[name] = value
        object.__setattr__(self, "budget_limits", MappingProxyType(limits))


Settings = ScanSettings
