"""Bounded, redacted descriptions of the exact bytes already captured by S0."""

import re

from malguard_core.reporting import redact
from malguard_core.intake import extension_of

_SHORT_SECRET = re.compile(
    r"(?i)(\b(?:token|password|secret|api[_-]?key|authorization)\s*[=:]\s*"
    r"(?:(?:Bearer|Basic)\s+)?)[^\s\"'&;,<>]+"
)

_LABELS = {
    "TEXT": ("Plain text", "متن ساده"),
    "WAVE_AUDIO": ("WAVE audio header", "سرآیند فایل صوتی WAVE"),
    "MPEG_AUDIO": ("MPEG audio frame header", "سرآیند فریم صوتی MPEG"),
    "ID3_AUDIO_METADATA": ("ID3 audio metadata", "فرادادهٔ صوتی ID3"),
    "FLAC_AUDIO": ("FLAC audio header", "سرآیند صوتی FLAC"),
    "OGG_MEDIA": ("Ogg media container", "ظرف رسانه‌ای Ogg"),
    "ISO_BASE_MEDIA": ("ISO media container (MP4 family)", "ظرف رسانه‌ای خانوادهٔ MP4"),
    "PNG_IMAGE": ("PNG image header", "سرآیند تصویر PNG"),
    "JPEG_IMAGE": ("JPEG image header", "سرآیند تصویر JPEG"),
    "GIF_IMAGE": ("GIF image header", "سرآیند تصویر GIF"),
    "WEBP_IMAGE": ("WebP image header", "سرآیند تصویر WebP"),
    "PDF_DOCUMENT": ("PDF document header", "سرآیند سند PDF"),
    "OLE_COMPOUND": ("OLE compound container", "ظرف مرکب OLE"),
    "UNKNOWN": ("Unrecognized binary content", "محتوای دودویی تشخیص‌داده‌نشده"),
    "MALFORMED_PE": ("Incomplete Windows PE structure", "ساختار ناقص PE ویندوز"),
    "LUA_SOURCE": ("Lua source text", "متن کد Lua"),
    "CS_SOURCE": ("C# source text", "متن کد C#"),
    "VB_SOURCE": ("Visual Basic source text", "متن کد ویژوال بیسیک"),
    "POWERSHELL": ("PowerShell source text", "متن کد PowerShell"),
    "BAT": ("Batch command text", "متن فرمان Batch"),
    "VBS": ("VBScript source text", "متن کد VBScript"),
    "INI": ("INI configuration text", "متن تنظیمات INI"),
    "CFG": ("CFG configuration text", "متن تنظیمات CFG"),
    "XML": ("XML text", "متن XML"),
    "ZIP": ("ZIP archive", "آرشیو ZIP"),
    "7Z": ("7Z archive", "آرشیو 7Z"),
    "RAR": ("RAR archive", "آرشیو RAR"),
}


def _display(value: str) -> str:
    return "".join(char if (char.isprintable() and char not in
                            "\u202a\u202b\u202c\u202d\u202e\u2066\u2067\u2068\u2069")
                   or char in "\n\t" else f"\\u{ord(char):04x}"
                   for char in _SHORT_SECRET.sub(r"\1[REDACTED]", redact(value)))


def describe(identity: dict, path: str, size: int, snapshot_available: bool,
             *, size_known: bool = True) -> dict:
    kind = identity["true_type"]
    declared = path.replace("\\", "/").rsplit("/", 1)[-1]
    supported = bool(identity.get("is_pe") or identity.get("is_archive")
                     or identity.get("is_script"))
    extension = extension_of(path)
    mismatched = ((extension in {".asi", ".dll", ".exe"} and not identity.get("is_pe"))
                  or (extension in {".zip", ".7z", ".rar"} and kind not in {"ZIP", "7Z", "RAR"}))
    state = "supported" if supported else "unsupported"
    if not snapshot_available:
        state = "unavailable"
    elif not size:
        state = "empty"
    elif mismatched or (not supported and identity["structure_status"] == "MALFORMED"):
        state = "mismatch"
    elif supported and identity["structure_status"] == "MALFORMED":
        state = "malformed"
    label_en, label_fa = _LABELS.get(kind, (kind.replace("_", " "), kind.replace("_", " ")))
    if state == "empty":
        label_en, label_fa = "Empty file", "فایل خالی"
    elif state == "unavailable":
        label_en, label_fa = "Content unavailable", "محتوا در دسترس نیست"
    notes = {
        "supported": (
            "The captured content can enter the static mod-analysis pipeline; identification alone does not establish safety.",
            "محتوای دریافت‌شده وارد مسیر تحلیل ایستای ماد می‌شود؛ تشخیص نوع به‌تنهایی ایمنی را تأیید نمی‌کند."),
        "unsupported": (
            "This content is outside direct GTA mod validation. Raw checks do not validate its format or approve it for installation.",
            "این محتوا خارج از پوشش تأیید مستقیم ماد GTA است. بررسی بایت‌ها، اعتبار این قالب یا مناسب‌بودن آن برای نصب را ثابت نمی‌کند."),
        "mismatch": (
            "The captured bytes do not have the structure required by the claimed mod/archive extension. Renaming a file does not convert its contents.",
            "بایت‌های فایل ساختار لازم برای پسوند ادعاشدهٔ ماد یا آرشیو را ندارند. تغییر نام یا پسوند، محتوای فایل را تبدیل نمی‌کند."),
        "empty": ("The file contains zero bytes; there is no mod content to inspect.",
                  "این فایل صفر بایت دارد؛ محتوای مادی برای بررسی وجود ندارد."),
        "malformed": (
            "A supported format header was recognized, but its internal structure could not be parsed as valid. The file may be truncated, damaged or incorrectly packaged.",
            "سرآیند یک قالب پشتیبانی‌شده شناسایی شد، اما ساختار داخلی معتبر نبود. فایل ممکن است ناقص، آسیب‌دیده یا نادرست بسته‌بندی شده باشد."),
        "unavailable": (
            "A complete stable byte snapshot could not be captured; file content was not identified reliably.",
            "نسخهٔ کامل و پایدار بایت‌ها دریافت نشد؛ محتوای فایل به‌طور قابل اتکا شناسایی نشده است."),
    }
    note_en, note_fa = notes[state]
    return {
        "filename": _display(declared[:8192]), "file_size": size,
        "size_known": size_known,
        "claimed_extension": extension,
        "detected_type": kind, "label_en": label_en, "label_fa": label_fa,
        "scope_state": state, "note_en": note_en, "note_fa": note_fa,
        "encoding": identity.get("text_encoding") if snapshot_available else None,
        # Redact the bounded decoded prefix before display truncation, so a
        # token crossing the 320-character display edge cannot leak a prefix.
        "preview": _display(identity.get("text_preview", ""))[:320] if snapshot_available else "",
        "preview_bytes": identity.get("preview_bytes", 0) if snapshot_available else 0,
        "identification_confidence": identity["type_confidence"] if snapshot_available else 0,
        "supported_formats": ["ASI/DLL (Windows PE)", "ZIP", "7Z", "RAR",
                              "Lua", "C#", "INI/CFG/XML"],
        "header_only": kind in {"WAVE_AUDIO", "MPEG_AUDIO", "ID3_AUDIO_METADATA", "FLAC_AUDIO",
                                "OGG_MEDIA", "ISO_BASE_MEDIA", "PNG_IMAGE", "JPEG_IMAGE",
                                "GIF_IMAGE", "WEBP_IMAGE", "PDF_DOCUMENT", "OLE_COMPOUND"},
    }
