"""The only filesystem boundary, bounded byte access and minimal type validation."""

import hashlib
import os
from pathlib import Path
import re
import stat
import struct
import unicodedata
from collections.abc import Iterator

from malguard_core.budget import BudgetLedger
from malguard_core.model import ArtifactStatus, ErrorCode, Evidence, EvidenceDomain, EvidenceLocation, Hashes, Severity, make_evidence


MAX_OFFSET = 2**63 - 1


class IntakeError(OSError):
    def __init__(self, message: str, error_code: ErrorCode) -> None:
        self.error_code = error_code
        super().__init__(message)


class BoundedByteSource:
    """Immutable bytes; every analyzer read is accounted on a shared ledger."""

    def __init__(self, data: bytes, ledger: BudgetLedger, per_read_limit: int = 1024 * 1024, *, _charge_file_bytes: bool = True) -> None:
        if not isinstance(data, bytes):
            raise TypeError("source requires immutable bytes")
        if isinstance(per_read_limit, bool) or not isinstance(per_read_limit, int) or per_read_limit <= 0:
            raise ValueError("per_read_limit must be positive")
        if len(data) > MAX_OFFSET:
            raise ValueError("source size exceeds offset range")
        if _charge_file_bytes:
            ledger.consume("file_bytes", len(data))
        self._data = data
        self.ledger = ledger
        self.per_read_limit = per_read_limit
        self.size = len(data)

    @classmethod
    def from_bytes(cls, data: bytes, ledger: BudgetLedger, per_read_limit: int = 1024 * 1024) -> "BoundedByteSource":
        return cls(data, ledger, per_read_limit)

    @classmethod
    def from_path(cls, path: str | os.PathLike[str], ledger: BudgetLedger, per_read_limit: int = 1024 * 1024, max_file_size: int = 64 * 1024 * 1024) -> "BoundedByteSource":
        if not isinstance(max_file_size, int) or isinstance(max_file_size, bool) or max_file_size < 0:
            raise ValueError("invalid maximum file size")
        if not isinstance(per_read_limit, int) or isinstance(per_read_limit, bool) or per_read_limit <= 0:
            raise ValueError("invalid per-read limit")
        native_path = os.fspath(path)
        if os.name == "nt":
            normalized_path = str(native_path).replace("/", "\\").casefold()
            if normalized_path.startswith(("\\\\", "\\device\\", "\\??\\")):
                raise IntakeError("device and network path namespaces are not scanned", ErrorCode.IO_ERROR)
            basename = normalized_path.rsplit("\\", 1)[-1].split(".", 1)[0].rstrip(" .:")
            if re.fullmatch(r"(?:con|prn|aux|nul|com[1-9]|lpt[1-9])", basename):
                raise IntakeError("Windows device names are not regular input", ErrorCode.IO_ERROR)
        flags = (os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
                 | getattr(os, "O_NONBLOCK", 0))
        try:
            preliminary = os.lstat(native_path)
            if not stat.S_ISREG(preliminary.st_mode):
                raise IntakeError("input must be an ordinary regular file", ErrorCode.IO_ERROR)
            descriptor = os.open(native_path, flags)
        except IntakeError:
            raise
        except OSError as exc:
            raise IntakeError("cannot open input as a regular file", ErrorCode.IO_ERROR) from exc
        try:
            before = os.fstat(descriptor)
            if not stat.S_ISREG(before.st_mode):
                raise IntakeError("input is not a regular file", ErrorCode.IO_ERROR)
            if before.st_size > max_file_size or before.st_size < 0:
                raise IntakeError("input exceeds configured file size limit", ErrorCode.ITERATION_BUDGET_EXHAUSTED)
            ledger.consume("file_bytes", before.st_size)
            parts = []
            remaining = before.st_size
            while remaining:
                amount = min(remaining, per_read_limit)
                ledger.consume("read_bytes", amount)
                part = os.read(descriptor, amount)
                if len(part) != amount:
                    raise IntakeError("input changed or truncated during capture", ErrorCode.CHANGED_DURING_SCAN)
                parts.append(part)
                remaining -= amount
            after = os.fstat(descriptor)
            if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns):
                raise IntakeError("input changed during capture", ErrorCode.CHANGED_DURING_SCAN)
            return cls(b"".join(parts), ledger, per_read_limit, _charge_file_bytes=False)
        finally:
            os.close(descriptor)

    @property
    def actual_size(self) -> int:
        return self.size

    def read(self, offset: int, length: int) -> bytes:
        for value in (offset, length):
            if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value <= MAX_OFFSET:
                raise ValueError("read requires bounded nonnegative integer offsets")
        if length > MAX_OFFSET - offset:
            raise ValueError("read offset overflow")
        if offset > self.size or length > self.size - offset:
            raise ValueError("read exceeds actual file bounds")
        if length > self.per_read_limit:
            raise ValueError("read exceeds per-read limit")
        self.ledger.consume("read_bytes", length)
        return self._data[offset:offset + length]

    def read_head(self, length: int) -> bytes:
        return self.read(0, length)

    def read_tail(self, length: int) -> bytes:
        if isinstance(length, bool) or not isinstance(length, int) or length < 0 or length > self.size:
            raise ValueError("invalid tail length")
        return self.read(self.size - length, length)

    def iter_chunks(self, chunk_size: int | None = None, *, offset: int = 0, length: int | None = None) -> Iterator[bytes]:
        amount = self.per_read_limit if chunk_size is None else chunk_size
        if isinstance(amount, bool) or not isinstance(amount, int) or not 0 < amount <= self.per_read_limit:
            raise ValueError("invalid chunk size")
        if isinstance(offset, bool) or not isinstance(offset, int) or not 0 <= offset <= self.size:
            raise ValueError("invalid chunk offset")
        total = self.size - offset if length is None else length
        if isinstance(total, bool) or not isinstance(total, int) or not 0 <= total <= self.size - offset:
            raise ValueError("invalid chunk length")
        position = offset
        end = offset + total
        while position < end:
            count = min(amount, end - position)
            yield self.read(position, count)
            position += count

    def read_all(self) -> bytes:
        return b"".join(self.iter_chunks())

    def hashes(self) -> Hashes:
        digests = [hashlib.sha256(), hashlib.sha1(usedforsecurity=False), hashlib.md5(usedforsecurity=False)]
        for chunk in self.iter_chunks():
            for digest in digests:
                digest.update(chunk)
        return Hashes(*(digest.hexdigest() for digest in digests))


def extension_of(logical_path: str) -> str:
    basename = logical_path.replace("\\", "/").rsplit("/", 1)[-1]
    return Path(unicodedata.normalize("NFKC", basename)).suffix.casefold()


def normalize_filename(logical_path: str) -> str:
    return unicodedata.normalize("NFKC", logical_path.replace("\\", "/")).casefold()


def analyze_filename(logical_path: str, artifact_id: str) -> tuple[Evidence, ...]:
    basename = logical_path.replace("\\", "/").rsplit("/", 1)[-1]
    normalized = unicodedata.normalize("NFKC", basename)
    location = EvidenceLocation(artifact_id, member=basename[:8192])
    result = []
    bidi = {"RLO", "LRO", "RLE", "LRE", "PDF", "RLI", "LRI", "FSI", "PDI"}
    if any(unicodedata.bidirectional(char) in bidi for char in basename):
        result.append(make_evidence("S0.FILENAME_BIDI", "S0", EvidenceDomain.STRUCTURE, "MASQUERADE", "bidi_filename", Severity.HIGH, location,
                                   "Filename contains bidirectional control characters that can disguise its extension.",
                                   "نام فایل دارای نویسه‌های کنترل جهت متن است و ممکن است پسوند واقعی را پنهان کند."))
    dangerous = {"exe", "dll", "asi", "scr", "com", "bat", "cmd", "ps1", "vbs", "js", "lnk", "msi"}
    harmless = {"jpg", "jpeg", "png", "gif", "txt", "pdf", "mp3", "mp4", "cfg", "ini", "xml"}
    suffixes = [part.casefold() for part in normalized.split(".")[1:]]
    if len(suffixes) >= 2 and suffixes[-1] in dangerous and any(item in harmless for item in suffixes[:-1]):
        result.append(make_evidence("S0.DOUBLE_EXTENSION", "S0", EvidenceDomain.STRUCTURE, "MASQUERADE", "double_extension", Severity.HIGH, location,
                                   "An executable filename also carries a document or media extension.",
                                   "نام فایل اجرایی علاوه بر پسوند اجرایی، پسوند سند یا رسانه نیز دارد."))
    return tuple(sorted(result, key=lambda item: item.id))


def identify(data: bytes, extension: str) -> dict:
    """Conservative bounds validator; MZ by itself is never a valid PE."""
    if not isinstance(data, bytes):
        raise TypeError("type identification requires immutable bytes")
    extension = extension.casefold()
    if extension and not extension.startswith("."):
        extension = "." + extension
    result = {"true_type": "UNKNOWN", "type_confidence": 0.0,
              "structure_status": ArtifactStatus.UNKNOWN, "is_pe": False,
              "is_dotnet": False, "is_archive": False, "is_script": False}
    if len(data) >= 64 and not data.startswith(b"MZ"):
        nt_offset = struct.unpack_from("<I", data, 0x3C)[0]
        if 64 <= nt_offset <= len(data) - 24 and data[nt_offset:nt_offset + 4] == b"PE\0\0":
            recovered = identify(b"MZ" + data[2:], extension)
            recovered["structure_status"] = ArtifactStatus.MALFORMED
            recovered["header_recovered"] = True
            recovered["type_confidence"] = min(recovered["type_confidence"], 0.8)
            return recovered
    if data.startswith(b"MZ"):
        result.update(is_pe=True, true_type="MALFORMED_PE", type_confidence=0.95,
                      structure_status=ArtifactStatus.MALFORMED)
        if len(data) < 64:
            return result
        nt = struct.unpack_from("<I", data, 0x3C)[0]
        if nt < 64 or nt > len(data) - 24 or data[nt:nt + 4] != b"PE\0\0":
            return result
        machine, sections, _, _, _, opt_size, characteristics = struct.unpack_from("<HHIIIHH", data, nt + 4)
        optional = nt + 24
        table = optional + opt_size
        if opt_size < 2 or table > len(data) or not 1 <= sections <= 96 or sections > (len(data) - table) // 40:
            return result
        magic = struct.unpack_from("<H", data, optional)[0]
        if magic not in {0x10B, 0x20B}:
            return result
        directory_offset = 96 if magic == 0x10B else 112
        if opt_size < directory_offset:
            return result
        is_dll = bool(characteristics & 0x2000)
        width = "PE32" if magic == 0x10B else "PE32_PLUS"
        malformed = machine not in {0x14C, 0x8664, 0xAA64, 0x1C4}
        if machine == 0x14C and magic != 0x10B or machine in {0x8664, 0xAA64} and magic != 0x20B:
            malformed = True
        sections_info = []
        raw_ranges = []
        for index in range(sections):
            base = table + index * 40
            virtual_size, rva, raw_size, raw_offset = struct.unpack_from("<IIII", data, base + 8)
            if raw_size and (raw_offset < table + sections * 40 or raw_offset > len(data) or raw_size > len(data) - raw_offset):
                malformed = True
            if rva + max(virtual_size, raw_size) > 2**32:
                malformed = True
            if raw_size:
                raw_ranges.append((raw_offset, raw_offset + raw_size))
            sections_info.append((rva, virtual_size, raw_size, raw_offset))
        raw_ranges.sort()
        if any(left[1] > right[0] for left, right in zip(raw_ranges, raw_ranges[1:], strict=False)):
            malformed = True
        directory_count = struct.unpack_from("<I", data, optional + directory_offset - 4)[0]
        if directory_count > 16 or directory_count > (opt_size - directory_offset) // 8:
            malformed = True
        clr_rva = clr_size = 0
        is_dotnet = False
        if directory_count > 14 and opt_size >= directory_offset + 15 * 8:
            clr_rva, clr_size = struct.unpack_from("<II", data, optional + directory_offset + 14 * 8)
            if clr_rva or clr_size:
                is_dotnet = True
                mapped = [raw + clr_rva - rva for rva, virtual, raw_size, raw in sections_info
                          if rva <= clr_rva and clr_rva - rva <= raw_size and clr_size <= raw_size - (clr_rva - rva)]
                if clr_size < 72 or len(mapped) != 1 or mapped[0] > len(data) - clr_size:
                    malformed = True
        result.update(true_type=("DOTNET_DLL" if is_dll else "DOTNET_EXE") if is_dotnet else f"{width}_{'DLL' if is_dll else 'EXE'}",
                      type_confidence=1.0, structure_status=ArtifactStatus.MALFORMED if malformed else ArtifactStatus.VALID,
                      is_dotnet=is_dotnet, is_dll=is_dll,
                      architecture={0x14C: "x86", 0x8664: "x64", 0xAA64: "arm64", 0x1C4: "arm"}.get(machine, "unknown"),
                      clr_rva=clr_rva, clr_size=clr_size)
        return result
    archive_types = ((b"PK\x03\x04", "ZIP"), (b"PK\x05\x06", "ZIP"),
                     (b"PK\x07\x08", "ZIP"), (b"7z\xbc\xaf\x27\x1c", "7Z"),
                     (b"Rar!\x1a\x07\x00", "RAR"), (b"Rar!\x1a\x07\x01\x00", "RAR"))
    for magic, true_type in archive_types:
        if data.startswith(magic):
            result.update(true_type=true_type, type_confidence=1.0, structure_status=ArtifactStatus.VALID, is_archive=True)
            return result
    if data.startswith(b"\x1bLua"):
        result.update(true_type="LUA_BYTECODE", type_confidence=1.0, structure_status=ArtifactStatus.UNKNOWN, is_script=True)
        return result
    if data.startswith(b"\x1bLJ"):
        result.update(true_type="LUAJIT_BYTECODE", type_confidence=1.0, structure_status=ArtifactStatus.UNKNOWN, is_script=True)
        return result
    if data.startswith(b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"):
        result.update(true_type="OLE_COMPOUND", type_confidence=1.0, structure_status=ArtifactStatus.UNKNOWN)
        return result
    script_types = {".lua": "LUA_SOURCE", ".cs": "CS_SOURCE", ".vb": "VB_SOURCE", ".ps1": "POWERSHELL",
                    ".bat": "BAT", ".cmd": "BAT", ".vbs": "VBS", ".ini": "INI", ".xml": "XML", ".cfg": "CFG"}
    prefix = data[:8192]
    text = None
    try:
        if prefix.startswith((b"\xff\xfe", b"\xfe\xff")):
            text = prefix[:len(prefix) - len(prefix) % 2].decode("utf-16")
        elif len(prefix) >= 8 and prefix[1::2].count(0) >= len(prefix) // 4:
            text = prefix[:len(prefix) - len(prefix) % 2].decode("utf-16le")
        elif len(prefix) >= 8 and prefix[0::2].count(0) >= len(prefix) // 4:
            text = prefix[:len(prefix) - len(prefix) % 2].decode("utf-16be")
        elif b"\0" not in prefix:
            text = prefix.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = None
    if text is not None and (not prefix or sum(char.isprintable() or char in "\r\n\t" for char in text) >= len(text) * 0.9):
        true_type = script_types.get(extension, "TEXT")
        if extension not in script_types:
            if re.search(r"\b(?:local\s+\w+|function\s+\w+|loadstring\s*\(|PerformHttpRequest\s*\()", text):
                true_type = "LUA_SOURCE"
            elif re.search(r"\b(?:Invoke-WebRequest|Invoke-Expression|New-Object)\b", text, re.I):
                true_type = "POWERSHELL"
        result.update(true_type=true_type, type_confidence=0.9 if extension in script_types else 0.7,
                      structure_status=ArtifactStatus.VALID, is_script=true_type != "TEXT")
        if extension in {".asi", ".dll", ".exe"}:
            result["structure_status"] = ArtifactStatus.MALFORMED
        return result
    if extension in {".asi", ".dll", ".exe", ".zip", ".7z", ".rar"}:
        result["structure_status"] = ArtifactStatus.MALFORMED
        result["is_archive"] = extension in {".zip", ".7z", ".rar"}
    return result


def type_mismatch_evidence(identity: dict, logical_path: str, artifact_id: str) -> tuple[Evidence, ...]:
    extension = extension_of(logical_path)
    if extension in {".asi", ".dll"} and identity.get("is_pe") and identity.get("is_dll") is False:
        return (make_evidence("S0.EXE_MASQUERADING_DLL", "S0", EvidenceDomain.STRUCTURE, "MASQUERADE", "exe_as_dll", Severity.CRITICAL,
                              EvidenceLocation(artifact_id, member=logical_path[:8192]),
                              "The PE header identifies an executable although the filename claims a DLL or ASI plugin.",
                              "ساختار PE فایل اجرایی را نشان می‌دهد، ولی نام فایل پسوند DLL یا افزونه ASI دارد."),)
    if identity.get("is_pe") and extension in {".txt", ".png", ".jpg", ".cfg", ".ini", ".xml", ".lua"}:
        return (make_evidence("S0.EXECUTABLE_DISGUISE", "S0", EvidenceDomain.STRUCTURE, "MASQUERADE", "executable_disguise", Severity.CRITICAL,
                              EvidenceLocation(artifact_id, member=logical_path[:8192]),
                              "Executable bytes are disguised with a source, configuration or media extension.",
                              "بایت‌های اجرایی زیر پسوند اسکریپت، تنظیمات یا رسانه پنهان شده‌اند."),)
    return ()
