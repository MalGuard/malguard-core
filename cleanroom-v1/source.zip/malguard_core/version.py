"""Engine and report schema versions shared by trusted entry points."""

ENGINE_VERSION = "1.1.0"
SCHEMA_VERSION = "1"
