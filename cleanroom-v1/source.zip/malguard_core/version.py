"""Engine and report schema versions shared by trusted entry points."""

ENGINE_VERSION = "1.2.1"
SCHEMA_VERSION = "1"
