"""Bounded archive analysis without filesystem extraction or external tools.

Member names remain report labels. Stored and deflated ZIP and stored RAR4
members are decoded internally; 7z uses a bounded in-memory writer factory.
Unsupported, encrypted, ambiguous or unavailable members never count as clean.
"""

from __future__ import annotations

import base64
import binascii
import io
import hashlib
import json
import re
import struct
import unicodedata
import zipfile
import zlib
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from malguard_core.budget import BudgetExceeded, BudgetLedger
from malguard_core.model import (
    CoverageState, ErrorCode, Evidence, EvidenceDomain, EvidenceLocation,
    Severity, StageResult, make_evidence,
)

_CHUNK = 64 * 1024
_MAX_MEMBER = 64 * 1024 * 1024
_MAX_HEADER = 8 * 1024 * 1024
_RATIO = 1000
_MAX_RESULT = 96 * 1024 * 1024
_RESERVED = re.compile(r"^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)", re.I)


def _label(value: str, maximum: int = 4096) -> str:
    if len(value) <= maximum:
        return value
    digest = hashlib.sha256(value.encode("utf-8", errors="surrogatepass")).hexdigest()
    return value[:maximum - 75] + "[sha256:" + digest + "]"


class ArchiveFormatError(ValueError):
    """An archive contains inconsistent, ambiguous or out-of-bounds metadata."""


class ArchiveOutputLimit(RuntimeError):
    """The bounded JSON result cannot contain further archive member bytes."""


def _slice(data: bytes, offset: int, length: int) -> bytes:
    if offset < 0 or length < 0 or offset > len(data) or length > len(data) - offset:
        raise ArchiveFormatError("archive range exceeds input")
    return data[offset:offset + length]


def normalize_member_name(name: str) -> tuple[str, tuple[str, ...]]:
    """Return Windows-aware collision key and reasons unsafe for extraction."""
    problems: set[str] = set()
    normalized = unicodedata.normalize("NFC", name).replace("\\", "/")
    if len(normalized) > 4096:
        problems.add("overlong_name")
    if not normalized or "\x00" in normalized:
        problems.add("empty_or_nul_name")
    if normalized.startswith("/"):
        problems.add("absolute_or_device_path")
    if re.match(r"^[a-zA-Z]:", normalized):
        problems.add("drive_prefixed_path")
    parts = normalized.split("/")
    if any(part == ".." for part in parts):
        problems.add("path_traversal")
    if any(":" in part for part in parts):
        problems.add("alternate_data_stream")
    if any(_RESERVED.match(part.rstrip(" .")) for part in parts):
        problems.add("windows_device_name")
    if any(ord(char) < 32 for char in normalized):
        problems.add("control_character")
    key = "/".join(part.rstrip(" .").casefold() for part in parts if part not in ("", "."))
    return key, tuple(sorted(problems))


@dataclass(slots=True)
class _Context:
    data: bytes
    artifact_id: str
    logical_path: str
    ledger: BudgetLedger
    depth: int
    max_member_size: int
    children: list[dict[str, Any]] = field(default_factory=list)
    evidence: list[Evidence] = field(default_factory=list)
    errors: list[ErrorCode] = field(default_factory=list)
    malformed: bool = False
    disagreement: bool = False
    incomplete: bool = False
    limited: bool = False
    seen_names: set[str] = field(default_factory=set)
    archive_type: str = "UNKNOWN"
    output_reserved: int = 4096

    def reserve_output(self, amount: int) -> None:
        if amount > _MAX_RESULT - self.output_reserved:
            raise ArchiveOutputLimit("archive IPC result limit exhausted")
        self.output_reserved += amount

    def error(self, code: ErrorCode) -> None:
        if code not in self.errors:
            self.errors.append(code)

    def signal(self, rule_id: str, family: str, description_en: str,
               description_fa: str, *, member: str | None = None,
               opacity: bool = False, severity: Severity = Severity.HIGH,
               offset: int | None = None) -> None:
        self.ledger.consume("evidence")
        item = make_evidence(
            rule_id=rule_id, stage="S6", domain=(EvidenceDomain.OPACITY if opacity else EvidenceDomain.STRUCTURE),
            family=family, kind="archive_structure", severity=severity,
            location=EvidenceLocation(self.artifact_id, offset=offset, member=_label(member) if member is not None else None),
            description_en=_label(description_en), description_fa=description_fa,
        )
        self.reserve_output(len(json.dumps(asdict(item), ensure_ascii=True,
                                           default=lambda value: value.value).encode("ascii")) + 2)
        self.evidence.append(item)

    def format_error(self, message: str, member: str | None = None) -> None:
        self.malformed = self.disagreement = self.incomplete = True
        self.error(ErrorCode.MALFORMED_INPUT)
        self.error(ErrorCode.PARSER_DISAGREEMENT)
        self.signal("MG.ARCHIVE.PARSER_DISAGREEMENT", "PARSER_EVASION", message,
                    "ساختار بسته ناسازگار است؛ تحلیل کامل اعضا ممکن نیست.", member=member, opacity=True)

    def check_name(self, name: str) -> None:
        key, problems = normalize_member_name(name)
        if key in self.seen_names:
            self.format_error("Duplicate or normalized-colliding archive member names.", name)
        self.seen_names.add(key)
        if problems:
            self.signal("MG.ARCHIVE.UNSAFE_PATH", "ARCHIVE_LAYOUT",
                        "Unsafe archive member path: " + ", ".join(problems),
                        "نام عضو بسته شامل مسیر خطرناک است؛ هیچ عضوی روی دیسک استخراج نشد.", member=name)
            self.malformed = True
            self.error(ErrorCode.MALFORMED_INPUT)

    def member(self, name: str, size: int, *, encrypted: bool = False) -> dict[str, Any]:
        self.ledger.consume("children")
        record = {"logical_path": _label(f"{self.logical_path}!/{name}", 8192), "member_name": _label(name),
                  "declared_size": min(size, (1 << 63) - 1), "data_b64": "", "encrypted": encrypted,
                  "readable": False, "reason": ""}
        self.reserve_output(len(json.dumps(record, ensure_ascii=True).encode("ascii")) + 128)
        self.children.append(record)
        self.check_name(name)
        return record

    def reserve(self, record: dict[str, Any], compressed_size: int | None = None) -> bool:
        size = record["declared_size"]
        if size < 0 or size > self.max_member_size:
            record["reason"] = "member_size_limit"
            self.incomplete = self.limited = True
            self.error(ErrorCode.ITERATION_BUDGET_EXHAUSTED)
            return False
        if (compressed_size is not None and size > 1024 * 1024
                and size > max(1, compressed_size) * _RATIO):
            record["reason"] = "compression_ratio_limit"
            self.incomplete = self.limited = True
            self.error(ErrorCode.ITERATION_BUDGET_EXHAUSTED)
            self.signal("MG.ARCHIVE.EXPANSION_RATIO", "PACKING",
                        "Archive expansion ratio exceeds the bounded analysis policy.",
                        "نسبت گسترش بسته از محدودیت تحلیل امن بیشتر است.",
                        member=record["member_name"], opacity=True, severity=Severity.MEDIUM)
            return False
        self.ledger.consume("decompressed_bytes", size)
        try:
            self.reserve_output(((size + 2) // 3) * 4)
        except ArchiveOutputLimit:
            record["reason"] = "result_payload_limit"
            self.incomplete = self.limited = True
            self.error(ErrorCode.ITERATION_BUDGET_EXHAUSTED)
            return False
        return True

    def unreadable(self, record: dict[str, Any], reason: str, code: ErrorCode) -> None:
        record["reason"] = reason
        self.incomplete = True
        self.error(code)

    def finish(self) -> StageResult:
        state = CoverageState.COMPLETE
        if self.limited:
            state = CoverageState.SKIPPED_LIMIT
        elif self.malformed or self.disagreement:
            state = CoverageState.PARTIAL
        elif self.incomplete:
            state = CoverageState.BLOCKED
        return StageResult(
            stage="S6", state=state, evidence=tuple(self.evidence),
            facts={"children": self.children, "incomplete_children": self.incomplete,
                   "malformed": self.malformed, "parser_disagreement": self.disagreement,
                   "archive_type": self.archive_type, "depth": self.depth},
            errors=tuple(self.errors),
            limitations=(("Unreadable or ambiguous archive members block a clean verdict.",) if self.incomplete else ()),
        )


@dataclass(slots=True)
class _ZipEntry:
    name: str
    raw_name: bytes
    flags: int
    method: int
    crc: int
    compressed_size: int
    size: int
    offset: int
    zip64: bool
    record: dict[str, Any] | None = None
    data_start: int = 0
    data_end: int = 0
    interval_end: int = 0
    valid: bool = True


def _zip64(extra: bytes, needs: tuple[bool, bool, bool, bool]) -> tuple[int | None, ...]:
    value: bytes | None = None
    pos = 0
    while pos < len(extra):
        if len(extra) - pos < 4:
            raise ArchiveFormatError("truncated ZIP extra field")
        tag, length = struct.unpack_from("<HH", extra, pos)
        field = _slice(extra, pos + 4, length)
        pos += 4 + length
        if tag == 1:
            if value is not None:
                raise ArchiveFormatError("duplicate ZIP64 extra fields")
            value = field
    if not any(needs):
        if value is not None and value:
            raise ArchiveFormatError("unnecessary ZIP64 extra data creates ambiguity")
        return (None,) * 4
    if value is None:
        raise ArchiveFormatError("missing ZIP64 extended sizes")
    result: list[int | None] = []
    pos = 0
    for index, needed in enumerate(needs):
        if needed:
            length = 4 if index == 3 else 8
            result.append(int.from_bytes(_slice(value, pos, length), "little"))
            pos += length
        else:
            result.append(None)
    if pos != len(value):
        raise ArchiveFormatError("inconsistent ZIP64 extra length")
    return tuple(result)


def _zip_central_entry(data: bytes, pos: int, directory_end: int) -> tuple[_ZipEntry, int]:
    values = struct.unpack("<4s6H3I5H2I", _slice(data, pos, 46))
    if values[0] != b"PK\x01\x02":
        raise ArchiveFormatError("invalid ZIP central-directory entry")
    flags, method, crc, compressed, size = values[3], values[4], values[7], values[8], values[9]
    name_len, extra_len, comment_len, start_disk, local_offset = values[10], values[11], values[12], values[13], values[16]
    total = 46 + name_len + extra_len + comment_len
    if total > directory_end - pos:
        raise ArchiveFormatError("ZIP central-directory entry exceeds directory")
    name = _slice(data, pos + 46, name_len)
    extra = _slice(data, pos + 46 + name_len, extra_len)
    zvalues = _zip64(extra, (size == 0xFFFFFFFF, compressed == 0xFFFFFFFF,
                            local_offset == 0xFFFFFFFF, start_disk == 0xFFFF))
    size = zvalues[0] if zvalues[0] is not None else size
    compressed = zvalues[1] if zvalues[1] is not None else compressed
    local_offset = zvalues[2] if zvalues[2] is not None else local_offset
    start_disk = zvalues[3] if zvalues[3] is not None else start_disk
    if start_disk:
        raise ArchiveFormatError("split ZIP member is unsupported")
    try:
        decoded = name.decode("utf-8" if flags & 0x800 else "cp437")
    except UnicodeDecodeError as exc:
        raise ArchiveFormatError("invalid ZIP filename encoding") from exc
    return (_ZipEntry(decoded, name, flags, method, crc, compressed, size, local_offset,
                      any(item is not None for item in zvalues)), pos + total)


def _zip_directory(ctx: _Context) -> tuple[list[_ZipEntry], int]:
    data = ctx.data
    lower = max(0, len(data) - 65557)
    end = data.rfind(b"PK\x05\x06", lower)
    if end < 0:
        raise ArchiveFormatError("missing ZIP end record")
    fixed = _slice(data, end, 22)
    _, disk, cd_disk, disk_entries, count, cd_size, cd_offset, comment = struct.unpack("<4s4H2IH", fixed)
    if end + 22 + comment != len(data):
        raise ArchiveFormatError("ZIP end record length or trailing bytes disagree")
    if disk or cd_disk or disk_entries != count:
        raise ArchiveFormatError("split-volume ZIP is unsupported or inconsistent")
    boundary = end
    if count == 0xFFFF or cd_size == 0xFFFFFFFF or cd_offset == 0xFFFFFFFF:
        locator_pos = end - 20
        locator = _slice(data, locator_pos, 20)
        sig, zip_disk, zip_offset, disks = struct.unpack("<4sIQI", locator)
        if sig != b"PK\x06\x07" or zip_disk or disks != 1:
            raise ArchiveFormatError("invalid ZIP64 locator")
        zhead = _slice(data, zip_offset, 56)
        vals = struct.unpack("<4sQ2H2I4Q", zhead)
        if vals[0] != b"PK\x06\x06" or vals[1] < 44 or vals[1] > _MAX_HEADER:
            raise ArchiveFormatError("invalid ZIP64 end record")
        if zip_offset + 12 + vals[1] != locator_pos or vals[4] or vals[5] or vals[6] != vals[7]:
            raise ArchiveFormatError("ZIP64 offsets or volume counts disagree")
        if count not in (0xFFFF, vals[7]) or cd_size not in (0xFFFFFFFF, vals[8]) or cd_offset not in (0xFFFFFFFF, vals[9]):
            raise ArchiveFormatError("ZIP64 and ZIP32 fields disagree")
        count, cd_size, cd_offset = vals[7], vals[8], vals[9]
        boundary = zip_offset
    elif end >= 20 and data[end - 20:end - 16] == b"PK\x06\x07":
        raise ArchiveFormatError("unnecessary ZIP64 end records are ambiguous")
    if cd_offset > boundary or cd_size > boundary - cd_offset or cd_offset + cd_size != boundary:
        raise ArchiveFormatError("ZIP central-directory range is inconsistent")
    if count > ctx.ledger.remaining("archive_entries"):
        ctx.ledger.consume("archive_entries", count)
    entries: list[_ZipEntry] = []
    pos = cd_offset
    for _ in range(count):
        ctx.ledger.consume_many({"archive_entries": 1, "parser_iterations": 1})
        try:
            entry, pos = _zip_central_entry(data, pos, cd_offset + cd_size)
        except (ArchiveFormatError, struct.error) as exc:
            ctx.format_error(str(exc))
            break
        entries.append(entry)
    if pos != cd_offset + cd_size:
        ctx.format_error("ZIP directory count does not match its size")
    return entries, cd_offset


def _zip_local(ctx: _Context, entry: _ZipEntry, cd_offset: int) -> None:
    fields = struct.unpack("<4s5H3I2H", _slice(ctx.data, entry.offset, 30))
    if fields[0] != b"PK\x03\x04":
        raise ArchiveFormatError("ZIP local header signature disagrees")
    flags, method, crc, compressed, size, name_len, extra_len = fields[2], fields[3], fields[6], fields[7], fields[8], fields[9], fields[10]
    raw_name = _slice(ctx.data, entry.offset + 30, name_len)
    extra = _slice(ctx.data, entry.offset + 30 + name_len, extra_len)
    if flags != entry.flags or method != entry.method or raw_name != entry.raw_name:
        raise ArchiveFormatError("ZIP central and local names, flags or compression disagree")
    zvalues = _zip64(extra, (size == 0xFFFFFFFF, compressed == 0xFFFFFFFF, False, False))
    size = zvalues[0] if zvalues[0] is not None else size
    compressed = zvalues[1] if zvalues[1] is not None else compressed
    if flags & 8:
        if crc not in (0, entry.crc) or size not in (0, entry.size) or compressed not in (0, entry.compressed_size):
            raise ArchiveFormatError("ZIP data-descriptor local fields disagree")
    elif (crc, compressed, size) != (entry.crc, entry.compressed_size, entry.size):
        raise ArchiveFormatError("ZIP central and local size or checksum disagree")
    entry.data_start = entry.offset + 30 + name_len + extra_len
    if entry.data_start > cd_offset or entry.compressed_size > cd_offset - entry.data_start:
        raise ArchiveFormatError("ZIP member crosses central directory")
    entry.data_end = entry.data_start + entry.compressed_size
    entry.interval_end = entry.data_end
    if flags & 8:
        pos = entry.data_end
        if _slice(ctx.data, pos, 4) == b"PK\x07\x08":
            pos += 4
        zip64 = entry.zip64 or fields[7] == 0xFFFFFFFF or fields[8] == 0xFFFFFFFF
        fmt = "<IQQ" if zip64 else "<III"
        length = struct.calcsize(fmt)
        if struct.unpack(fmt, _slice(ctx.data, pos, length)) != (entry.crc, entry.compressed_size, entry.size):
            raise ArchiveFormatError("ZIP data descriptor disagrees")
        entry.interval_end = pos + length
        if entry.interval_end > cd_offset:
            raise ArchiveFormatError("ZIP descriptor overlaps central directory")


def _inflate(ctx: _Context, entry: _ZipEntry) -> bytes:
    output = bytearray()
    if entry.method == 0:
        if entry.size != entry.compressed_size:
            raise ArchiveFormatError("stored ZIP member sizes disagree")
        for pos in range(entry.data_start, entry.data_end, _CHUNK):
            ctx.ledger.consume("parser_iterations")
            output.extend(ctx.data[pos:min(pos + _CHUNK, entry.data_end)])
    else:
        decoder = zlib.decompressobj(-15)
        for pos in range(entry.data_start, entry.data_end, _CHUNK):
            incoming = ctx.data[pos:min(pos + _CHUNK, entry.data_end)]
            while incoming:
                ctx.ledger.consume("parser_iterations")
                block = decoder.decompress(incoming, min(_CHUNK, entry.size - len(output) + 1))
                output.extend(block)
                if len(output) > entry.size:
                    raise ArchiveFormatError("ZIP output exceeds declared member size")
                incoming = decoder.unconsumed_tail
            if decoder.unused_data:
                raise ArchiveFormatError("ZIP compressed stream contains trailing data")
        if not decoder.eof or decoder.unused_data:
            raise ArchiveFormatError("ZIP compressed stream is truncated or ambiguous")
    if len(output) != entry.size or binascii.crc32(output) & 0xFFFFFFFF != entry.crc:
        raise ArchiveFormatError("ZIP member size or checksum disagrees")
    return bytes(output)


def _analyze_zip(ctx: _Context) -> None:
    entries, cd_offset = _zip_directory(ctx)
    try:
        # Never feed an independently inconsistent central directory to a parser
        # that ignores its declared count and may allocate all hidden records.
        if not ctx.malformed:
            with zipfile.ZipFile(io.BytesIO(ctx.data)) as parser:
                infos = parser.infolist()
            if len(infos) != len(entries):
                raise ArchiveFormatError("ZIP parsers disagree about member count")
            for info, entry in zip(infos, entries, strict=True):
                ctx.ledger.consume("parser_iterations")
                if (info.filename, info.header_offset, info.compress_size, info.file_size, info.CRC,
                        info.flag_bits, info.compress_type) != (entry.name, entry.offset, entry.compressed_size,
                        entry.size, entry.crc, entry.flags, entry.method):
                    raise ArchiveFormatError("ZIP parsers disagree about member metadata")
    except (zipfile.BadZipFile, ValueError) as exc:
        ctx.format_error(str(exc))
    for entry in entries:
        if not entry.name.endswith("/") or entry.size:
            entry.record = ctx.member(entry.name, entry.size, encrypted=bool(entry.flags & 1))
            if entry.name.endswith("/"):
                ctx.format_error("ZIP directory entry contains hidden nonempty file data.", entry.name)
        else:
            ctx.check_name(entry.name)
        try:
            _zip_local(ctx, entry, cd_offset)
        except (ArchiveFormatError, struct.error) as exc:
            entry.valid = False
            ctx.format_error(str(exc), entry.name)
            if entry.record is not None:
                entry.record["reason"] = "local_header_disagreement"
    ordered = sorted((item for item in entries if item.valid), key=lambda item: (item.offset, item.name))
    end = 0
    previous: _ZipEntry | None = None
    for entry in ordered:
        if entry.offset < end:
            entry.valid = False
            if previous is not None:
                previous.valid = False
                if previous.record is not None:
                    previous.record["reason"] = "overlapping_entries"
            ctx.format_error("ZIP local records overlap.", entry.name)
            if entry.record is not None:
                entry.record["reason"] = "overlapping_entries"
        elif entry.offset != end:
            ctx.format_error("ZIP contains unindexed bytes between local records.", entry.name)
        if entry.interval_end > end:
            end, previous = entry.interval_end, entry
    if end != cd_offset:
        ctx.format_error("ZIP contains unindexed bytes before its central directory.")
    for entry in entries:
        record = entry.record
        if record is None or not entry.valid:
            continue
        if entry.flags & (1 | 0x40):
            record["encrypted"] = True
            ctx.unreadable(record, "encrypted_member", ErrorCode.ENCRYPTED_MEMBER)
            continue
        if entry.flags & (0x20 | 0x2000) or entry.method not in (0, 8):
            ctx.unreadable(record, "unsupported_compression_or_flags", ErrorCode.UNSUPPORTED_FORMAT)
            continue
        if not ctx.reserve(record, entry.compressed_size):
            continue
        try:
            payload = _inflate(ctx, entry)
            record.update(data_b64=base64.b64encode(payload).decode("ascii"), readable=True)
        except (ArchiveFormatError, zlib.error) as exc:
            ctx.format_error(str(exc), entry.name)
            record["reason"] = "decompression_or_crc_failure"


def _analyze_7z(ctx: _Context) -> None:
    header = _slice(ctx.data, 0, 32)
    if header[:6] != b"7z\xbc\xaf\x27\x1c" or header[6] != 0:
        raise ArchiveFormatError("unsupported or malformed 7z signature/version")
    if binascii.crc32(header[12:32]) & 0xFFFFFFFF != struct.unpack_from("<I", header, 8)[0]:
        raise ArchiveFormatError("7z start-header CRC disagrees")
    offset, size, crc = struct.unpack_from("<QQI", header, 12)
    if size > _MAX_HEADER:
        ctx.incomplete = ctx.limited = True
        ctx.error(ErrorCode.ITERATION_BUDGET_EXHAUSTED)
        return
    next_header = _slice(ctx.data, 32 + offset, size)
    if 32 + offset + size != len(ctx.data):
        raise ArchiveFormatError("7z next-header range or trailing bytes disagree")
    if binascii.crc32(next_header) & 0xFFFFFFFF != crc:
        raise ArchiveFormatError("7z next-header CRC disagrees")
    try:
        import py7zr
        from py7zr.io import Py7zIO, WriterFactory
    except ImportError:
        ctx.incomplete = True
        ctx.error(ErrorCode.PARSER_UNAVAILABLE)
        return

    class Sink(Py7zIO):
        def __init__(self, expected: int) -> None:
            self.expected = expected
            self.stream = io.BytesIO()

        def write(self, block: bytes | bytearray) -> int:
            ctx.ledger.consume("parser_iterations")
            if self.stream.tell() > self.expected or len(block) > self.expected - self.stream.tell():
                raise ArchiveFormatError("7z output exceeds declared member size")
            return self.stream.write(block)

        def read(self, size: int | None = None) -> bytes:
            return self.stream.read(-1 if size is None else size)

        def seek(self, offset: int, whence: int = 0) -> int:
            if whence not in (0, 1, 2):
                raise ArchiveFormatError("invalid 7z writer seek")
            base = 0 if whence == 0 else self.stream.tell() if whence == 1 else self.size()
            target = base + offset
            if target < 0 or target > self.expected:
                raise ArchiveFormatError("7z writer seek exceeds size")
            return self.stream.seek(target)

        def flush(self) -> None:
            self.stream.flush()

        def size(self) -> int:
            return self.stream.getbuffer().nbytes

    class Factory(WriterFactory):
        def __init__(self, allowed: dict[str, dict[str, Any]]) -> None:
            self.allowed = {Path(name).as_posix(): item for name, item in allowed.items()}
            self.sinks: dict[str, Sink] = {}

        def create(self, filename: str) -> Sink:
            if filename not in self.allowed or filename in self.sinks:
                raise ArchiveFormatError("7z writer returned an unexpected or duplicate name")
            record = self.allowed[filename]
            sink = Sink(record["declared_size"])
            self.sinks[filename] = sink
            return sink

    with py7zr.SevenZipFile(io.BytesIO(ctx.data), mode="r", mp=False,
                           max_extract_size=ctx.ledger.remaining("decompressed_bytes")) as parser:
        infos = parser.list()
        ctx.ledger.consume("archive_entries", len(infos))
        allowed: dict[str, dict[str, Any]] = {}
        encrypted = parser.needs_password()
        cumulative_size = sum(info.uncompressed for info in infos if not info.is_directory)
        excessive_ratio = cumulative_size > 1024 * 1024 and cumulative_size > max(1, len(ctx.data)) * _RATIO
        for info in infos:
            ctx.ledger.consume("parser_iterations")
            if info.is_directory:
                ctx.check_name(info.filename)
                continue
            record = ctx.member(info.filename, info.uncompressed, encrypted=encrypted)
            _, problems = normalize_member_name(info.filename)
            if encrypted:
                ctx.unreadable(record, "encrypted_member", ErrorCode.ENCRYPTED_MEMBER)
            elif excessive_ratio:
                record["reason"] = "compression_ratio_limit"
                ctx.incomplete = ctx.limited = True
                ctx.error(ErrorCode.ITERATION_BUDGET_EXHAUSTED)
            elif problems or not info.is_file or info.is_symlink:
                ctx.unreadable(record, "unsafe_or_special_member", ErrorCode.UNSUPPORTED_FORMAT)
            elif info.filename in allowed:
                ctx.unreadable(record, "duplicate_member", ErrorCode.PARSER_DISAGREEMENT)
            elif ctx.reserve(record, info.compressed):
                allowed[info.filename] = record
        if encrypted or not allowed:
            return
        if ctx.disagreement:
            for record in allowed.values():
                ctx.unreadable(record, "ambiguous_member_names", ErrorCode.PARSER_DISAGREEMENT)
            return
        factory = Factory(allowed)
        try:
            parser.extract(targets=sorted(allowed), factory=factory)
        finally:
            for filename, sink in factory.sinks.items():
                record = factory.allowed[filename]
                payload = sink.stream.getvalue()
                if len(payload) == record["declared_size"]:
                    record.update(data_b64=base64.b64encode(payload).decode("ascii"), readable=True)
        for record in allowed.values():
            if not record["readable"]:
                ctx.unreadable(record, "missing_or_incomplete_7z_output", ErrorCode.MALFORMED_INPUT)


def _rar4_headers(ctx: _Context) -> int:
    """Independently bound RAR4 block iteration before invoking rarfile."""
    pos = 7
    finished = False
    count = 0
    while pos < len(ctx.data):
        ctx.ledger.consume("parser_iterations")
        crc, kind, flags, header_size = struct.unpack("<HBHH", _slice(ctx.data, pos, 7))
        if header_size < 7:
            raise ArchiveFormatError("RAR4 header size is invalid")
        header = _slice(ctx.data, pos, header_size)
        if binascii.crc32(header[2:]) & 0xFFFF != crc:
            raise ArchiveFormatError("RAR4 header checksum disagrees")
        packed = struct.unpack_from("<I", header, 7)[0] if flags & 0x8000 else 0
        if kind == 0x74:
            ctx.ledger.consume("archive_entries")
            count += 1
            if header_size < 32:
                raise ArchiveFormatError("RAR4 file header is truncated")
            if flags & 0x100:
                if header_size < 40:
                    raise ArchiveFormatError("RAR4 large-file header is truncated")
                packed |= struct.unpack_from("<I", header, 32)[0] << 32
        if kind == 0x73 and flags & 0x80:
            ctx.incomplete = True
            ctx.error(ErrorCode.ENCRYPTED_MEMBER)
            return count
        if packed > len(ctx.data) - pos - header_size:
            raise ArchiveFormatError("RAR4 packed range exceeds input")
        pos += header_size + packed
        if kind == 0x7B:
            finished = True
            break
    if not finished or pos != len(ctx.data):
        raise ArchiveFormatError("RAR4 end record is absent or trailing data exists")
    return count


def _analyze_rar(ctx: _Context) -> None:
    if ctx.data.startswith(b"Rar!\x1a\x07\x01\x00"):
        ctx.incomplete = True
        ctx.error(ErrorCode.UNSUPPORTED_FORMAT)
        return
    expected_count = _rar4_headers(ctx)
    if ErrorCode.ENCRYPTED_MEMBER in ctx.errors:
        return
    try:
        import rarfile
    except ImportError:
        ctx.incomplete = True
        ctx.error(ErrorCode.PARSER_UNAVAILABLE)
        return
    with rarfile.RarFile(io.BytesIO(ctx.data), errors="strict", crc_check=True) as parser:
        infos = parser.infolist()
        if len(infos) != expected_count:
            raise ArchiveFormatError("RAR parsers disagree about file entries")
        for info in infos:
            ctx.ledger.consume("parser_iterations")
            if info.is_dir():
                ctx.check_name(info.filename)
                continue
            record = ctx.member(info.filename, info.file_size, encrypted=info.needs_password())
            if info.needs_password():
                ctx.unreadable(record, "encrypted_member", ErrorCode.ENCRYPTED_MEMBER)
                continue
            if (info.compress_type != rarfile.RAR_M0 or info.file_redir is not None
                    or not info.is_file() or info.flags & (0x1 | 0x2 | 0x4 | 0x10)):
                ctx.unreadable(record, "unsupported_compressed_split_or_special_rar_member", ErrorCode.UNSUPPORTED_FORMAT)
                continue
            if info.compress_size != info.file_size:
                raise ArchiveFormatError("RAR stored member sizes disagree")
            if not ctx.reserve(record, info.compress_size):
                continue
            output = bytearray()
            with parser.open(info) as stream:
                while True:
                    ctx.ledger.consume("parser_iterations")
                    block = stream.read(min(_CHUNK, info.file_size - len(output) + 1))
                    if not block:
                        break
                    output.extend(block)
                    if len(output) > info.file_size:
                        raise ArchiveFormatError("RAR stored output exceeds declared size")
            if len(output) != info.file_size:
                raise ArchiveFormatError("RAR stored member is truncated")
            record.update(data_b64=base64.b64encode(output).decode("ascii"), readable=True)


def analyze(data: bytes, artifact_id: str, logical_path: str, ledger: BudgetLedger,
            depth: int = 0, max_depth: int = 4,
            max_member_size: int = _MAX_MEMBER) -> StageResult:
    """Return archive evidence and member bytes; never return a verdict."""
    if type(data) is not bytes:
        raise TypeError("archive input must be immutable bytes")
    if any(type(value) is not int or not 0 <= value <= (1 << 63) - 1
           for value in (depth, max_depth, max_member_size)):
        raise ValueError("archive limits must be bounded nonnegative integers")
    ctx = _Context(data, artifact_id, logical_path, ledger, depth, max_member_size)
    if depth >= max_depth:
        ctx.incomplete = ctx.limited = True
        ctx.error(ErrorCode.ITERATION_BUDGET_EXHAUSTED)
        return ctx.finish()
    try:
        ledger.consume("parser_iterations")
        if data.startswith((b"PK\x03\x04", b"PK\x05\x06", b"PK\x06\x06")):
            ctx.archive_type = "ZIP"
            _analyze_zip(ctx)
        elif data.startswith(b"7z\xbc\xaf\x27\x1c"):
            ctx.archive_type = "7Z"
            _analyze_7z(ctx)
        elif data.startswith(b"Rar!\x1a\x07"):
            ctx.archive_type = "RAR"
            _analyze_rar(ctx)
        else:
            ctx.incomplete = True
            ctx.error(ErrorCode.UNSUPPORTED_FORMAT)
    except (BudgetExceeded, ArchiveOutputLimit):
        ctx.incomplete = ctx.limited = True
        ctx.error(ErrorCode.ITERATION_BUDGET_EXHAUSTED)
        for record in ctx.children:
            if not record["readable"] and not record["reason"]:
                record["reason"] = "global_work_budget_exhausted"
    except (ArchiveFormatError, struct.error, EOFError, ValueError, OSError) as exc:
        try:
            ctx.format_error(str(exc))
        except (BudgetExceeded, ArchiveOutputLimit):
            ctx.incomplete = ctx.limited = True
            ctx.error(ErrorCode.ITERATION_BUDGET_EXHAUSTED)
    except Exception as exc:
        # Libraries may raise format-specific exception classes. Previously
        # collected evidence and completed children must survive every fault.
        ctx.incomplete = True
        ctx.error(ErrorCode.MALFORMED_INPUT)
        try:
            ctx.format_error(f"Archive parser failed: {type(exc).__name__}")
        except (BudgetExceeded, ArchiveOutputLimit):
            ctx.limited = True
            ctx.error(ErrorCode.ITERATION_BUDGET_EXHAUSTED)
    return ctx.finish()


__all__ = ["analyze", "normalize_member_name", "ArchiveFormatError"]
