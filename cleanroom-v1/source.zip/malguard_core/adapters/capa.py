"""Strict, read-only capa JSON adapter; arbitrary tools are never executed."""

from __future__ import annotations

import json
from math import isfinite

from malguard_core.budget import BudgetLedger
from malguard_core.model import EvidenceDomain, EvidenceLocation, Severity, StageResult, make_evidence


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate capa JSON key")
        result[key] = value
    return result


def _validate_primitives(document) -> None:
    pending = [(document, 0)]
    visited = 0
    while pending:
        value, depth = pending.pop()
        visited += 1
        if depth > 20 or visited > 100_000:
            raise ValueError("capa document nesting or item limit exceeded")
        if value is None or isinstance(value, bool):
            continue
        if isinstance(value, int):
            if not -(2**63) <= value <= 2**64 - 1:
                raise ValueError("capa integer range exceeded")
        elif isinstance(value, float):
            if not isfinite(value):
                raise ValueError("non-finite capa JSON number")
        elif isinstance(value, str):
            if len(value) > 8192:
                raise ValueError("capa string length exceeded")
        elif isinstance(value, dict):
            pending.extend((item, depth + 1) for item in value.values())
            pending.extend((key, depth + 1) for key in value)
        elif isinstance(value, list):
            pending.extend((item, depth + 1) for item in value)
        else:
            raise ValueError("capa document contains an unsupported value")


def import_capa_json(data: bytes, artifact_id: str, expected_sha256: str,
                     ledger: BudgetLedger) -> StageResult:
    """Import bounded capa context only when its sample hash identifies this file.

    Imported findings remain context with zero safety credit. They cannot serve as
    a trusted verdict or bypass the scanner's required native analyses.
    """
    if not isinstance(data, bytes) or len(data) > 4 * 1024 * 1024:
        raise ValueError("capa document exceeds the 4 MiB limit")
    if not isinstance(expected_sha256, str) or len(expected_sha256) != 64 or any(character not in "0123456789abcdef" for character in expected_sha256):
        raise ValueError("expected sample identity must be lowercase SHA256")
    ledger.consume("parser_iterations", max(1, len(data) // 64))
    try:
        document = json.loads(data.decode("utf-8"), object_pairs_hook=_unique_object)
    except (ValueError, UnicodeError, RecursionError) as exc:
        raise ValueError("malformed capa JSON") from exc
    _validate_primitives(document)
    if not isinstance(document, dict) or set(document) - {"meta", "rules"}:
        raise ValueError("unexpected capa top-level schema")
    meta = document.get("meta")
    rules = document.get("rules")
    if not isinstance(meta, dict) or not isinstance(rules, dict) or len(rules) > 4096:
        raise ValueError("invalid capa metadata or rule count")
    sample = meta.get("sample")
    if not isinstance(sample, dict) or sample.get("sha256") != expected_sha256:
        raise ValueError("capa sample identity does not match the scanned artifact")
    version = meta.get("version")
    if not isinstance(version, str) or not 1 <= len(version) <= 128:
        raise ValueError("capa version is missing or invalid")
    names = []
    for name, result in sorted(rules.items()):
        ledger.consume("parser_iterations")
        if not isinstance(name, str) or not 1 <= len(name) <= 256 or not isinstance(result, dict):
            raise ValueError("invalid capa rule record")
        matches = result.get("matches", [])
        if not isinstance(matches, list) or len(matches) > 4096:
            raise ValueError("invalid capa match count")
        if matches:
            names.append(name)
    ledger.consume("evidence")
    evidence = make_evidence(
        "adapter.capa.context", "S3", EvidenceDomain.CONTEXT, "EXTERNAL_STATIC_CONTEXT", "CAPA_IMPORT", Severity.INFO,
        EvidenceLocation(artifact_id, detail="Validated external JSON sample identity"),
        "A bounded capa JSON document was matched to this sample; external findings supply context only.",
        "سند محدود JSON ابزار capa با هویت نمونه تطبیق یافت؛ یافته‌های خارجی فقط زمینهٔ تحلیل فراهم می‌کنند.",
        confidence=1.0, reliability=.75, attributes=(("matched_rule_count", len(names)),),
    )
    return StageResult("S3", evidence=(evidence,), facts={"capa_rules": names, "capa_version": version})
