"""Optional external static-analysis result adapters."""

from .capa import import_capa_json

__all__ = ["import_capa_json"]
