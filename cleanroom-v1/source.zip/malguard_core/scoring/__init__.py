"""Deterministic family saturation with narrowly scoped GTA mitigation."""

from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP
from collections import defaultdict
from collections.abc import Iterable

from malguard_core.model import Evidence, EvidenceDomain


@dataclass(frozen=True, slots=True)
class FamilyScore:
    artifact_id: str
    domain: EvidenceDomain
    family: str
    score: float
    decisive_confidence: float


@dataclass(frozen=True, slots=True)
class RiskAssessment:
    risk: int
    harm_total: float
    opacity_total: float
    structural_bonus: float
    families: tuple[FamilyScore, ...]


def _decimal(value: float | int) -> Decimal:
    return Decimal(str(value))


def assess(evidence: Iterable[Evidence]) -> RiskAssessment:
    unique = {item.id: item for item in evidence}
    semantic: dict = {}
    for item in unique.values():
        key = (item.location.artifact_id, item.rule_id, item.domain, item.family,
               item.kind, item.location.offset, item.location.length)
        previous = semantic.get(key)
        if previous is None or (item.effective_weight, item.id) > (previous.effective_weight, previous.id):
            semantic[key] = item
    groups: dict = defaultdict(list)
    gta_scope: set[str] = set()
    for item in semantic.values():
        attrs = dict(item.attributes)
        if (item.domain == EvidenceDomain.CONTEXT and item.mitigating
                and item.confidence >= 0.9 and attrs.get("gta_exclusive") is True
                and attrs.get("target_linked") is True):
            gta_scope.add(item.location.artifact_id)
        if not item.mitigating and item.domain in (EvidenceDomain.HARM, EvidenceDomain.OPACITY):
            groups[(item.location.artifact_id, item.domain, item.family)].append(item)
    families: list[FamilyScore] = []
    for (artifact_id, domain, family), items in sorted(groups.items(), key=lambda pair: (pair[0][0], pair[0][1].value, pair[0][2])):
        items.sort(key=lambda item: (-item.effective_weight, item.id))
        weights = [_decimal(item.base_weight) * _decimal(item.confidence) * _decimal(item.reliability) for item in items[:3]]
        saturated = sum((value * multiplier for value, multiplier in zip(weights, (Decimal(1), Decimal("0.5"), Decimal("0.25")), strict=False)), Decimal(0))
        saturated = min(Decimal(32 if domain == EvidenceDomain.HARM else 18), saturated)
        # Any unrelated target disables mitigation at the analyzer; this extra
        # gate requires validated exclusive target linkage on each harm record.
        if (artifact_id in gta_scope and family in {"PROCESS_INJECTION", "GAME_PROCESS_MODIFICATION"}
                and all(dict(item.attributes).get("gta_exclusive") is True for item in items)):
            saturated *= Decimal("0.6")
        decisive = max((item.confidence for item in items if item.effective_weight >= 16), default=0.0)
        families.append(FamilyScore(artifact_id, domain, family, float(saturated), decisive))
    harm = sorted((item.score for item in families if item.domain == EvidenceDomain.HARM), reverse=True)[:3]
    opacity = sorted((item.score for item in families if item.domain == EvidenceDomain.OPACITY), reverse=True)[:2]
    h = sum(map(_decimal, harm), Decimal(0))
    o = min(Decimal(20), Decimal("0.6") * sum(map(_decimal, opacity), Decimal(0)))
    structural = sorted((_decimal(item.effective_weight) for item in semantic.values()
                         if item.domain == EvidenceDomain.STRUCTURE and not item.mitigating), reverse=True)[:3]
    d = min(Decimal(15), sum((value * multiplier for value, multiplier in zip(structural, (Decimal(1), Decimal("0.5"), Decimal("0.25")), strict=False)), Decimal(0)))
    risk = int(min(Decimal(100), h + o + d).quantize(Decimal(1), rounding=ROUND_HALF_UP))
    return RiskAssessment(risk, float(h), float(o), float(d), tuple(families))
