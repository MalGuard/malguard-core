"""Bounded offline Authenticode image-digest and CMS signature verification.

This parser runs inside the PE worker. It never consults the network or Windows
loaders. Cryptographic integrity and signer identity are facts, never safety
credit. Root trust, time validity and timestamp chains require a separately
verified trust snapshot and are reported as unverified here.
"""

import hashlib
import hmac
import struct
from collections.abc import Callable
from typing import Any, BinaryIO, cast

from malguard_core.budget import BudgetExceeded, BudgetLedger
from malguard_core.intake import BoundedByteSource
from malguard_core.model import (
    CoverageState, ErrorCode, EvidenceDomain, EvidenceLocation, Severity,
    StageResult, make_evidence,
)


_MAX_TABLE = 2 * 1024 * 1024
_MAX_CMS = 512 * 1024
_MAX_CERTIFICATES = 32
_MAX_SIGNATURES = 16
_MAX_DER_DEPTH = 24
_MAX_DER_NODES = 16_384
_DIGESTS = frozenset({"sha1", "sha256", "sha384", "sha512"})
_LIMITATIONS = (
    "Offline Authenticode verifies image digest and CMS cryptographic signature; certificate root trust, current-time validity and timestamp chains are not established.",
    "No online OCSP or CRL requests are made; only explicitly supplied signed-bundle revocations are used.",
    "Nested signatures, RSA-PSS and uncommon CMS algorithms are not verified by this bounded adapter.",
)


class SignatureFormatError(ValueError):
    """Malformed or ambiguous certificate structure."""


class UnsupportedSignature(ValueError):
    """A signature algorithm or structure is not safely supported."""


class _BoundedFile:
    """File-like parser adapter with no filesystem and ledger-accounted reads."""

    def __init__(self, source: BoundedByteSource) -> None:
        self.source = source
        self.position = 0

    def tell(self) -> int:
        return self.position

    def seek(self, offset: int, whence: int = 0) -> int:
        if isinstance(offset, bool) or not isinstance(offset, int):
            raise SignatureFormatError("invalid parser seek")
        base = {0: 0, 1: self.position, 2: self.source.size}.get(whence)
        if base is None or not 0 <= base + offset <= self.source.size:
            raise SignatureFormatError("parser seek exceeds captured bytes")
        self.position = base + offset
        return self.position

    def read(self, length: int = -1) -> bytes:
        if length == -1:
            length = self.source.size - self.position
        if isinstance(length, bool) or not isinstance(length, int) or length < 0:
            raise SignatureFormatError("invalid parser read")
        length = min(length, self.source.size - self.position)
        result = self.source.read(self.position, length)
        self.position += length
        return result


def _bounds(data: bytes, start: int, length: int) -> None:
    if start < 0 or length < 0 or start > len(data) or length > len(data) - start:
        raise SignatureFormatError("certificate offset exceeds captured bytes")


def _pe_layout(data: bytes, ledger: BudgetLedger) -> tuple[int, int, int, int]:
    source = BoundedByteSource(data, ledger, _charge_file_bytes=False)
    def unpack(format_string: str, offset: int) -> tuple:
        return struct.unpack(format_string, source.read(offset, struct.calcsize(format_string)))
    ledger.consume("parser_iterations")
    _bounds(data, 0, 64)
    if source.read(0, 2) != b"MZ":
        raise SignatureFormatError("not a PE image")
    pe_offset = unpack("<I", 60)[0]
    _bounds(data, pe_offset, 24)
    if source.read(pe_offset, 4) != b"PE\0\0":
        raise SignatureFormatError("missing PE signature")
    sections = unpack("<H", pe_offset + 6)[0]
    optional_size = unpack("<H", pe_offset + 20)[0]
    optional_offset = pe_offset + 24
    _bounds(data, optional_offset, optional_size)
    if optional_size < 68:
        raise SignatureFormatError("optional header cannot accommodate checksum")
    magic = unpack("<H", optional_offset)[0]
    if magic == 0x10B:
        count_relative, directory_relative = 92, 96
    elif magic == 0x20B:
        count_relative, directory_relative = 108, 112
    else:
        raise SignatureFormatError("unsupported optional header")
    if optional_size < count_relative + 4:
        return optional_offset + 64, 0, 0, 0
    directory_count = unpack("<I", optional_offset + count_relative)[0]
    if directory_count < 5:
        return optional_offset + 64, 0, 0, 0
    if optional_size < directory_relative + 40:
        raise SignatureFormatError("certificate directory lies outside optional header")
    directory = optional_offset + directory_relative + 32
    start, size = unpack("<II", directory)
    if not start and not size:
        return optional_offset + 64, directory, 0, 0
    if not start or not size or start % 8:
        raise SignatureFormatError("inconsistent or unaligned certificate table")
    if size > _MAX_TABLE:
        raise UnsupportedSignature("certificate table exceeds bounded capacity")
    _bounds(data, start, size)
    section_table = optional_offset + optional_size
    if sections > 96:
        raise SignatureFormatError("absurd PE section count")
    _bounds(data, section_table, sections * 40)
    header_size = unpack("<I", optional_offset + 60)[0]
    if start < max(header_size, section_table + sections * 40):
        raise SignatureFormatError("certificate table overlaps image headers")
    for index in range(sections):
        ledger.consume("parser_iterations")
        position = section_table + 40 * index
        raw_size, raw_start = unpack("<II", position + 16)
        _bounds(data, raw_start, raw_size)
        if raw_size and raw_start < start + size and start < raw_start + raw_size:
            raise SignatureFormatError("certificate table overlaps section bytes")
    return optional_offset + 64, directory, start, size


def _validate_der(data: bytes, ledger: BudgetLedger, *, envelope: bool = True) -> None:
    """Iterative definite-length TLV validation before third-party ASN.1 parsing."""
    if not data or len(data) > _MAX_CMS:
        raise UnsupportedSignature("CMS size exceeds bounded capacity")
    stack = [(0, len(data), 0)]
    nodes = 0
    while stack:
        start, end, depth = stack.pop()
        if depth > _MAX_DER_DEPTH:
            raise UnsupportedSignature("ASN.1 nesting exceeds bounded capacity")
        position = start
        while position < end:
            ledger.consume("parser_iterations")
            nodes += 1
            if nodes > _MAX_DER_NODES:
                raise UnsupportedSignature("ASN.1 node count exceeds bounded capacity")
            if end - position < 2:
                raise SignatureFormatError("truncated ASN.1 header")
            tag = data[position]
            position += 1
            if tag & 31 == 31:
                raise UnsupportedSignature("high-tag-number ASN.1 is unsupported")
            first = data[position]
            position += 1
            if first == 0x80:
                raise SignatureFormatError("indefinite ASN.1 length is rejected")
            if first & 0x80:
                count = first & 0x7F
                if count == 0 or count > 4 or end - position < count:
                    raise SignatureFormatError("invalid ASN.1 length")
                if data[position] == 0:
                    raise SignatureFormatError("nonminimal ASN.1 length")
                length = int.from_bytes(data[position:position + count], "big")
                position += count
                if length < 128:
                    raise SignatureFormatError("nonminimal ASN.1 long length")
            else:
                length = first
            if length > end - position:
                raise SignatureFormatError("ASN.1 value exceeds container")
            if tag & 0x20:
                stack.append((position, position + length, depth + 1))
            position += length
    if envelope:
        # One envelope only. ASN.1 loaders can otherwise ignore suffixes.
        from asn1crypto import cms
        from asn1crypto.core import ParsableOctetString
        container = cms.ContentInfo.load(data, strict=True)
        if container["content_type"].native != "signed_data":
            raise SignatureFormatError("certificate payload is not CMS SignedData")
        content = container["content"]["encap_content_info"]["content"]
        if isinstance(content, ParsableOctetString):
            # CMS v3 hides ASN.1 inside a primitive OCTET STRING. Validate its
            # depth and node count before signify follows the parsed property.
            _validate_der(bytes(content), ledger, envelope=False)


def _image_digest(data: bytes, checksum: int, directory: int, start: int, size: int,
                  name: str, ledger: BudgetLedger) -> bytes:
    if name not in _DIGESTS:
        raise UnsupportedSignature("unsupported image digest algorithm")
    omitted = [(checksum, checksum + 4), (directory, directory + 8), (start, start + size)]
    omitted.sort()
    digest = hashlib.new(name)
    position = 0
    source = BoundedByteSource(data, ledger, _charge_file_bytes=False)
    for begin, end in omitted:
        if begin < position:
            raise SignatureFormatError("overlapping Authenticode exclusion ranges")
        for offset in range(position, begin, 1024 * 1024):
            ledger.consume("parser_iterations")
            digest.update(source.read(offset, min(begin - offset, 1024 * 1024)))
        position = end
    for offset in range(position, len(data), 1024 * 1024):
        ledger.consume("parser_iterations")
        digest.update(source.read(offset, min(len(data) - offset, 1024 * 1024)))
    return digest.digest()


def _signature_fact(cms_data: bytes, data: bytes, layout: tuple[int, int, int, int],
                    ledger: BudgetLedger, revoked: frozenset[str]) -> dict[str, Any]:
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.asymmetric import ec, padding, rsa
    from signify.authenticode.signed_data import AuthenticodeSignature
    from signify.authenticode.signed_file.pe import SignedPEFile

    _validate_der(cms_data, ledger)
    signature = AuthenticodeSignature.from_envelope(cms_data)
    signer = signature.signer_info
    digest_name = signature.digest_algorithm().name
    if digest_name not in _DIGESTS or signer.digest_algorithm().name != digest_name:
        raise UnsupportedSignature("unsupported or inconsistent CMS digest")
    if signature.indirect_data.digest_algorithm().name != digest_name:
        raise SignatureFormatError("CMS and image digest algorithms disagree")
    if signature.indirect_data.content_type != "microsoft_spc_pe_image_data":
        raise SignatureFormatError("Authenticode content is not a PE image digest")
    expected = _image_digest(data, *layout, digest_name, ledger)
    # Differential check with the maintained parser, independent of our omissions.
    ledger.consume("parser_iterations", max(1, (len(data) + 1_048_575) // 1_048_576))
    third_party = SignedPEFile(cast(BinaryIO, _BoundedFile(BoundedByteSource(data, ledger, _charge_file_bytes=False)))).get_fingerprint(getattr(hashlib, digest_name))
    if not hmac.compare_digest(expected, third_party):
        raise SignatureFormatError("Authenticode digest parsers disagree")
    image_valid = hmac.compare_digest(expected, signature.indirect_data.digest)
    if not hmac.compare_digest(signature.get_content_digest(), signer.message_digest or b""):
        raise SignatureFormatError("CMS content digest does not match signed attributes")
    certificates = signature.asn1["certificates"]
    if len(certificates) > _MAX_CERTIFICATES:
        raise UnsupportedSignature("too many CMS certificates")
    sid = signer.asn1["sid"]
    if sid.name != "issuer_and_serial_number":
        raise UnsupportedSignature("unsupported signer identifier")
    certificate_der = None
    for entry in certificates:
        ledger.consume("parser_iterations")
        if entry.name != "certificate":
            continue
        certificate = entry.chosen
        if (certificate.serial_number == sid.chosen["serial_number"].native
                and certificate.issuer.dump() == sid.chosen["issuer"].dump()):
            if certificate_der is not None:
                raise SignatureFormatError("ambiguous signer certificate")
            certificate_der = certificate.dump()
    if certificate_der is None:
        raise SignatureFormatError("CMS signer certificate is missing")
    certificate = x509.load_der_x509_certificate(certificate_der)
    public_key = certificate.public_key()
    if not isinstance(public_key, (rsa.RSAPublicKey, ec.EllipticCurvePublicKey)):
        raise UnsupportedSignature("unsupported certificate public key algorithm")
    if ((isinstance(public_key, rsa.RSAPublicKey) and not 1024 <= public_key.key_size <= 8192)
            or (isinstance(public_key, ec.EllipticCurvePublicKey) and not 224 <= public_key.key_size <= 571)):
        raise UnsupportedSignature("signer key size exceeds bounded policy")
    digest_factories: dict[str, Callable[[], hashes.HashAlgorithm]] = {
        "sha1": hashes.SHA1, "sha256": hashes.SHA256,
        "sha384": hashes.SHA384, "sha512": hashes.SHA512,
    }
    digest = digest_factories[digest_name]()
    attrs = signer.asn1["signed_attrs"]
    if not attrs:
        raise SignatureFormatError("CMS signed attributes are required")
    encoded_attrs = attrs.dump()
    if encoded_attrs[:1] != b"\xa0":
        raise SignatureFormatError("unexpected CMS signed attributes tag")
    payload = b"\x31" + encoded_attrs[1:]
    algorithm = signer.asn1["signature_algorithm"]["algorithm"].native
    value = signer.encrypted_digest
    ledger.consume("parser_iterations")
    from cryptography.exceptions import InvalidSignature
    crypto_valid = True
    try:
        if isinstance(public_key, rsa.RSAPublicKey) and algorithm in {
            "rsassa_pkcs1v15", "sha1_rsa", "sha256_rsa", "sha384_rsa", "sha512_rsa",
        }:
            if algorithm != "rsassa_pkcs1v15" and algorithm.split("_")[0] != digest_name:
                raise SignatureFormatError("RSA signature digest disagrees")
            public_key.verify(value, payload, padding.PKCS1v15(), digest)
        elif isinstance(public_key, ec.EllipticCurvePublicKey) and algorithm in {
            "sha1_ecdsa", "sha256_ecdsa", "sha384_ecdsa", "sha512_ecdsa",
        }:
            if algorithm.split("_")[0] != digest_name:
                raise SignatureFormatError("ECDSA signature digest disagrees")
            public_key.verify(value, payload, ec.ECDSA(digest))
        else:
            raise UnsupportedSignature("unsupported CMS signature algorithm")
    except InvalidSignature:
        crypto_valid = False
    fingerprint = certificate.fingerprint(hashes.SHA256()).hex()
    # Never expose unbounded names taken from hostile certificates.
    subject = certificate.subject.rfc4514_string()[:512]
    return {
        "signer_sha256": fingerprint, "subject": subject,
        "image_digest_valid": image_valid, "cms_signature_valid": crypto_valid,
        "digest_algorithm": digest_name, "chain_trust": "UNVERIFIED",
        "timestamp_trust": "UNVERIFIED", "revoked": fingerprint in revoked,
        "nested_signatures_present": bool(signer.unauthenticated_attributes.get("microsoft_nested_signature")),
    }


def analyze(data: bytes, artifact_id: str, logical_path: str, ledger: BudgetLedger,
            pe_facts: dict | None = None) -> StageResult:
    """Analyze captured bytes; supplied revocation fingerprints must be bundle-verified."""
    del logical_path
    evidence = []
    facts: dict[str, Any] = {"authenticode_present": False, "signatures": []}
    state = CoverageState.COMPLETE
    errors = []
    offset = None
    def add(rule: str, domain: EvidenceDomain, family: str, kind: str,
            severity: Severity, english: str, persian: str, attributes=()) -> None:
        ledger.consume("evidence")
        evidence.append(make_evidence(rule_id=rule, stage="S2", domain=domain,
            family=family, kind=kind, severity=severity,
            location=EvidenceLocation(artifact_id, offset=offset),
            description_en=english, description_fa=persian, attributes=attributes))
    try:
        source = BoundedByteSource(data, ledger, _charge_file_bytes=False)
        layout = _pe_layout(data, ledger)
        offset, size = layout[2:]
        if not size:
            return StageResult("S2", facts=facts)
        facts["authenticode_present"] = True
        records = (pe_facts or {}).get("revoked_signer_sha256", ())
        if not isinstance(records, (list, tuple)) or len(records) > 100_000:
            raise ValueError("invalid supplied signer revocations")
        if any(not isinstance(x, str) or len(x) != 64 or any(c not in "0123456789abcdefABCDEF" for c in x)
               for x in records):
            raise ValueError("invalid supplied signer revocation fingerprint")
        revoked = frozenset(x.lower() for x in records)
        position = offset
        end = offset + size
        count = 0
        while position < end:
            ledger.consume("parser_iterations")
            count += 1
            if count > _MAX_SIGNATURES:
                raise UnsupportedSignature("too many certificate table records")
            if end - position < 8:
                raise SignatureFormatError("truncated WIN_CERTIFICATE header")
            length, revision, cert_type = struct.unpack("<IHH", source.read(position, 8))
            if length <= 8 or length > end - position:
                raise SignatureFormatError("invalid WIN_CERTIFICATE length")
            aligned = (length + 7) & ~7
            if aligned > end - position:
                raise SignatureFormatError("certificate alignment exceeds table")
            if any(source.read(position + length, aligned - length)):
                raise SignatureFormatError("nonzero certificate alignment padding")
            if revision != 0x200 or cert_type != 2:
                raise UnsupportedSignature("unsupported certificate revision or type")
            offset = position
            if length - 8 > _MAX_CMS:
                raise UnsupportedSignature("CMS size exceeds bounded capacity")
            result = _signature_fact(source.read(position + 8, length - 8), data, layout, ledger, revoked)
            facts["signatures"].append(result)
            if result["revoked"]:
                add("AUTH.REVOKED_SIGNER", EvidenceDomain.REPUTATION, "SIGNER_REVOCATION", "revoked_signer",
                    Severity.HIGH, "Signer certificate is revoked by the supplied verified offline bundle.",
                    "گواهی امضاکننده در بستهٔ آفلاین تأییدشده ابطال شده است.",
                    (("signer_sha256", result["signer_sha256"]),))
            if result["image_digest_valid"] and result["cms_signature_valid"]:
                add("AUTH.CRYPTO_INTEGRITY", EvidenceDomain.CONTEXT, "AUTHENTICODE", "signature_integrity",
                    Severity.INFO, "Authenticode image digest and CMS signature are cryptographically valid; signer trust is unverified.",
                    "چکیدهٔ تصویر و امضای رمزنگاری معتبرند؛ اعتماد به امضاکننده تأیید نشده است.",
                    (("signer_sha256", result["signer_sha256"]),))
            else:
                state = CoverageState.PARTIAL
                errors.append(ErrorCode.INTEGRITY_FAILURE)
                add("AUTH.INTEGRITY_FAILURE", EvidenceDomain.STRUCTURE, "SIGNATURE_INTEGRITY", "invalid_signature",
                    Severity.HIGH, "Authenticode image digest or CMS cryptographic signature is invalid.",
                    "چکیدهٔ تصویر یا امضای رمزنگاری فایل معتبر نیست.")
            if result["nested_signatures_present"]:
                facts["nested_signatures_unverified"] = True
            position += aligned
    except BudgetExceeded:
        state = CoverageState.SKIPPED_LIMIT
        errors.append(ErrorCode.ITERATION_BUDGET_EXHAUSTED)
    except UnsupportedSignature as exc:
        state = CoverageState.PARTIAL
        errors.append(ErrorCode.UNSUPPORTED_FORMAT)
        facts["authenticode_incomplete_reason"] = str(exc)
    except ImportError:
        state = CoverageState.UNAVAILABLE
        errors.append(ErrorCode.PARSER_UNAVAILABLE)
    except Exception as exc:
        state = CoverageState.PARTIAL
        code = ErrorCode.PARSER_DISAGREEMENT if "parsers disagree" in str(exc) else ErrorCode.MALFORMED_INPUT
        errors.append(code)
        facts["authenticode_incomplete_reason"] = type(exc).__name__
        try:
            add("AUTH.MALFORMED", EvidenceDomain.STRUCTURE, "SIGNATURE_INTEGRITY", "malformed_signature",
                Severity.MEDIUM, "The certificate table or Authenticode structure is malformed or ambiguous.",
                "ساختار گواهی یا امضای فایل خراب یا مبهم است.")
        except BudgetExceeded:
            state = CoverageState.SKIPPED_LIMIT
            errors.append(ErrorCode.ITERATION_BUDGET_EXHAUSTED)
    return StageResult("S2", state=state, evidence=tuple(evidence), facts=facts,
                       errors=tuple(dict.fromkeys(errors)), limitations=_LIMITATIONS)


__all__ = ["analyze"]
