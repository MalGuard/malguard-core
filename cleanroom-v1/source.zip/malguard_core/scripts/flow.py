"""Bounded lexical relationships for source that is never evaluated.

Only ordered, same-scope bindings and explicit call arguments supply lineage.
Unknown expressions do not inherit credential lineage. The token and nesting
limits fail through the shared work budget rather than silently claiming safety.
"""

from __future__ import annotations

from bisect import bisect_left, bisect_right
import base64
import binascii
from collections.abc import Mapping
from dataclasses import dataclass
import re

from malguard_core.budget import BudgetExceeded, BudgetLedger


_MAX_SOURCE = 2 * 1024 * 1024
_MAX_TOKENS = 65_536
_MAX_DEPTH = 64
_IDENTIFIER = re.compile(r"\$?[A-Za-z_]\w*(?:\s*\.\s*[A-Za-z_]\w*)*")
_QUOTED = r'''"(?:\\.|""|[^"\\])*"|'(?:\\.|''|[^'\\])*' '''.strip()
_TOKEN = re.compile(
    rf"{_QUOTED}|\$?[A-Za-z_]\w*(?:[ \t]*\.[ \t]*[A-Za-z_]\w*)*"
    r"|\r\n|\n|\r|<<=|>>=|[+*/%&|^-]=|\+\+|--|==|!=|<=|>=|[^\s]"
)
_LITERAL = re.compile(_QUOTED)
_STORE = re.compile(
    r"login\s+data|password_value|encrypted_value|logins\.json|key4\.db|wallet\.dat"
    r"|discord[^\r\n]{0,64}(?:token|leveldb)"
    r"|steam[^\r\n]{0,64}(?:ssfn|loginusers\.vdf)", re.IGNORECASE,
)
_WRITES = {"=", "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=", "<<=", ">>=", "++", "--"}
_READ = 1
_DECRYPTED = 2
_PATH = 3


def _charge(ledger: BudgetLedger | None, amount: int = 1) -> None:
    if ledger is not None:
        ledger.consume("parser_iterations", amount)


def _limit(ledger: BudgetLedger | None) -> None:
    if ledger is not None:
        ledger.consume("parser_iterations", ledger.remaining("parser_iterations") + 1)
    raise BudgetExceeded("parser_iterations", 1, 0)


@dataclass(frozen=True, slots=True)
class _Token:
    value: str
    start: int
    end: int
    literal: bool = False


def _tokens(text: str, code: str, ledger: BudgetLedger | None) -> list[_Token]:
    if len(text) != len(code) or len(code) > _MAX_SOURCE:
        _limit(ledger)
    _charge(ledger, max(1, len(code) // 32))
    visible: list[_Token] = []
    for match in _TOKEN.finditer(code):
        raw = match.group()
        value = re.sub(r"[ \t]", "", raw)
        _charge(ledger)
        if len(visible) >= _MAX_TOKENS:
            _limit(ledger)
        visible.append(_Token(value, match.start(), match.end()))
    literals: list[_Token] = []
    if text != code:
        _charge(ledger, max(1, len(text) // 32))
        for match in _LITERAL.finditer(text):
            _charge(ledger)
            if code[match.start():match.end()].strip():
                continue
            if len(visible) + len(literals) >= _MAX_TOKENS:
                _limit(ledger)
            raw = match.group()
            value = raw[1:-1].replace('""', '"').replace("''", "'")
            literals.append(_Token(value, match.start(), match.end(), True))
    # Each stream already follows source order. Merge them once, retaining
    # executable subexpressions even when they occur inside a quoted string.
    result: list[_Token] = []
    left = right = 0
    while left < len(visible) and right < len(literals):
        _charge(ledger)
        if visible[left].start < literals[right].start:
            result.append(visible[left])
            left += 1
        else:
            result.append(literals[right])
            right += 1
    result.extend(visible[left:])
    result.extend(literals[right:])
    return result


class SourceFlowIndex:
    """One reusable scope/write index; variable checks use binary searches."""

    def __init__(self, code: str, tokens: list[_Token], *, case_insensitive_variables: bool,
                 ledger: BudgetLedger | None, extension: str | None = None):
        self.code = code
        self.case_insensitive_variables = case_insensitive_variables
        self.tokens = tokens
        self.starts = [item.start for item in tokens]
        self.scopes: list[int] = []
        self.scope_offsets = [-1]
        self.scope_ids = [0]
        self.parents: dict[int, int | None] = {0: None}
        self.writes: dict[tuple[int, str], list[int]] = {}
        self.pairs: dict[int, int] = {}
        if extension is None:
            values = {token.value for token in tokens if not token.literal}
            lua_scope = bool(values.intersection({"local", "then", "repeat", "end"}))
            lua_scope = lua_scope or "function" in values and "{" not in values
            vb_scope = case_insensitive_variables and bool(
                re.search(r"\b(?:Sub|Function)\s+[A-Za-z_]", code, re.IGNORECASE))
        else:
            lua_scope = extension.casefold() == ".lua"
            vb_scope = extension.casefold() in {".vb", ".vbs"}
        keyword_openings = {"function", "if", "do", "repeat"} if lua_scope else {"sub", "function", "if"} if vb_scope else set()
        keyword_closings = {"end", "until"} if lua_scope else {"end"} if vb_scope else set()
        scope_stack = [0]
        delimiters: list[tuple[str, int]] = []
        next_scope = 0
        previous = ""
        for index, token in enumerate(tokens):
            _charge(ledger)
            value = token.value.casefold() if not token.literal else ""
            opening_scope = (value == "{" or value in keyword_openings) and previous != "end"
            closing_scope = value == "}" or value in keyword_closings
            if opening_scope:
                if len(scope_stack) >= _MAX_DEPTH:
                    _limit(ledger)
                next_scope += 1
                self.parents[next_scope] = scope_stack[-1]
                scope_stack.append(next_scope)
                self.scope_offsets.append(token.end if value == "{" else token.start)
                self.scope_ids.append(next_scope)
            self.scopes.append(scope_stack[-1])
            if closing_scope and len(scope_stack) > 1:
                scope_stack.pop()
                self.scope_offsets.append(token.end)
                self.scope_ids.append(scope_stack[-1])
            if not token.literal and value in {"(", "["}:
                if len(delimiters) >= _MAX_DEPTH:
                    _limit(ledger)
                delimiters.append((value, index))
            elif not token.literal and value in {")", "]"}:
                if delimiters and delimiters[-1][0] == ("(" if value == ")" else "["):
                    _, begin = delimiters.pop()
                    self.pairs[begin] = index
                    self.pairs[index] = begin
                else:
                    delimiters.clear()
            previous = value
        for index, token in enumerate(tokens):
            _charge(ledger)
            if token.literal:
                continue
            candidate = None
            if token.value in _WRITES:
                previous_index = index - 1
                if previous_index >= 0 and tokens[previous_index].value == "]":
                    previous_index = self.pairs.get(previous_index, 0) - 1
                if previous_index >= 0 and _IDENTIFIER.fullmatch(tokens[previous_index].value):
                    candidate = tokens[previous_index]
                elif token.value in {"++", "--"} and index + 1 < len(tokens):
                    candidate = tokens[index + 1]
            elif token.value.casefold() in {"ref", "out"} and index + 1 < len(tokens):
                candidate = tokens[index + 1]
            if candidate is not None and _IDENTIFIER.fullmatch(candidate.value):
                variable = self.canonical(candidate.value.split(".", 1)[0])
                self.writes.setdefault((self.scopes[index], variable), []).append(candidate.start)

    def canonical(self, variable: str) -> str:
        return variable.casefold() if self.case_insensitive_variables else variable

    def scope_at(self, position: int) -> int:
        return self.scope_ids[bisect_right(self.scope_offsets, position) - 1]

    def link(self, variable: str, producer_offset: int, consumer_offset: int) -> bool:
        """Consumer offset identifies the variable itself, not its enclosing call."""
        if producer_offset >= consumer_offset:
            return False
        consumer = bisect_left(self.starts, consumer_offset)
        if consumer >= len(self.tokens) or self.tokens[consumer].start != consumer_offset:
            return False
        name = self.canonical(variable)
        if self.canonical(self.tokens[consumer].value) != name:
            return False
        scope = self.scope_at(producer_offset)
        if scope != self.scope_at(consumer_offset):
            return False
        writes = self.writes.get((scope, name), ())
        next_write = bisect_right(writes, producer_offset)
        return next_write == len(writes) or writes[next_write] >= consumer_offset


def source_flow_index(code: str, *, case_insensitive_variables: bool = False,
                      ledger: BudgetLedger | None = None,
                      extension: str | None = None) -> SourceFlowIndex:
    tokens = _tokens(code, code, ledger)
    return SourceFlowIndex(code, tokens, case_insensitive_variables=case_insensitive_variables,
                           ledger=ledger, extension=extension)


def visible_flow_link(code: str, variable: str, producer_offset: int, consumer_offset: int,
                      *, case_insensitive_variables: bool = False,
                      ledger: BudgetLedger | None = None,
                      index: SourceFlowIndex | None = None,
                      extension: str | None = None) -> bool:
    if index is None:
        index = source_flow_index(code, case_insensitive_variables=case_insensitive_variables,
                                  ledger=ledger, extension=extension)
    return index.link(variable, producer_offset, consumer_offset)


class _CredentialParser:
    def __init__(self, index: SourceFlowIndex, ledger: BudgetLedger | None):
        self.index = index
        self.ledger = ledger
        self.bindings: dict[tuple[int, str], int] = {}
        self.credential = False
        self.sent = False

    def binding_scope(self, bindings: Mapping[tuple[int, str], object], scope: int,
                      name: str) -> int | None:
        """Resolve the closest lexical binding; a zero value still shadows."""
        current: int | None = scope
        while current is not None:
            _charge(self.ledger)
            if (current, name) in bindings:
                return current
            current = self.index.parents[current]
        return None

    def declared(self, begin: int, lhs: int) -> bool:
        tokens = self.index.tokens
        if lhs <= begin:
            return False
        preceding = tokens[lhs - 1].value.casefold()
        if preceding in {"var", "local", "string", "dim", "const", "]", ">"}:
            return True
        return bool(_IDENTIFIER.fullmatch(preceding) and preceding not in {
            "return", "await", "throw", "yield", "ref", "out",
        })

    def invalidate(self, variable: str, scope: int) -> None:
        name = self.index.canonical(variable)
        destination = self.binding_scope(self.bindings, scope, name)
        if destination is not None:
            self.bindings[(destination, name)] = 0

    def expression(self, begin: int, end: int, scope: int, depth: int = 0) -> int:
        if depth >= _MAX_DEPTH:
            _limit(self.ledger)
        tokens = self.index.tokens
        values = []
        cursor = begin
        while cursor < end:
            _charge(self.ledger)
            token = tokens[cursor]
            if token.value in {"\n", "\r", "\r\n"} and not token.literal:
                cursor += 1
                continue
            if token.literal:
                values.append(_PATH if _STORE.search(token.value) else 0)
                cursor += 1
                continue
            if _IDENTIFIER.fullmatch(token.value):
                if token.value.casefold() == "await":
                    cursor += 1
                    continue
                opening = cursor + 1
                closing = self.index.pairs.get(opening)
                if opening < end and tokens[opening].value == "(" and closing is not None and closing < end:
                    arguments = []
                    start = opening + 1
                    position = start
                    while position < closing:
                        _charge(self.ledger)
                        if tokens[position].value == ",":
                            arguments.append(self.expression(start, position, scope, depth + 1))
                            start = position + 1
                        elif tokens[position].value in {"(", "["} and position in self.index.pairs:
                            position = self.index.pairs[position]
                        position += 1
                    arguments.append(self.expression(start, closing, scope, depth + 1))
                    name = token.value.casefold()
                    parts = name.split(".")
                    result = 0
                    if len(parts) >= 2 and parts[-2] == "file" and parts[-1] in {"readallbytes", "readalltext", "openread"}:
                        if arguments and arguments[0] == _PATH:
                            result = _READ
                    elif (len(parts) >= 2 and parts[-2:] == ["protecteddata", "unprotect"]) or parts[-1] in {"cryptunprotectdata", "bcryptdecrypt", "ncryptdecrypt"}:
                        if arguments and arguments[0] == _READ:
                            result = _DECRYPTED
                            self.credential = True
                    elif parts[-1] in {"uploaddata", "uploadstring", "postasync", "postasjsonasync", "send"}:
                        if _DECRYPTED in arguments:
                            self.sent = True
                    values.append(result)
                    cursor = closing + 1
                    continue
                name = self.index.canonical(token.value)
                binding = self.binding_scope(self.bindings, scope, name)
                values.append(self.bindings.get((binding, name), 0) if binding is not None else 0)
            elif token.value == "(" and cursor in self.index.pairs and self.index.pairs[cursor] < end:
                closing = self.index.pairs[cursor]
                values.append(self.expression(cursor + 1, closing, scope, depth + 1))
                cursor = closing + 1
                continue
            else:
                values.append(0)
            cursor += 1
        return values[0] if len(values) == 1 else 0

    def statement(self, begin: int, end: int, scope: int) -> None:
        if begin >= end:
            return
        tokens = self.index.tokens
        assignments = [position for position in range(begin, end)
                       if not tokens[position].literal and tokens[position].value in _WRITES]
        _charge(self.ledger, end - begin)
        by_reference = [tokens[position + 1].value.split(".", 1)[0]
                        for position in range(begin, end - 1)
                        if not tokens[position].literal
                        and tokens[position].value.casefold() in {"ref", "out"}]
        if len(assignments) == 1:
            assignment = assignments[0]
            if tokens[assignment].value == "=" and assignment > begin:
                lhs = tokens[assignment - 1]
                if _IDENTIFIER.fullmatch(lhs.value) and "." not in lhs.value:
                    value = self.expression(assignment + 1, end, scope)
                    name = self.index.canonical(lhs.value)
                    destination = None if self.declared(begin, assignment - 1) else self.binding_scope(self.bindings, scope, name)
                    self.bindings[(scope if destination is None else destination, name)] = value
                    for variable in by_reference:
                        self.invalidate(variable, scope)
                    return
        self.expression(begin, end, scope)
        # Unsupported writes and by-reference arguments terminate known lineage.
        for position in range(begin, end):
            token = tokens[position]
            if token.literal:
                continue
            if token.value in _WRITES:
                candidate = position - 1
                if candidate >= begin and tokens[candidate].value == "]":
                    candidate = self.index.pairs.get(candidate, begin) - 1
                if candidate < begin and position + 1 < end:
                    candidate = position + 1
            elif token.value.casefold() in {"ref", "out"}:
                candidate = position + 1
            else:
                continue
            if begin <= candidate < end:
                name = tokens[candidate].value.split(".", 1)[0]
                self.invalidate(name, scope)

    def run(self) -> tuple[bool, bool]:
        start = 0
        current_scope = 0
        depth = 0
        for position, token in enumerate(self.index.tokens):
            scope = self.index.scopes[position]
            if not token.literal and token.value in {"(", "["}:
                depth += 1
            elif not token.literal and token.value in {")", "]"}:
                depth = max(0, depth - 1)
            boundary = (not token.literal and (token.value.casefold() in {
                ";", "{", "}", "end", "until",
            } or depth == 0 and token.value in {"\n", "\r", "\r\n"}))
            if scope != current_scope:
                self.statement(start, position, current_scope)
                start = position
                current_scope = scope
            if boundary:
                self.statement(start, position, current_scope)
                start = position + 1
        self.statement(start, len(self.index.tokens), current_scope)
        return self.credential, self.sent


def credential_flow(text: str, code: str, *, case_insensitive_variables: bool = False,
                    ledger: BudgetLedger | None = None,
                    extension: str | None = None) -> tuple[bool, bool]:
    """Find explicit ordered credential read/decrypt/upload relationships."""
    tokens = _tokens(text, code, ledger)
    index = SourceFlowIndex(code, tokens, case_insensitive_variables=case_insensitive_variables,
                            ledger=ledger, extension=extension)
    return _CredentialParser(index, ledger).run()


@dataclass(frozen=True, slots=True)
class _DecodedBody:
    text: str
    decoded: bool


class _DecodedParser(_CredentialParser):
    def __init__(self, index: SourceFlowIndex, ledger: BudgetLedger | None,
                 *, plaintext: bool = False):
        super().__init__(index, ledger)
        self.constants: dict[tuple[int, str], _DecodedBody | None] = {}
        self.sources: list[str] = []
        self.executions: list[tuple[str, bool]] = []
        self.seen: dict[str, int] = {}
        self.plaintext = plaintext
        self.decoded_count = 0
        self.decoded_bytes = 0

    def literal(self, value: str) -> _DecodedBody | None:
        """Resolve ordinary quoted Lua escapes without evaluating expressions."""
        if "\\" not in value:
            return _DecodedBody(value, False)
        escapes = {"a": "\a", "b": "\b", "f": "\f", "n": "\n", "r": "\r",
                   "t": "\t", "v": "\v", "\\": "\\", "\"": "\"", "'": "'"}
        parts = []
        cursor = 0
        while cursor < len(value):
            _charge(self.ledger)
            if value[cursor] != "\\":
                parts.append(value[cursor])
                cursor += 1
                continue
            cursor += 1
            if cursor >= len(value):
                return None
            escaped = value[cursor]
            if escaped in escapes:
                parts.append(escapes[escaped])
                cursor += 1
                continue
            numeric = re.match(r"[0-9]{1,3}", value[cursor:cursor + 3])
            hexadecimal = re.match(r"x[0-9a-fA-F]{2}", value[cursor:cursor + 3])
            if numeric or hexadecimal:
                match = numeric if numeric is not None else hexadecimal
                assert match is not None
                token = match.group()
                number = int(token[1:], 16) if token.startswith("x") else int(token)
                if number > 127:
                    return None
                parts.append(chr(number))
                cursor += len(token)
                continue
            return None
        return _DecodedBody("".join(parts), False)

    def executed(self, body: _DecodedBody | None) -> None:
        if body is None or not body.decoded and not self.plaintext:
            return
        if body.text in self.seen:
            position = self.seen[body.text]
            previous_text, previous_decoded = self.executions[position]
            if previous_decoded and not body.decoded:
                self.executions[position] = (previous_text, False)
            return
        if len(self.executions) >= 16:
            _limit(self.ledger)
        if not body.decoded:
            if self.decoded_count >= 16:
                _limit(self.ledger)
            size = len(body.text.encode("utf-8"))
            if self.ledger is not None:
                self.ledger.consume_many({"decoded_candidates": 1, "decoded_bytes": size})
            self.decoded_count += 1
            self.decoded_bytes += size
            if self.decoded_bytes > 128 * 1024:
                _limit(self.ledger)
        self.seen[body.text] = len(self.executions)
        self.executions.append((body.text, body.decoded))
        if body.decoded:
            self.sources.append(body.text)

    def decode(self, name: str, argument: _DecodedBody | None) -> _DecodedBody | None:
        if argument is None or len(argument.text) > 65_536:
            return None
        if self.decoded_count >= 16:
            _limit(self.ledger)
        if self.ledger is not None:
            self.ledger.consume("decoded_candidates")
        self.decoded_count += 1
        try:
            if name in {"base64.decode", "mime.unb64"}:
                data = base64.b64decode(argument.text, validate=True)
            else:
                data = bytes.fromhex(argument.text)
            if self.ledger is not None:
                self.ledger.consume("decoded_bytes", len(data))
            self.decoded_bytes += len(data)
            if self.decoded_bytes > 128 * 1024:
                _limit(self.ledger)
            return _DecodedBody(data.decode("utf-8-sig"), True)
        except (ValueError, binascii.Error, UnicodeError):
            return None

    def value(self, begin: int, end: int, scope: int, depth: int = 0) -> _DecodedBody | None:
        if depth >= _MAX_DEPTH:
            _limit(self.ledger)
        tokens = self.index.tokens
        values: list[_DecodedBody | None] = []
        cursor = begin
        while cursor < end:
            _charge(self.ledger)
            token = tokens[cursor]
            if not token.literal and token.value in {"\n", "\r", "\r\n"}:
                cursor += 1
                continue
            if token.literal:
                values.append(self.literal(token.value))
            elif _IDENTIFIER.fullmatch(token.value):
                opening = cursor + 1
                closing = self.index.pairs.get(opening)
                if opening < end and tokens[opening].value == "(" and closing is not None and closing < end:
                    arguments = []
                    start = opening + 1
                    position = start
                    while position < closing:
                        _charge(self.ledger)
                        if tokens[position].value == ",":
                            arguments.append(self.value(start, position, scope, depth + 1))
                            start = position + 1
                        elif tokens[position].value in {"(", "["} and position in self.index.pairs:
                            position = self.index.pairs[position]
                        position += 1
                    arguments.append(self.value(start, closing, scope, depth + 1))
                    name = token.value.casefold()
                    result = None
                    if name in {"base64.decode", "mime.unb64", "hex.decode"}:
                        result = self.decode(name, arguments[0] if arguments else None)
                    elif name in {"load", "loadstring"} and arguments:
                        self.executed(arguments[0])
                    values.append(result)
                    cursor = closing + 1
                    continue
                name = self.index.canonical(token.value)
                binding = self.binding_scope(self.constants, scope, name)
                values.append(self.constants.get((binding, name)) if binding is not None else None)
            elif token.value == "(" and cursor in self.index.pairs and self.index.pairs[cursor] < end:
                closing = self.index.pairs[cursor]
                values.append(self.value(cursor + 1, closing, scope, depth + 1))
                cursor = closing + 1
                continue
            else:
                values.append(None)
            cursor += 1
        return values[0] if len(values) == 1 else None

    def statement(self, begin: int, end: int, scope: int) -> None:
        if begin >= end:
            return
        tokens = self.index.tokens
        assignments = [position for position in range(begin, end)
                       if not tokens[position].literal and tokens[position].value in _WRITES]
        _charge(self.ledger, end - begin)
        if len(assignments) == 1:
            position = assignments[0]
            if tokens[position].value == "=" and position > begin:
                lhs = tokens[position - 1]
                if _IDENTIFIER.fullmatch(lhs.value) and "." not in lhs.value:
                    name = self.index.canonical(lhs.value)
                    destination = None if self.declared(begin, position - 1) else self.binding_scope(self.constants, scope, name)
                    self.constants[(scope if destination is None else destination, name)] = self.value(position + 1, end, scope)
                    return
        self.value(begin, end, scope)
        for position in assignments:
            candidate = position - 1
            if candidate >= begin and tokens[candidate].value == "]":
                candidate = self.index.pairs.get(candidate, begin) - 1
            if candidate < begin and position + 1 < end:
                candidate = position + 1
            if begin <= candidate < end:
                name = self.index.canonical(tokens[candidate].value)
                binding = self.binding_scope(self.constants, scope, name)
                if binding is not None:
                    self.constants[(binding, name)] = None


def decoded_execution_sources(text: str, code: str, extension: str, *,
                              ledger: BudgetLedger | None = None) -> tuple[str, ...]:
    """Only an explicit Lua decoder-to-interpreter argument becomes source.

    This small grammar models base64.decode, mime.unb64 and hex.decode. Other
    decoder APIs and languages require the caller's incomplete/opacity fallback.
    Ordinary encoded literals and unrelated decoded heap strings remain data.
    """
    if extension.casefold() != ".lua":
        return ()
    tokens = _tokens(text, code, ledger)
    index = SourceFlowIndex(code, tokens, case_insensitive_variables=False, ledger=ledger,
                            extension=extension)
    parser = _DecodedParser(index, ledger)
    parser.run()
    return tuple(parser.sources)


def execution_sources(text: str, code: str, extension: str, *,
                      ledger: BudgetLedger | None = None) -> tuple[tuple[str, bool], ...]:
    """Collect explicit quoted/decoded Lua bodies passed to an interpreter.

    Each body is returned once with its decoded provenance. Plaintext sources
    share the candidate and byte caps with decoder work; unknown expressions,
    long-bracket strings and other languages require the caller's fallback.
    """
    if extension.casefold() != ".lua":
        return ()
    tokens = _tokens(text, code, ledger)
    index = SourceFlowIndex(code, tokens, case_insensitive_variables=False, ledger=ledger,
                            extension=extension)
    parser = _DecodedParser(index, ledger, plaintext=True)
    parser.run()
    return tuple(parser.executions)


__all__ = ["credential_flow", "source_flow_index", "visible_flow_link", "SourceFlowIndex",
           "decoded_execution_sources", "execution_sources"]
