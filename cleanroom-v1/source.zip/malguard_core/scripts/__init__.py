"""Bounded source recognizers with comment removal and visible data-flow checks.

These recognizers do not compile, import, evaluate, or execute source. They model
simple lexical call chains and retain an explicit limitation for complex flows.
"""

from __future__ import annotations

import base64
import binascii
import re
from dataclasses import dataclass
from pathlib import PurePath
from typing import Any

from malguard_core.budget import BudgetExceeded, BudgetLedger
from malguard_core.gta_context import identify_target_context
from malguard_core.model import (
    CoverageState, EvidenceDomain, EvidenceLocation, Severity, StageResult, make_evidence,
)
from .flow import (
    credential_flow as _credential_flow, execution_sources, source_flow_index,
)


_SOURCE_EXTENSIONS = {".lua", ".cs", ".vb", ".ps1", ".psm1", ".bat", ".cmd", ".vbs", ".ini", ".xml", ".cfg"}
_CALL = re.compile(r"\b([A-Za-z_][\w.]*)\s*\(")
_CONCAT = re.compile(r"([\"'])([^\"'\r\n]{0,4096})\1\s*(?:\.\.|\+|&)\s*([\"'])([^\"'\r\n]{0,4096})\3")
_CHAR_CALL = re.compile(r"\b(?:string\.char|String\.fromCharCode|ChrW?|chr)\s*\(\s*([0-9xXa-fA-F,\s]{1,8192})\s*\)", re.IGNORECASE)
_STORE = re.compile(r"(?:login\s+data|password_value|encrypted_value|logins\.json|key4\.db|wallet\.dat|discord[^\r\n]{0,64}(?:token|leveldb)|steam[^\r\n]{0,64}(?:ssfn|loginusers\.vdf))", re.IGNORECASE)
_MAX_SOURCE_BYTES = 2 * 1024 * 1024
_MAX_DECODED_SOURCE_BYTES = 128 * 1024
_DYNAMIC_SINK = re.compile(r"\b(?:load|loadstring|Assembly\.Load|Invoke-Expression|iex|ExecuteGlobal|Execute)\b|\b_G\s*\[", re.IGNORECASE)
_SOURCE_DECODER = re.compile(r"\b((?:[A-Za-z_]\w*\.)*(?:decode|decrypt|unb64|frombase64string|fromhexstring|char))\s*\(", re.IGNORECASE)
_LUA_EVAL = re.compile(r"\b(?:load|loadstring)\s*\(")


def _calls(code: str) -> set[str]:
    names: set[str] = set()
    for match in _CALL.finditer(code):
        parts = match.group(1).lower().split(".")
        names.update(".".join(parts[-count:]) for count in range(1, min(3, len(parts)) + 1))
    return names


def _literal_value(expression: str) -> str | None:
    """Resolve a deliberately small constant expression grammar."""
    char_match = _CHAR_CALL.fullmatch(expression.strip())
    if char_match:
        values = [value.strip() for value in char_match.group(1).split(",")]
        if len(values) > 1024:
            return None
        try:
            numbers = [int(value, 16 if value.lower().startswith("0x") else 10) for value in values]
        except ValueError:
            return None
        if any(number < 0 or number > 255 for number in numbers):
            return None
        return bytes(numbers).decode("latin-1")
    parts = re.findall(r"([\"'])([^\"'\r\n]{0,4096})\1", expression)
    remainder = re.sub(r"([\"'])([^\"'\r\n]{0,4096})\1", "", expression)
    if parts and not re.sub(r"\s|\.\.|\+|&", "", remainder):
        return "".join(value for _, value in parts)
    return None


def _dynamic_variables(text: str, code: str) -> set[str]:
    variables = set()
    for match in re.finditer(r"\b(?:load|loadstring)\s*\(\s*([A-Za-z_]\w*)\s*\)", code, re.IGNORECASE):
        variables.add(match.group(1))
    for match in re.finditer(r"\b_G\s*\[([^\]\r\n]{1,8192})\]\s*\(\s*([A-Za-z_]\w*)\s*\)", text, re.IGNORECASE):
        if code[match.start():match.start() + 2].lower() != "_g":
            continue
        value = _literal_value(match.group(1))
        if value and value.lower() in {"load", "loadstring"}:
            variables.add(match.group(2))
    return variables


@dataclass(frozen=True, slots=True)
class LexicalSource:
    text: str
    code: str
    literals: tuple[str, ...]
    malformed: bool
    unsupported_dynamic: bool = False


def _mask_declarations(code: str, extension: str, ledger: BudgetLedger) -> str:
    """Mask proven signatures, preserving bodies and all source offsets.

    A declaration names a capability but is not a use of it. Ambiguous syntax
    remains visible; this bounded recognizer never compiles scanned source.
    """
    if extension not in {".cs", ".vb", ".vbs", ".lua"}:
        return code
    output = list(code)
    for match in _CALL.finditer(code):
        ledger.consume("parser_iterations")
        if extension == ".cs" and match.group(1) in {
            "if", "while", "for", "foreach", "switch", "using", "lock", "catch",
            "fixed", "checked", "unchecked", "sizeof", "typeof", "default", "nameof",
        }:
            continue
        prefix_limit = max(0, match.start() - 512)
        begin = max(code.rfind(char, prefix_limit, match.start()) for char in ";{}\r\n") + 1
        if begin < prefix_limit:
            continue
        prefix = code[begin:match.start()]
        ledger.consume("parser_iterations", len(prefix))
        if len(prefix) > 512:
            continue
        declaration = False
        if extension == ".lua":
            declaration = bool(re.search(r"\bfunction\s*$", prefix))
        elif extension in {".vb", ".vbs"}:
            declaration = bool(re.search(r"\b(?:Sub|Function)\s*$", prefix, re.IGNORECASE))
        elif "." not in match.group(1):
            typed = re.fullmatch(
                r"\s*(?:\[[^\]\r\n]{0,512}\]\s*)*(?:(?:public|private|protected|internal|static|extern|virtual|override|abstract|async|sealed|new|unsafe|partial)\s+)*"
                r"(?:[A-Za-z_][\w?.<>,\[\]]*\s+)?", prefix,
            )
            forbidden = re.search(r"\b(?:return|throw|await|new|yield|case)\s*$", prefix)
            declaration = bool(typed and not forbidden)
        if not declaration:
            continue
        position = match.end()
        depth = 1
        while position < len(code) and position - match.end() <= 8192 and depth:
            ledger.consume("parser_iterations")
            if code[position] == "(":
                depth += 1
            elif code[position] == ")":
                depth -= 1
            if depth > 64:
                break
            position += 1
        if depth:
            continue
        if extension == ".cs":
            tail = code[position:position + 128].lstrip()
            typed_prefix = bool(prefix.strip())
            if not (tail.startswith(("{", "=>")) or (typed_prefix and tail.startswith(";"))):
                continue
        for index in range(match.start(), position):
            if code[index] not in "\r\n":
                output[index] = " "
    return "".join(output)


def _mask_echo_operands(text: str, code: str, ledger: BudgetLedger) -> str:
    """CMD echo operands are data until a visible unescaped command separator."""
    output = list(code)
    for match in re.finditer(r"(?im)^[ \t]*@?echo(?:[ .(]|$)", code):
        position = match.end()
        quoted = False
        while position < len(code) and code[position] not in "\r\n":
            ledger.consume("parser_iterations")
            char = text[position]
            if char == "^" and position + 1 < len(code) and text[position + 1] not in "\r\n":
                output[position] = output[position + 1] = " "
                position += 2
                continue
            if char == '"':
                quoted = not quoted
            if not quoted and char in "&|<>":
                break
            output[position] = " "
            position += 1
    return "".join(output)


def lex_source(text: str, extension: str, ledger: BudgetLedger) -> LexicalSource:
    """Remove comments and mask string contents while preserving source offsets."""
    clean = list(text)
    code = list(text)
    literals = []
    position = 0
    length = len(text)
    malformed = False
    unsupported_dynamic = False
    while position < length:
        ledger.consume("parser_iterations")
        char = text[position]
        # Lua long strings/comments use a bounded delimiter; all nesting is linear.
        if extension == ".lua" and (text.startswith("--[", position) or char == "["):
            prefix = position + (2 if text.startswith("--", position) else 0)
            opening = re.match(r"\[(={0,16})\[", text[prefix:prefix + 20])
            if opening:
                closing = "]" + opening.group(1) + "]"
                begin = prefix + len(opening.group(0))
                end = text.find(closing, begin)
                if end < 0:
                    end = length
                    malformed = True
                    after = end
                else:
                    after = end + len(closing)
                ledger.consume("parser_iterations", max(1, (after - position) // 32))
                if prefix != position:
                    for index in range(position, after):
                        if text[index] not in "\r\n":
                            clean[index] = code[index] = " "
                else:
                    literals.append(text[begin:end])
                    for index in range(position, after):
                        if text[index] not in "\r\n":
                            code[index] = " "
                position = after
                continue
        line_comment = (
            (extension == ".lua" and text.startswith("--", position))
            or (extension in {".cs", ".cfg", ".ini"} and text.startswith("//", position))
            or (extension in {".ps1", ".psm1"} and char == "#")
            or (extension in {".vb", ".vbs"} and char == "'")
            or (extension in {".vb", ".vbs"} and (position == 0 or text[position - 1] in "\r\n:") and re.match(r"[ \t]*REM\b", text[position:], re.IGNORECASE))
            or (extension == ".ini" and (position == 0 or text[position - 1] in "\r\n") and re.match(r"[ \t]*[;#]", text[position:]))
            or (extension == ".cfg" and (position == 0 or text[position - 1] in "\r\n") and re.match(r"[ \t]*#", text[position:]))
            or (extension in {".bat", ".cmd"} and (position == 0 or text[position - 1] in "\r\n&|") and re.match(r"[ \t]*(?:@?rem\b|::)", text[position:], re.IGNORECASE))
        )
        block_open = "/*" if extension in {".cs", ".cfg"} else "<#" if extension in {".ps1", ".psm1"} else "<!--" if extension == ".xml" else ""
        if line_comment:
            end = text.find("\n", position)
            if end < 0:
                end = length
            ledger.consume("parser_iterations", max(1, (end - position) // 32))
            for index in range(position, end):
                if text[index] != "\r":
                    clean[index] = code[index] = " "
            position = end
            continue
        if block_open and text.startswith(block_open, position):
            closing = {"/*": "*/", "<#": "#>", "<!--": "-->"}[block_open]
            end = text.find(closing, position + len(block_open))
            if end < 0:
                malformed = True
                end = length
            else:
                end += len(closing)
            ledger.consume("parser_iterations", max(1, (end - position) // 32))
            for index in range(position, end):
                if text[index] not in "\r\n":
                    clean[index] = code[index] = " "
            position = end
            continue
        if char in {"\"", "'"}:
            quote = char
            start = position
            position += 1
            parts = []
            closed = False
            while position < length:
                ledger.consume("parser_iterations")
                current = text[position]
                if current == quote:
                    if position + 1 < length and text[position + 1] == quote and extension in {".vb", ".vbs"}:
                        parts.append(quote)
                        position += 2
                        continue
                    position += 1
                    closed = True
                    break
                if current == "\\" and position + 1 < length and extension not in {".vb", ".vbs", ".bat", ".cmd"}:
                    following = text[position + 1]
                    if following in {"\\", "\"", "'"}:
                        parts.append(following)
                        position += 2
                        continue
                parts.append(current)
                position += 1
            if not closed:
                malformed = True
            literal = "".join(parts)
            literals.append(literal)
            if extension in {".ps1", ".psm1"} and quote == '"' and re.search(r"(?<!`)(?:``)*\$\(", literal):
                unsupported_dynamic = True
            if extension in {".cs", ".vb"} and "$" in text[max(0, start - 2):start]:
                if "{" in literal.replace("{{", "") or "}" in literal.replace("}}", ""):
                    unsupported_dynamic = True
            for index in range(start, position):
                if text[index] not in "\r\n":
                    code[index] = " "
            continue
        position += 1
    code_text = _mask_declarations("".join(code), extension, ledger)
    if extension in {".bat", ".cmd"}:
        code_text = _mask_echo_operands(text, code_text, ledger)
    return LexicalSource("".join(clean), code_text, tuple(literals), malformed, unsupported_dynamic)


def reconstruct_constants(text: str, ledger: BudgetLedger) -> tuple[str, ...]:
    """Fold fixed concatenations and constant character calls without evaluation."""
    candidates = []
    folded = text
    for _ in range(8):
        matches = list(_CONCAT.finditer(folded))
        if not matches:
            break
        pieces = []
        cursor = 0
        for match in matches:
            ledger.consume("decoded_candidates")
            value = match.group(2) + match.group(4)
            ledger.consume("decoded_bytes", len(value.encode("utf-8")))
            pieces.append(folded[cursor:match.start()])
            pieces.append('"' + value + '"')
            candidates.append(value)
            cursor = match.end()
        pieces.append(folded[cursor:])
        folded = "".join(pieces)
    for match in _CHAR_CALL.finditer(text):
        values = [value.strip() for value in match.group(1).split(",")]
        if len(values) > 1024:
            continue
        try:
            numbers = [int(value, 16 if value.lower().startswith("0x") else 10) for value in values]
            if any(number < 0 or number > 255 for number in numbers):
                continue
            ledger.consume("decoded_candidates")
            ledger.consume("decoded_bytes", len(numbers))
            candidates.append(bytes(numbers).decode("latin-1"))
        except ValueError:
            continue
    return tuple(dict.fromkeys(candidates))


def _decode_source(data: bytes) -> tuple[str, bool]:
    if data.startswith((b"\xff\xfe", b"\xfe\xff")):
        try:
            return data.decode("utf-16"), False
        except UnicodeError:
            return data.decode("utf-16", errors="replace"), True
    if len(data) >= 8 and data[1::2].count(0) > len(data) // 4:
        try:
            return data.decode("utf-16-le"), False
        except UnicodeError:
            return data.decode("utf-16-le", errors="replace"), True
    try:
        return data.decode("utf-8-sig"), False
    except UnicodeError:
        return data.decode("latin-1"), b"\x00" in data


def analyze(data: bytes, artifact_id: str, logical_path: str, ledger: BudgetLedger,
            strings: tuple = ()) -> StageResult:
    evidence = []
    facts: dict[str, Any] = {"capabilities": [], "unresolved_loader": False}
    extension = PurePath(logical_path).suffix.lower()
    if extension not in _SOURCE_EXTENSIONS:
        extension = ".lua" if b"function" in data and b"end" in data else ".ps1"
    try:
        ledger.consume("parser_iterations", max(1, len(data) // 128))
        if data.startswith((b"\x1bLua", b"\x1bLJ")):
            ledger.consume("evidence")
            evidence.append(make_evidence(
                "scripts.bytecode.unsupported", "S5", EvidenceDomain.OPACITY, "OBFUSCATION", "BYTECODE", Severity.MEDIUM,
                EvidenceLocation(artifact_id, offset=0, length=min(4, len(data))),
                "Lua bytecode is recognized, but source-level control flow cannot be completed by this analyzer.",
                "بایت‌کد Lua شناسایی شد، ولی تحلیل جریان کنترل در سطح منبع کامل نمی‌شود.",
                confidence=1.0, reliability=1.0,
            ))
            return StageResult("S5", CoverageState.PARTIAL, tuple(evidence), facts,
                               limitations=("Lua/LuaJIT bytecode requires a dedicated bounded bytecode parser; raw analysis remains active.",))
        source_limited = len(data) > _MAX_SOURCE_BYTES
        source, encoding_problem = _decode_source(data[:_MAX_SOURCE_BYTES])
        lexical = lex_source(source, extension, ledger)
        constants: tuple[str, ...] = ()
        literal_text = "\n".join(lexical.literals)
        functions = _calls(lexical.code)
        facts["capabilities"] = sorted(functions)[:1024]
        any_remote_memory = False
        all_remote_gta = True
        target_processes: set[str] = set()
        facts.update(gta_only=False, classification_tags=[], target_processes=[])
        decode_limited = False
        unmodeled_dynamic_source = False
        candidate_semantics_incomplete = lexical.unsupported_dynamic
        has_source_decoder = False
        # Decode only an explicit interpreter argument here; generic string decoding
        # belongs to S0 and must not turn a data literal into executable source.
        encoded_commands = re.compile(r"\b(?:powershell|pwsh)(?:\.exe)?\b[^\r\n&|;]{0,512}?-(?:enc|encodedcommand)\s+([A-Za-z0-9+/=]{8,65536})(?![A-Za-z0-9+/=])", re.IGNORECASE)
        saw_encoded_command = False
        facts["encoded_command_decoded"] = True
        def source_candidates():
            nonlocal decode_limited, unmodeled_dynamic_source, saw_encoded_command
            # Yield ordinary source before attempting any optional decoding. A
            # decoding failure must retain already collected behavioral evidence.
            yield lexical, False, extension
            interpreter_candidates = 0
            interpreter_bytes = 0
            for encoded_match in encoded_commands.finditer(lexical.text):
                if not re.match(r"(?:powershell|pwsh)", lexical.code[encoded_match.start():encoded_match.start() + 16], re.IGNORECASE):
                    continue
                saw_encoded_command = True
                if interpreter_candidates >= 16:
                    decode_limited = True
                    break
                interpreter_candidates += 1
                ledger.consume("decoded_candidates")
                try:
                    decoded = base64.b64decode(encoded_match.group(1), validate=True)
                    ledger.consume("decoded_bytes", len(decoded))
                    decoded_text = decoded.decode("utf-16-le")
                    interpreter_bytes += len(decoded)
                    if interpreter_bytes > _MAX_DECODED_SOURCE_BYTES:
                        decode_limited = True
                        break
                    yield lex_source(decoded_text, ".ps1", ledger), True, ".ps1"
                except (binascii.Error, UnicodeError):
                    facts["unresolved_loader"] = True
                    facts["encoded_command_decoded"] = False
            decoder_calls = tuple(_SOURCE_DECODER.finditer(lexical.code))
            lua_sinks = tuple(_LUA_EVAL.finditer(lexical.code)) if extension == ".lua" else ()
            if lua_sinks or (decoder_calls and _DYNAMIC_SINK.search(lexical.code)):
                explicit_sources = execution_sources(
                    lexical.text, lexical.code, extension, ledger=ledger,
                )
                # Every visible decoder must be accounted for; a successful
                # candidate cannot conceal a second unresolved decoding path.
                unmodeled_dynamic_source |= len(explicit_sources) < max(len(decoder_calls), len(lua_sinks))
                for explicit_source, was_decoded in explicit_sources:
                    yield lex_source(explicit_source, extension, ledger), was_decoded, extension
        findings: dict[str, tuple[EvidenceDomain, str, Severity, str, str, float, bool]] = {}

        def find(rule: str, domain: EvidenceDomain, family: str, severity: Severity,
                 en: str, fa: str, confidence: float = .95, decoded: bool = False) -> None:
            previous = findings.get(rule)
            if previous is None or (previous[-1] and not decoded):
                findings[rule] = (domain, family, severity, en, fa, confidence, decoded)
                ledger.consume("evidence")
                evidence.append(make_evidence(
                    rule, "S5", domain, family, "SOURCE_CALL_CHAIN", severity,
                    EvidenceLocation(artifact_id, detail="Comment-stripped source calls and literal relationships"),
                    en, fa, confidence=confidence, reliability=.60 if decoded else .95,
                    attributes=(("decoded", decoded),),
                ))

        for candidate, is_decoded, candidate_extension in source_candidates():
            candidate_semantics_incomplete |= candidate.malformed or candidate.unsupported_dynamic
            has_source_decoder |= bool(_SOURCE_DECODER.search(candidate.code))
            if candidate is not lexical and (
                (candidate_extension == ".lua" and _LUA_EVAL.search(candidate.code))
                or (_SOURCE_DECODER.search(candidate.code) and _DYNAMIC_SINK.search(candidate.code))
            ):
                # This stage models one explicit layer. Further dynamic layers
                # retain ordinary evidence but cannot receive complete coverage.
                unmodeled_dynamic_source = True
            text = candidate.text
            code = candidate.code
            names = _calls(code)
            insensitive_variables = candidate_extension in {".vb", ".vbs", ".ps1", ".psm1", ".bat", ".cmd"}
            candidate_remote_memory = bool(names.intersection({"writeprocessmemory", "readprocessmemory"}))
            candidate_context = identify_target_context(text, candidate_remote_memory, code,
                                                         case_insensitive_variables=insensitive_variables)
            target_processes.update(candidate_context.targets)
            if candidate_remote_memory:
                any_remote_memory = True
                all_remote_gta &= candidate_context.gta_only
            facts["gta_only"] = any_remote_memory and all_remote_gta
            facts["classification_tags"] = ["HACKTOOL_PUA"] if facts["gta_only"] else []
            facts["target_processes"] = sorted(target_processes)
            flow = source_flow_index(code, case_insensitive_variables=insensitive_variables, ledger=ledger, extension=candidate_extension)
            literals = "\n".join(candidate.literals)
            has_fetch = bool(names.intersection({"performhttprequest", "http.get", "https.get", "http.request", "downloadstring", "downloaddata", "webclient.downloadstring", "webclient.downloaddata", "client.downloadstring", "client.downloaddata"})) or bool(re.search(r"\b(?:Invoke-WebRequest|Invoke-RestMethod|iwr|irm|DownloadString|DownloadData)\b", code, re.IGNORECASE))
            dynamic_variables = _dynamic_variables(text, code)
            dynamic = bool(dynamic_variables) or bool(names.intersection({"load", "loadstring", "execute", "executeglobal"})) or bool(re.search(r"\b(?:Invoke-Expression|iex|ExecuteGlobal|Execute)\b", code, re.IGNORECASE))
            linked_remote = False
            # Lua request callbacks explicitly bind the response parameter.
            callback = re.compile(r"\bPerformHttpRequest\s*\([^\r\n]{0,512}?\bfunction\s*\(\s*\w+\s*,\s*(\w+)\s*(?:,|\))", re.IGNORECASE)
            for match in callback.finditer(code):
                variable = match.group(1)
                for sink in re.finditer(r"\b(?:load|loadstring)\s*\(\s*([A-Za-z_]\w*)\s*\)", code):
                    if flow.link(variable, match.start(1), sink.start(1)):
                        linked_remote = True
                for sink in re.finditer(r"\b_G\s*\[[^\]\r\n]{1,8192}\]\s*\(\s*([A-Za-z_]\w*)\s*\)", text):
                    if variable in dynamic_variables and flow.link(variable, match.start(1), sink.start(1)):
                        linked_remote = True
            fetched_variables: list[tuple[str, int]] = []
            for match in re.finditer(r"(?:\blocal\s+|\bvar\s+|\bstring\s+|\bbyte\[\]\s+)?(\$?[A-Za-z_]\w*)\s*=\s*([^\r\n;]{1,512})", code):
                if re.search(r"(?:http(?:s)?\.get|DownloadString|DownloadData|Invoke-WebRequest|Invoke-RestMethod|\biwr\b|\birm\b)", match.group(2), re.IGNORECASE):
                    fetched_variables.append((match.group(1), match.start(1)))
            for variable, producer in fetched_variables:
                for sink in re.finditer(r"\b(?:load|loadstring|Assembly\.Load)\s*\(\s*(\$?[A-Za-z_]\w*)\s*\)|\b(?:iex|Invoke-Expression)\s+(\$?[A-Za-z_]\w*)\b", code, re.IGNORECASE):
                    group = 1 if sink.group(1) is not None else 2
                    if flow.link(variable, producer, sink.start(group)):
                        linked_remote = True
            if re.search(r"(?:DownloadString|Invoke-WebRequest|Invoke-RestMethod|\biwr\b|\birm\b)[^\r\n]{0,512}\|\s*(?:iex|Invoke-Expression)\b", code, re.IGNORECASE):
                linked_remote = True
            if dynamic and re.search(r"\b(?:Execute|ExecuteGlobal)\b[^\r\n]{0,128}\.ResponseText\b", code, re.IGNORECASE):
                linked_remote = True
            if has_fetch and dynamic and linked_remote:
                find("scripts.remote_fetch_execute", EvidenceDomain.HARM, "REMOTE_CODE_EXECUTION", Severity.CRITICAL,
                     "A fetched response is visibly passed into a dynamic-code execution sink.",
                     "پاسخ دریافت‌شده از شبکه به‌صورت آشکار به اجرای کد پویا داده می‌شود.", .98, is_decoded)
                facts["unresolved_loader"] = True
            elif has_fetch and dynamic:
                find("scripts.unresolved_fetch_execute", EvidenceDomain.OPACITY, "OBFUSCATION", Severity.HIGH,
                     "Network fetching and dynamic-code evaluation occur together, but their data relationship is unresolved.",
                     "دریافت شبکه و ارزیابی کد پویا هم‌زمان دیده شد، اما رابطهٔ دادهٔ آن‌ها روشن نیست.", .85, is_decoded)
                facts["unresolved_loader"] = True
            read = bool(names.intersection({"file.readallbytes", "file.readalltext", "file.openread", "io.open", "readfile", "sqlite3_exec", "sqlite3_prepare_v2"}))
            decrypt = bool(names.intersection({"protecteddata.unprotect", "cryptunprotectdata", "bcryptdecrypt", "ncryptdecrypt"}))
            stores = bool(_STORE.search(literals + "\n" + literal_text))
            credential_flow, outbound_flow = _credential_flow(text, code, case_insensitive_variables=insensitive_variables, ledger=ledger, extension=candidate_extension)
            sensitive = stores and read and decrypt and credential_flow
            if sensitive:
                find("scripts.credential.read_decrypt", EvidenceDomain.HARM, "CREDENTIAL_ACCESS", Severity.CRITICAL,
                     "Credential-specific paths or fields occur with source calls to read and decrypt protected data.",
                     "مسیر یا فیلد مشخص اعتبارنامه همراه با فراخوانی خواندن و رمزگشایی دادهٔ محافظت‌شده دیده شد.", .96, is_decoded)
            outbound = bool(names.intersection({"uploadstring", "uploaddata", "postasjsonasync", "postasync", "http.post", "send", "smtpsend"}))
            if sensitive and outbound and outbound_flow:
                find("scripts.exfil.credential_send", EvidenceDomain.HARM, "EXFILTRATION", Severity.CRITICAL,
                     "Credential collection co-occurs with an explicit outbound upload or POST call.",
                     "جمع‌آوری اعتبارنامه همراه با فراخوانی صریح بارگذاری یا POST به بیرون دیده شد.", .95, is_decoded)
            source_injection = {"openprocess", "writeprocessmemory", "createremotethread"}.issubset(names) and "virtualallocex" in names
            if source_injection:
                find("scripts.injection.chain", EvidenceDomain.HARM, "PROCESS_INJECTION", Severity.CRITICAL,
                     "Source calls combine remote-process opening, allocation, memory writing, and remote thread execution.",
                     "فراخوانی‌های منبع، باز کردن فرایند دیگر، تخصیص و نوشتن حافظه و اجرای نخ از راه دور را ترکیب می‌کنند.", .96, is_decoded)
            elif {"openprocess", "writeprocessmemory"}.issubset(names) and not candidate_context.gta_only:
                find("scripts.remote_memory.unknown_scope", EvidenceDomain.HARM, "PROCESS_INJECTION", Severity.HIGH,
                     "Source calls write another process's memory without proving an exclusive GTA target.",
                     "فراخوانی‌های منبع حافظهٔ فرایند دیگر را می‌نویسند و محدود بودن هدف به GTA اثبات نشده است.", .95, is_decoded)
            persistence = bool(re.search(r"\bschtasks(?:\.exe)?\b[^\r\n]{0,256}/create|\b(?:Register-ScheduledTask|New-Service)\b", code, re.IGNORECASE)) or bool(re.search(r"CurrentVersion[\\/]Run(?:Once)?\b", literals, re.IGNORECASE) and re.search(r"\b(?:Set-ItemProperty|New-ItemProperty|RegSetValueEx|SetValue|reg\s+add)\b", code, re.IGNORECASE))
            if persistence:
                find("scripts.persistence.install", EvidenceDomain.HARM, "PERSISTENCE", Severity.CRITICAL,
                     "Executable script syntax installs an autorun, scheduled task, or service.",
                     "دستورهای قابل تحلیل اسکریپت، اجرای خودکار، وظیفهٔ زمان‌بندی‌شده یا سرویس نصب می‌کنند.", .96, is_decoded)
            if re.search(r"\bSet-MpPreference\b[^\r\n]{0,256}-DisableRealtimeMonitoring\s+(?:\$true\b|1\b)|\b(?:Set-MpPreference|Add-MpPreference)\b[^\r\n]{0,256}-(?:ExclusionPath|ExclusionProcess)\b|\bsc(?:\.exe)?\s+(?:stop|delete)\s+(?:WinDefend|WdNisSvc)\b", code, re.IGNORECASE):
                find("scripts.security_tampering", EvidenceDomain.HARM, "SECURITY_TAMPERING", Severity.CRITICAL,
                     "The script disables or excludes security monitoring, or stops a security service.",
                     "اسکریپت نظارت امنیتی را غیرفعال یا مستثنا می‌کند، یا سرویس امنیتی را متوقف می‌کند.", .98, is_decoded)
            if re.search(r"\b(?:vssadmin(?:\.exe)?\s+delete\s+shadows|format\s+[a-z]:|Remove-Item\b[^\r\n]{0,128}-Recurse[^\r\n]{0,128}-Force)", code, re.IGNORECASE):
                find("scripts.destructive.command", EvidenceDomain.HARM, "DESTRUCTIVE_BEHAVIOR", Severity.HIGH,
                     "The script contains a recovery-deletion, volume-format, or forceful recursive deletion command.",
                     "اسکریپت دستور حذف بازیابی، قالب‌بندی حجم یا حذف اجباری بازگشتی دارد.", .9, is_decoded)
            if re.search(r"\bAssembly\.Load\s*\(", code, re.IGNORECASE) and bool(names.intersection({"assembly.getmanifestresourcestream", "getmanifestresourcestream", "convert.frombase64string", "client.downloaddata", "webclient.downloaddata"})):
                if re.search(r"\b(?:Invoke|CreateInstance|GetMethod)\s*\(", code, re.IGNORECASE):
                    find("scripts.memory_loader", EvidenceDomain.HARM, "LOADER_IN_MEMORY_EXECUTION", Severity.CRITICAL,
                         "Byte decoding or resource/network access feeds an assembly load with reflective invocation markers.",
                         "رمزگشایی بایت یا دسترسی منبع یا شبکه همراه با بارگذاری اسمبلی و نشانگر فراخوانی بازتابی دیده شد.", .95, is_decoded)
                    facts["unresolved_loader"] = True
            if names.intersection({"os.execute", "io.popen"}) and re.search(r"\b(?:powershell|pwsh|cmd|wscript|cscript)(?:\.exe)?\b", literals, re.IGNORECASE):
                find("scripts.interpreter_chain", EvidenceDomain.OPACITY, "OBFUSCATION", Severity.MEDIUM,
                     "A Lua script launches another command interpreter; the child command requires separate static analysis.",
                     "اسکریپت Lua مفسر دستور دیگری را فراخوانی می‌کند؛ دستور فرزند به تحلیل ایستای جداگانه نیاز دارد.", .9, is_decoded)
                facts["unresolved_loader"] = True
            if names.intersection({"io.open"}) and re.search(r"\b(?:write|writeline)\s*\(", code, re.IGNORECASE) and re.search(r"(?:fxmanifest\.lua|__resource\.lua|[\\/]resources[\\/])", literals, re.IGNORECASE) and dynamic:
                find("scripts.resource_reinjection", EvidenceDomain.HARM, "REMOTE_CODE_EXECUTION", Severity.HIGH,
                     "Dynamic-code activity is paired with writes targeting other Lua resource manifests.",
                     "کد پویا همراه با نوشتن در مانیفست منابع Lua دیگر دیده شد.", .9, is_decoded)
        constants = reconstruct_constants(lexical.text, ledger)
        if constants:
            find("scripts.opacity.constant_reconstruction", EvidenceDomain.OPACITY, "STRING_ENCRYPTION", Severity.LOW,
                 "Fixed concatenations or character arrays reconstruct strings; this finding alone is low severity.",
                 "رشته‌ها با اتصال ثابت یا آرایهٔ نویسه بازسازی می‌شوند؛ این قرینه به‌تنهایی کم‌خطر است.", .8)
        if saw_encoded_command:
            find("scripts.opacity.encoded_command", EvidenceDomain.OPACITY, "OBFUSCATION", Severity.MEDIUM,
                 "An encoded PowerShell interpreter argument was statically decoded where valid.",
                 "آرگومان رمزگذاری‌شدهٔ PowerShell در صورت معتبر بودن به‌صورت ایستا رمزگشایی شد.", 1.0)
        if unmodeled_dynamic_source:
            if has_source_decoder:
                find("scripts.opacity.unresolved_decoding", EvidenceDomain.OPACITY, "STRING_ENCRYPTION", Severity.MEDIUM,
                     "Visible decoding and dynamic evaluation require a data relationship that the bounded source model cannot resolve.",
                     "رمزگشایی و ارزیابی پویا دیده شد، ولی رابطهٔ دادهٔ آن‌ها در مدل محدود منبع روشن نیست.", .95)
            else:
                find("scripts.opacity.unresolved_dynamic_source", EvidenceDomain.OPACITY, "OBFUSCATION", Severity.MEDIUM,
                     "A dynamic interpreter input cannot be fully reconstructed by the bounded source model.",
                     "ورودی مفسر پویا در مدل محدود تحلیل منبع به‌طور کامل قابل بازسازی نیست.", .95)
            facts["unresolved_loader"] = True
        incomplete = candidate_semantics_incomplete or encoding_problem or source_limited or decode_limited or unmodeled_dynamic_source or bool(saw_encoded_command and not facts.get("encoded_command_decoded"))
        facts["source_semantics_incomplete"] = candidate_semantics_incomplete or unmodeled_dynamic_source
        facts["decoded_source_limited"] = decode_limited
        facts["source_bytes_analyzed"] = min(len(data), _MAX_SOURCE_BYTES)
        facts["source_limited"] = source_limited
        return StageResult("S5", CoverageState.PARTIAL if incomplete else CoverageState.COMPLETE,
                           tuple(evidence), facts, limitations=(
                               "Source analysis recognizes bounded lexical call chains; aliases, complex control flow, dynamic reflection, and unsupported encodings can conceal behavior.",
                           ))
    except BudgetExceeded as exc:
        return StageResult("S5", CoverageState.SKIPPED_LIMIT, tuple(evidence), facts,
                           errors=(exc.error_code,), limitations=(f"Script work budget exhausted: {exc.resource}.",))


__all__ = ["analyze", "lex_source", "reconstruct_constants"]
