"""Bounded PE structure analysis with independent parser comparison.

Only admitted bytes are parsed. No Windows loader or entry point is invoked.
The internal validator deliberately rejects ambiguous RVA mappings and files
that would demand unbounded work before the third-party parser sees them.
"""

from __future__ import annotations

import base64
import hashlib
import math
import struct
from collections import Counter
from dataclasses import dataclass

from malguard_core.budget import BudgetExceeded, BudgetLedger
from malguard_core.intake import BoundedByteSource
from malguard_core.model import (
    CoverageState, ErrorCode, EvidenceDomain, EvidenceLocation, Severity,
    StageResult, make_evidence,
)


class PEFormatError(ValueError):
    """The supplied bytes do not have a unique, bounded PE interpretation."""


@dataclass(frozen=True, slots=True)
class Section:
    name: str
    virtual_address: int
    virtual_size: int
    raw_offset: int
    raw_size: int
    flags: int


@dataclass(frozen=True, slots=True)
class PELayout:
    source: BoundedByteSource
    ledger: BudgetLedger
    nt_offset: int
    optional_offset: int
    machine: int
    architecture: str
    is_dll: bool
    is_64: bool
    timestamp: int
    entry_rva: int
    image_base: int
    size_headers: int
    size_image: int
    sections: tuple[Section, ...]
    directories: tuple[tuple[int, int], ...]

    def rva(self, address: int, size: int = 1) -> int:
        if address < 0 or size < 0 or address > 0xFFFFFFFF - size:
            raise PEFormatError("RVA arithmetic overflow")
        matches = []
        if address < self.size_headers and size <= self.size_headers - address:
            matches.append(address)
        for section in self.sections:
            self.ledger.consume("parser_iterations")
            relative = address - section.virtual_address
            if relative >= 0 and relative <= section.raw_size and size <= section.raw_size - relative:
                matches.append(section.raw_offset + relative)
        if len(matches) != 1:
            raise PEFormatError("RVA is unmapped or ambiguous")
        offset = matches[0]
        if offset > self.source.size or size > self.source.size - offset:
            raise PEFormatError("RVA resolves outside file")
        return offset

    def directory(self, number: int) -> tuple[int, int]:
        return self.directories[number] if number < len(self.directories) else (0, 0)

    def cstring(self, address: int, maximum: int = 512) -> str:
        offset = self.rva(address)
        collected = bytearray()
        for index in range(maximum):
            self.ledger.consume("parser_iterations")
            byte = self.source.read(self.rva(address + index), 1)[0]
            if byte == 0:
                try:
                    return collected.decode("ascii")
                except UnicodeDecodeError as exc:
                    raise PEFormatError("non-ASCII PE symbol") from exc
            collected.append(byte)
        raise PEFormatError(f"unterminated PE symbol at {offset}")


def _u16(source: BoundedByteSource, offset: int) -> int:
    return struct.unpack("<H", source.read(offset, 2))[0]


def _u32(source: BoundedByteSource, offset: int) -> int:
    return struct.unpack("<I", source.read(offset, 4))[0]


def _recover_section_count(source: BoundedByteSource, table: int, headers: int, ledger: BudgetLedger) -> int:
    """Recognize existing section rows followed by zero-filled header padding.

    This is evidence recovery, never a replacement loader interpretation. A
    damaged count is not used to allocate or iterate. Every recovered row is
    subsequently subject to the ordinary mapping and directory checks.
    """
    capacity = min(96, (headers - table) // 40)
    count = 0
    for index in range(capacity):
        ledger.consume("parser_iterations")
        record = source.read(table + index * 40, 40)
        if not any(record):
            break
        name = record[:8].rstrip(b"\x00")
        virtual_size, virtual_address, raw_size = struct.unpack_from("<III", record, 8)
        if not name or any(byte < 32 or byte > 126 for byte in name) or not virtual_address or not (virtual_size or raw_size):
            raise PEFormatError("section-count recovery has an unsupported table row")
        count += 1
    if not count:
        raise PEFormatError("section-count recovery found no supported rows")
    # Nonzero bytes after the recognized contiguous table make the extent
    # ambiguous; do not infer nonexistent rows or consume adjacent data.
    padding = headers - table - count * 40
    ledger.consume("parser_iterations", max(1, max(0, padding) // 64))
    if padding < 0 or any(any(chunk) for chunk in source.iter_chunks(offset=table + count * 40, length=padding)):
        raise PEFormatError("section-count recovery has ambiguous header padding")
    return count


def _validate_at(data: bytes, ledger: BudgetLedger, *, nt_override: int | None = None, recovery: bool = False) -> PELayout:
    source = BoundedByteSource(data, ledger, per_read_limit=1024 * 1024)
    try:
        if source.size < 64 or not recovery and source.read(0, 2) != b"MZ":
            raise PEFormatError("missing complete DOS header")
        nt = _u32(source, 60) if nt_override is None else nt_override
        if nt < 64 or nt > source.size - 24 or not recovery and source.read(nt, 4) != b"PE\x00\x00":
            raise PEFormatError("invalid NT header offset or signature")
        machine, count, timestamp, _, _, opt_size, flags = struct.unpack("<HHIIIHH", source.read(nt + 4, 20))
        damaged_count = count == 0 or count > 96
        if damaged_count and not recovery:
            raise PEFormatError("section count outside supported loader bounds")
        ledger.consume("parser_iterations", 1 if damaged_count else count)
        optional = nt + 24
        if opt_size > source.size - optional:
            raise PEFormatError("truncated optional header")
        magic = _u16(source, optional)
        is_64 = magic == 0x20B
        minimum = 112 if is_64 else 96
        if magic not in (0x10B, 0x20B) or opt_size < minimum:
            raise PEFormatError("unsupported optional header")
        architectures = {0x14C: "x86", 0x8664: "x64", 0xAA64: "arm64", 0x1C4: "arm32"}
        architecture = architectures.get(machine, f"machine-{machine:04x}")
        if machine == 0x14C and is_64 or machine in (0x8664, 0xAA64) and not is_64:
            raise PEFormatError("machine and optional header disagree")
        entry = _u32(source, optional + 16)
        image_base = struct.unpack("<Q" if is_64 else "<I", source.read(optional + (24 if is_64 else 28), 8 if is_64 else 4))[0]
        section_alignment = _u32(source, optional + 32)
        file_alignment = _u32(source, optional + 36)
        size_image, size_headers = struct.unpack("<II", source.read(optional + 56, 8))
        if not section_alignment or not file_alignment or file_alignment & (file_alignment - 1):
            raise PEFormatError("invalid PE alignment")
        if section_alignment < file_alignment or section_alignment < 4096 and section_alignment != file_alignment:
            raise PEFormatError("inconsistent file/section alignment")
        if section_alignment >= 4096 and not 512 <= file_alignment <= 65536:
            raise PEFormatError("file alignment outside loader bounds")
        if size_headers > source.size or size_headers < optional + opt_size + 40:
            raise PEFormatError("invalid SizeOfHeaders")
        if damaged_count:
            count = _recover_section_count(source, optional + opt_size, size_headers, ledger)
        if size_headers < optional + opt_size + count * 40:
            raise PEFormatError("invalid SizeOfHeaders")
        if size_image < size_headers:
            raise PEFormatError("invalid SizeOfImage")
        if size_headers % file_alignment or size_image % section_alignment:
            raise PEFormatError("unaligned image or header size")
        ndirs = _u32(source, optional + (108 if is_64 else 92))
        if ndirs > 16 or minimum + ndirs * 8 > opt_size:
            raise PEFormatError("invalid data-directory count")
        directories = tuple(struct.unpack("<II", source.read(optional + minimum + number * 8, 8)) for number in range(ndirs))
        sections = []
        raw_ranges = []
        virtual_ranges = []
        for number in range(count):
            record = source.read(optional + opt_size + number * 40, 40)
            name = record[:8].rstrip(b"\x00").decode("ascii", "replace")
            virtual_size, virtual_address, raw_size, raw_offset = struct.unpack_from("<IIII", record, 8)
            section_flags = struct.unpack_from("<I", record, 36)[0]
            if virtual_address % section_alignment or raw_size and (raw_offset % file_alignment or raw_size % file_alignment):
                raise PEFormatError("unaligned section mapping")
            if raw_size and (raw_offset < size_headers or raw_offset > source.size or raw_size > source.size - raw_offset):
                raise PEFormatError("section raw data exceeds file or overlaps headers")
            span = max(virtual_size, raw_size)
            if virtual_address > 0xFFFFFFFF - span or virtual_address + span > size_image:
                raise PEFormatError("section virtual range exceeds image")
            if span and virtual_address < size_headers:
                raise PEFormatError("section virtual range overlaps headers")
            if raw_size:
                raw_ranges.append((raw_offset, raw_offset + raw_size))
            if span:
                virtual_ranges.append((virtual_address, virtual_address + span))
            sections.append(Section(name, virtual_address, virtual_size, raw_offset, raw_size, section_flags))
        for ranges in (raw_ranges, virtual_ranges):
            ranges.sort()
            if any(second[0] < first[1] for first, second in zip(ranges, ranges[1:], strict=False)):
                raise PEFormatError("overlapping section ranges")
        layout = PELayout(source, ledger, nt, optional, machine, architecture, bool(flags & 0x2000), is_64, timestamp, entry, image_base, size_headers, size_image, tuple(sections), directories)
        for number, (address, size) in enumerate(directories):
            ledger.consume("parser_iterations")
            if bool(address) != bool(size):
                raise PEFormatError("inconsistent directory address and size")
            if not address:
                continue
            if number == 4:
                if address % 8 or address > source.size or size > source.size - address:
                    raise PEFormatError("invalid certificate table range")
            else:
                layout.rva(address, size)
        if entry:
            layout.rva(entry)
        return layout
    except (struct.error, IndexError, ValueError) as exc:
        if isinstance(exc, PEFormatError):
            raise
        raise PEFormatError(str(exc)) from exc


def validate(data: bytes, ledger: BudgetLedger, *, recovery: bool = False) -> PELayout:
    """Validate unique bounds, optionally recovering damaged header locators.

    Recovery never changes the admitted bytes. It permits damaged signatures,
    a damaged DOS NT pointer, and an unusable section count only when existing
    rows, alignments, RVA mappings and every directory remain consistent. The
    caller must report recovered analysis as malformed and incomplete.
    """
    if not recovery:
        return _validate_at(data, ledger)
    candidates: dict[int, PELayout] = {}
    pointed = None
    if len(data) >= 64:
        source = BoundedByteSource(data, ledger, per_read_limit=1024 * 1024, _charge_file_bytes=False)
        pointed = _u32(source, 60)
        try:
            candidates[pointed] = _validate_at(data, ledger, recovery=True)
        except PEFormatError:
            pass
        # A bounded prefix search recovers only full NT signatures. Corrupted
        # NT signatures can be recovered at the explicit DOS pointer only.
        prefix_size = min(source.size, 1024 * 1024)
        ledger.consume("parser_iterations", max(1, prefix_size // 64))
        prefix = source.read(0, prefix_size)
        start = 64
        examined = 0
        while (offset := prefix.find(b"PE\x00\x00", start)) >= 0:
            ledger.consume("parser_iterations")
            examined += 1
            if examined > 32:
                raise PEFormatError("NT recovery candidate count exceeds supported bounds")
            start = offset + 4
            if offset == pointed:
                continue
            try:
                candidates[offset] = _validate_at(data, ledger, nt_override=offset, recovery=True)
            except PEFormatError:
                continue
    if len(candidates) != 1:
        raise PEFormatError("PE recovery has no unique consistent header interpretation")
    return next(iter(candidates.values()))


def is_pe_candidate(data: bytes, ledger: BudgetLedger) -> bool:
    """Recognize bounded PE header evidence without trusting structure validity.

    MZ alone is insufficient. A complete NT/optional header is required, or a
    unique strictly mapped recovery layout when signatures/locators failed.
    Malformed recognized candidates must still enter the normal child pipeline.
    """
    source = BoundedByteSource(data, ledger, per_read_limit=1024 * 1024, _charge_file_bytes=False)
    if source.size < 64:
        return False
    try:
        has_mz = source.read(0, 2) == b"MZ"
        nt = _u32(source, 60)
        if has_mz:
            if 64 <= nt <= source.size - 26 and source.read(nt, 4) == b"PE\x00\x00":
                optional_size = _u16(source, nt + 20)
                magic = _u16(source, nt + 24)
                minimum = 112 if magic == 0x20B else 96
                if magic in (0x10B, 0x20B) and minimum <= optional_size <= source.size - nt - 24:
                    return True
        if not has_mz and not (64 <= nt <= source.size - 26 and _u16(source, nt + 24) in (0x10B, 0x20B)):
            return False
        validate(data, ledger, recovery=True)
        return True
    except PEFormatError:
        return False


def _imports(layout: PELayout) -> tuple[list[str], list[dict]]:
    capabilities: set[str] = set()
    records: list[dict] = []
    for directory_index, delayed in ((1, False), (13, True)):
        address, size = layout.directory(directory_index)
        if not address:
            continue
        width = 32 if delayed else 20
        if size < width or size // width > 4096:
            raise PEFormatError("invalid import descriptor count")
        terminated = False
        for number in range(size // width):
            layout.ledger.consume("parser_iterations")
            descriptor = layout.source.read(layout.rva(address + number * width, width), width)
            fields = struct.unpack("<8I" if delayed else "<5I", descriptor)
            if not any(fields):
                terminated = True
                break
            if delayed:
                if fields[0] != 1:
                    raise PEFormatError("unsupported delay-import VA addressing")
                name_rva, thunk_rva = fields[1], fields[4] or fields[3]
            else:
                thunk_rva, name_rva = fields[0] or fields[4], fields[3]
            dll = layout.cstring(name_rva).lower()
            if not dll or not thunk_rva:
                raise PEFormatError("incomplete import descriptor")
            thunk_size = 8 if layout.is_64 else 4
            ordinal_flag = 1 << (thunk_size * 8 - 1)
            for index in range(8192):
                layout.ledger.consume("parser_iterations")
                thunk = int.from_bytes(layout.source.read(layout.rva(thunk_rva + index * thunk_size, thunk_size), thunk_size), "little")
                if not thunk:
                    break
                if len(records) >= 16384:
                    raise PEFormatError("excessive import symbols")
                if thunk & ordinal_flag:
                    name = f"ordinal:{thunk & 0xFFFF}"
                else:
                    layout.rva(thunk, 2)
                    name = layout.cstring(thunk + 2)
                normalized = name[:-1] if len(name) > 1 and name[-1] in "AW" and name[-2].islower() else name
                capabilities.add(normalized)
                records.append({"dll": dll, "name": name, "normalized": normalized, "delayed": delayed})
            else:
                raise PEFormatError("unterminated import thunk array")
        if not terminated:
            raise PEFormatError("unterminated import descriptors")
    return sorted(capabilities), records


def _exports(layout: PELayout) -> tuple[list[str], list[dict]]:
    address, size = layout.directory(0)
    if not address:
        return [], []
    if size < 40:
        raise PEFormatError("truncated export directory")
    fields = struct.unpack("<IIHHIIIIIII", layout.source.read(layout.rva(address, 40), 40))
    functions, names, function_rva, name_rva, ordinal_rva = fields[6:11]
    if functions > 8192 or names > functions:
        raise PEFormatError("invalid export count")
    layout.rva(function_rva, functions * 4)
    layout.rva(name_rva, names * 4)
    layout.rva(ordinal_rva, names * 2)
    exported = []
    forwarded = []
    for index in range(names):
        layout.ledger.consume("parser_iterations")
        pointer = _u32(layout.source, layout.rva(name_rva + index * 4, 4))
        ordinal = _u16(layout.source, layout.rva(ordinal_rva + index * 2, 2))
        if ordinal >= functions:
            raise PEFormatError("export ordinal exceeds table")
        name = layout.cstring(pointer)
        exported.append(name)
        target = _u32(layout.source, layout.rva(function_rva + ordinal * 4, 4))
        if address <= target < address + size:
            forwarded.append({"name": name, "target": layout.cstring(target)})
        elif target:
            layout.rva(target)
    return sorted(exported), sorted(forwarded, key=lambda item: item["name"])


def _resources(layout: PELayout, results: list[dict] | None = None, on_resource=None) -> list[dict]:
    root, size = layout.directory(2)
    results = [] if results is None else results
    if not root:
        return results
    visited: set[int] = set()
    captured = 0

    def visit(relative: int, path: tuple[str, ...], depth: int) -> None:
        nonlocal captured
        if depth > 8 or relative in visited or relative > size - 16:
            raise PEFormatError("cyclic or excessive resource directory")
        visited.add(relative)
        layout.ledger.consume("resource_entries")
        record = layout.source.read(layout.rva(root + relative, 16), 16)
        count = sum(struct.unpack_from("<HH", record, 12))
        if count > 4096 or count * 8 > size - relative - 16:
            raise PEFormatError("resource entries exceed directory bounds")
        for index in range(count):
            layout.ledger.consume("resource_entries")
            name, target = struct.unpack("<II", layout.source.read(layout.rva(root + relative + 16 + index * 8, 8), 8))
            if name & 0x80000000:
                name_offset = name & 0x7FFFFFFF
                if name_offset > size - 2:
                    raise PEFormatError("resource name outside directory")
                length = _u16(layout.source, layout.rva(root + name_offset, 2))
                if length > 512 or length * 2 > size - name_offset - 2:
                    raise PEFormatError("invalid resource name length")
                label = layout.source.read(layout.rva(root + name_offset + 2, length * 2), length * 2).decode("utf-16le", "replace")
            else:
                label = str(name)
            child_path = (*path, label)
            offset = target & 0x7FFFFFFF
            if target & 0x80000000:
                visit(offset, child_path, depth + 1)
                continue
            if offset > size - 16:
                raise PEFormatError("resource data descriptor outside directory")
            data_rva, length, codepage, _ = struct.unpack("<IIII", layout.source.read(layout.rva(root + offset, 16), 16))
            file_offset = layout.rva(data_rva, length)
            if length > 1024 * 1024 or captured + length > 4 * 1024 * 1024:
                raise BudgetExceeded("resource_entries", 1, 0)
            blob = layout.source.read(file_offset, length)
            captured += length
            resource = {"name": "/".join(child_path), "offset": file_offset, "size": length, "codepage": codepage, "data_b64": base64.b64encode(blob).decode("ascii"), "sha256": hashlib.sha256(blob).hexdigest()}
            results.append(resource)
            if on_resource is not None:
                on_resource(resource, blob)

    visit(0, (), 0)
    return results


def _carve_embedded(layout: PELayout, resources: list[dict], results: list[dict], emit) -> None:
    """Carve bounded recognized PE candidates from sections and overlays.

    Resource ranges already have child records. Candidates are never loaded;
    malformed candidates are captured too, so corrupting a child header cannot
    make its payload disappear. Every appended record survives later failures.
    """
    excluded = [(resource["offset"], resource["offset"] + resource["size"]) for resource in resources]
    source = layout.source
    cursor = layout.size_headers
    previous = b""
    examined = 0
    nt_examined = 0
    captured = 0
    captured_ranges: list[tuple[int, int]] = []
    seen_offsets: set[int] = set()
    for chunk in source.iter_chunks(chunk_size=65536, offset=cursor):
        layout.ledger.consume("parser_iterations", max(1, len(chunk) // 64))
        searchable = previous + chunk
        base = cursor - len(previous)
        candidates: set[int] = set()
        for signature in (b"MZ", b"PE\x00\x00"):
            start = 0
            while (found := searchable.find(signature, start)) >= 0:
                start = found + len(signature)
                position = base + found
                if any(begin <= position < end for begin, end in (*excluded, *captured_ranges)):
                    continue
                if signature == b"MZ":
                    candidates.add(position)
                    continue
                nt_examined += 1
                if nt_examined > 32:
                    raise BudgetExceeded("resource_entries", 1, 0)
                # A damaged DOS signature remains recognizable through its
                # existing NT-pointer field. Examine a bounded lookback rather
                # than guessing a fixed DOS-stub length or changing any bytes.
                for origin in range(max(layout.size_headers, position - 4096), position - 63):
                    layout.ledger.consume("parser_iterations")
                    if _u32(source, origin + 60) == position - origin:
                        candidates.add(origin)
        for offset in sorted(candidates):
            if any(begin <= offset < end for begin, end in (*excluded, *captured_ranges)):
                continue
            if offset in seen_offsets:
                continue
            seen_offsets.add(offset)
            layout.ledger.consume("parser_iterations")
            examined += 1
            if examined > 32:
                raise BudgetExceeded("resource_entries", 1, 0)
            available = source.size - offset
            length = min(available, 1024 * 1024)
            blob = source.read(offset, length)
            if not is_pe_candidate(blob, layout.ledger):
                continue
            layout.ledger.consume("resource_entries")
            structure = "MALFORMED"
            try:
                child_layout = validate(blob, layout.ledger)
                end = max([child_layout.size_headers, *(section.raw_offset + section.raw_size for section in child_layout.sections)])
                cert, cert_size = child_layout.directory(4)
                if cert:
                    end = max(end, cert + cert_size)
                length = end
                blob = blob[:length]
                structure = "VALID"
            except PEFormatError:
                pass
            if captured + length > 4 * 1024 * 1024:
                raise BudgetExceeded("resource_entries", 1, 0)
            captured += length
            record = {"offset": offset, "size": length, "data_b64": base64.b64encode(blob).decode("ascii"), "type": "pe", "structure_status": structure, "truncated": available > 1024 * 1024 and structure != "VALID"}
            results.append(record)
            captured_ranges.append((offset, offset + length if structure == "VALID" else offset + 2))
            emit("PE.CARVED", "EMBEDDED_PAYLOAD", "embedded_pe", Severity.HIGH, "Recognized PE headers occur inside mapped data or an overlay; the child is analyzed independently and execution is not assumed.", "سرآیندهای قابل شناسایی PE در دادهٔ نگاشت‌شده یا پیوست قرار دارند؛ فرزند جداگانه تحلیل می‌شود و اجرای آن فرض نمی‌شود.", offset)
            if record["truncated"]:
                raise BudgetExceeded("resource_entries", 1, 0)
        previous = chunk[-3:]
        cursor += len(chunk)


def _tls(layout: PELayout) -> list[int]:
    address, size = layout.directory(9)
    if not address:
        return []
    width = 8 if layout.is_64 else 4
    required = 40 if layout.is_64 else 24
    if size < required:
        raise PEFormatError("truncated TLS directory")
    record = layout.source.read(layout.rva(address, required), required)
    callbacks = int.from_bytes(record[width * 3:width * 4], "little")
    if not callbacks:
        return []
    if callbacks < layout.image_base or callbacks - layout.image_base > 0xFFFFFFFF:
        raise PEFormatError("invalid TLS callback array VA")
    callback_rva = callbacks - layout.image_base
    results: list[int] = []
    for index in range(256):
        layout.ledger.consume("parser_iterations")
        target = int.from_bytes(layout.source.read(layout.rva(callback_rva + index * width, width), width), "little")
        if not target:
            return results
        if target < layout.image_base or target - layout.image_base > 0xFFFFFFFF:
            raise PEFormatError("invalid TLS callback VA")
        layout.rva(target - layout.image_base)
        results.append(target - layout.image_base)
    raise PEFormatError("unterminated TLS callbacks")


def _entropy(blob: bytes) -> float:
    if not blob:
        return 0.0
    return -sum((count / len(blob)) * math.log2(count / len(blob)) for count in Counter(blob).values())


def analyze(data: bytes, artifact_id: str, logical_path: str, ledger: BudgetLedger, revoked_signers: tuple[str, ...] = ()) -> StageResult:
    """Produce PE facts and opacity/structure evidence, never a verdict."""
    evidence = []
    errors = []
    limitations = []
    facts: dict = {"structure_status": "MALFORMED", "imports": [], "import_records": [], "exports": [], "forwarded_exports": [], "resources": [], "embedded_artifacts": [], "parser_disagreement": False}
    state = CoverageState.COMPLETE

    def emit(rule: str, family: str, kind: str, severity: Severity, en: str, fa: str, offset: int | None = None, domain: EvidenceDomain = EvidenceDomain.OPACITY, confidence: float = 1.0) -> None:
        ledger.consume("evidence")
        evidence.append(make_evidence(rule, "S2", domain, family, kind, severity, EvidenceLocation(artifact_id, offset=offset), en, fa, confidence=confidence))

    try:
        recovered = False
        try:
            layout = validate(data, ledger)
        except PEFormatError:
            layout = validate(data, ledger, recovery=True)
            recovered = True
            state = CoverageState.PARTIAL
            errors.append(ErrorCode.MALFORMED_INPUT)
            limitations.append("Bounded PE facts were recovered after malformed header fields; original bytes remain unchanged.")
            emit("PE.RECOVERY", "PARSER_EVASION", "header_recovery", Severity.MEDIUM, "Consistent bounded mappings recover static facts despite damaged PE headers; the structure remains malformed.", "با وجود سرآیند خراب PE، نگاشت‌های سازگار و محدود شواهد ایستا را بازیابی می‌کنند؛ ساختار همچنان خراب است.", domain=EvidenceDomain.STRUCTURE)
        facts.update({"architecture": layout.architecture, "is_dll": layout.is_dll, "is_64": layout.is_64, "structure_status": "MALFORMED" if recovered else "VALID", "recovered_structure": recovered, "entry_point": layout.entry_rva, "timestamp": layout.timestamp, "sections": [], "is_dotnet": bool(layout.directory(14)[0]), "clr_rva": layout.directory(14)[0], "clr_size": layout.directory(14)[1], "security_offset": layout.directory(4)[0], "security_size": layout.directory(4)[1]})
        # Collect bounded semantic identities before optional bulk inspection.
        # Hostile resource/overlay work must not erase admitted import facts.
        for parser, keys in ((_imports, ("imports", "import_records")), (_exports, ("exports", "forwarded_exports"))):
            try:
                result = parser(layout)
                facts.update(dict(zip(keys, result, strict=True)))
            except PEFormatError as exc:
                errors.append(ErrorCode.MALFORMED_INPUT)
                facts["structure_status"] = "MALFORMED"
                limitations.append(str(exc))
                state = CoverageState.PARTIAL
        for section in layout.sections:
            ledger.consume("parser_iterations", max(1, section.raw_size // 64))
            blob = b"".join(layout.source.iter_chunks(offset=section.raw_offset, length=section.raw_size)) if section.raw_size else b""
            entropy = round(_entropy(blob), 4)
            executable = bool(section.flags & 0x20000000)
            writable = bool(section.flags & 0x80000000)
            facts["sections"].append({"name": section.name, "raw_offset": section.raw_offset, "raw_size": section.raw_size, "virtual_address": section.virtual_address, "virtual_size": section.virtual_size, "flags": section.flags, "entropy": entropy, "executable": executable, "writable": writable})
            if executable and writable:
                emit("PE.RWX", "PACKING", "rwx_section", Severity.MEDIUM, "A section is both executable and writable; this is an opacity signal, not proof of malware.", "یک بخش هم نوشتنی و هم اجرایی است؛ این نشانهٔ ابهام است و به‌تنهایی بدافزار بودن را ثابت نمی‌کند.", section.raw_offset)
            if entropy >= 7.3 and section.raw_size >= 1024:
                emit("PE.ENTROPY", "PACKING", "high_entropy_section", Severity.MEDIUM, "A high-entropy section limits reliable static inspection.", "آنتروپی زیاد یک بخش، بررسی ایستای قابل اعتماد را محدود می‌کند.", section.raw_offset)
            if section.name.lower().startswith(("upx", ".mpress", ".vmp", ".themida")):
                emit("PE.PROTECTOR", "PACKING", "protector_section", Severity.HIGH, "A recognized protector-style section name indicates packing; legitimate programs also use protectors.", "نام بخش با محافظ یا بسته‌بند سازگار است؛ برنامه‌های سالم نیز از آن استفاده می‌کنند.", section.raw_offset)
        entry_sections = [section for section in layout.sections if section.virtual_address <= layout.entry_rva < section.virtual_address + max(section.virtual_size, section.raw_size)]
        facts["entry_point_section"] = entry_sections[0].name if entry_sections else None
        if layout.entry_rva and (not entry_sections or not entry_sections[0].flags & 0x20000000):
            emit("PE.ENTRY", "PARSER_EVASION", "non_executable_entry", Severity.HIGH, "The entry point does not map to an executable section.", "نقطهٔ ورود در بخش اجرایی معتبر قرار ندارد.", layout.rva(layout.entry_rva), domain=EvidenceDomain.STRUCTURE)
            facts["structure_status"] = "MALFORMED"
        end = max([layout.size_headers, *(section.raw_offset + section.raw_size for section in layout.sections)])
        cert_offset, cert_size = layout.directory(4)
        if cert_offset and cert_offset >= end:
            end = max(end, cert_offset + cert_size)
        facts["overlay_size"] = len(data) - end
        facts["overlay_offset"] = end
        if len(data) > end:
            emit("PE.OVERLAY", "EMBEDDED_CONTENT", "overlay", Severity.LOW, "Data follows the mapped PE sections; its presence alone is not harmful.", "پس از بخش‌های نگاشت‌شدهٔ PE داده وجود دارد؛ وجود آن به‌تنهایی رفتار مخرب نیست.", end, domain=EvidenceDomain.CONTEXT)
        if layout.timestamp == 0xFFFFFFFF:
            emit("PE.TIMESTAMP", "METADATA_JUNK", "timestamp_anomaly", Severity.LOW, "The PE timestamp uses an anomalous sentinel value.", "مهر زمانی PE مقدار غیرمعمول دارد.", layout.nt_offset + 8)
        def retain_resource(resource: dict, blob: bytes) -> None:
            resource["embedded_pe"] = is_pe_candidate(blob, ledger)
            if resource["embedded_pe"]:
                emit("PE.EMBEDDED", "EMBEDDED_PAYLOAD", "embedded_pe", Severity.HIGH, "A resource contains recognized PE headers, including malformed candidates; the child is analyzed independently and execution is not assumed.", "منبع شامل سرآیند قابل شناسایی PE، حتی با ساختار خراب است؛ فرزند جداگانه تحلیل می‌شود و اجرای آن فرض نمی‌شود.", resource["offset"])

        try:
            _resources(layout, facts["resources"], retain_resource)
        except PEFormatError as exc:
            errors.append(ErrorCode.MALFORMED_INPUT)
            facts["structure_status"] = "MALFORMED"
            limitations.append(str(exc))
            state = CoverageState.PARTIAL
        _carve_embedded(layout, facts["resources"], facts["embedded_artifacts"], emit)
        try:
            facts["tls_callbacks"] = _tls(layout)
        except PEFormatError as exc:
            errors.append(ErrorCode.MALFORMED_INPUT)
            facts["structure_status"] = "MALFORMED"
            limitations.append(str(exc))
            state = CoverageState.PARTIAL
        try:
            if recovered:
                raise PEFormatError("recovered headers cannot be admitted to the selected parser")
            import pefile
            ledger.consume("parser_iterations", max(1, len(data) // 64))
            parsed = pefile.PE(data=data, fast_load=True, max_symbol_exports=8192)
            disagreement = parsed.FILE_HEADER.Machine != layout.machine or bool(parsed.FILE_HEADER.Characteristics & 0x2000) != layout.is_dll or parsed.OPTIONAL_HEADER.AddressOfEntryPoint != layout.entry_rva or len(parsed.sections) != len(layout.sections)
            for internal, external in zip(layout.sections, parsed.sections, strict=False):
                ledger.consume("parser_iterations")
                disagreement |= (internal.raw_offset, internal.raw_size, internal.virtual_address, internal.virtual_size) != (external.PointerToRawData, external.SizeOfRawData, external.VirtualAddress, external.Misc_VirtualSize)
            parsed.parse_data_directories(directories=[0, 1, 9, 13])
            external_imports = sorted({(entry.dll.decode("ascii", "replace").lower(), symbol.name.decode("ascii", "replace") if symbol.name else f"ordinal:{symbol.ordinal}", delayed) for delayed, name in ((False, "DIRECTORY_ENTRY_IMPORT"), (True, "DIRECTORY_ENTRY_DELAY_IMPORT")) for entry in getattr(parsed, name, ()) for symbol in entry.imports})
            internal_imports = sorted({(record["dll"], record["name"], record["delayed"]) for record in facts["import_records"]})
            disagreement |= internal_imports != external_imports
            external_exports = sorted(symbol.name.decode("ascii", "replace") for symbol in getattr(getattr(parsed, "DIRECTORY_ENTRY_EXPORT", None), "symbols", ()) if symbol.name)
            disagreement |= facts["exports"] != external_exports
            facts["imphash"] = parsed.get_imphash()
            warnings = parsed.get_warnings()
            facts["parser_warnings"] = [str(warning)[:512] for warning in warnings[:32]]
            if disagreement:
                raise PEFormatError("internal and selected PE parsers disagree")
            parsed.close()
        except ImportError:
            state = CoverageState.UNAVAILABLE
            errors.append(ErrorCode.PARSER_UNAVAILABLE)
            limitations.append("The selected PE parser is unavailable.")
        except Exception as exc:
            if isinstance(exc, BudgetExceeded):
                raise
            facts["parser_disagreement"] = True
            state = CoverageState.PARTIAL
            errors.append(ErrorCode.PARSER_DISAGREEMENT)
            limitations.append(f"Selected parser disagreement: {type(exc).__name__}: {str(exc)[:256]}")
            emit("PE.DISAGREEMENT", "PARSER_EVASION", "parser_disagreement", Severity.HIGH, "Independent PE interpretations disagree; coverage is incomplete.", "تفسیرهای مستقل PE اختلاف دارند؛ پوشش تحلیل ناقص است.", domain=EvidenceDomain.STRUCTURE)
        from malguard_core.authenticode import analyze as analyze_authenticode
        signature_facts = dict(facts)
        signature_facts["revoked_signer_sha256"] = list(revoked_signers)
        signature = analyze_authenticode(data, artifact_id, logical_path, ledger, signature_facts)
        facts["authenticode"] = signature.facts
        evidence.extend(signature.evidence)
        errors.extend(signature.errors)
        limitations.extend(signature.limitations)
        if signature.state != CoverageState.COMPLETE:
            state = signature.state if state == CoverageState.COMPLETE else CoverageState.PARTIAL
    except BudgetExceeded as exc:
        state = CoverageState.SKIPPED_LIMIT
        errors.append(ErrorCode.ITERATION_BUDGET_EXHAUSTED)
        limitations.append(str(exc))
    except PEFormatError as exc:
        state = CoverageState.PARTIAL
        errors.append(ErrorCode.MALFORMED_INPUT)
        limitations.append(str(exc))
        try:
            emit("PE.MALFORMED", "PARSER_EVASION", "malformed_pe", Severity.MEDIUM, "The claimed PE structure is malformed; raw analysis remains necessary.", "ساختار ادعایی PE خراب است؛ تحلیل دادهٔ خام همچنان لازم است.", domain=EvidenceDomain.STRUCTURE)
        except BudgetExceeded:
            state = CoverageState.SKIPPED_LIMIT
            errors.append(ErrorCode.ITERATION_BUDGET_EXHAUSTED)
    return StageResult("S2", state=state, evidence=tuple(evidence), facts=facts, errors=tuple(dict.fromkeys(errors)), limitations=tuple(limitations))
