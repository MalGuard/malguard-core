"""Strict primitive-only protocol; never deserialize arbitrary Python objects."""

import base64
import dataclasses
import json
import math
import struct
from enum import Enum
from typing import Any, IO

from malguard_core.model import (
    Evidence, EvidenceDomain, EvidenceLocation, ErrorCode, Severity, StageResult,
    CoverageState, make_evidence,
)
from malguard_core.settings import DEFAULT_BUDGETS

SCHEMA_VERSION = 1
MAX_FRAME = 128 * 1024 * 1024
MAX_TEXT = 8192
STAGES = frozenset({"pe", "dotnet", "archives", "yara"})


class ProtocolError(ValueError):
    """The worker violated a length, type, identity, or semantic constraint."""


def primitive(value: Any) -> Any:
    if isinstance(value, Enum):
        return value.value
    if dataclasses.is_dataclass(value) and not isinstance(value, type):
        return {field.name: primitive(getattr(value, field.name)) for field in dataclasses.fields(value)}
    if isinstance(value, dict):
        return {key: primitive(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [primitive(item) for item in value]
    if value is None or type(value) in (str, int, float, bool):
        return value
    raise ProtocolError("non-primitive protocol value")


def _pairs(pairs: list) -> dict:
    output: dict = {}
    for key, value in pairs:
        if key in output:
            raise ProtocolError("duplicate JSON key")
        output[key] = value
    return output


def encode(value: dict) -> bytes:
    payload = json.dumps(primitive(value), ensure_ascii=True, sort_keys=True,
                         separators=(",", ":"), allow_nan=False).encode("ascii")
    if len(payload) > MAX_FRAME:
        raise ProtocolError("frame length limit")
    return struct.pack(">I", len(payload)) + payload


def _exact(stream: IO[bytes], length: int) -> bytes:
    output = bytearray()
    while len(output) < length:
        chunk = stream.read(length - len(output))
        if not chunk:
            raise EOFError("worker pipe closed")
        output.extend(chunk)
    return bytes(output)


def read_frame(stream: IO[bytes]) -> dict:
    length = struct.unpack(">I", _exact(stream, 4))[0]
    if length == 0 or length > MAX_FRAME:
        raise ProtocolError("frame length limit")
    payload = _exact(stream, length)
    try:
        value = json.loads(payload, object_pairs_hook=_pairs,
                           parse_constant=lambda _: (_ for _ in ()).throw(ProtocolError("nonfinite JSON")))
    except (ValueError, UnicodeError, RecursionError) as exc:
        raise ProtocolError("invalid JSON") from exc
    if type(value) is not dict:
        raise ProtocolError("object frame required")
    validate_tree(value)
    return value


def integer(value: Any, minimum: int = 0, maximum: int = (1 << 63) - 1) -> int:
    if type(value) is not int or not minimum <= value <= maximum:
        raise ProtocolError("integer outside protocol range")
    return value


def text_field(value: Any, maximum: int = MAX_TEXT) -> str:
    if type(value) is not str or len(value) > maximum:
        raise ProtocolError("invalid string field")
    return value


def validate_tree(value: Any, *, depth: int = 0, counter: list[int] | None = None) -> None:
    if counter is None:
        counter = [0]
    counter[0] += 1
    if counter[0] > 500_000 or depth > 32:
        raise ProtocolError("result nesting/count limit")
    if value is None or type(value) is bool:
        return
    if type(value) is int:
        integer(value, -(1 << 63), (1 << 63) - 1)
    elif type(value) is float:
        if not math.isfinite(value) or abs(value) > (1 << 63):
            raise ProtocolError("invalid float")
    elif type(value) is str:
        # Binary payloads use one explicitly bounded base64 field.
        text_field(value, MAX_FRAME)
    elif type(value) is list:
        if len(value) > 100_000:
            raise ProtocolError("array count limit")
        for item in value:
            validate_tree(item, depth=depth + 1, counter=counter)
    elif type(value) is dict:
        if len(value) > 4096:
            raise ProtocolError("object count limit")
        for key, item in value.items():
            text_field(key, 256)
            validate_tree(item, depth=depth + 1, counter=counter)
    else:
        raise ProtocolError("invalid primitive")


def decode_data(encoded: Any, maximum: int) -> bytes:
    encoded = text_field(encoded, ((maximum + 2) // 3) * 4)
    try:
        result = base64.b64decode(encoded, validate=True)
    except ValueError as exc:
        raise ProtocolError("invalid base64") from exc
    if len(result) > maximum:
        raise ProtocolError("binary length limit")
    return result


def validate_evidence(item: Any, artifact_id: str, stage: str, data_size: int) -> Evidence:
    required = {field.name for field in dataclasses.fields(Evidence)}
    if type(item) is not dict or set(item) != required:
        raise ProtocolError("evidence schema mismatch")
    location = item["location"]
    if type(location) is not dict or set(location) != {field.name for field in dataclasses.fields(EvidenceLocation)}:
        raise ProtocolError("location schema mismatch")
    if location["artifact_id"] != artifact_id:
        raise ProtocolError("artifact identity mismatch")
    for name in ("offset", "length"):
        if location[name] is not None:
            integer(location[name], 0, data_size)
    if location["offset"] is not None and location["length"] is not None:
        if location["length"] > data_size - location["offset"]:
            raise ProtocolError("location exceeds artifact")
    for name in ("member", "detail"):
        if location[name] is not None:
            text_field(location[name])
    for name in ("id", "rule_id", "stage", "family", "kind", "description_fa", "description_en"):
        text_field(item[name])
    # Each analyzer declares S2/S4/S6/S7 in its evidence, not the dispatch name.
    expected = {"pe": "S2", "dotnet": "S4", "archives": "S6", "yara": "S7"}[stage]
    if item["stage"] != expected:
        raise ProtocolError("evidence stage mismatch")
    try:
        domain = EvidenceDomain(item["domain"])
        severity = Severity(item["severity"])
    except (ValueError, TypeError) as exc:
        raise ProtocolError("unknown evidence enum") from exc
    if domain == EvidenceDomain.HARM and item["family"] not in {
        "PROCESS_INJECTION", "CREDENTIAL_ACCESS", "EXFILTRATION", "PERSISTENCE",
        "LOADER_IN_MEMORY_EXECUTION", "KEYLOGGING", "REMOTE_CODE_EXECUTION",
        "SECURITY_TAMPERING", "DESTRUCTIVE_BEHAVIOR",
    }:
        raise ProtocolError("unknown HARM family")
    expected_weight = {"INFO": 0, "LOW": 4, "MEDIUM": 10, "HIGH": 18, "CRITICAL": 28}[severity.value]
    if item["base_weight"] != expected_weight or type(item["base_weight"]) not in (int, float):
        raise ProtocolError("untrusted weight")
    for name in ("confidence", "reliability"):
        if type(item[name]) not in (int, float) or not math.isfinite(item[name]) or not 0 <= item[name] <= 1:
            raise ProtocolError("invalid confidence/reliability")
    if type(item["mitigating"]) is not bool:
        raise ProtocolError("invalid mitigation")
    attributes = item["attributes"]
    if type(attributes) is not list or len(attributes) > 128:
        raise ProtocolError("invalid attributes")
    seen: set[str] = set()
    normalized = []
    for attribute in attributes:
        if type(attribute) is not list or len(attribute) != 2:
            raise ProtocolError("invalid attribute pair")
        key = text_field(attribute[0], 128)
        if key in seen or type(attribute[1]) not in (str, int, float, bool, type(None)):
            raise ProtocolError("invalid attribute value")
        if type(attribute[1]) is str:
            text_field(attribute[1])
        seen.add(key)
        normalized.append((key, attribute[1]))
    result = make_evidence(
        rule_id=item["rule_id"], stage=item["stage"], domain=domain,
        family=item["family"], kind=item["kind"], severity=severity,
        location=EvidenceLocation(**location), description_en=item["description_en"],
        description_fa=item["description_fa"], confidence=item["confidence"],
        reliability=item["reliability"], mitigating=item["mitigating"],
        attributes=tuple(normalized),
    )
    if result.id != item["id"]:
        raise ProtocolError("evidence ID mismatch")
    return result


def decode_result(message: dict, request: dict) -> tuple[StageResult, dict[str, int]]:
    if set(message) != {"schema_version", "request_id", "stage", "result", "usage", "rss_bytes"}:
        raise ProtocolError("response schema mismatch")
    if (type(message["schema_version"]) is not int or type(message["request_id"]) is not int
            or type(message["stage"]) is not str or message["schema_version"] != SCHEMA_VERSION
            or message["request_id"] != request["request_id"] or message["stage"] != request["stage"]):
        raise ProtocolError("response identity mismatch")
    integer(message["rss_bytes"])
    usage = message["usage"]
    if type(usage) is not dict or set(usage) != set(DEFAULT_BUDGETS) or set(request["budgets"]) != set(DEFAULT_BUDGETS):
        raise ProtocolError("usage schema mismatch")
    for name, amount in usage.items():
        integer(amount, 0, request["budgets"][name])
    result = message["result"]
    required = {field.name for field in dataclasses.fields(StageResult)}
    if type(result) is not dict or set(result) != required:
        raise ProtocolError("result schema mismatch")
    expected = {"pe": "S2", "dotnet": "S4", "archives": "S6", "yara": "S7"}[request["stage"]]
    if result["stage"] != expected:
        raise ProtocolError("result stage mismatch")
    try:
        state = CoverageState(result["state"])
        errors = tuple(ErrorCode(code) for code in result["errors"])
    except (ValueError, TypeError) as exc:
        raise ProtocolError("invalid result enums") from exc
    if type(result["errors"]) is not list or len(result["errors"]) > 128:
        raise ProtocolError("error count limit")
    if state == CoverageState.COMPLETE and errors:
        raise ProtocolError("completed stage reported errors")
    evidence = result["evidence"]
    if type(evidence) is not list or len(evidence) > min(20_000, request["budgets"].get("evidence", 20_000)):
        raise ProtocolError("evidence count limit")
    verified = tuple(validate_evidence(item, request["artifact_id"], request["stage"], request["data_size"]) for item in evidence)
    if usage["evidence"] < len(verified):
        raise ProtocolError("evidence accounting underreported")
    validate_tree(result["facts"])
    if type(result["facts"]) is not dict or "verdict" in result["facts"]:
        raise ProtocolError("workers cannot return verdicts")
    children = result["facts"].get("children", [])
    if type(children) is not list or len(children) > request["budgets"].get("children", 0):
        raise ProtocolError("child count limit")
    child_total = 0
    for child in children:
        required_child = {"logical_path", "data_b64", "encrypted", "readable", "reason"}
        allowed_child = required_child | {"member_name", "declared_size"}
        if type(child) is not dict or not required_child <= set(child) or not set(child) <= allowed_child:
            raise ProtocolError("invalid child")
        text_field(child.get("logical_path"), 8192)
        text_field(child["reason"], 8192)
        if "member_name" in child:
            text_field(child["member_name"], 8192)
        if "declared_size" in child:
            integer(child["declared_size"])
        for key in ("encrypted", "readable"):
            if type(child.get(key)) is not bool:
                raise ProtocolError("invalid child state")
        decoded = decode_data(child.get("data_b64", ""), request["max_file_size"])
        if (not child["readable"] or child["encrypted"]) and decoded:
            raise ProtocolError("unreadable child returned bytes")
        if child["readable"] and not child["encrypted"] and "declared_size" in child and len(decoded) != child["declared_size"]:
            raise ProtocolError("child size inconsistency")
        child_total += len(decoded)
    if child_total > request["budgets"].get("decompressed_bytes", 0):
        raise ProtocolError("child expansion exceeds budget")
    if usage["children"] < len(children) or usage["decompressed_bytes"] < child_total:
        raise ProtocolError("child accounting underreported")
    validate_facts(result["facts"], request["data_size"], request["max_file_size"])
    validate_stage_facts(result["facts"], request["stage"], state, request["budgets"])
    limitations = result["limitations"]
    if type(limitations) is not list or len(limitations) > 128:
        raise ProtocolError("limitations count limit")
    limitations = tuple(text_field(item) for item in limitations)
    return StageResult(stage=expected, state=state, evidence=verified, facts=result["facts"], errors=errors, limitations=limitations), usage


def validate_facts(value: Any, data_size: int, max_file_size: int) -> None:
    """Constrain physical offsets, names, counts and payloads in parser facts."""
    if type(value) is dict:
        for key, item in value.items():
            if key == "children":
                continue  # Dedicated child schema checked above.
            if key == "data_b64":
                decode_data(item, max_file_size)
            elif type(item) is str:
                text_field(item, 8192)
            elif key in {"offset", "raw_offset", "overlay_offset", "security_offset"} and item is not None:
                integer(item, 0, data_size)
            elif key in {"raw_size", "overlay_size", "security_size", "code_size"} and item is not None:
                integer(item, 0, data_size)
            else:
                validate_facts(item, data_size, max_file_size)
        if "raw_offset" in value and "raw_size" in value:
            if integer(value["raw_size"]) > data_size - integer(value["raw_offset"]):
                raise ProtocolError("section bytes exceed artifact")
        if "offset" in value and "size" in value and "data_b64" in value:
            if integer(value["size"]) > data_size - integer(value["offset"]):
                raise ProtocolError("resource bytes exceed artifact")
            if len(decode_data(value["data_b64"], max_file_size)) != value["size"]:
                raise ProtocolError("resource size inconsistency")
    elif type(value) is list:
        for item in value:
            validate_facts(item, data_size, max_file_size)


def validate_stage_facts(facts: dict, stage: str, state: CoverageState, budgets: dict) -> None:
    """Validate every collection and flag consumed by the coordinator."""
    for key in ("is_dll", "is_dotnet", "is_64", "parser_disagreement", "malformed",
                "incomplete_children", "recovered_metadata"):
        if key in facts and type(facts[key]) is not bool:
            raise ProtocolError("invalid parser flag")
    if "structure_status" in facts and (type(facts["structure_status"]) is not str or facts["structure_status"] not in {"VALID", "MALFORMED", "UNKNOWN", "BLOCKED"}):
        raise ProtocolError("invalid structure status")
    if "architecture" in facts and (type(facts["architecture"]) is not str or facts["architecture"] not in {"x86", "x64", "arm", "arm64", "unknown"}):
        raise ProtocolError("invalid architecture")
    for key in ("imports", "exports", "forwarded_exports", "assembly_refs", "streams", "matched_rules"):
        if key not in facts:
            continue
        values = facts[key]
        if type(values) is not list or len(values) > 100_000:
            raise ProtocolError("invalid parser string collection")
        for value in values:
            text_field(value, 2048)
    for key in ("sections", "import_records", "type_refs", "member_refs", "methods", "pinvoke"):
        if key not in facts:
            continue
        values = facts[key]
        maximum = 96 if key == "sections" else min(100_000, budgets["metadata_rows"] if stage == "dotnet" else budgets["parser_iterations"])
        if type(values) is not list or len(values) > maximum or any(type(value) is not dict for value in values):
            raise ProtocolError("invalid parser record collection")
    resources = facts.get("resources", [])
    if type(resources) is not list or len(resources) > budgets["resource_entries"]:
        raise ProtocolError("invalid resource collection")
    for resource in resources:
        if type(resource) is not dict:
            raise ProtocolError("invalid resource record")
        if "external" in resource and type(resource["external"]) is not bool:
            raise ProtocolError("invalid external resource flag")
        if "embedded_pe" in resource and type(resource["embedded_pe"]) is not bool:
            raise ProtocolError("invalid embedded resource flag")
        if not resource.get("external", False) and not {"offset", "size", "data_b64"} <= set(resource):
            raise ProtocolError("missing resource byte fields")
    if "embedded_artifacts" in facts:
        artifacts = facts["embedded_artifacts"]
        if type(artifacts) is not list or len(artifacts) > budgets["resource_entries"]:
            raise ProtocolError("invalid embedded artifact collection")
        for artifact in artifacts:
            if type(artifact) is not dict or not {"offset", "size", "data_b64", "type", "structure_status"} <= set(artifact):
                raise ProtocolError("invalid embedded artifact schema")
            if type(artifact["type"]) is not str or artifact["type"] != "pe" or type(artifact["structure_status"]) is not str or artifact["structure_status"] not in {"VALID", "MALFORMED"}:
                raise ProtocolError("invalid embedded artifact type")
    for key in ("imphash", "structural_hash", "mvid"):
        if key in facts:
            text_field(facts[key], 128)
    if "authenticode" in facts and type(facts["authenticode"]) is not dict:
        raise ProtocolError("invalid Authenticode record")
    if "authenticode" in facts:
        signatures = facts["authenticode"].get("signatures", [])
        if type(signatures) is not list or len(signatures) > 16 or any(type(signature) is not dict for signature in signatures):
            raise ProtocolError("invalid signature collection")
        for signature in signatures:
            if "signer_sha256" in signature:
                digest = text_field(signature["signer_sha256"], 64)
                if len(digest) != 64 or any(char not in "0123456789abcdef" for char in digest):
                    raise ProtocolError("invalid signer identity")
            for key in ("image_digest_valid", "cms_signature_valid", "revoked", "nested_signatures_present"):
                if key in signature and type(signature[key]) is not bool:
                    raise ProtocolError("invalid signature flag")
    for method in facts.get("methods", []):
        calls = method.get("calls", [])
        if type(calls) is not list or len(calls) > 100_000:
            raise ProtocolError("invalid managed call collection")
        for call in calls:
            if type(call) is not dict or "name" not in call:
                raise ProtocolError("invalid managed call record")
            text_field(call["name"], 2048)
            if "parameters" in call and (type(call["parameters"]) is not list or len(call["parameters"]) > 4096
                                          or any(type(parameter) is not str for parameter in call["parameters"])):
                raise ProtocolError("invalid managed parameter list")
    if "metadata_row_counts" in facts:
        counts = facts["metadata_row_counts"]
        if type(counts) is not dict or len(counts) > 64:
            raise ProtocolError("invalid metadata row counts")
        for key, count in counts.items():
            if not key.isdecimal() or not 0 <= int(key) < 64:
                raise ProtocolError("invalid metadata table ID")
            integer(count, 0, budgets["metadata_rows"])
        if sum(counts.values()) > budgets["metadata_rows"]:
            raise ProtocolError("metadata count budget exceeded")
    if state == CoverageState.COMPLETE and stage in {"pe", "dotnet"}:
        required = {"structure_status", "parser_disagreement", "resources"}
        required |= {"architecture", "is_dll", "is_dotnet", "imports", "exports", "sections"} if stage == "pe" else {"assembly_refs", "type_refs", "member_refs", "methods", "pinvoke"}
        if not required <= set(facts) or facts["structure_status"] != "VALID" or facts.get("parser_disagreement"):
            raise ProtocolError("incomplete structured facts claimed complete")
    if state == CoverageState.COMPLETE and stage == "archives":
        if not {"children", "archive_type", "parser_disagreement", "malformed", "incomplete_children"} <= set(facts):
            raise ProtocolError("incomplete archive facts claimed complete")
        if type(facts["archive_type"]) is not str or facts["archive_type"] not in {"ZIP", "7Z", "RAR"} or facts["malformed"] or facts["parser_disagreement"] or facts["incomplete_children"]:
            raise ProtocolError("incomplete archive state claimed complete")
    if state == CoverageState.COMPLETE and stage == "yara" and "matched_rules" not in facts:
        raise ProtocolError("missing rule result collection")
