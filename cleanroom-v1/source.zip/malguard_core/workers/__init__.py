"""Isolated, framed-JSON static parser workers."""

from .pool import WorkerPool

__all__ = ["WorkerPool"]
