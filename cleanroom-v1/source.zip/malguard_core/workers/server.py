"""Trusted worker entry point. Admission happens before hostile request intake."""

import os
import sys
from pathlib import Path

# -I removes caller-controlled import paths. Only our fixed installed package root
# is admitted, before importing trusted engine modules.
if not getattr(sys, "frozen", False):
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from malguard_core.budget import BudgetExceeded, BudgetLedger
from malguard_core.model import CoverageState, ErrorCode, StageResult
from malguard_core.workers.protocol import (
    SCHEMA_VERSION, STAGES, ProtocolError, decode_data, encode, integer,
    read_frame, text_field, validate_tree,
)
from malguard_core.settings import DEFAULT_BUDGETS


def _rss() -> int:
    if sys.platform != "win32" and os.name == "posix":
        import resource
        amount = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        return int(amount if sys.platform == "darwin" else amount * 1024)
    if sys.platform == "win32":
        import ctypes
        from ctypes import wintypes

        class Counters(ctypes.Structure):
            _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD)] + [
                (name, ctypes.c_size_t) for name in (
                    "PeakWorkingSetSize", "WorkingSetSize", "QuotaPeakPagedPoolUsage",
                    "QuotaPagedPoolUsage", "QuotaPeakNonPagedPoolUsage",
                    "QuotaNonPagedPoolUsage", "PagefileUsage", "PeakPagefileUsage",
                )
            ]
        counters = Counters()
        counters.cb = ctypes.sizeof(counters)
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.GetCurrentProcess.restype = wintypes.HANDLE
        psapi = ctypes.WinDLL("psapi", use_last_error=True)
        psapi.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD]
        if psapi.GetProcessMemoryInfo(kernel.GetCurrentProcess(), ctypes.byref(counters), counters.cb):
            return int(counters.PeakWorkingSetSize)
    return 0


def _admit(message: dict) -> None:
    if set(message) != {"schema_version", "admit", "memory_mb", "cpu_seconds"} or type(message["schema_version"]) is not int or message["schema_version"] != SCHEMA_VERSION or message["admit"] is not True:
        raise ProtocolError("invalid admission")
    memory_mb = integer(message["memory_mb"], 64, 16384)
    cpu_seconds = integer(message["cpu_seconds"], 1, 3600)
    if sys.platform != "win32" and os.name == "posix":
        import resource
        resource.setrlimit(resource.RLIMIT_AS, (memory_mb * 1024 * 1024,) * 2)
        resource.setrlimit(resource.RLIMIT_CPU, (cpu_seconds, cpu_seconds))
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        resource.setrlimit(resource.RLIMIT_NOFILE, (64, 64))
    # Windows admission is sent only after the parent successfully assigns Job.


def _request(message: dict) -> tuple[bytes, BudgetLedger]:
    required = {"schema_version", "request_id", "stage", "artifact_id", "logical_path",
                "data_b64", "data_size", "max_file_size", "budgets", "extra"}
    if set(message) != required or type(message["schema_version"]) is not int or message["schema_version"] != SCHEMA_VERSION:
        raise ProtocolError("invalid request schema")
    integer(message["request_id"])
    if type(message["stage"]) is not str or message["stage"] not in STAGES:
        raise ProtocolError("unknown stage")
    text_field(message["artifact_id"], 128)
    text_field(message["logical_path"], 8192)
    maximum = integer(message["max_file_size"], 0, 64 * 1024 * 1024)
    size = integer(message["data_size"], 0, maximum)
    if type(message["budgets"]) is not dict or set(message["budgets"]) != set(DEFAULT_BUDGETS):
        raise ProtocolError("invalid budget schema")
    for key, value in message["budgets"].items():
        text_field(key, 128)
        integer(value)
    validate_tree(message["extra"])
    if type(message["extra"]) is not dict:
        raise ProtocolError("invalid extra schema")
    data = decode_data(message["data_b64"], maximum)
    if len(data) != size:
        raise ProtocolError("size mismatch")
    return data, BudgetLedger(message["budgets"])


def _dispatch(message: dict, data: bytes, ledger: BudgetLedger) -> StageResult:
    args = (data, message["artifact_id"], message["logical_path"], ledger)
    stage = message["stage"]
    if stage == "pe":
        from malguard_core.pe import analyze as analyze_pe
        revoked = message["extra"].get("revoked_signers", [])
        if type(revoked) is not list or len(revoked) > 50_000 or any(type(value) is not str or len(value) != 64 or any(char not in "0123456789abcdef" for char in value) for value in revoked):
            raise ProtocolError("invalid signer revocations")
        return analyze_pe(*args, revoked_signers=tuple(revoked))
    if stage == "dotnet":
        from malguard_core.dotnet import analyze as analyze_dotnet
        return analyze_dotnet(*args, pe_facts=message["extra"].get("pe_facts"))
    if stage == "archives":
        from malguard_core.archives import analyze as analyze_archive
        return analyze_archive(*args, depth=integer(message["extra"].get("depth", 0), 0, 64),
                       max_depth=integer(message["extra"].get("max_depth", 4), 0, 64),
                       max_member_size=integer(message["extra"].get("max_member_size", 64 * 1024 * 1024), 0, 64 * 1024 * 1024))
    from malguard_core.rules import analyze as analyze_rules
    return analyze_rules(*args, rules_source=message["extra"].get("rules_source"))


def main() -> int:
    incoming = sys.stdin.buffer
    outgoing = sys.stdout.buffer
    try:
        _admit(read_frame(incoming))
        outgoing.write(encode({"schema_version": SCHEMA_VERSION, "ready": True}))
        outgoing.flush()
        while True:
            message = read_frame(incoming)
            data, ledger = _request(message)
            try:
                result = _dispatch(message, data, ledger)
            except BudgetExceeded:
                result = StageResult(stage={"pe": "S2", "dotnet": "S4", "archives": "S6", "yara": "S7"}[message["stage"]],
                                     state=CoverageState.SKIPPED_LIMIT,
                                     errors=(ErrorCode.ITERATION_BUDGET_EXHAUSTED,),
                                     limitations=("The deterministic parser work budget was exhausted.",))
            except Exception as exc:
                # Error text can include hostile secrets, so return its type only.
                result = StageResult(stage={"pe": "S2", "dotnet": "S4", "archives": "S6", "yara": "S7"}[message["stage"]],
                                     state=CoverageState.FAILED, errors=(ErrorCode.WORKER_FAILURE,),
                                     limitations=(f"Isolated static parser failed: {type(exc).__name__}.",))
            outgoing.write(encode({"schema_version": SCHEMA_VERSION,
                                  "request_id": message["request_id"], "stage": message["stage"],
                                  "result": result, "usage": dict(ledger.usage()), "rss_bytes": _rss()}))
            outgoing.flush()
            if result.state in (CoverageState.FAILED, CoverageState.TIMEOUT):
                return 0
    except EOFError:
        return 0
    except (ProtocolError, ValueError, OSError, MemoryError):
        return 70


if __name__ == "__main__":
    raise SystemExit(main())
