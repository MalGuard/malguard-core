"""Reusable bounded parser process with strict admission and failure recycling."""

import base64
import os
import queue
import signal
import subprocess
import sys
import threading
from pathlib import Path

from malguard_core.budget import BudgetLedger
from malguard_core.model import CoverageState, ErrorCode, StageResult
from malguard_core.settings import ScanSettings
from .job import WindowsJob
from .protocol import SCHEMA_VERSION, STAGES, ProtocolError, decode_result, encode, read_frame


def worker_launch() -> tuple[list[str], Path]:
    """Select only the trusted engine worker, including in a frozen bundle."""
    if getattr(sys, "frozen", False):
        executable = Path(sys.executable).resolve()
        return [str(executable), "--malguard-worker"], executable.parent
    server = Path(__file__).with_name("server.py").resolve()
    return [sys.executable, "-I", "-u", str(server)], server.parent


def _exchange(process: subprocess.Popen[bytes], message: dict, timeout: float) -> dict:
    result_queue: queue.Queue = queue.Queue(maxsize=1)

    def exchange() -> None:
        try:
            assert process.stdin is not None and process.stdout is not None
            process.stdin.write(encode(message))
            process.stdin.flush()
            result_queue.put((True, read_frame(process.stdout)))
        except Exception as exc:
            result_queue.put((False, exc))

    threading.Thread(target=exchange, daemon=True, name="malguard-worker-io").start()
    try:
        ok, output = result_queue.get(timeout=timeout)
    except queue.Empty as exc:
        raise TimeoutError("parser wallclock safety timeout") from exc
    if not ok:
        raise output
    return output


class WorkerPool:
    """Sequential scan workers reuse imports, and never reuse a failed parser."""

    def __init__(self, settings: ScanSettings):
        self.settings = settings
        self._process: subprocess.Popen[bytes] | None = None
        self._job: WindowsJob | None = None
        self._count = 0
        self._bytes = 0
        self._request_id = 0
        self._lock = threading.RLock()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def _start(self) -> None:
        self.close()
        command, directory = worker_launch()
        creation_flags = 0
        if sys.platform == "win32":
            creation_flags = subprocess.CREATE_NO_WINDOW
        process = subprocess.Popen(  # noqa: S603 -- fixed trusted interpreter and engine entry point
            command,
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            shell=False, close_fds=True, start_new_session=(os.name == "posix"),
            cwd=str(directory),
            creationflags=creation_flags,
        )
        self._process = process
        if os.name == "nt":
            self._job = WindowsJob(self.settings.worker_memory_mb, self.settings.worker_cpu_seconds)
            self._job.assign(process.pid)
        ready = _exchange(process, {"schema_version": SCHEMA_VERSION, "admit": True,
                                    "memory_mb": self.settings.worker_memory_mb,
                                    "cpu_seconds": self.settings.worker_cpu_seconds},
                          self.settings.worker_timeout)
        if (ready != {"schema_version": SCHEMA_VERSION, "ready": True}
                or type(ready.get("schema_version")) is not int or ready.get("ready") is not True):
            raise ProtocolError("worker admission failed")
        self._count = 0
        self._bytes = 0

    def close(self) -> None:
        with self._lock:
            process, self._process = self._process, None
            if self._job is not None:
                self._job.close()
                self._job = None
            if process is not None:
                try:
                    if process.poll() is None:
                        if sys.platform != "win32" and os.name == "posix":
                            os.killpg(process.pid, signal.SIGKILL)
                        else:
                            process.kill()
                    process.wait(timeout=2)
                except (OSError, subprocess.TimeoutExpired):
                    pass
                for stream in (process.stdin, process.stdout):
                    if stream is not None:
                        stream.close()

    def _failure_charge(self, ledger: BudgetLedger, request: dict) -> None:
        # A killed parser cannot report actual use; debit all issued stage work.
        resources = {
            "pe": ("parser_iterations", "resource_entries", "evidence"),
            "dotnet": ("parser_iterations", "metadata_rows", "resource_entries", "evidence"),
            "archives": ("parser_iterations", "archive_entries", "decompressed_bytes", "children", "evidence"),
            "yara": ("yara_bytes", "evidence"),
        }[request["stage"]]
        for resource in resources:
            ledger.consume(resource, request["budgets"].get(resource, 0))

    def run(self, stage: str, data: bytes, artifact_id: str, logical_path: str,
            ledger: BudgetLedger, extra: dict | None = None) -> StageResult:
        if stage not in STAGES:
            raise ValueError("unsupported worker stage")
        expected = {"pe": "S2", "dotnet": "S4", "archives": "S6", "yara": "S7"}[stage]
        if len(data) > min(self.settings.max_file_size, 64 * 1024 * 1024):
            return StageResult(stage=expected, state=CoverageState.SKIPPED_LIMIT,
                               errors=(ErrorCode.ITERATION_BUDGET_EXHAUSTED,),
                               limitations=("Input exceeds the isolated parser byte limit.",))
        with self._lock:
            self._request_id += 1
            request = {"schema_version": SCHEMA_VERSION, "request_id": self._request_id,
                       "stage": stage, "artifact_id": artifact_id, "logical_path": logical_path,
                       "data_b64": base64.b64encode(data).decode("ascii"), "data_size": len(data),
                       "max_file_size": min(self.settings.max_file_size, 64 * 1024 * 1024),
                       "budgets": {name: ledger.remaining(name) for name in ledger.usage()},
                       "extra": extra or {}}
            try:
                if self._process is None or self._process.poll() is not None:
                    self._start()
                assert self._process is not None
                message = _exchange(self._process, request, self.settings.worker_timeout)
                result, usage = decode_result(message, request)
                for name, amount in usage.items():
                    ledger.consume(name, amount)
                self._count += 1
                self._bytes += len(data)
                if (result.state in (CoverageState.FAILED, CoverageState.TIMEOUT)
                        or result.errors or self._count >= self.settings.worker_recycle_count
                        or self._bytes >= self.settings.worker_recycle_bytes
                        or message["rss_bytes"] > self.settings.worker_memory_mb * 1024 * 1024 * 0.8):
                    self.close()
                return result
            except TimeoutError:
                self.close()
                self._failure_charge(ledger, request)
                return StageResult(stage=expected, state=CoverageState.TIMEOUT,
                                   errors=(ErrorCode.WALLCLOCK_TIMEOUT,),
                                   limitations=("The isolated parser exceeded the wallclock safety timeout.",))
            except (ProtocolError, ValueError, OSError, EOFError, subprocess.SubprocessError) as exc:
                self.close()
                self._failure_charge(ledger, request)
                code = ErrorCode.PROTOCOL_VIOLATION if isinstance(exc, (ProtocolError, ValueError)) else ErrorCode.WORKER_FAILURE
                return StageResult(stage=expected, state=CoverageState.FAILED, errors=(code,),
                                   limitations=(f"The isolated parser was rejected: {type(exc).__name__}.",))
