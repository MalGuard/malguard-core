"""Bounded decoding of common static encodings; no code evaluation occurs."""

import base64
import binascii
import re
from collections import deque
from dataclasses import replace

from malguard_core.budget import BudgetExceeded, BudgetLedger
from malguard_core.strings import ExtractedString


_HEX = re.compile(r"(?<![A-Za-z0-9])(?:[0-9a-fA-F]{2}){4,}(?![A-Za-z0-9])")
_BASE64 = re.compile(r"(?<![A-Za-z0-9+/])(?:[A-Za-z0-9+/]{4}){2,}(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?(?![A-Za-z0-9+/])")
_CHAR_CALL = re.compile(r"(?:string\.char|String\.fromCharCode)\s*\(\s*((?:\d{1,3}\s*,\s*)*\d{1,3})\s*\)", re.I)
_ACTIVE = re.compile(r"(?:process|memory|assembly|loadstring|http|cookie|login\s*data|local\s*state|password|download|invoke|powershell|schtasks|currentversion|discord|token|virtualalloc|createremote|webclient|clipboard|gta5|scripthook|cryptunprotect|\bPOST\b|\bupload\b)", re.I)


def _text(data: bytes) -> str | None:
    if len(data) < 4:
        return None
    try:
        if data.startswith((b"\xff\xfe", b"\xfe\xff")):
            value = data.decode("utf-16")
        elif len(data) % 2 == 0 and data[1::2].count(0) >= len(data) // 4:
            value = data.decode("utf-16le")
        else:
            value = data.decode("utf-8")
    except UnicodeDecodeError:
        return None
    # Native string tables commonly use NUL separators. Preserve token
    # boundaries as newlines instead of discarding an otherwise textual table.
    value = value.replace("\0", "\n")
    if len(value.strip()) < 4 or sum(char.isprintable() or char in "\r\n\t" for char in value) < len(value) * 0.95:
        return None
    return value


def decode_strings(strings: tuple[ExtractedString, ...], ledger: BudgetLedger, max_depth: int = 2) -> tuple[ExtractedString, ...]:
    if isinstance(max_depth, bool) or not isinstance(max_depth, int) or not 0 <= max_depth <= 4:
        raise ValueError("invalid decode depth")
    queue = deque((item, 0) for item in strings)
    seen = {(item.offset, item.text) for item in strings}
    result: list[ExtractedString] = []

    def candidate(value: bytes | str, source: ExtractedString, encoding: str, depth: int) -> None:
        ledger.consume("decoded_candidates")
        if isinstance(value, bytes):
            ledger.consume("decoded_bytes", len(value))
            text = _text(value)
        else:
            ledger.consume("decoded_bytes", len(value.encode("utf-8")))
            text = value
        if text is None or len(text) > 65536 or len(text) < 4:
            return
        key = (source.offset, text)
        if key in seen:
            return
        ledger.consume_many({"strings": 1, "string_bytes": len(text.encode("utf-8"))})
        seen.add(key)
        decoded = ExtractedString(text, source.offset, encoding, True)
        result.append(decoded)
        queue.append((decoded, depth + 1))

    try:
        while queue:
            source, depth = queue.popleft()
            if depth >= max_depth or len(source.text) > 65536:
                continue
            text = source.text
            for match in _HEX.finditer(text):
                try:
                    candidate(bytes.fromhex(match.group()), source, "hex", depth)
                except ValueError:
                    continue
            for match in _BASE64.finditer(text):
                token = match.group()
                # Long mixed-case or explicitly padded candidates avoid decoding ordinary names.
                if len(token) < 16 and "=" not in token:
                    continue
                if not any(char.islower() for char in token) or not any(char.isupper() for char in token):
                    continue
                try:
                    raw = base64.b64decode(token, validate=True)
                except (binascii.Error, ValueError):
                    continue
                candidate(raw, source, "base64", depth)
            if re.search(r"\\x[0-9A-Fa-f]{2}", text):
                reconstructed = re.sub(r"\\x([0-9A-Fa-f]{2})", lambda match: chr(int(match.group(1), 16)), text)
                candidate(reconstructed, source, "hex-escape", depth)
            if re.search(r"\\u[0-9A-Fa-f]{4}", text):
                reconstructed = re.sub(r"\\u([0-9A-Fa-f]{4})", lambda match: chr(int(match.group(1), 16)), text)
                if not any(0xD800 <= ord(char) <= 0xDFFF for char in reconstructed):
                    candidate(reconstructed, source, "unicode-escape", depth)
            joined = re.sub(r"(['\"])\s*(?:\+|\.\.|&)\s*\1", "", text)
            if joined != text:
                candidate(joined, source, "string-concatenation", depth)
            for match in _CHAR_CALL.finditer(text):
                numbers = [int(item.strip()) for item in match.group(1).split(",")]
                if len(numbers) <= 4096 and all(number <= 255 for number in numbers):
                    candidate(bytes(numbers), source, "character-array", depth)
            reversed_text = text[::-1]
            if _ACTIVE.search(reversed_text) and not _ACTIVE.search(text):
                candidate(reversed_text, source, "reversed", depth)
    except BudgetExceeded as exc:
        exc.partial_results = tuple(sorted(result, key=lambda item: (item.offset, item.encoding, item.text)))
        raise
    return tuple(sorted(result, key=lambda item: (item.offset, item.encoding, item.text)))


def decode_bytes(data: bytes, ledger: BudgetLedger, *, min_length: int = 8, max_input: int = 65536) -> tuple[ExtractedString, ...]:
    """Find active ASCII text under one-byte XOR, without executing decoders.

    Adjacent XOR fingerprints infer candidate keys in one bounded pass. This is a heuristic;
    decoded findings have lower reliability than validated metadata facts.
    """
    if not isinstance(data, bytes) or not 4 <= min_length <= 128 or not 0 <= max_input <= 1024 * 1024:
        raise ValueError("invalid XOR decoding input")
    view = data[:max_input]
    result: list[ExtractedString] = []
    seen: set[tuple[int, str]] = set()
    inferred_keys: set[int] = set()
    try:
        ledger.consume("parser_iterations", len(view))
        fingerprints = bytes(left ^ right for left, right in zip(view, view[1:], strict=False))
        anchors = (b"WriteProcessMemory", b"CreateRemoteThread", b"VirtualAllocEx", b"Assembly.Load",
                   b"loadstring", b"PerformHttpRequest", b"DownloadString", b"DownloadData", b"HttpClient",
                   b"Invoke-Expression", b"Invoke-WebRequest", b"Login Data", b"CurrentVersion",
                   b"Local State", b"Cookies", b"password", b"schtasks", b"GTA5.exe", b"ScriptHookV", b"POST", b"upload")
        signatures = sorted({variant for anchor in anchors for variant in (anchor, anchor.lower(), anchor.upper())})
        for anchor in signatures:
            ledger.consume("parser_iterations")
            signature = bytes(left ^ right for left, right in zip(anchor, anchor[1:], strict=False))
            position = 0
            while True:
                offset = fingerprints.find(signature, position)
                if offset < 0:
                    break
                position = offset + 1
                key = view[offset] ^ anchor[0]
                if key == 0:
                    continue
                ledger.consume("decoded_candidates")
                ledger.consume("parser_iterations", len(anchor))
                if bytes(byte ^ key for byte in view[offset:offset + len(anchor)]) != anchor:
                    continue
                if len(anchor) >= 8:
                    inferred_keys.add(key)
                start = offset
                while start > 0 and offset - start < 2048 and (32 <= view[start - 1] ^ key <= 126 or view[start - 1] ^ key == 9):
                    start -= 1
                end = offset + len(anchor)
                while end < len(view) and end - start < 4096 and (32 <= view[end] ^ key <= 126 or view[end] ^ key == 9):
                    end += 1
                ledger.consume("parser_iterations", end - start)
                ledger.consume("decoded_bytes", end - start)
                text = bytes(byte ^ key for byte in view[start:end]).decode("ascii")
                identity = (start, text)
                if identity in seen or (len(text) < min_length and text.casefold() not in {"post", "upload"}):
                    continue
                seen.add(identity)
                ledger.consume_many({"strings": 1, "string_bytes": len(text)})
                result.append(ExtractedString(text, start, f"xor-{key:02x}", True))
        # A strong recovered anchor establishes a candidate constant key for
        # this bounded window. Recover adjacent string-table entries too,
        # including encoded entries without their own recognizable API anchor.
        for key in sorted(inferred_keys):
            ledger.consume_many({"parser_iterations": len(view), "decoded_bytes": len(view)})
            decoded_view = bytes(byte ^ key for byte in view)
            for match in re.finditer(rb"[\x20-\x7e\t]{4,4096}", decoded_view):
                text = match.group().decode("ascii")
                identity = (match.start(), text)
                if identity in seen:
                    continue
                ledger.consume_many({"decoded_candidates": 1, "strings": 1, "string_bytes": len(text)})
                seen.add(identity)
                result.append(ExtractedString(text, match.start(), f"xor-{key:02x}", True))
    except BudgetExceeded as exc:
        exc.partial_results = tuple(sorted(result, key=lambda item: (item.offset, item.encoding, item.text)))
        raise
    return tuple(sorted(result, key=lambda item: (item.offset, item.encoding, item.text)))


def decode_artifact_bytes(data: bytes, ledger: BudgetLedger) -> tuple[ExtractedString, ...]:
    """Cover the captured artifact with bounded, overlapping XOR windows.

    The overlap covers the low-level decoder's longest 4,096-byte candidate.
    Absolute offsets survive window translation. Work and decoded candidates
    consume the root ledger; exhaustion retains prior results and blocks SAFE.
    """
    if not isinstance(data, bytes):
        raise ValueError("invalid artifact decoding input")
    window_size = 65536
    stride = window_size - 4096
    result: dict[tuple[int, str, str], ExtractedString] = {}

    def retain(items: tuple[ExtractedString, ...], start: int) -> None:
        for item in items:
            absolute = replace(item, offset=item.offset + start)
            result[(absolute.offset, absolute.encoding, absolute.text)] = absolute

    for start in range(0, len(data), stride):
        end = min(len(data), start + window_size)
        try:
            retain(decode_bytes(data[start:end], ledger), start)
        except BudgetExceeded as exc:
            retain(exc.partial_results, start)
            exc.partial_results = tuple(sorted(result.values(), key=lambda item: (item.offset, item.encoding, item.text)))
            raise
        if end == len(data):
            break
    return tuple(sorted(result.values(), key=lambda item: (item.offset, item.encoding, item.text)))
