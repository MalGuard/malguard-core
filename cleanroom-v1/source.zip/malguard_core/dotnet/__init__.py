"""ECMA-335 metadata and IL analysis without loading or JIT compiling input.

Heap/table index validation precedes dnfile. Decisions use metadata identities
and correctly decoded IL operands; an arbitrary printable API name is not a
managed call. Analysis records uncertainty where flow cannot be established.
"""

from __future__ import annotations

import base64
import struct
import unicodedata
from dataclasses import dataclass

from malguard_core.budget import BudgetExceeded, BudgetLedger
from malguard_core.model import (
    CoverageState, ErrorCode, EvidenceDomain, EvidenceLocation, Severity,
    StageResult, make_evidence,
)
from malguard_core.pe import PEFormatError, PELayout, _entropy, is_pe_candidate, validate


# ECMA-335 II.22 schemas. Columns are fixed integers, heap indices, table
# indices (tN), or coded indices (cNAME). Reserved tables are rejected.
SCHEMAS = {
    0: ("u2", "str", "guid", "guid", "guid"),
    1: ("cResolutionScope", "str", "str"),
    2: ("u4", "str", "str", "cTypeDefOrRef", "t4", "t6"),
    3: ("t4",), 4: ("u2", "str", "blob"), 5: ("t6",),
    6: ("u4", "u2", "u2", "str", "blob", "t8"), 7: ("t8",),
    8: ("u2", "u2", "str"), 9: ("t2", "cTypeDefOrRef"),
    10: ("cMemberRefParent", "str", "blob"),
    11: ("u2", "cHasConstant", "blob"),
    12: ("cHasCustomAttribute", "cCustomAttributeType", "blob"),
    13: ("cHasFieldMarshal", "blob"),
    14: ("u2", "cHasDeclSecurity", "blob"),
    15: ("u2", "u4", "t2"), 16: ("u4", "t4"), 17: ("blob",),
    18: ("t2", "t20"), 19: ("t20",),
    20: ("u2", "str", "cTypeDefOrRef"),
    21: ("t2", "t23"), 22: ("t23",), 23: ("u2", "str", "blob"),
    24: ("u2", "t6", "cHasSemantics"),
    25: ("t2", "cMethodDefOrRef", "cMethodDefOrRef"),
    26: ("str",), 27: ("blob",),
    28: ("u2", "cMemberForwarded", "str", "t26"),
    29: ("u4", "t4"), 30: ("u4", "u4"), 31: ("u4",),
    32: ("u4", "u2", "u2", "u2", "u2", "u4", "blob", "str", "str"),
    33: ("u4",), 34: ("u4", "u4", "u4"),
    35: ("u2", "u2", "u2", "u2", "u4", "blob", "str", "str", "blob"),
    36: ("u4", "t35"), 37: ("u4", "u4", "u4", "t35"),
    38: ("u4", "str", "blob"),
    39: ("u4", "u4", "str", "str", "cImplementation"),
    40: ("u4", "u4", "str", "cImplementation"),
    41: ("t2", "t2"), 42: ("u2", "u2", "cTypeOrMethodDef", "str"),
    43: ("cMethodDefOrRef", "blob"), 44: ("t42", "cTypeDefOrRef"),
}
CODED = {
    "ResolutionScope": (2, (0, 26, 35, 1)),
    "TypeDefOrRef": (2, (2, 1, 27)),
    "MemberRefParent": (3, (2, 1, 26, 6, 27)),
    "HasConstant": (2, (4, 8, 23)),
    "HasCustomAttribute": (5, (6, 4, 1, 2, 8, 9, 10, 0, 14, 23, 20, 17, 26, 27, 32, 35, 38, 39, 40, 42, 44, 43)),
    "CustomAttributeType": (3, (-1, -1, 6, 10, -1)),
    "HasFieldMarshal": (1, (4, 8)),
    "HasDeclSecurity": (2, (2, 6, 32)),
    "HasSemantics": (1, (20, 23)),
    "MethodDefOrRef": (1, (6, 10)),
    "MemberForwarded": (1, (4, 6)),
    "Implementation": (2, (38, 35, 39)),
    "TypeOrMethodDef": (1, (2, 6)),
}


class MetadataError(PEFormatError):
    """Managed metadata or method code is malformed or ambiguous."""


@dataclass(slots=True)
class Metadata:
    layout: PELayout
    streams: dict[str, tuple[int, int]]
    tables: dict[int, list[tuple[int, ...]]]
    row_offsets: dict[int, list[int]]
    heap_sizes: int
    resource_rva: int
    resource_size: int
    flags: int
    entry_token: int
    resource_error: str = ""

    def heap_read(self, name: str, relative: int, length: int) -> bytes:
        offset, size = self.streams.get(name, (0, 0))
        if relative < 0 or length < 0 or relative > size or length > size - relative:
            raise MetadataError(f"{name} heap index exceeds bounds")
        return self.layout.source.read(offset + relative, length)

    def string(self, relative: int) -> str:
        if not relative:
            return ""
        _, size = self.streams.get("#Strings", (0, 0))
        output = bytearray()
        for index in range(min(4096, size - relative)):
            self.layout.ledger.consume("parser_iterations")
            byte = self.heap_read("#Strings", relative + index, 1)[0]
            if not byte:
                try:
                    return output.decode("utf-8")
                except UnicodeDecodeError as exc:
                    raise MetadataError("invalid UTF-8 metadata string") from exc
            output.append(byte)
        raise MetadataError("unterminated or oversized metadata string")

    def compressed(self, heap: str, relative: int) -> tuple[int, int]:
        first = self.heap_read(heap, relative, 1)[0]
        if first < 0x80:
            return first, 1
        if first < 0xC0:
            return ((first & 0x3F) << 8) | self.heap_read(heap, relative + 1, 1)[0], 2
        if first < 0xE0:
            tail = self.heap_read(heap, relative + 1, 3)
            return ((first & 0x1F) << 24) | int.from_bytes(tail, "big"), 4
        raise MetadataError("reserved compressed integer encoding")

    def blob(self, relative: int, maximum: int = 65536) -> bytes:
        if not relative:
            return b""
        size, width = self.compressed("#Blob", relative)
        if size > maximum:
            raise MetadataError("oversized metadata signature blob")
        return self.heap_read("#Blob", relative + width, size)

    def user_string(self, relative: int) -> str:
        if not relative:
            return ""
        size, width = self.compressed("#US", relative)
        if size < 1 or size > 8193 or size % 2 != 1:
            raise MetadataError("invalid user string length")
        return self.heap_read("#US", relative + width, size - 1).decode("utf-16le", "strict")

    def coded(self, name: str, value: int) -> tuple[int, int]:
        bits, tables = CODED[name]
        tag = value & ((1 << bits) - 1)
        index = value >> bits
        if tag >= len(tables) or tables[tag] < 0 or index > len(self.tables.get(tables[tag], ())):
            raise MetadataError("invalid coded table index")
        return tables[tag], index


def parse_metadata(layout: PELayout) -> Metadata:
    clr_rva, clr_size = layout.directory(14)
    if not clr_rva or clr_size < 72:
        raise MetadataError("missing complete CLR header")
    header = layout.source.read(layout.rva(clr_rva, 72), 72)
    cb = struct.unpack_from("<I", header)[0]
    if cb < 72 or cb > clr_size:
        raise MetadataError("invalid CLR header size")
    metadata_rva, metadata_size, flags, entry = struct.unpack_from("<IIII", header, 8)
    resource_rva, resource_size = struct.unpack_from("<II", header, 24)
    resource_error = ""
    try:
        if bool(resource_rva) != bool(resource_size):
            raise MetadataError("inconsistent managed resource directory")
        if resource_rva:
            layout.rva(resource_rva, resource_size)
    except PEFormatError as exc:
        # CLR resources have an independent directory. Keep validated metadata
        # and IL analyzable when that optional directory is corrupt.
        resource_error = str(exc)
        resource_rva = resource_size = 0
    if metadata_size < 20 or metadata_size > 32 * 1024 * 1024:
        raise MetadataError("metadata root exceeds limits")
    root = layout.rva(metadata_rva, metadata_size)
    fixed = layout.source.read(root, 16)
    signature, major, minor, reserved, version_length = struct.unpack("<IHHII", fixed)
    if signature != 0x424A5342 or reserved or version_length > 256 or version_length > metadata_size - 20:
        raise MetadataError("invalid CLR metadata signature/version")
    layout.source.read(root + 16, version_length)
    cursor = (16 + version_length + 3) & ~3
    if cursor > metadata_size - 4:
        raise MetadataError("truncated metadata stream count")
    _, stream_count = struct.unpack("<HH", layout.source.read(root + cursor, 4))
    cursor += 4
    if stream_count == 0 or stream_count > 16:
        raise MetadataError("invalid metadata stream count")
    streams = {}
    stream_ranges = []
    for _ in range(stream_count):
        layout.ledger.consume("parser_iterations")
        if cursor > metadata_size - 8:
            raise MetadataError("truncated metadata stream header")
        relative, size = struct.unpack("<II", layout.source.read(root + cursor, 8))
        cursor += 8
        stream_name = bytearray()
        for _ in range(32):
            if cursor >= metadata_size:
                raise MetadataError("truncated stream name")
            byte = layout.source.read(root + cursor, 1)[0]
            cursor += 1
            if not byte:
                break
            stream_name.append(byte)
        else:
            raise MetadataError("unterminated stream name")
        cursor = (cursor + 3) & ~3
        try:
            label = stream_name.decode("ascii")
        except UnicodeDecodeError as exc:
            raise MetadataError("non-ASCII metadata stream name") from exc
        if label in streams or relative > metadata_size or size > metadata_size - relative:
            raise MetadataError("duplicate or out-of-bounds metadata stream")
        streams[label] = (root + relative, size)
        if size:
            stream_ranges.append((relative, relative + size))
    stream_ranges.sort()
    if any(start < cursor for start, _ in stream_ranges) or any(second[0] < first[1] for first, second in zip(stream_ranges, stream_ranges[1:], strict=False)):
        raise MetadataError("overlapping metadata streams or headers")
    if ("#~" in streams) == ("#-" in streams):
        raise MetadataError("ambiguous metadata tables stream")
    for name in ("#Strings", "#Blob", "#GUID"):
        if name not in streams:
            raise MetadataError(f"missing {name} heap")
    table_offset, table_size = streams["#~"] if "#~" in streams else streams["#-"]
    if table_size < 24:
        raise MetadataError("truncated table stream")
    record = layout.source.read(table_offset, 24)
    reserved, _, _, heap_sizes, reserved2, valid, _ = struct.unpack("<IBBBBQQ", record)
    if reserved or reserved2 != 1 or heap_sizes & ~7 or valid >> 45:
        raise MetadataError("unsupported/reserved metadata table header")
    cursor = 24
    counts = {}
    for table in range(45):
        if valid & (1 << table):
            if cursor > table_size - 4:
                raise MetadataError("truncated table row counts")
            count = int.from_bytes(layout.source.read(table_offset + cursor, 4), "little")
            layout.ledger.consume("metadata_rows", count)
            counts[table] = count
            cursor += 4

    def width(column: str) -> int:
        if column in ("u2", "u4"):
            return int(column[1])
        if column in ("str", "guid", "blob"):
            flag = {"str": 1, "guid": 2, "blob": 4}[column]
            return 4 if heap_sizes & flag else 2
        if column.startswith("t"):
            return 4 if counts.get(int(column[1:]), 0) >= 65536 else 2
        bits, options = CODED[column[1:]]
        return 4 if max((counts.get(table, 0) for table in options), default=0) >= 1 << (16 - bits) else 2

    tables = {}
    row_offsets = {}
    for table, count in sorted(counts.items()):
        schema = SCHEMAS[table]
        widths = [width(column) for column in schema]
        row_size = sum(widths)
        if count > (table_size - cursor) // row_size:
            raise MetadataError("metadata rows exceed tables stream")
        rows = []
        offsets = []
        for _ in range(count):
            layout.ledger.consume("parser_iterations")
            offsets.append(table_offset + cursor)
            record = layout.source.read(table_offset + cursor, row_size)
            pointer = 0
            values = []
            for column_width in widths:
                values.append(int.from_bytes(record[pointer:pointer + column_width], "little"))
                pointer += column_width
            rows.append(tuple(values))
            cursor += row_size
        tables[table] = rows
        row_offsets[table] = offsets
    metadata = Metadata(layout, streams, tables, row_offsets, heap_sizes, resource_rva, resource_size, flags, entry, resource_error)
    # Validate every reference, including unused rows attackers might weaponize.
    for table, rows in tables.items():
        for row in rows:
            layout.ledger.consume("parser_iterations")
            for column_index, (column, value) in enumerate(zip(SCHEMAS[table], row, strict=True)):
                if not value:
                    continue
                if column == "str":
                    metadata.string(value)
                elif column == "blob":
                    length, size_width = metadata.compressed("#Blob", value)
                    _, heap_size = streams["#Blob"]
                    if length > heap_size - value - size_width:
                        raise MetadataError("blob length exceeds heap")
                elif column == "guid":
                    metadata.heap_read("#GUID", (value - 1) * 16, 16)
                elif column.startswith("t"):
                    maximum = counts.get(int(column[1:]), 0)
                    # List-start indices may legally be one past the final row.
                    sentinel = (table, column_index) in {(2, 4), (2, 5), (6, 5), (18, 1), (21, 1)}
                    if value > maximum + int(sentinel):
                        raise MetadataError("table index exceeds row count")
                elif column.startswith("c"):
                    metadata.coded(column[1:], value)
    if entry and not flags & 0x10:
        if entry >> 24 != 6 or (entry & 0xFFFFFF) > len(tables.get(6, ())):
            raise MetadataError("invalid managed entry-point token")
    return metadata


def _signature_types(blob: bytes) -> tuple[str, ...]:
    """Decode parameter types, enough to distinguish byte[] from string loads."""
    position = 0

    def read() -> int:
        nonlocal position
        if position >= len(blob):
            raise MetadataError("truncated method signature")
        byte = blob[position]
        position += 1
        return byte

    def compressed() -> int:
        first = read()
        if first < 0x80:
            return first
        if first < 0xC0:
            return ((first & 0x3F) << 8) | read()
        if first < 0xE0:
            return ((first & 0x1F) << 24) | (read() << 16) | (read() << 8) | read()
        raise MetadataError("invalid signature integer")

    def typed(depth: int = 0) -> str:
        if depth > 24:
            raise MetadataError("excessively nested signature")
        byte = read()
        names = {1: "void", 2: "bool", 3: "char", 4: "sbyte", 5: "byte", 6: "int16", 7: "uint16", 8: "int32", 9: "uint32", 10: "int64", 11: "uint64", 12: "single", 13: "double", 14: "string", 22: "typedref", 24: "nativeint", 25: "nativeuint", 28: "object"}
        if byte in names:
            return names[byte]
        if byte in (0x11, 0x12, 0x13, 0x1E):
            return f"type:{compressed()}"
        if byte in (0x0F, 0x10, 0x1D, 0x45):
            return typed(depth + 1) + {0x0F: "*", 0x10: "&", 0x1D: "[]", 0x45: " pinned"}[byte]
        if byte in (0x1F, 0x20):
            compressed()
            return typed(depth + 1)
        if byte == 0x15:
            base = typed(depth + 1)
            count = compressed()
            if count > 128:
                raise MetadataError("excessive generic signature arguments")
            return base + "<" + ",".join(typed(depth + 1) for _ in range(count)) + ">"
        if byte == 0x14:
            element = typed(depth + 1)
            rank = compressed()
            sizes = compressed()
            if rank > 32 or sizes > rank:
                raise MetadataError("invalid array signature")
            for _ in range(sizes):
                compressed()
            bounds = compressed()
            if bounds > rank:
                raise MetadataError("invalid array bounds signature")
            for _ in range(bounds):
                compressed()
            return element + "[multi]"
        raise MetadataError("unsupported method signature type")

    flags = read()
    if flags & 0x10:
        compressed()
    count = compressed()
    if count > 1024:
        raise MetadataError("excessive method parameters")
    typed()
    parameters = []
    for _ in range(count):
        if position < len(blob) and blob[position] == 0x41:
            position += 1
        parameters.append(typed())
    if position != len(blob):
        raise MetadataError("trailing method signature bytes")
    return tuple(parameters)


# Operand widths for ECMA-335 III opcodes. Unknown/reserved opcodes fail the
# method rather than treating operand bytes as instructions.
_OPCODES = {opcode: 0 for opcode in list(range(0x00, 0x0E)) + list(range(0x14, 0x1F)) + [0x25, 0x26, 0x2A] + list(range(0x46, 0x6F)) + [0x76, 0x7A] + list(range(0x82, 0x8C)) + [0x8E] + list(range(0x90, 0xA3)) + list(range(0xB3, 0xBB)) + [0xC3] + list(range(0xD1, 0xDD)) + [0xDC, 0xDF, 0xE0]}
_OPCODES.update({opcode: 1 for opcode in list(range(0x0E, 0x14)) + [0x1F] + list(range(0x2B, 0x38)) + [0xDE]})
_OPCODES.update({opcode: 4 for opcode in [0x20, 0x22, 0x27, 0x28, 0x29] + list(range(0x38, 0x45)) + list(range(0x6F, 0x76)) + list(range(0x79, 0x82)) + [0x8C, 0x8D, 0x8F, 0xA3, 0xA4, 0xA5, 0xC2, 0xC6, 0xD0, 0xDD]})
_OPCODES.update({0x21: 8, 0x23: 8, 0x45: -1})
_EXTENDED = {opcode: 0 for opcode in [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x0F, 0x11, 0x13, 0x14, 0x17, 0x18, 0x1A, 0x1D, 0x1E]}
_EXTENDED.update({0x06: 4, 0x07: 4, 0x09: 2, 0x0A: 2, 0x0B: 2, 0x0C: 2, 0x0D: 2, 0x0E: 2, 0x12: 1, 0x15: 4, 0x16: 4, 0x19: 1, 0x1C: 4})


def _method_il(metadata: Metadata, rva: int) -> dict:
    layout = metadata.layout
    start = layout.rva(rva)
    first = layout.source.read(start, 1)[0]
    extra_sections = False
    if first & 3 == 2:
        code_size, header_size = first >> 2, 1
    elif first & 3 == 3:
        header = layout.source.read(layout.rva(rva, 12), 12)
        flags, max_stack, code_size, local_token = struct.unpack("<HHII", header)
        header_size = (flags >> 12) * 4
        if header_size < 12 or header_size > 64 or max_stack > 32768:
            raise MetadataError("invalid fat method header")
        layout.rva(rva, header_size)
        if local_token and (local_token >> 24 != 17 or local_token & 0xFFFFFF > len(metadata.tables.get(17, ()))):
            raise MetadataError("invalid local-variable signature token")
        extra_sections = bool(flags & 8)
    else:
        raise MetadataError("invalid IL method header")
    if code_size > 1024 * 1024:
        raise MetadataError("method body exceeds analysis limit")
    code = layout.source.read(layout.rva(rva + header_size, code_size), code_size)
    cursor = 0
    calls = []
    strings = []
    indirect_calls = []
    instructions = set()
    branches = []
    while cursor < len(code):
        layout.ledger.consume("parser_iterations")
        instructions.add(cursor)
        instruction_offset = cursor
        opcode = code[cursor]
        cursor += 1
        extended = opcode == 0xFE
        if extended:
            if cursor >= len(code):
                raise MetadataError("truncated extended IL opcode")
            opcode = code[cursor]
            cursor += 1
        width = (_EXTENDED if extended else _OPCODES).get(opcode)
        if width is None:
            raise MetadataError("unknown/reserved IL opcode")
        if width == -1:
            if cursor > len(code) - 4:
                raise MetadataError("truncated switch count")
            count = int.from_bytes(code[cursor:cursor + 4], "little")
            if count > 4096 or count > (len(code) - cursor - 4) // 4:
                raise MetadataError("invalid IL switch table")
            layout.ledger.consume("parser_iterations", count)
            after = cursor + 4 + count * 4
            for index in range(count):
                displacement = int.from_bytes(code[cursor + 4 + index * 4:cursor + 8 + index * 4], "little", signed=True)
                branches.append(after + displacement)
            cursor = after
            continue
        if width > len(code) - cursor:
            raise MetadataError("truncated IL operand")
        operand = code[cursor:cursor + width]
        cursor += width
        if not extended and opcode in (0x27, 0x28, 0x6F, 0x73):
            calls.append({"token": int.from_bytes(operand, "little"), "offset": start + header_size + instruction_offset})
        elif not extended and opcode == 0x29:
            token = int.from_bytes(operand, "little")
            if token >> 24 != 17 or not 0 < token & 0xFFFFFF <= len(metadata.tables.get(17, ())):
                raise MetadataError("invalid calli signature token")
            indirect_calls.append(start + header_size + instruction_offset)
        elif not extended and opcode == 0x72:
            token = int.from_bytes(operand, "little")
            if token >> 24 != 0x70:
                raise MetadataError("invalid ldstr token")
            strings.append({"text": metadata.user_string(token & 0xFFFFFF), "offset": start + header_size + instruction_offset})
        elif not extended and (0x2B <= opcode <= 0x44 or opcode in (0xDD, 0xDE)):
            branches.append(cursor + int.from_bytes(operand, "little", signed=True))
    if any(target not in instructions for target in branches):
        raise MetadataError("IL branch target is outside instruction boundaries")
    if extra_sections:
        section_rva = (rva + header_size + code_size + 3) & ~3
        for _ in range(32):
            layout.ledger.consume("parser_iterations")
            header = layout.source.read(layout.rva(section_rva, 4), 4)
            flags = header[0]
            if flags & 0x3F != 1:
                raise MetadataError("unsupported IL extra section")
            fat = bool(flags & 0x40)
            size = int.from_bytes(header[1:4], "little") if fat else header[1]
            width = 24 if fat else 12
            if size < 4 or (size - 4) % width:
                raise MetadataError("invalid IL exception table")
            layout.rva(section_rva, size)
            layout.ledger.consume("parser_iterations", (size - 4) // width)
            if not flags & 0x80:
                break
            section_rva = (section_rva + size + 3) & ~3
        else:
            raise MetadataError("excessive IL exception sections")
    return {"calls": calls, "strings": strings, "indirect_calls": indirect_calls, "code_size": code_size, "offset": start}


def analyze(data: bytes, artifact_id: str, logical_path: str, ledger: BudgetLedger, pe_facts: dict | None = None) -> StageResult:
    evidence = []
    evidence_ids: set[str] = set()
    errors = []
    limitations = []
    facts: dict = {"structure_status": "MALFORMED", "assembly_refs": [], "type_refs": [], "member_refs": [], "methods": [], "pinvoke": [], "resources": [], "parser_disagreement": False}
    state = CoverageState.COMPLETE

    def emit(rule: str, family: str, kind: str, severity: Severity, en: str, fa: str, offset: int | None = None, domain: EvidenceDomain = EvidenceDomain.OPACITY, confidence: float = 1.0, attributes: tuple = ()) -> None:
        item = make_evidence(rule, "S4", domain, family, kind, severity, EvidenceLocation(artifact_id, offset=offset), en, fa, confidence=confidence, attributes=attributes)
        if item.id in evidence_ids:
            return
        ledger.consume("evidence")
        evidence.append(item)
        evidence_ids.add(item.id)

    try:
        recovered = False
        try:
            layout = validate(data, ledger)
        except PEFormatError:
            layout = validate(data, ledger, recovery=True)
            recovered = True
            state = CoverageState.PARTIAL
            errors.append(ErrorCode.MALFORMED_INPUT)
            limitations.append("Managed evidence was recovered through strictly bounded section mappings after malformed PE headers.")
            emit("NET.RECOVERY", "PARSER_EVASION", "metadata_recovery", Severity.MEDIUM, "Managed metadata analysis recovered evidence after malformed PE headers; structure remains invalid.", "پس از خرابی سرآیند PE، شواهد فراداده بازیابی شد؛ ساختار همچنان نامعتبر است.", domain=EvidenceDomain.STRUCTURE)
        metadata = parse_metadata(layout)
        facts["structure_status"] = "MALFORMED" if recovered else "VALID"
        facts["recovered_metadata"] = recovered
        if metadata.resource_error:
            facts["incomplete_resources"] = True
            facts["structure_status"] = "MALFORMED"
            state = CoverageState.PARTIAL
            errors.append(ErrorCode.MALFORMED_INPUT)
            limitations.append(f"Managed resource directory: {metadata.resource_error}")
            emit("NET.RESOURCE_DIRECTORY", "PARSER_EVASION", "malformed_resource_directory", Severity.MEDIUM, "The CLR resource directory is malformed; validated metadata and method analysis continue.", "دایرکتوری منابع CLR خراب است؛ تحلیل فرادادهٔ معتبر و متدها ادامه می‌یابد.", domain=EvidenceDomain.STRUCTURE)
        facts["metadata_row_counts"] = {str(table): len(rows) for table, rows in metadata.tables.items()}
        facts["streams"] = sorted(metadata.streams)
        refs = []
        for row in metadata.tables.get(35, ()):
            refs.append(metadata.string(row[6]))
        facts["assembly_refs"] = sorted(refs)
        types = {}
        for index, row in enumerate(metadata.tables.get(1, ()), 1):
            scope_table, scope_index = metadata.coded("ResolutionScope", row[0])
            name, namespace = metadata.string(row[1]), metadata.string(row[2])
            types[index] = f"{namespace}.{name}".strip(".")
            facts["type_refs"].append({"name": name, "namespace": namespace, "scope_table": scope_table, "scope_index": scope_index})
        members = {}
        for index, row in enumerate(metadata.tables.get(10, ()), 1):
            parent_table, parent_index = metadata.coded("MemberRefParent", row[0])
            parent = types.get(parent_index, "") if parent_table == 1 else ""
            name = metadata.string(row[1])
            member_signature = metadata.blob(row[2])
            parameters: tuple[str, ...] = ()
            if member_signature and member_signature[0] & 0xF != 6:
                parameters = _signature_types(member_signature)
            full_name = parent + "::" + name
            members[index] = {"name": full_name, "parameters": list(parameters), "parent_table": parent_table, "parent_index": parent_index}
            facts["member_refs"].append(members[index])
        methods = metadata.tables.get(6, ())
        method_names = {index: metadata.string(row[3]) for index, row in enumerate(methods, 1)}
        module_refs = {index: metadata.string(row[0]) for index, row in enumerate(metadata.tables.get(26, ()), 1)}
        for row in metadata.tables.get(28, ()):
            table, index = metadata.coded("MemberForwarded", row[1])
            record = {"name": metadata.string(row[2]), "module": module_refs.get(row[3], ""), "method": method_names.get(index, "") if table == 6 else "", "table": table, "index": index}
            facts["pinvoke"].append(record)
        module_rows = metadata.tables.get(0, ())
        if module_rows and module_rows[0][2]:
            raw_guid = metadata.heap_read("#GUID", (module_rows[0][2] - 1) * 16, 16)
            import uuid
            facts["mvid"] = str(uuid.UUID(bytes_le=raw_guid))
        from malguard_core.similarity import dotnet_structural_hash
        facts["structural_hash"] = dotnet_structural_hash(refs, types.values())
        gta_refs = [name for name in refs if name.lower().startswith(("scripthookvdotnet", "gta"))]
        if gta_refs:
            emit("NET.SHVDN", "GTA_MOD_CONTEXT", "shvdn_reference", Severity.INFO, "Metadata references GTA scripting infrastructure; this provides context only.", "فراداده به زیرساخت اسکریپت GTA ارجاع می‌دهد؛ این فقط زمینهٔ تحلیل است.", domain=EvidenceDomain.CONTEXT, attributes=(("references", ",".join(gta_refs)[:8192]),))
        protector_markers = ("confuser", "dotfuscator", "smartassembly", "eazfuscator", "reactor")
        all_names = [*types.values(), *method_names.values(), *refs]
        if any(any(marker in name.casefold() for marker in protector_markers) for name in all_names):
            emit("NET.PROTECTOR", "OBFUSCATION", "protector_metadata", Severity.HIGH, "Metadata names suggest a managed protector, which is legitimate-use opacity.", "نام‌های فراداده با محافظ دات‌نت سازگارند؛ این ابهام می‌تواند کاربرد سالم داشته باشد.")
        weird = sum(any(unicodedata.category(char) in ("Cf", "Cs", "Co", "Cn") for char in name) for name in all_names)
        if weird or len(all_names) > 20000:
            emit("NET.JUNK", "METADATA_JUNK", "unusual_metadata_names", Severity.MEDIUM, "Unusual Unicode names or unusually large metadata impair inspection.", "نام‌های غیرمعمول یونیکد یا حجم زیاد فراداده، بررسی را دشوار می‌کنند.")
        captured_resources = 0
        for row in metadata.tables.get(40, ()):
            try:
                layout.ledger.consume("resource_entries")
                relative, flags, name_index, implementation = row
                name = metadata.string(name_index)
                if implementation:
                    facts["resources"].append({"name": name, "external": True})
                    continue
                if not metadata.resource_rva or relative > metadata.resource_size - 4:
                    raise MetadataError("managed resource offset exceeds resource directory")
                length = int.from_bytes(layout.source.read(layout.rva(metadata.resource_rva + relative, 4), 4), "little")
                if length > metadata.resource_size - relative - 4:
                    raise MetadataError("managed resource exceeds resource-directory bounds")
                if length > 1024 * 1024 or captured_resources + length > 4 * 1024 * 1024:
                    raise BudgetExceeded("resource_entries", 1, 0)
                captured_resources += length
                offset = layout.rva(metadata.resource_rva + relative + 4, length)
                blob = layout.source.read(offset, length)
                resource_entropy = round(_entropy(blob), 4)
                resource = {"name": name, "offset": offset, "size": length, "entropy": resource_entropy, "data_b64": base64.b64encode(blob).decode("ascii"), "embedded_pe": False}
                facts["resources"].append(resource)
                if is_pe_candidate(blob, ledger):
                    resource["embedded_pe"] = True
                    emit("NET.EMBEDDED", "EMBEDDED_PAYLOAD", "embedded_pe", Severity.HIGH, "A managed resource contains recognized PE headers, including malformed candidates; its child requires independent analysis.", "منبع دات‌نت شامل سرآیند قابل شناسایی PE، حتی با ساختار خراب است؛ فرزند به تحلیل مستقل نیاز دارد.", offset)
                if resource_entropy >= 7.3 and length >= 1024:
                    emit("NET.RESOURCE_ENTROPY", "ENCRYPTION", "high_entropy_resource", Severity.HIGH, "A managed resource is high-entropy; its contents may be compressed or encrypted.", "آنتروپی یک منبع دات‌نت زیاد است؛ محتوا ممکن است فشرده یا رمزگذاری شده باشد.", offset)
            except BudgetExceeded as exc:
                # A resource limit does not prevent inspection of independent
                # method bodies using the remaining global work dimensions.
                facts["incomplete_resources"] = True
                state = CoverageState.SKIPPED_LIMIT
                errors.append(ErrorCode.ITERATION_BUDGET_EXHAUSTED)
                limitations.append(f"Managed resource capture: {exc}")
                break
            except (PEFormatError, UnicodeError, struct.error) as exc:
                facts["incomplete_resources"] = True
                facts["structure_status"] = "MALFORMED"
                state = CoverageState.PARTIAL
                errors.append(ErrorCode.MALFORMED_INPUT)
                limitations.append(f"Managed resource: {str(exc)[:256]}")
                emit("NET.RESOURCE_MALFORMED", "PARSER_EVASION", "unreadable_resource", Severity.MEDIUM, "A managed resource is malformed; independent method analysis and previously captured children are retained.", "یک منبع دات‌نت خراب است؛ تحلیل مستقل متدها و فرزندان قبلی حفظ می‌شود.", domain=EvidenceDomain.STRUCTURE)
        bodies: dict[int, dict] = {}

        def inspect_method(index: int, body: dict, *, closure: bool = False) -> None:
            nonlocal state
            reachable = {index}
            if closure:
                pending = list(body["local_calls"])
                while pending:
                    layout.ledger.consume("parser_iterations")
                    target = pending.pop()
                    if target in reachable or target not in bodies:
                        continue
                    if len(reachable) >= 128:
                        state = CoverageState.PARTIAL
                        limitations.append("Local method call closure exceeded 128 methods.")
                        break
                    reachable.add(target)
                    pending.extend(bodies[target]["local_calls"])
            calls = [call for target in sorted(reachable) for call in bodies[target]["calls"]]
            names = {call["name"] for call in calls}
            strings = [entry["text"] for target in sorted(reachable) for entry in bodies[target]["strings"]]
            byte_load = any(call["name"] == "System.Reflection.Assembly::Load" and call["parameters"] and call["parameters"][0] == "byte[]" for call in calls)
            reflection = any(name in names for name in ("System.Reflection.MethodBase::Invoke", "System.Reflection.MethodInfo::Invoke", "System.Reflection.ConstructorInfo::Invoke", "System.Type::InvokeMember"))
            decode = any(name in names for name in ("System.Convert::FromBase64String", "System.Security.Cryptography.CryptoStream::Read", "System.Security.Cryptography.ICryptoTransform::TransformFinalBlock", "System.Security.Cryptography.Aes::Create"))
            embedded = any(resource.get("embedded_pe") for resource in facts["resources"])
            resource_load = any(name.endswith("::GetManifestResourceStream") for name in names)
            download = any(name.endswith(("::DownloadData", "::DownloadString", "::GetByteArrayAsync", "::GetStringAsync")) for name in names)
            if byte_load and (reflection or resource_load or decode or download):
                emit("NET.MEMORY_LOADER", "LOADER_IN_MEMORY_EXECUTION", "byte_array_load_chain", Severity.CRITICAL, "A reachable method chain loads an assembly from bytes and obtains, decodes, or invokes runtime code.", "زنجیرهٔ متد قابل دسترسی، اسمبلی را از آرایهٔ بایت بارگذاری و کد زمان اجرا را دریافت، رمزگشایی یا فراخوانی می‌کند.", body["offset"], domain=EvidenceDomain.HARM, confidence=0.95, attributes=(("byte_array_load", True), ("reflection", reflection), ("resource_load", resource_load), ("embedded_pe", embedded), ("decode", decode), ("download", download)))
            elif byte_load:
                emit("NET.BYTE_LOAD", "LOADER_IN_MEMORY_EXECUTION", "byte_array_load", Severity.HIGH, "IL calls Assembly.Load(byte[]); intended payload behavior cannot be inferred.", "IL متد Assembly.Load(byte[]) را فراخوانی می‌کند؛ رفتار نهایی محموله از آن معلوم نیست.", body["offset"], domain=EvidenceDomain.HARM, confidence=0.9)
            if download and (byte_load or any(name == "System.Diagnostics.Process::Start" for name in names)):
                emit("NET.DOWNLOAD_EXEC", "REMOTE_CODE_EXECUTION", "download_execute_chain", Severity.CRITICAL, "A reachable method chain combines remote download with code loading or process launch.", "زنجیرهٔ متد قابل دسترسی، دریافت راه دور را با بارگذاری کد یا شروع فرایند ترکیب می‌کند.", body["offset"], domain=EvidenceDomain.HARM, confidence=0.85)
            if any("System.Reflection.Emit." in name for name in names):
                emit("NET.EMIT", "OBFUSCATION", "runtime_codegen", Severity.MEDIUM, "IL calls Reflection.Emit; dynamic code generation limits static coverage.", "IL از Reflection.Emit استفاده می‌کند؛ تولید کد پویا پوشش ایستا را محدود می‌کند.", body["offset"])
            if reflection and decode and not byte_load:
                emit("NET.REFLECTION_ENCRYPTED", "STRING_ENCRYPTION", "decoded_reflection", Severity.HIGH, "A reachable method chain decodes data and invokes reflection, leaving targets unresolved.", "زنجیرهٔ متد قابل دسترسی، داده را رمزگشایی و reflection را فراخوانی می‌کند؛ مقصد نامشخص می‌ماند.", body["offset"])
            credential_paths = any(any(marker in value.casefold() for marker in ("login data", "local state", "cookies", "discord", "leveldb", "steam\\config", "wallet.dat")) for value in strings)
            file_read = any(name in names for name in ("System.IO.File::ReadAllBytes", "System.IO.File::ReadAllText", "System.IO.FileStream::.ctor", "System.IO.File::OpenRead"))
            secret_decode = any(name in names for name in ("System.Security.Cryptography.ProtectedData::Unprotect", "System.Security.Cryptography.Aes::Create", "System.Data.SQLite.SQLiteCommand::ExecuteReader"))
            upload = any(name.endswith(("::UploadData", "::UploadFile", "::UploadString", "::PostAsync", "::Post", "::SendAsync")) for name in names)
            if credential_paths and file_read and secret_decode:
                emit("NET.CREDENTIAL", "CREDENTIAL_ACCESS", "credential_store_read_chain", Severity.CRITICAL, "A reachable method chain reads a credential-store path and decrypts or queries secret data.", "زنجیرهٔ متد قابل دسترسی، مسیر مخزن اعتبارنامه را می‌خواند و دادهٔ محرمانه را رمزگشایی یا پرس‌وجو می‌کند.", body["offset"], domain=EvidenceDomain.HARM, confidence=0.9)
            if credential_paths and file_read and upload:
                emit("NET.EXFILTRATION", "EXFILTRATION", "credential_upload_chain", Severity.CRITICAL, "A reachable method chain reads a credential-store path and calls a network upload API.", "زنجیرهٔ متد قابل دسترسی، مسیر مخزن اعتبارنامه را می‌خواند و API ارسال شبکه را فراخوانی می‌کند.", body["offset"], domain=EvidenceDomain.HARM, confidence=0.85)

        for index, row in enumerate(methods, 1):
            layout.ledger.consume("parser_iterations")
            rva, implementation_flags, method_flags, name_index, signature, param_start = row
            if not rva:
                continue
            if implementation_flags & 3:
                state = CoverageState.PARTIAL
                limitations.append("A managed method has a native/runtime implementation that is not IL analyzable.")
                continue
            method_offset = None
            try:
                method_offset = layout.rva(rva)
                body = _method_il(metadata, rva)
                calls = []
                local_calls = []
                for call in body["calls"]:
                    token = call["token"]
                    table, target = token >> 24, token & 0xFFFFFF
                    if table == 10 and target in members:
                        calls.append({**members[target], "offset": call["offset"]})
                    elif table == 6 and target in method_names:
                        local_calls.append(target)
                    elif table == 43 and 0 < target <= len(metadata.tables.get(43, ())):
                        coded, _ = metadata.tables[43][target - 1]
                        target_table, target_index = metadata.coded("MethodDefOrRef", coded)
                        if target_table == 10 and target_index in members:
                            calls.append({**members[target_index], "offset": call["offset"]})
                        elif target_table == 6 and target_index in method_names:
                            local_calls.append(target_index)
                        else:
                            raise MetadataError("IL call references invalid method token")
                    else:
                        raise MetadataError("IL call references invalid method token")
            except (PEFormatError, UnicodeError, struct.error) as exc:
                state = CoverageState.PARTIAL
                facts["structure_status"] = "MALFORMED"
                errors.append(ErrorCode.MALFORMED_INPUT)
                limitations.append(f"Method {index}: {str(exc)[:256]}")
                emit("NET.IL_OPAQUE", "ANTI_TAMPER", "unreadable_method", Severity.MEDIUM, "A method cannot be decoded reliably; failed decoding is not evidence of safety.", "بدنهٔ یک متد قابل رمزگشایی معتبر نیست؛ شکست تحلیل دلیل سلامت نیست.", method_offset)
                continue
            admitted = {"name": method_names[index], "calls": calls, "local_calls": local_calls, "strings": body["strings"], "offset": body["offset"], "code_size": body["code_size"]}
            bodies[index] = admitted
            facts["methods"].append({"index": index, **admitted})
            # Commit facts and direct semantic evidence before another method or
            # optional graph traversal can fail or exhaust a shared work budget.
            inspect_method(index, admitted)
            if body["indirect_calls"]:
                state = CoverageState.PARTIAL
                limitations.append("Indirect IL call targets cannot be resolved reliably by this static analyzer.")
                emit("NET.INDIRECT_CALL", "DYNAMIC_API_RESOLUTION", "unresolved_indirect_call", Severity.MEDIUM, "IL uses calli with a runtime function pointer; its target remains unresolved.", "IL با calli اشاره‌گر تابع زمان اجرا را فراخوانی می‌کند؛ مقصد نامشخص می‌ماند.", body["indirect_calls"][0])
        # Forward helper references can add corroborated evidence once their
        # independently admitted methods are available. Repeated facts are not
        # charged or emitted twice.
        for index, body in sorted(bodies.items()):
            if body["local_calls"]:
                inspect_method(index, body, closure=True)
        try:
            if recovered:
                raise MetadataError("recovered PE headers cannot be admitted to the selected managed parser")
            import dnfile
            layout.ledger.consume("parser_iterations", max(1, len(data) // 64))
            parsed = dnfile.dnPE(data=data, clr_lazy_load=False)
            if not parsed.net or not parsed.net.mdtables:
                raise MetadataError("selected parser could not load admitted CLR metadata")
            for table, rows in metadata.tables.items():
                external = parsed.net.mdtables.tables.get(table)
                if external is None or external.num_rows != len(rows):
                    raise MetadataError("selected parser table counts disagree")
            external_refs = sorted(str(row.Name) for row in getattr(getattr(parsed.net.mdtables, "AssemblyRef", None), "rows", ()))
            external_types = sorted(f"{str(row.TypeNamespace)}.{str(row.TypeName)}".strip(".") for row in getattr(getattr(parsed.net.mdtables, "TypeRef", None), "rows", ()))
            if external_refs != sorted(refs) or external_types != sorted(types.values()):
                raise MetadataError("selected parser reference identities disagree")
            parsed.close()
        except ImportError:
            state = CoverageState.UNAVAILABLE
            errors.append(ErrorCode.PARSER_UNAVAILABLE)
            limitations.append("The selected managed metadata parser is unavailable.")
        except Exception as exc:
            if isinstance(exc, BudgetExceeded):
                raise
            state = CoverageState.PARTIAL
            facts["parser_disagreement"] = True
            errors.append(ErrorCode.PARSER_DISAGREEMENT)
            limitations.append(f"Managed parser disagreement: {type(exc).__name__}: {str(exc)[:256]}")
            emit("NET.DISAGREEMENT", "PARSER_EVASION", "parser_disagreement", Severity.HIGH, "Independent CLR metadata interpretations disagree; retained evidence remains valid.", "تفسیرهای مستقل فرادادهٔ CLR اختلاف دارند؛ شواهد جمع‌آوری‌شده حفظ می‌شوند.", domain=EvidenceDomain.STRUCTURE)
    except BudgetExceeded as exc:
        state = CoverageState.SKIPPED_LIMIT
        errors.append(ErrorCode.ITERATION_BUDGET_EXHAUSTED)
        limitations.append(str(exc))
    except (PEFormatError, UnicodeError, struct.error) as exc:
        state = CoverageState.PARTIAL
        facts["structure_status"] = "MALFORMED"
        errors.append(ErrorCode.MALFORMED_INPUT)
        limitations.append(str(exc))
        try:
            emit("NET.MALFORMED", "PARSER_EVASION", "malformed_metadata", Severity.MEDIUM, "Managed metadata is malformed; raw analysis and collected evidence must be retained.", "فرادادهٔ دات‌نت خراب است؛ تحلیل خام و شواهد قبلی باید حفظ شوند.", domain=EvidenceDomain.STRUCTURE)
        except BudgetExceeded:
            state = CoverageState.SKIPPED_LIMIT
            errors.append(ErrorCode.ITERATION_BUDGET_EXHAUSTED)
    if ErrorCode.ITERATION_BUDGET_EXHAUSTED in errors and state in (CoverageState.COMPLETE, CoverageState.PARTIAL):
        state = CoverageState.SKIPPED_LIMIT
    return StageResult("S4", state=state, evidence=tuple(evidence), facts=facts, errors=tuple(dict.fromkeys(errors)), limitations=tuple(dict.fromkeys(limitations)))
