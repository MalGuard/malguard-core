# MalGuard clean-room implementation contract

The workspace was empty on 2026-10-03. There is no legacy engine or test suite to port. Python 3.12.14 is available on Linux; Windows runtime checks require Windows CI. All scanned bytes are untrusted and are never executed.

## Shared contracts

`malguard_core.scan_file(path) -> Report` delegates to `Scanner.scan_file`.
`Scanner(settings: ScanSettings | None = None, reputation: ReputationStore | None = None)` is a reusable context manager holding isolated worker pools. Root owns API, orchestration, correlation, scoring, verdict, reporting.

Foundational agent owns model, settings, budget, intake, strings, decoding. Define:

- `Verdict`: SAFE, SUSPICIOUS, MALICIOUS, INVALID, INCONCLUSIVE.
- `ArtifactStatus`: VALID, MALFORMED, UNKNOWN, BLOCKED.
- `EvidenceDomain`: HARM, OPACITY, CONTEXT, STRUCTURE, REPUTATION.
- `Severity`: INFO, LOW, MEDIUM, HIGH, CRITICAL with base weights 0/4/10/18/28.
- `CoverageState`: COMPLETE, PARTIAL, SKIPPED_LIMIT, TIMEOUT, FAILED, UNAVAILABLE, BLOCKED.
- `ErrorCode`: ITERATION_BUDGET_EXHAUSTED, WALLCLOCK_TIMEOUT, MALFORMED_INPUT, PARSER_DISAGREEMENT, PARSER_UNAVAILABLE, WORKER_FAILURE, PROTOCOL_VIOLATION, ENCRYPTED_MEMBER, UNSUPPORTED_FORMAT, IO_ERROR, INTEGRITY_FAILURE, CHANGED_DURING_SCAN.
- frozen `EvidenceLocation(artifact_id, offset=None, length=None, member=None, detail=None)`.
- frozen `Evidence` with required user fields. `attributes` is tuple of (string, primitive value) pairs. `make_evidence(rule_id, stage, domain, family, kind, severity, location, description_en, description_fa, confidence=1.0, reliability=1.0, mitigating=False, attributes=())` validates fields and constructs content-derived SHA256 ID. Evidence contains `effective_weight` property.
- `CoverageEntry(stage, state, reason='', error_code=None, applicable=True)`.
- `Hashes(sha256, sha1, md5)`.
- `StageResult(stage, state=COMPLETE, evidence=(), facts=dict, errors=(), limitations=())`. Facts contain JSON primitives only, are internal analysis facts, and never a verdict.
- `Artifact(artifact_id, logical_path, declared_type, true_type, type_confidence, file_size, hashes, structure_status, parent_artifact_id=None, archive_depth=0, evidence=(), coverage=(), child_artifact_ids=())`.
- `Report(verdict, risk_score, confidence, coverage_score, root_artifact_id, artifacts, evidence, classification_tags, limitations, residual_evidence, engine_version, ruleset_version, reputation_bundle_version, schema_version)` with root-derived hashes/type properties or root accessor and `to_json()`/`to_text()` delegation.

`BudgetLedger(limits: Mapping[str,int])`: consume(resource, amount=1), remaining(resource), snapshot(), usage(); `BudgetExceeded` includes resource and error_code ITERATION_BUDGET_EXHAUSTED. No child reset. Resources: file_bytes, read_bytes, archive_entries, decompressed_bytes, parser_iterations, metadata_rows, resource_entries, decoded_candidates, strings, children, evidence, yara_bytes.

`BoundedByteSource(data: bytes, ledger, per_read_limit)` with `.size`, read/read_head/read_tail/iter_chunks. Intake is the only code reading root filesystem (regular file, avoid symlink where possible, snapshot stability); it boundedly captures bytes into source. Analyzers accept bytes only when coordinator has read them via this abstraction.

`ScanSettings` default bounded limits plus max_file_size (64MiB), max_depth (4), per_read_limit (1MiB), worker_timeout (15s), worker_memory_mb (512), worker_cpu_seconds (10), worker_recycle_count (32), worker_recycle_bytes (128MiB), decode_max_depth (2), max_string_length (4096), min_string_length (4), enable_yara=True, isolate_parsers=True. Cannot disable required safety gating by turning parsers off.

Strings module exposes `extract_strings(source, ledger, max_length=4096, min_length=4) -> tuple[ExtractedString,...]`; object fields text, offset, encoding, decoded=False. Decoding exposes `decode_strings(strings, ledger, max_depth=2) -> tuple[ExtractedString,...]`. Intake exposes `identify(data: bytes, extension: str) -> dict` with true_type, type_confidence, structure_status (enum/value), is_pe, is_dotnet, is_archive, is_script; `analyze_filename(logical_path, artifact_id) -> tuple[Evidence,...]`. Root can adapt actual finalized exports; agents notify changes.

## Analyzer interfaces

To avoid shared mutable contexts, modules export byte-oriented pure static functions:

`pe.analyze(data: bytes, artifact_id: str, logical_path: str, ledger: BudgetLedger) -> StageResult`
`dotnet.analyze(data: bytes, artifact_id: str, logical_path: str, ledger: BudgetLedger, pe_facts: dict | None = None) -> StageResult`
`native.analyze(data: bytes, artifact_id: str, logical_path: str, ledger: BudgetLedger, strings: tuple, pe_facts: dict | None = None) -> StageResult`
`scripts.analyze(data: bytes, artifact_id: str, logical_path: str, ledger: BudgetLedger, strings: tuple=()) -> StageResult`
`archives.analyze(data: bytes, artifact_id: str, logical_path: str, ledger: BudgetLedger, depth: int=0, max_depth: int=4) -> StageResult`

Archive StageResult facts contains `children`: list of `{logical_path: str, data_b64: str, encrypted: bool, readable: bool, reason: str}`; all paths are logical labels only, never extraction paths. Facts `incomplete_children: bool`. Parent bounds output and charges shared budgets. Children follow the full normal pipeline.

PE facts: architecture, is_dll, imports (normalized strings), exports, forwarded_exports, sections (bounded dict records), is_dotnet, clr_rva, clr_size, resources (bounded data_b64 records), imphash. Failed structure retains evidence. Native must fall back to raw strings/APIs even when imports unavailable.

## Worker ownership and isolation

Workers agent owns workers/ with `WorkerPool(settings).run(stage: str, data: bytes, artifact_id: str, logical_path: str, ledger: BudgetLedger, extra: dict | None=None) -> StageResult` and close/context manager. Stages pe, dotnet, archives, yara. Fixed trusted dispatch, length-prefixed JSON (no pickle); validate strict schema/request/stage/length/facts/evidence at parent. No worker returns a verdict. Share remaining budgets with child and charge validated usage back sequentially, pessimistically consume issued work quotas on timeout/protocol failure. Windows suspended launch / admission handshake with Job Object memory, CPU, kill on close, no breakaway; Linux RLIMIT fallback for runtime testing. Recycle after faults/count/bytes. Wallclock timeout distinct from work limit. Scanned bytes never passed as shell commands or paths to executable invocation.

Rules/integrity agent owns integrity/, reputation/, rules/ and signed data tooling. Rules exported `analyze(data, artifact_id, logical_path, ledger, rules_source=None) -> StageResult` and compiler/last-good manager. Builtin rules are trusted packaged engine code; externally supplied updates require signature verification and epoch acceptance before compilation, atomic install only after success. Reputation exact blocklist precedes every deep parser, allowlist cannot cancel harmful evidence. Default security data empty; no invented IOCs/hashes. Trust anchor never taken from scanned input/settings. Signing development fixtures use temporary keys and test-specific trust.

## Scoring and safe gating

Root implements specified family saturation and top-three HARM/top-two OPACITY risk, no cross-artifact fabrication of HARM combinations. MALICIOUS requires two independent decisive HARM families per artifact or exact trusted blocklist. Parent inherits strongest child verdict/evidence. GTA text alone never establishes exclusive GTA target; structured or code relation required. Opacity never MALICIOUS. Partial/unsupported analyzability blocks SAFE. Every analysis failure retains already collected evidence and raw analysis precedes deep parsing.

Synthetic fixture builders only; independent benign look-alikes, mutation and malformed regression. Every executed verification goes into WORK_LOG.md. Corpus acceptance targets remain unmeasured until user-provided evaluation.
