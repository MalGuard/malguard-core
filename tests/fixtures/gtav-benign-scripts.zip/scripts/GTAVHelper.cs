using GTA; public class GTAVHelper : Script { public void Tick(){ var p = Game.Player.Character.Position; } }
