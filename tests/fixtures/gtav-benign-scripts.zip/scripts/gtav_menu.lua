local enabled = true
if enabled then print("GTA V menu") end
